import { ApiObject, ApiObjectMetadata, GroupVersionKind } from 'cdk8s';
import { Construct } from 'constructs';
/**
 * ACRAccessToken returns an Azure Container Registry token
that can be used for pushing/pulling images.
Note: by default it will return an ACR Refresh Token with full access
(depending on the identity).
This can be scoped down to the repository level using .spec.scope.
In case scope is defined it will return an ACR Access Token.

See docs: https://github.com/Azure/acr/blob/main/docs/AAD-OAuth.md
 *
 * @schema ACRAccessToken
 */
export declare class AcrAccessToken extends ApiObject {
    /**
     * Returns the apiVersion and kind for "ACRAccessToken"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "ACRAccessToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: AcrAccessTokenProps): any;
    /**
     * Defines a "ACRAccessToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: AcrAccessTokenProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * ACRAccessToken returns an Azure Container Registry token
 * that can be used for pushing/pulling images.
 * Note: by default it will return an ACR Refresh Token with full access
 * (depending on the identity).
 * This can be scoped down to the repository level using .spec.scope.
 * In case scope is defined it will return an ACR Access Token.
 *
 * See docs: https://github.com/Azure/acr/blob/main/docs/AAD-OAuth.md
 *
 * @schema ACRAccessToken
 */
export interface AcrAccessTokenProps {
    /**
     * @schema ACRAccessToken#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * ACRAccessTokenSpec defines how to generate the access token
     * e.g. how to authenticate and which registry to use.
     * see: https://github.com/Azure/acr/blob/main/docs/AAD-OAuth.md#overview
     *
     * @schema ACRAccessToken#spec
     */
    readonly spec?: AcrAccessTokenSpec;
}
/**
 * Converts an object of type 'AcrAccessTokenProps' to JSON representation.
 */
export declare function toJson_AcrAccessTokenProps(obj: AcrAccessTokenProps | undefined): Record<string, any> | undefined;
/**
 * ACRAccessTokenSpec defines how to generate the access token
 * e.g. how to authenticate and which registry to use.
 * see: https://github.com/Azure/acr/blob/main/docs/AAD-OAuth.md#overview
 *
 * @schema AcrAccessTokenSpec
 */
export interface AcrAccessTokenSpec {
    /**
     * ACRAuth defines the authentication methods for Azure Container Registry.
     *
     * @schema AcrAccessTokenSpec#auth
     */
    readonly auth: AcrAccessTokenSpecAuth;
    /**
     * EnvironmentType specifies the Azure cloud environment endpoints to use for
     * connecting and authenticating with Azure. By default, it points to the public cloud AAD endpoint.
     * The following endpoints are available, also see here: https://github.com/Azure/go-autorest/blob/main/autorest/azure/environments.go#L152
     * PublicCloud, USGovernmentCloud, ChinaCloud, GermanCloud
     *
     * @schema AcrAccessTokenSpec#environmentType
     */
    readonly environmentType?: AcrAccessTokenSpecEnvironmentType;
    /**
     * the domain name of the ACR registry
     * e.g. foobarexample.azurecr.io
     *
     * @schema AcrAccessTokenSpec#registry
     */
    readonly registry: string;
    /**
     * Define the scope for the access token, e.g. pull/push access for a repository.
     * if not provided it will return a refresh token that has full scope.
     * Note: you need to pin it down to the repository level, there is no wildcard available.
     *
     * examples:
     * repository:my-repository:pull,push
     * repository:my-repository:pull
     *
     * see docs for details: https://docs.docker.com/registry/spec/auth/scope/
     *
     * @schema AcrAccessTokenSpec#scope
     */
    readonly scope?: string;
    /**
     * TenantID configures the Azure Tenant to send requests to. Required for ServicePrincipal auth type.
     *
     * @schema AcrAccessTokenSpec#tenantId
     */
    readonly tenantId?: string;
}
/**
 * Converts an object of type 'AcrAccessTokenSpec' to JSON representation.
 */
export declare function toJson_AcrAccessTokenSpec(obj: AcrAccessTokenSpec | undefined): Record<string, any> | undefined;
/**
 * ACRAuth defines the authentication methods for Azure Container Registry.
 *
 * @schema AcrAccessTokenSpecAuth
 */
export interface AcrAccessTokenSpecAuth {
    /**
     * ManagedIdentity uses Azure Managed Identity to authenticate with Azure.
     *
     * @schema AcrAccessTokenSpecAuth#managedIdentity
     */
    readonly managedIdentity?: AcrAccessTokenSpecAuthManagedIdentity;
    /**
     * ServicePrincipal uses Azure Service Principal credentials to authenticate with Azure.
     *
     * @schema AcrAccessTokenSpecAuth#servicePrincipal
     */
    readonly servicePrincipal?: AcrAccessTokenSpecAuthServicePrincipal;
    /**
     * WorkloadIdentity uses Azure Workload Identity to authenticate with Azure.
     *
     * @schema AcrAccessTokenSpecAuth#workloadIdentity
     */
    readonly workloadIdentity?: AcrAccessTokenSpecAuthWorkloadIdentity;
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuth' to JSON representation.
 */
export declare function toJson_AcrAccessTokenSpecAuth(obj: AcrAccessTokenSpecAuth | undefined): Record<string, any> | undefined;
/**
 * EnvironmentType specifies the Azure cloud environment endpoints to use for
 * connecting and authenticating with Azure. By default, it points to the public cloud AAD endpoint.
 * The following endpoints are available, also see here: https://github.com/Azure/go-autorest/blob/main/autorest/azure/environments.go#L152
 * PublicCloud, USGovernmentCloud, ChinaCloud, GermanCloud
 *
 * @schema AcrAccessTokenSpecEnvironmentType
 */
export declare enum AcrAccessTokenSpecEnvironmentType {
    /** PublicCloud */
    PUBLIC_CLOUD = "PublicCloud",
    /** USGovernmentCloud */
    US_GOVERNMENT_CLOUD = "USGovernmentCloud",
    /** ChinaCloud */
    CHINA_CLOUD = "ChinaCloud",
    /** GermanCloud */
    GERMAN_CLOUD = "GermanCloud",
    /** AzureStackCloud */
    AZURE_STACK_CLOUD = "AzureStackCloud"
}
/**
 * ManagedIdentity uses Azure Managed Identity to authenticate with Azure.
 *
 * @schema AcrAccessTokenSpecAuthManagedIdentity
 */
export interface AcrAccessTokenSpecAuthManagedIdentity {
    /**
     * If multiple Managed Identity is assigned to the pod, you can select the one to be used
     *
     * @schema AcrAccessTokenSpecAuthManagedIdentity#identityId
     */
    readonly identityId?: string;
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthManagedIdentity' to JSON representation.
 */
export declare function toJson_AcrAccessTokenSpecAuthManagedIdentity(obj: AcrAccessTokenSpecAuthManagedIdentity | undefined): Record<string, any> | undefined;
/**
 * ServicePrincipal uses Azure Service Principal credentials to authenticate with Azure.
 *
 * @schema AcrAccessTokenSpecAuthServicePrincipal
 */
export interface AcrAccessTokenSpecAuthServicePrincipal {
    /**
     * AzureACRServicePrincipalAuthSecretRef defines the secret references for Azure Service Principal authentication.
     * It uses static credentials stored in a Kind=Secret.
     *
     * @schema AcrAccessTokenSpecAuthServicePrincipal#secretRef
     */
    readonly secretRef: AcrAccessTokenSpecAuthServicePrincipalSecretRef;
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthServicePrincipal' to JSON representation.
 */
export declare function toJson_AcrAccessTokenSpecAuthServicePrincipal(obj: AcrAccessTokenSpecAuthServicePrincipal | undefined): Record<string, any> | undefined;
/**
 * WorkloadIdentity uses Azure Workload Identity to authenticate with Azure.
 *
 * @schema AcrAccessTokenSpecAuthWorkloadIdentity
 */
export interface AcrAccessTokenSpecAuthWorkloadIdentity {
    /**
     * ServiceAccountRef specified the service account
     * that should be used when authenticating with WorkloadIdentity.
     *
     * @schema AcrAccessTokenSpecAuthWorkloadIdentity#serviceAccountRef
     */
    readonly serviceAccountRef?: AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef;
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthWorkloadIdentity' to JSON representation.
 */
export declare function toJson_AcrAccessTokenSpecAuthWorkloadIdentity(obj: AcrAccessTokenSpecAuthWorkloadIdentity | undefined): Record<string, any> | undefined;
/**
 * AzureACRServicePrincipalAuthSecretRef defines the secret references for Azure Service Principal authentication.
 * It uses static credentials stored in a Kind=Secret.
 *
 * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRef
 */
export interface AcrAccessTokenSpecAuthServicePrincipalSecretRef {
    /**
     * The Azure clientId of the service principle used for authentication.
     *
     * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRef#clientId
     */
    readonly clientId?: AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId;
    /**
     * The Azure ClientSecret of the service principle used for authentication.
     *
     * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRef#clientSecret
     */
    readonly clientSecret?: AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret;
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthServicePrincipalSecretRef' to JSON representation.
 */
export declare function toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRef(obj: AcrAccessTokenSpecAuthServicePrincipalSecretRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountRef specified the service account
 * that should be used when authenticating with WorkloadIdentity.
 *
 * @schema AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef
 */
export interface AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef' to JSON representation.
 */
export declare function toJson_AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj: AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * The Azure clientId of the service principle used for authentication.
 *
 * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId
 */
export interface AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId' to JSON representation.
 */
export declare function toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId(obj: AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId | undefined): Record<string, any> | undefined;
/**
 * The Azure ClientSecret of the service principle used for authentication.
 *
 * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret
 */
export interface AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret' to JSON representation.
 */
export declare function toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret(obj: AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret | undefined): Record<string, any> | undefined;
/**
 * CloudsmithAccessToken generates Cloudsmith access token using OIDC authentication
 *
 * @schema CloudsmithAccessToken
 */
export declare class CloudsmithAccessToken extends ApiObject {
    /**
     * Returns the apiVersion and kind for "CloudsmithAccessToken"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "CloudsmithAccessToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: CloudsmithAccessTokenProps): any;
    /**
     * Defines a "CloudsmithAccessToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: CloudsmithAccessTokenProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * CloudsmithAccessToken generates Cloudsmith access token using OIDC authentication
 *
 * @schema CloudsmithAccessToken
 */
export interface CloudsmithAccessTokenProps {
    /**
     * @schema CloudsmithAccessToken#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * CloudsmithAccessTokenSpec defines the configuration for generating a Cloudsmith access token using OIDC authentication.
     *
     * @schema CloudsmithAccessToken#spec
     */
    readonly spec?: CloudsmithAccessTokenSpec;
}
/**
 * Converts an object of type 'CloudsmithAccessTokenProps' to JSON representation.
 */
export declare function toJson_CloudsmithAccessTokenProps(obj: CloudsmithAccessTokenProps | undefined): Record<string, any> | undefined;
/**
 * CloudsmithAccessTokenSpec defines the configuration for generating a Cloudsmith access token using OIDC authentication.
 *
 * @schema CloudsmithAccessTokenSpec
 */
export interface CloudsmithAccessTokenSpec {
    /**
     * APIURL configures the Cloudsmith API URL. Defaults to https://api.cloudsmith.io.
     *
     * @default https://api.cloudsmith.io.
     * @schema CloudsmithAccessTokenSpec#apiUrl
     */
    readonly apiUrl?: string;
    /**
     * OrgSlug is the organization slug in Cloudsmith
     *
     * @schema CloudsmithAccessTokenSpec#orgSlug
     */
    readonly orgSlug: string;
    /**
     * Name of the service account you are federating with
     *
     * @schema CloudsmithAccessTokenSpec#serviceAccountRef
     */
    readonly serviceAccountRef: CloudsmithAccessTokenSpecServiceAccountRef;
    /**
     * ServiceSlug is the service slug in Cloudsmith for OIDC authentication
     *
     * @schema CloudsmithAccessTokenSpec#serviceSlug
     */
    readonly serviceSlug: string;
}
/**
 * Converts an object of type 'CloudsmithAccessTokenSpec' to JSON representation.
 */
export declare function toJson_CloudsmithAccessTokenSpec(obj: CloudsmithAccessTokenSpec | undefined): Record<string, any> | undefined;
/**
 * Name of the service account you are federating with
 *
 * @schema CloudsmithAccessTokenSpecServiceAccountRef
 */
export interface CloudsmithAccessTokenSpecServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema CloudsmithAccessTokenSpecServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema CloudsmithAccessTokenSpecServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema CloudsmithAccessTokenSpecServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'CloudsmithAccessTokenSpecServiceAccountRef' to JSON representation.
 */
export declare function toJson_CloudsmithAccessTokenSpecServiceAccountRef(obj: CloudsmithAccessTokenSpecServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * ClusterGenerator represents a cluster-wide generator which can be referenced as part of `generatorRef` fields.
 *
 * @schema ClusterGenerator
 */
export declare class ClusterGenerator extends ApiObject {
    /**
     * Returns the apiVersion and kind for "ClusterGenerator"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "ClusterGenerator".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: ClusterGeneratorProps): any;
    /**
     * Defines a "ClusterGenerator" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: ClusterGeneratorProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * ClusterGenerator represents a cluster-wide generator which can be referenced as part of `generatorRef` fields.
 *
 * @schema ClusterGenerator
 */
export interface ClusterGeneratorProps {
    /**
     * @schema ClusterGenerator#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * ClusterGeneratorSpec defines the desired state of a ClusterGenerator.
     *
     * @schema ClusterGenerator#spec
     */
    readonly spec?: ClusterGeneratorSpec;
}
/**
 * Converts an object of type 'ClusterGeneratorProps' to JSON representation.
 */
export declare function toJson_ClusterGeneratorProps(obj: ClusterGeneratorProps | undefined): Record<string, any> | undefined;
/**
 * ClusterGeneratorSpec defines the desired state of a ClusterGenerator.
 *
 * @schema ClusterGeneratorSpec
 */
export interface ClusterGeneratorSpec {
    /**
     * Generator the spec for this generator, must match the kind.
     *
     * @schema ClusterGeneratorSpec#generator
     */
    readonly generator: ClusterGeneratorSpecGenerator;
    /**
     * Kind the kind of this generator.
     *
     * @schema ClusterGeneratorSpec#kind
     */
    readonly kind: ClusterGeneratorSpecKind;
}
/**
 * Converts an object of type 'ClusterGeneratorSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpec(obj: ClusterGeneratorSpec | undefined): Record<string, any> | undefined;
/**
 * Generator the spec for this generator, must match the kind.
 *
 * @schema ClusterGeneratorSpecGenerator
 */
export interface ClusterGeneratorSpecGenerator {
    /**
     * ACRAccessTokenSpec defines how to generate the access token
     * e.g. how to authenticate and which registry to use.
     * see: https://github.com/Azure/acr/blob/main/docs/AAD-OAuth.md#overview
     *
     * @schema ClusterGeneratorSpecGenerator#acrAccessTokenSpec
     */
    readonly acrAccessTokenSpec?: ClusterGeneratorSpecGeneratorAcrAccessTokenSpec;
    /**
     * CloudsmithAccessTokenSpec defines the configuration for generating a Cloudsmith access token using OIDC authentication.
     *
     * @schema ClusterGeneratorSpecGenerator#cloudsmithAccessTokenSpec
     */
    readonly cloudsmithAccessTokenSpec?: ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpec;
    /**
     * ECRAuthorizationTokenSpec defines the desired state to generate an AWS ECR authorization token.
     *
     * @schema ClusterGeneratorSpecGenerator#ecrAuthorizationTokenSpec
     */
    readonly ecrAuthorizationTokenSpec?: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec;
    /**
     * FakeSpec contains the static data.
     *
     * @schema ClusterGeneratorSpecGenerator#fakeSpec
     */
    readonly fakeSpec?: ClusterGeneratorSpecGeneratorFakeSpec;
    /**
     * GCRAccessTokenSpec defines the desired state to generate a Google Container Registry access token.
     *
     * @schema ClusterGeneratorSpecGenerator#gcrAccessTokenSpec
     */
    readonly gcrAccessTokenSpec?: ClusterGeneratorSpecGeneratorGcrAccessTokenSpec;
    /**
     * GithubAccessTokenSpec defines the desired state to generate a GitHub access token.
     *
     * @schema ClusterGeneratorSpecGenerator#githubAccessTokenSpec
     */
    readonly githubAccessTokenSpec?: ClusterGeneratorSpecGeneratorGithubAccessTokenSpec;
    /**
     * GrafanaSpec controls the behavior of the grafana generator.
     *
     * @schema ClusterGeneratorSpecGenerator#grafanaSpec
     */
    readonly grafanaSpec?: ClusterGeneratorSpecGeneratorGrafanaSpec;
    /**
     * MFASpec controls the behavior of the mfa generator.
     *
     * @schema ClusterGeneratorSpecGenerator#mfaSpec
     */
    readonly mfaSpec?: ClusterGeneratorSpecGeneratorMfaSpec;
    /**
     * PasswordSpec controls the behavior of the password generator.
     *
     * @schema ClusterGeneratorSpecGenerator#passwordSpec
     */
    readonly passwordSpec?: ClusterGeneratorSpecGeneratorPasswordSpec;
    /**
     * QuayAccessTokenSpec defines the desired state to generate a Quay access token.
     *
     * @schema ClusterGeneratorSpecGenerator#quayAccessTokenSpec
     */
    readonly quayAccessTokenSpec?: ClusterGeneratorSpecGeneratorQuayAccessTokenSpec;
    /**
     * SSHKeySpec controls the behavior of the ssh key generator.
     *
     * @schema ClusterGeneratorSpecGenerator#sshKeySpec
     */
    readonly sshKeySpec?: ClusterGeneratorSpecGeneratorSshKeySpec;
    /**
     * STSSessionTokenSpec defines the desired state to generate an AWS STS session token.
     *
     * @schema ClusterGeneratorSpecGenerator#stsSessionTokenSpec
     */
    readonly stsSessionTokenSpec?: ClusterGeneratorSpecGeneratorStsSessionTokenSpec;
    /**
     * UUIDSpec controls the behavior of the uuid generator.
     *
     * @schema ClusterGeneratorSpecGenerator#uuidSpec
     */
    readonly uuidSpec?: any;
    /**
     * VaultDynamicSecretSpec defines the desired spec of VaultDynamicSecret.
     *
     * @schema ClusterGeneratorSpecGenerator#vaultDynamicSecretSpec
     */
    readonly vaultDynamicSecretSpec?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec;
    /**
     * WebhookSpec controls the behavior of the external generator. Any body parameters should be passed to the server through the parameters field.
     *
     * @schema ClusterGeneratorSpecGenerator#webhookSpec
     */
    readonly webhookSpec?: ClusterGeneratorSpecGeneratorWebhookSpec;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGenerator' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGenerator(obj: ClusterGeneratorSpecGenerator | undefined): Record<string, any> | undefined;
/**
 * Kind the kind of this generator.
 *
 * @schema ClusterGeneratorSpecKind
 */
export declare enum ClusterGeneratorSpecKind {
    /** ACRAccessToken */
    ACR_ACCESS_TOKEN = "ACRAccessToken",
    /** CloudsmithAccessToken */
    CLOUDSMITH_ACCESS_TOKEN = "CloudsmithAccessToken",
    /** ECRAuthorizationToken */
    ECR_AUTHORIZATION_TOKEN = "ECRAuthorizationToken",
    /** Fake */
    FAKE = "Fake",
    /** GCRAccessToken */
    GCR_ACCESS_TOKEN = "GCRAccessToken",
    /** GithubAccessToken */
    GITHUB_ACCESS_TOKEN = "GithubAccessToken",
    /** QuayAccessToken */
    QUAY_ACCESS_TOKEN = "QuayAccessToken",
    /** Password */
    PASSWORD = "Password",
    /** SSHKey */
    SSH_KEY = "SSHKey",
    /** STSSessionToken */
    STS_SESSION_TOKEN = "STSSessionToken",
    /** UUID */
    UUID = "UUID",
    /** VaultDynamicSecret */
    VAULT_DYNAMIC_SECRET = "VaultDynamicSecret",
    /** Webhook */
    WEBHOOK = "Webhook",
    /** Grafana */
    GRAFANA = "Grafana"
}
/**
 * ACRAccessTokenSpec defines how to generate the access token
 * e.g. how to authenticate and which registry to use.
 * see: https://github.com/Azure/acr/blob/main/docs/AAD-OAuth.md#overview
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpec
 */
export interface ClusterGeneratorSpecGeneratorAcrAccessTokenSpec {
    /**
     * ACRAuth defines the authentication methods for Azure Container Registry.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpec#auth
     */
    readonly auth: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth;
    /**
     * EnvironmentType specifies the Azure cloud environment endpoints to use for
     * connecting and authenticating with Azure. By default, it points to the public cloud AAD endpoint.
     * The following endpoints are available, also see here: https://github.com/Azure/go-autorest/blob/main/autorest/azure/environments.go#L152
     * PublicCloud, USGovernmentCloud, ChinaCloud, GermanCloud
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpec#environmentType
     */
    readonly environmentType?: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType;
    /**
     * the domain name of the ACR registry
     * e.g. foobarexample.azurecr.io
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpec#registry
     */
    readonly registry: string;
    /**
     * Define the scope for the access token, e.g. pull/push access for a repository.
     * if not provided it will return a refresh token that has full scope.
     * Note: you need to pin it down to the repository level, there is no wildcard available.
     *
     * examples:
     * repository:my-repository:pull,push
     * repository:my-repository:pull
     *
     * see docs for details: https://docs.docker.com/registry/spec/auth/scope/
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpec#scope
     */
    readonly scope?: string;
    /**
     * TenantID configures the Azure Tenant to send requests to. Required for ServicePrincipal auth type.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpec#tenantId
     */
    readonly tenantId?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpec(obj: ClusterGeneratorSpecGeneratorAcrAccessTokenSpec | undefined): Record<string, any> | undefined;
/**
 * CloudsmithAccessTokenSpec defines the configuration for generating a Cloudsmith access token using OIDC authentication.
 *
 * @schema ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpec
 */
export interface ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpec {
    /**
     * APIURL configures the Cloudsmith API URL. Defaults to https://api.cloudsmith.io.
     *
     * @default https://api.cloudsmith.io.
     * @schema ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpec#apiUrl
     */
    readonly apiUrl?: string;
    /**
     * OrgSlug is the organization slug in Cloudsmith
     *
     * @schema ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpec#orgSlug
     */
    readonly orgSlug: string;
    /**
     * Name of the service account you are federating with
     *
     * @schema ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpec#serviceAccountRef
     */
    readonly serviceAccountRef: ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpecServiceAccountRef;
    /**
     * ServiceSlug is the service slug in Cloudsmith for OIDC authentication
     *
     * @schema ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpec#serviceSlug
     */
    readonly serviceSlug: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpec(obj: ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpec | undefined): Record<string, any> | undefined;
/**
 * ECRAuthorizationTokenSpec defines the desired state to generate an AWS ECR authorization token.
 *
 * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec
 */
export interface ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec {
    /**
     * Auth defines how to authenticate with AWS
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec#auth
     */
    readonly auth?: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth;
    /**
     * Region specifies the region to operate in.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec#region
     */
    readonly region: string;
    /**
     * You can assume a role before making calls to the
     * desired AWS service.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec#role
     */
    readonly role?: string;
    /**
     * Scope specifies the ECR service scope.
     * Valid options are private and public.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec#scope
     */
    readonly scope?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec(obj: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec | undefined): Record<string, any> | undefined;
/**
 * FakeSpec contains the static data.
 *
 * @schema ClusterGeneratorSpecGeneratorFakeSpec
 */
export interface ClusterGeneratorSpecGeneratorFakeSpec {
    /**
     * Used to select the correct ESO controller (think: ingress.ingressClassName)
     * The ESO controller is instantiated with a specific controller name and filters VDS based on this property
     *
     * @schema ClusterGeneratorSpecGeneratorFakeSpec#controller
     */
    readonly controller?: string;
    /**
     * Data defines the static data returned
     * by this generator.
     *
     * @schema ClusterGeneratorSpecGeneratorFakeSpec#data
     */
    readonly data?: {
        [key: string]: string;
    };
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorFakeSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorFakeSpec(obj: ClusterGeneratorSpecGeneratorFakeSpec | undefined): Record<string, any> | undefined;
/**
 * GCRAccessTokenSpec defines the desired state to generate a Google Container Registry access token.
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpec
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpec {
    /**
     * Auth defines the means for authenticating with GCP
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpec#auth
     */
    readonly auth: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth;
    /**
     * ProjectID defines which project to use to authenticate with
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpec#projectID
     */
    readonly projectId: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpec(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpec | undefined): Record<string, any> | undefined;
/**
 * GithubAccessTokenSpec defines the desired state to generate a GitHub access token.
 *
 * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpec
 */
export interface ClusterGeneratorSpecGeneratorGithubAccessTokenSpec {
    /**
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpec#appID
     */
    readonly appId: string;
    /**
     * Auth configures how ESO authenticates with a Github instance.
     *
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpec#auth
     */
    readonly auth: ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth;
    /**
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpec#installID
     */
    readonly installId: string;
    /**
     * Map of permissions the token will have. If omitted, defaults to all permissions the GitHub App has.
     *
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpec#permissions
     */
    readonly permissions?: {
        [key: string]: string;
    };
    /**
     * List of repositories the token will have access to. If omitted, defaults to all repositories the GitHub App
     * is installed to.
     *
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpec#repositories
     */
    readonly repositories?: string[];
    /**
     * URL configures the GitHub instance URL. Defaults to https://github.com/.
     *
     * @default https://github.com/.
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpec#url
     */
    readonly url?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGithubAccessTokenSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpec(obj: ClusterGeneratorSpecGeneratorGithubAccessTokenSpec | undefined): Record<string, any> | undefined;
/**
 * GrafanaSpec controls the behavior of the grafana generator.
 *
 * @schema ClusterGeneratorSpecGeneratorGrafanaSpec
 */
export interface ClusterGeneratorSpecGeneratorGrafanaSpec {
    /**
     * Auth is the authentication configuration to authenticate
     * against the Grafana instance.
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpec#auth
     */
    readonly auth: ClusterGeneratorSpecGeneratorGrafanaSpecAuth;
    /**
     * ServiceAccount is the configuration for the service account that
     * is supposed to be generated by the generator.
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpec#serviceAccount
     */
    readonly serviceAccount: ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount;
    /**
     * URL is the URL of the Grafana instance.
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpec#url
     */
    readonly url: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGrafanaSpec(obj: ClusterGeneratorSpecGeneratorGrafanaSpec | undefined): Record<string, any> | undefined;
/**
 * MFASpec controls the behavior of the mfa generator.
 *
 * @schema ClusterGeneratorSpecGeneratorMfaSpec
 */
export interface ClusterGeneratorSpecGeneratorMfaSpec {
    /**
     * Algorithm to use for encoding. Defaults to SHA1 as per the RFC.
     *
     * @default SHA1 as per the RFC.
     * @schema ClusterGeneratorSpecGeneratorMfaSpec#algorithm
     */
    readonly algorithm?: string;
    /**
     * Length defines the token length. Defaults to 6 characters.
     *
     * @default 6 characters.
     * @schema ClusterGeneratorSpecGeneratorMfaSpec#length
     */
    readonly length?: number;
    /**
     * Secret is a secret selector to a secret containing the seed secret to generate the TOTP value from.
     *
     * @schema ClusterGeneratorSpecGeneratorMfaSpec#secret
     */
    readonly secret: ClusterGeneratorSpecGeneratorMfaSpecSecret;
    /**
     * TimePeriod defines how long the token can be active. Defaults to 30 seconds.
     *
     * @default 30 seconds.
     * @schema ClusterGeneratorSpecGeneratorMfaSpec#timePeriod
     */
    readonly timePeriod?: number;
    /**
     * When defines a time parameter that can be used to pin the origin time of the generated token.
     *
     * @schema ClusterGeneratorSpecGeneratorMfaSpec#when
     */
    readonly when?: Date;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorMfaSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorMfaSpec(obj: ClusterGeneratorSpecGeneratorMfaSpec | undefined): Record<string, any> | undefined;
/**
 * PasswordSpec controls the behavior of the password generator.
 *
 * @schema ClusterGeneratorSpecGeneratorPasswordSpec
 */
export interface ClusterGeneratorSpecGeneratorPasswordSpec {
    /**
     * set AllowRepeat to true to allow repeating characters.
     *
     * @schema ClusterGeneratorSpecGeneratorPasswordSpec#allowRepeat
     */
    readonly allowRepeat: boolean;
    /**
     * Digits specifies the number of digits in the generated
     * password. If omitted it defaults to 25% of the length of the password
     *
     * @schema ClusterGeneratorSpecGeneratorPasswordSpec#digits
     */
    readonly digits?: number;
    /**
     * Encoding specifies the encoding of the generated password.
     * Valid values are:
     * - "raw" (default): no encoding
     * - "base64": standard base64 encoding
     * - "base64url": base64url encoding
     * - "base32": base32 encoding
     * - "hex": hexadecimal encoding
     *
     * @schema ClusterGeneratorSpecGeneratorPasswordSpec#encoding
     */
    readonly encoding?: ClusterGeneratorSpecGeneratorPasswordSpecEncoding;
    /**
     * Length of the password to be generated.
     * Defaults to 24
     *
     * @default 24
     * @schema ClusterGeneratorSpecGeneratorPasswordSpec#length
     */
    readonly length: number;
    /**
     * Set NoUpper to disable uppercase characters
     *
     * @schema ClusterGeneratorSpecGeneratorPasswordSpec#noUpper
     */
    readonly noUpper: boolean;
    /**
     * SecretKeys defines the keys that will be populated with generated passwords.
     * Defaults to "password" when not set.
     *
     * @default password" when not set.
     * @schema ClusterGeneratorSpecGeneratorPasswordSpec#secretKeys
     */
    readonly secretKeys?: string[];
    /**
     * SymbolCharacters specifies the special characters that should be used
     * in the generated password.
     *
     * @schema ClusterGeneratorSpecGeneratorPasswordSpec#symbolCharacters
     */
    readonly symbolCharacters?: string;
    /**
     * Symbols specifies the number of symbol characters in the generated
     * password. If omitted it defaults to 25% of the length of the password
     *
     * @schema ClusterGeneratorSpecGeneratorPasswordSpec#symbols
     */
    readonly symbols?: number;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorPasswordSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorPasswordSpec(obj: ClusterGeneratorSpecGeneratorPasswordSpec | undefined): Record<string, any> | undefined;
/**
 * QuayAccessTokenSpec defines the desired state to generate a Quay access token.
 *
 * @schema ClusterGeneratorSpecGeneratorQuayAccessTokenSpec
 */
export interface ClusterGeneratorSpecGeneratorQuayAccessTokenSpec {
    /**
     * Name of the robot account you are federating with
     *
     * @schema ClusterGeneratorSpecGeneratorQuayAccessTokenSpec#robotAccount
     */
    readonly robotAccount: string;
    /**
     * Name of the service account you are federating with
     *
     * @schema ClusterGeneratorSpecGeneratorQuayAccessTokenSpec#serviceAccountRef
     */
    readonly serviceAccountRef: ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef;
    /**
     * URL configures the Quay instance URL. Defaults to quay.io.
     *
     * @default quay.io.
     * @schema ClusterGeneratorSpecGeneratorQuayAccessTokenSpec#url
     */
    readonly url?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorQuayAccessTokenSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorQuayAccessTokenSpec(obj: ClusterGeneratorSpecGeneratorQuayAccessTokenSpec | undefined): Record<string, any> | undefined;
/**
 * SSHKeySpec controls the behavior of the ssh key generator.
 *
 * @schema ClusterGeneratorSpecGeneratorSshKeySpec
 */
export interface ClusterGeneratorSpecGeneratorSshKeySpec {
    /**
     * Comment specifies an optional comment for the SSH key
     *
     * @schema ClusterGeneratorSpecGeneratorSshKeySpec#comment
     */
    readonly comment?: string;
    /**
     * KeySize specifies the key size for RSA keys (default: 2048) and ECDSA keys (default: 256).
     * For RSA keys: 2048, 3072, 4096
     * For ECDSA keys: 256, 384, 521
     * Ignored for ed25519 keys
     *
     * @schema ClusterGeneratorSpecGeneratorSshKeySpec#keySize
     */
    readonly keySize?: number;
    /**
     * KeyType specifies the SSH key type (rsa, ecdsa, ed25519)
     *
     * @schema ClusterGeneratorSpecGeneratorSshKeySpec#keyType
     */
    readonly keyType?: ClusterGeneratorSpecGeneratorSshKeySpecKeyType;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorSshKeySpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorSshKeySpec(obj: ClusterGeneratorSpecGeneratorSshKeySpec | undefined): Record<string, any> | undefined;
/**
 * STSSessionTokenSpec defines the desired state to generate an AWS STS session token.
 *
 * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpec
 */
export interface ClusterGeneratorSpecGeneratorStsSessionTokenSpec {
    /**
     * Auth defines how to authenticate with AWS
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpec#auth
     */
    readonly auth?: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth;
    /**
     * Region specifies the region to operate in.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpec#region
     */
    readonly region: string;
    /**
     * RequestParameters contains parameters that can be passed to the STS service.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpec#requestParameters
     */
    readonly requestParameters?: ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters;
    /**
     * You can assume a role before making calls to the
     * desired AWS service.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpec#role
     */
    readonly role?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpec(obj: ClusterGeneratorSpecGeneratorStsSessionTokenSpec | undefined): Record<string, any> | undefined;
/**
 * VaultDynamicSecretSpec defines the desired spec of VaultDynamicSecret.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec {
    /**
     * Do not fail if no secrets are found. Useful for requests where no data is expected.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec#allowEmptyResponse
     */
    readonly allowEmptyResponse?: boolean;
    /**
     * Used to select the correct ESO controller (think: ingress.ingressClassName)
     * The ESO controller is instantiated with a specific controller name and filters VDS based on this property
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec#controller
     */
    readonly controller?: string;
    /**
     * Vault API method to use (GET/POST/other)
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec#method
     */
    readonly method?: string;
    /**
     * Parameters to pass to Vault write (for non-GET methods)
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec#parameters
     */
    readonly parameters?: any;
    /**
     * Vault path to obtain the dynamic secret from
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec#path
     */
    readonly path: string;
    /**
     * Vault provider common spec
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec#provider
     */
    readonly provider: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider;
    /**
     * Result type defines which data is returned from the generator.
     * By default, it is the "data" section of the Vault API response.
     * When using e.g. /auth/token/create the "data" section is empty but
     * the "auth" section contains the generated token.
     * Please refer to the vault docs regarding the result data structure.
     * Additionally, accessing the raw response is possibly by using "Raw" result type.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec#resultType
     */
    readonly resultType?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType;
    /**
     * Used to configure http retries if failed
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec#retrySettings
     */
    readonly retrySettings?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec | undefined): Record<string, any> | undefined;
/**
 * WebhookSpec controls the behavior of the external generator. Any body parameters should be passed to the server through the parameters field.
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpec
 */
export interface ClusterGeneratorSpecGeneratorWebhookSpec {
    /**
     * Auth specifies a authorization protocol. Only one protocol may be set.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpec#auth
     */
    readonly auth?: ClusterGeneratorSpecGeneratorWebhookSpecAuth;
    /**
     * Body
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpec#body
     */
    readonly body?: string;
    /**
     * PEM encoded CA bundle used to validate webhook server certificate. Only used
     * if the Server URL is using HTTPS protocol. This parameter is ignored for
     * plain HTTP protocol connection. If not set the system root certificates
     * are used to validate the TLS connection.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpec#caBundle
     */
    readonly caBundle?: string;
    /**
     * The provider for the CA bundle to use to validate webhook server certificate.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpec#caProvider
     */
    readonly caProvider?: ClusterGeneratorSpecGeneratorWebhookSpecCaProvider;
    /**
     * Headers
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpec#headers
     */
    readonly headers?: {
        [key: string]: string;
    };
    /**
     * Webhook Method
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpec#method
     */
    readonly method?: string;
    /**
     * Result formatting
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpec#result
     */
    readonly result: ClusterGeneratorSpecGeneratorWebhookSpecResult;
    /**
     * Secrets to fill in templates
     * These secrets will be passed to the templating function as key value pairs under the given name
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpec#secrets
     */
    readonly secrets?: ClusterGeneratorSpecGeneratorWebhookSpecSecrets[];
    /**
     * Timeout
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpec#timeout
     */
    readonly timeout?: string;
    /**
     * Webhook url to call
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpec#url
     */
    readonly url: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpec' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorWebhookSpec(obj: ClusterGeneratorSpecGeneratorWebhookSpec | undefined): Record<string, any> | undefined;
/**
 * ACRAuth defines the authentication methods for Azure Container Registry.
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth
 */
export interface ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth {
    /**
     * ManagedIdentity uses Azure Managed Identity to authenticate with Azure.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth#managedIdentity
     */
    readonly managedIdentity?: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity;
    /**
     * ServicePrincipal uses Azure Service Principal credentials to authenticate with Azure.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth#servicePrincipal
     */
    readonly servicePrincipal?: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal;
    /**
     * WorkloadIdentity uses Azure Workload Identity to authenticate with Azure.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth#workloadIdentity
     */
    readonly workloadIdentity?: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth(obj: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth | undefined): Record<string, any> | undefined;
/**
 * EnvironmentType specifies the Azure cloud environment endpoints to use for
 * connecting and authenticating with Azure. By default, it points to the public cloud AAD endpoint.
 * The following endpoints are available, also see here: https://github.com/Azure/go-autorest/blob/main/autorest/azure/environments.go#L152
 * PublicCloud, USGovernmentCloud, ChinaCloud, GermanCloud
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType
 */
export declare enum ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType {
    /** PublicCloud */
    PUBLIC_CLOUD = "PublicCloud",
    /** USGovernmentCloud */
    US_GOVERNMENT_CLOUD = "USGovernmentCloud",
    /** ChinaCloud */
    CHINA_CLOUD = "ChinaCloud",
    /** GermanCloud */
    GERMAN_CLOUD = "GermanCloud",
    /** AzureStackCloud */
    AZURE_STACK_CLOUD = "AzureStackCloud"
}
/**
 * Name of the service account you are federating with
 *
 * @schema ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpecServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpecServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpecServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpecServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpecServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpecServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpecServiceAccountRef(obj: ClusterGeneratorSpecGeneratorCloudsmithAccessTokenSpecServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * Auth defines how to authenticate with AWS
 *
 * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth
 */
export interface ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth {
    /**
     * AWSJWTAuth provides configuration to authenticate against AWS using service account tokens.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth#jwt
     */
    readonly jwt?: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt;
    /**
     * AWSAuthSecretRef holds secret references for AWS credentials
     * both AccessKeyID and SecretAccessKey must be defined in order to properly authenticate.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth#secretRef
     */
    readonly secretRef?: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth(obj: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth | undefined): Record<string, any> | undefined;
/**
 * Auth defines the means for authenticating with GCP
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth {
    /**
     * GCPSMAuthSecretRef defines the reference to a secret containing Google Cloud Platform credentials.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth#secretRef
     */
    readonly secretRef?: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef;
    /**
     * GCPWorkloadIdentity defines the configuration for using GCP Workload Identity authentication.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth#workloadIdentity
     */
    readonly workloadIdentity?: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity;
    /**
     * GCPWorkloadIdentityFederation holds the configurations required for generating federated access tokens.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth#workloadIdentityFederation
     */
    readonly workloadIdentityFederation?: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth | undefined): Record<string, any> | undefined;
/**
 * Auth configures how ESO authenticates with a Github instance.
 *
 * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth
 */
export interface ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth {
    /**
     * GithubSecretRef references a secret containing GitHub credentials.
     *
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth#privateKey
     */
    readonly privateKey: ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth(obj: ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth | undefined): Record<string, any> | undefined;
/**
 * Auth is the authentication configuration to authenticate
 * against the Grafana instance.
 *
 * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuth
 */
export interface ClusterGeneratorSpecGeneratorGrafanaSpecAuth {
    /**
     * Basic auth credentials used to authenticate against the Grafana instance.
     * Note: you need a token which has elevated permissions to create service accounts.
     * See here for the documentation on basic roles offered by Grafana:
     * https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/access-control/rbac-fixed-basic-role-definitions/
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuth#basic
     */
    readonly basic?: ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic;
    /**
     * A service account token used to authenticate against the Grafana instance.
     * Note: you need a token which has elevated permissions to create service accounts.
     * See here for the documentation on basic roles offered by Grafana:
     * https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/access-control/rbac-fixed-basic-role-definitions/
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuth#token
     */
    readonly token?: ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpecAuth' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuth(obj: ClusterGeneratorSpecGeneratorGrafanaSpecAuth | undefined): Record<string, any> | undefined;
/**
 * ServiceAccount is the configuration for the service account that
 * is supposed to be generated by the generator.
 *
 * @schema ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount
 */
export interface ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount {
    /**
     * Name is the name of the service account that will be created by ESO.
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount#name
     */
    readonly name: string;
    /**
     * Role is the role of the service account.
     * See here for the documentation on basic roles offered by Grafana:
     * https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/access-control/rbac-fixed-basic-role-definitions/
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount#role
     */
    readonly role: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount(obj: ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount | undefined): Record<string, any> | undefined;
/**
 * Secret is a secret selector to a secret containing the seed secret to generate the TOTP value from.
 *
 * @schema ClusterGeneratorSpecGeneratorMfaSpecSecret
 */
export interface ClusterGeneratorSpecGeneratorMfaSpecSecret {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorMfaSpecSecret#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorMfaSpecSecret#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorMfaSpecSecret#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorMfaSpecSecret' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorMfaSpecSecret(obj: ClusterGeneratorSpecGeneratorMfaSpecSecret | undefined): Record<string, any> | undefined;
/**
 * Encoding specifies the encoding of the generated password.
 * Valid values are:
 * - "raw" (default): no encoding
 * - "base64": standard base64 encoding
 * - "base64url": base64url encoding
 * - "base32": base32 encoding
 * - "hex": hexadecimal encoding
 *
 * @schema ClusterGeneratorSpecGeneratorPasswordSpecEncoding
 */
export declare enum ClusterGeneratorSpecGeneratorPasswordSpecEncoding {
    /** base64 */
    BASE64 = "base64",
    /** base64url */
    BASE64URL = "base64url",
    /** base32 */
    BASE32 = "base32",
    /** hex */
    HEX = "hex",
    /** raw */
    RAW = "raw"
}
/**
 * Name of the service account you are federating with
 *
 * @schema ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef(obj: ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * KeyType specifies the SSH key type (rsa, ecdsa, ed25519)
 *
 * @schema ClusterGeneratorSpecGeneratorSshKeySpecKeyType
 */
export declare enum ClusterGeneratorSpecGeneratorSshKeySpecKeyType {
    /** rsa */
    RSA = "rsa",
    /** ecdsa */
    ECDSA = "ecdsa",
    /** ed25519 */
    ED25519 = "ed25519"
}
/**
 * Auth defines how to authenticate with AWS
 *
 * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth
 */
export interface ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth {
    /**
     * AWSJWTAuth provides configuration to authenticate against AWS using service account tokens.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth#jwt
     */
    readonly jwt?: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt;
    /**
     * AWSAuthSecretRef holds secret references for AWS credentials
     * both AccessKeyID and SecretAccessKey must be defined in order to properly authenticate.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth#secretRef
     */
    readonly secretRef?: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth(obj: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth | undefined): Record<string, any> | undefined;
/**
 * RequestParameters contains parameters that can be passed to the STS service.
 *
 * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters
 */
export interface ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters {
    /**
     * SerialNumber is the identification number of the MFA device that is associated with the IAM user who is making
     * the GetSessionToken call.
     * Possible values: hardware device (such as GAHT12345678) or an Amazon Resource Name (ARN) for a virtual device
     * (such as arn:aws:iam::123456789012:mfa/user)
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters#serialNumber
     */
    readonly serialNumber?: string;
    /**
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters#sessionDuration
     */
    readonly sessionDuration?: number;
    /**
     * TokenCode is the value provided by the MFA device, if MFA is required.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters#tokenCode
     */
    readonly tokenCode?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters(obj: ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters | undefined): Record<string, any> | undefined;
/**
 * Vault provider common spec
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider {
    /**
     * Auth configures how secret-manager authenticates with the Vault server.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#auth
     */
    readonly auth?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth;
    /**
     * PEM encoded CA bundle used to validate Vault server certificate. Only used
     * if the Server URL is using HTTPS protocol. This parameter is ignored for
     * plain HTTP protocol connection. If not set the system root certificates
     * are used to validate the TLS connection.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#caBundle
     */
    readonly caBundle?: string;
    /**
     * The provider for the CA bundle to use to validate Vault server certificate.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#caProvider
     */
    readonly caProvider?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider;
    /**
     * CheckAndSet defines the Check-And-Set (CAS) settings for PushSecret operations.
     * Only applies to Vault KV v2 stores. When enabled, write operations must include
     * the current version of the secret to prevent unintentional overwrites.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#checkAndSet
     */
    readonly checkAndSet?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCheckAndSet;
    /**
     * ForwardInconsistent tells Vault to forward read-after-write requests to the Vault
     * leader instead of simply retrying within a loop. This can increase performance if
     * the option is enabled serverside.
     * https://www.vaultproject.io/docs/configuration/replication#allow_forwarding_via_header
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#forwardInconsistent
     */
    readonly forwardInconsistent?: boolean;
    /**
     * Headers to be added in Vault request
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#headers
     */
    readonly headers?: {
        [key: string]: string;
    };
    /**
     * Name of the vault namespace. Namespaces is a set of features within Vault Enterprise that allows
     * Vault environments to support Secure Multi-tenancy. e.g: "ns1".
     * More about namespaces can be found here https://www.vaultproject.io/docs/enterprise/namespaces
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#namespace
     */
    readonly namespace?: string;
    /**
     * Path is the mount path of the Vault KV backend endpoint, e.g:
     * "secret". The v2 KV secret engine version specific "/data" path suffix
     * for fetching secrets from Vault is optional and will be appended
     * if not present in specified path.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#path
     */
    readonly path?: string;
    /**
     * ReadYourWrites ensures isolated read-after-write semantics by
     * providing discovered cluster replication states in each request.
     * More information about eventual consistency in Vault can be found here
     * https://www.vaultproject.io/docs/enterprise/consistency
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#readYourWrites
     */
    readonly readYourWrites?: boolean;
    /**
     * Server is the connection address for the Vault server, e.g: "https://vault.example.com:8200".
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#server
     */
    readonly server: string;
    /**
     * The configuration used for client side related TLS communication, when the Vault server
     * requires mutual authentication. Only used if the Server URL is using HTTPS protocol.
     * This parameter is ignored for plain HTTP protocol connection.
     * It's worth noting this configuration is different from the "TLS certificates auth method",
     * which is available under the `auth.cert` section.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#tls
     */
    readonly tls?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls;
    /**
     * Version is the Vault KV secret engine version. This can be either "v1" or
     * "v2". Version defaults to "v2".
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider#version
     */
    readonly version?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider | undefined): Record<string, any> | undefined;
/**
 * Result type defines which data is returned from the generator.
 * By default, it is the "data" section of the Vault API response.
 * When using e.g. /auth/token/create the "data" section is empty but
 * the "auth" section contains the generated token.
 * Please refer to the vault docs regarding the result data structure.
 * Additionally, accessing the raw response is possibly by using "Raw" result type.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType
 */
export declare enum ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType {
    /** Data */
    DATA = "Data",
    /** Auth */
    AUTH = "Auth",
    /** Raw */
    RAW = "Raw"
}
/**
 * Used to configure http retries if failed
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings {
    /**
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings#maxRetries
     */
    readonly maxRetries?: number;
    /**
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings#retryInterval
     */
    readonly retryInterval?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings | undefined): Record<string, any> | undefined;
/**
 * Auth specifies a authorization protocol. Only one protocol may be set.
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuth
 */
export interface ClusterGeneratorSpecGeneratorWebhookSpecAuth {
    /**
     * NTLMProtocol configures the store to use NTLM for auth
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuth#ntlm
     */
    readonly ntlm?: ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlm;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecAuth' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorWebhookSpecAuth(obj: ClusterGeneratorSpecGeneratorWebhookSpecAuth | undefined): Record<string, any> | undefined;
/**
 * The provider for the CA bundle to use to validate webhook server certificate.
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpecCaProvider
 */
export interface ClusterGeneratorSpecGeneratorWebhookSpecCaProvider {
    /**
     * The key where the CA certificate can be found in the Secret or ConfigMap.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecCaProvider#key
     */
    readonly key?: string;
    /**
     * The name of the object located at the provider type.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecCaProvider#name
     */
    readonly name: string;
    /**
     * The namespace the Provider type is in.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecCaProvider#namespace
     */
    readonly namespace?: string;
    /**
     * The type of provider to use such as "Secret", or "ConfigMap".
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecCaProvider#type
     */
    readonly type: ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecCaProvider' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorWebhookSpecCaProvider(obj: ClusterGeneratorSpecGeneratorWebhookSpecCaProvider | undefined): Record<string, any> | undefined;
/**
 * Result formatting
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpecResult
 */
export interface ClusterGeneratorSpecGeneratorWebhookSpecResult {
    /**
     * Json path of return value
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecResult#jsonPath
     */
    readonly jsonPath?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecResult' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorWebhookSpecResult(obj: ClusterGeneratorSpecGeneratorWebhookSpecResult | undefined): Record<string, any> | undefined;
/**
 * WebhookSecret defines a secret reference that will be used in webhook templates.
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpecSecrets
 */
export interface ClusterGeneratorSpecGeneratorWebhookSpecSecrets {
    /**
     * Name of this secret in templates
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecSecrets#name
     */
    readonly name: string;
    /**
     * Secret ref to fill in credentials
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecSecrets#secretRef
     */
    readonly secretRef: ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecSecrets' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorWebhookSpecSecrets(obj: ClusterGeneratorSpecGeneratorWebhookSpecSecrets | undefined): Record<string, any> | undefined;
/**
 * ManagedIdentity uses Azure Managed Identity to authenticate with Azure.
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity
 */
export interface ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity {
    /**
     * If multiple Managed Identity is assigned to the pod, you can select the one to be used
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity#identityId
     */
    readonly identityId?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity(obj: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity | undefined): Record<string, any> | undefined;
/**
 * ServicePrincipal uses Azure Service Principal credentials to authenticate with Azure.
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal
 */
export interface ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal {
    /**
     * AzureACRServicePrincipalAuthSecretRef defines the secret references for Azure Service Principal authentication.
     * It uses static credentials stored in a Kind=Secret.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal#secretRef
     */
    readonly secretRef: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal(obj: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal | undefined): Record<string, any> | undefined;
/**
 * WorkloadIdentity uses Azure Workload Identity to authenticate with Azure.
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity
 */
export interface ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity {
    /**
     * ServiceAccountRef specified the service account
     * that should be used when authenticating with WorkloadIdentity.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity#serviceAccountRef
     */
    readonly serviceAccountRef?: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity(obj: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity | undefined): Record<string, any> | undefined;
/**
 * AWSJWTAuth provides configuration to authenticate against AWS using service account tokens.
 *
 * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt
 */
export interface ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt {
    /**
     * ServiceAccountSelector is a reference to a ServiceAccount resource.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt#serviceAccountRef
     */
    readonly serviceAccountRef?: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt(obj: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt | undefined): Record<string, any> | undefined;
/**
 * AWSAuthSecretRef holds secret references for AWS credentials
 * both AccessKeyID and SecretAccessKey must be defined in order to properly authenticate.
 *
 * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef
 */
export interface ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef {
    /**
     * The AccessKeyID is used for authentication
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef#accessKeyIDSecretRef
     */
    readonly accessKeyIdSecretRef?: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef;
    /**
     * The SecretAccessKey is used for authentication
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef#secretAccessKeySecretRef
     */
    readonly secretAccessKeySecretRef?: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef;
    /**
     * The SessionToken used for authentication
     * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
     * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef#sessionTokenSecretRef
     */
    readonly sessionTokenSecretRef?: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef(obj: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef | undefined): Record<string, any> | undefined;
/**
 * GCPSMAuthSecretRef defines the reference to a secret containing Google Cloud Platform credentials.
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef {
    /**
     * The SecretAccessKey is used for authentication
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef#secretAccessKeySecretRef
     */
    readonly secretAccessKeySecretRef?: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef | undefined): Record<string, any> | undefined;
/**
 * GCPWorkloadIdentity defines the configuration for using GCP Workload Identity authentication.
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity {
    /**
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity#clusterLocation
     */
    readonly clusterLocation: string;
    /**
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity#clusterName
     */
    readonly clusterName: string;
    /**
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity#clusterProjectID
     */
    readonly clusterProjectId?: string;
    /**
     * ServiceAccountSelector is a reference to a ServiceAccount resource.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity#serviceAccountRef
     */
    readonly serviceAccountRef: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity | undefined): Record<string, any> | undefined;
/**
 * GCPWorkloadIdentityFederation holds the configurations required for generating federated access tokens.
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation {
    /**
     * audience is the Secure Token Service (STS) audience which contains the resource name for the workload identity pool and the provider identifier in that pool.
     * If specified, Audience found in the external account credential config will be overridden with the configured value.
     * audience must be provided when serviceAccountRef or awsSecurityCredentials is configured.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation#audience
     */
    readonly audience?: string;
    /**
     * awsSecurityCredentials is for configuring AWS region and credentials to use for obtaining the access token,
     * when using the AWS metadata server is not an option.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation#awsSecurityCredentials
     */
    readonly awsSecurityCredentials?: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials;
    /**
     * credConfig holds the configmap reference containing the GCP external account credential configuration in JSON format and the key name containing the json data.
     * For using Kubernetes cluster as the identity provider, use serviceAccountRef instead. Operators mounted serviceaccount token cannot be used as the token source, instead
     * serviceAccountRef must be used by providing operators service account details.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation#credConfig
     */
    readonly credConfig?: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig;
    /**
     * externalTokenEndpoint is the endpoint explicitly set up to provide tokens, which will be matched against the
     * credential_source.url in the provided credConfig. This field is merely to double-check the external token source
     * URL is having the expected value.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation#externalTokenEndpoint
     */
    readonly externalTokenEndpoint?: string;
    /**
     * serviceAccountRef is the reference to the kubernetes ServiceAccount to be used for obtaining the tokens,
     * when Kubernetes is configured as provider in workload identity pool.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation#serviceAccountRef
     */
    readonly serviceAccountRef?: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederation | undefined): Record<string, any> | undefined;
/**
 * GithubSecretRef references a secret containing GitHub credentials.
 *
 * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey
 */
export interface ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey {
    /**
     * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
     * In some instances, `key` is a required field.
     *
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey#secretRef
     */
    readonly secretRef: ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey(obj: ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey | undefined): Record<string, any> | undefined;
/**
 * Basic auth credentials used to authenticate against the Grafana instance.
 * Note: you need a token which has elevated permissions to create service accounts.
 * See here for the documentation on basic roles offered by Grafana:
 * https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/access-control/rbac-fixed-basic-role-definitions/
 *
 * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic
 */
export interface ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic {
    /**
     * A basic auth password used to authenticate against the Grafana instance.
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic#password
     */
    readonly password: ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword;
    /**
     * A basic auth username used to authenticate against the Grafana instance.
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic#username
     */
    readonly username: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic(obj: ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic | undefined): Record<string, any> | undefined;
/**
 * A service account token used to authenticate against the Grafana instance.
 * Note: you need a token which has elevated permissions to create service accounts.
 * See here for the documentation on basic roles offered by Grafana:
 * https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/access-control/rbac-fixed-basic-role-definitions/
 *
 * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken
 */
export interface ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken {
    /**
     * The key where the token is found.
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken#name
     */
    readonly name?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken(obj: ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken | undefined): Record<string, any> | undefined;
/**
 * AWSJWTAuth provides configuration to authenticate against AWS using service account tokens.
 *
 * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt
 */
export interface ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt {
    /**
     * ServiceAccountSelector is a reference to a ServiceAccount resource.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt#serviceAccountRef
     */
    readonly serviceAccountRef?: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt(obj: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt | undefined): Record<string, any> | undefined;
/**
 * AWSAuthSecretRef holds secret references for AWS credentials
 * both AccessKeyID and SecretAccessKey must be defined in order to properly authenticate.
 *
 * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef
 */
export interface ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef {
    /**
     * The AccessKeyID is used for authentication
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef#accessKeyIDSecretRef
     */
    readonly accessKeyIdSecretRef?: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef;
    /**
     * The SecretAccessKey is used for authentication
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef#secretAccessKeySecretRef
     */
    readonly secretAccessKeySecretRef?: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef;
    /**
     * The SessionToken used for authentication
     * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
     * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef#sessionTokenSecretRef
     */
    readonly sessionTokenSecretRef?: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef(obj: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef | undefined): Record<string, any> | undefined;
/**
 * Auth configures how secret-manager authenticates with the Vault server.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth {
    /**
     * AppRole authenticates with Vault using the App Role auth mechanism,
     * with the role and secret stored in a Kubernetes Secret resource.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth#appRole
     */
    readonly appRole?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole;
    /**
     * Cert authenticates with TLS Certificates by passing client certificate, private key and ca certificate
     * Cert authentication method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth#cert
     */
    readonly cert?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert;
    /**
     * Gcp authenticates with Vault using Google Cloud Platform authentication method
     * GCP authentication method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth#gcp
     */
    readonly gcp?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp;
    /**
     * Iam authenticates with vault by passing a special AWS request signed with AWS IAM credentials
     * AWS IAM authentication method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth#iam
     */
    readonly iam?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam;
    /**
     * Jwt authenticates with Vault by passing role and JWT token using the
     * JWT/OIDC authentication method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth#jwt
     */
    readonly jwt?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt;
    /**
     * Kubernetes authenticates with Vault by passing the ServiceAccount
     * token stored in the named Secret resource to the Vault server.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth#kubernetes
     */
    readonly kubernetes?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes;
    /**
     * Ldap authenticates with Vault by passing username/password pair using
     * the LDAP authentication method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth#ldap
     */
    readonly ldap?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap;
    /**
     * Name of the vault namespace to authenticate to. This can be different than the namespace your secret is in.
     * Namespaces is a set of features within Vault Enterprise that allows
     * Vault environments to support Secure Multi-tenancy. e.g: "ns1".
     * More about namespaces can be found here https://www.vaultproject.io/docs/enterprise/namespaces
     * This will default to Vault.Namespace field if set, or empty otherwise
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth#namespace
     */
    readonly namespace?: string;
    /**
     * TokenSecretRef authenticates with Vault by presenting a token.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth#tokenSecretRef
     */
    readonly tokenSecretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef;
    /**
     * UserPass authenticates with Vault by passing username/password pair
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth#userPass
     */
    readonly userPass?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth | undefined): Record<string, any> | undefined;
/**
 * The provider for the CA bundle to use to validate Vault server certificate.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider {
    /**
     * The key where the CA certificate can be found in the Secret or ConfigMap.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider#key
     */
    readonly key?: string;
    /**
     * The name of the object located at the provider type.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider#name
     */
    readonly name: string;
    /**
     * The namespace the Provider type is in.
     * Can only be defined when used in a ClusterSecretStore.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider#namespace
     */
    readonly namespace?: string;
    /**
     * The type of provider to use such as "Secret", or "ConfigMap".
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider#type
     */
    readonly type: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider | undefined): Record<string, any> | undefined;
/**
 * CheckAndSet defines the Check-And-Set (CAS) settings for PushSecret operations.
 * Only applies to Vault KV v2 stores. When enabled, write operations must include
 * the current version of the secret to prevent unintentional overwrites.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCheckAndSet
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCheckAndSet {
    /**
     * Required when true, all write operations must include a check-and-set parameter.
     * This helps prevent unintentional overwrites of secrets.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCheckAndSet#required
     */
    readonly required?: boolean;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCheckAndSet' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCheckAndSet(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCheckAndSet | undefined): Record<string, any> | undefined;
/**
 * The configuration used for client side related TLS communication, when the Vault server
 * requires mutual authentication. Only used if the Server URL is using HTTPS protocol.
 * This parameter is ignored for plain HTTP protocol connection.
 * It's worth noting this configuration is different from the "TLS certificates auth method",
 * which is available under the `auth.cert` section.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls {
    /**
     * CertSecretRef is a certificate added to the transport layer
     * when communicating with the Vault server.
     * If no key for the Secret is specified, external-secret will default to 'tls.crt'.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls#certSecretRef
     */
    readonly certSecretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef;
    /**
     * KeySecretRef to a key in a Secret resource containing client private key
     * added to the transport layer when communicating with the Vault server.
     * If no key for the Secret is specified, external-secret will default to 'tls.key'.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls#keySecretRef
     */
    readonly keySecretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls | undefined): Record<string, any> | undefined;
/**
 * Version is the Vault KV secret engine version. This can be either "v1" or
 * "v2". Version defaults to "v2".
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion
 */
export declare enum ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion {
    /** v1 */
    V1 = "v1",
    /** v2 */
    V2 = "v2"
}
/**
 * NTLMProtocol configures the store to use NTLM for auth
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlm
 */
export interface ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlm {
    /**
     * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
     * In some instances, `key` is a required field.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlm#passwordSecret
     */
    readonly passwordSecret: ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmPasswordSecret;
    /**
     * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
     * In some instances, `key` is a required field.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlm#usernameSecret
     */
    readonly usernameSecret: ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmUsernameSecret;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlm' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlm(obj: ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlm | undefined): Record<string, any> | undefined;
/**
 * The type of provider to use such as "Secret", or "ConfigMap".
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType
 */
export declare enum ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType {
    /** Secret */
    SECRET = "Secret",
    /** ConfigMap */
    CONFIG_MAP = "ConfigMap"
}
/**
 * Secret ref to fill in credentials
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef
 */
export interface ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef {
    /**
     * The key where the token is found.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef#name
     */
    readonly name?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef(obj: ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef | undefined): Record<string, any> | undefined;
/**
 * AzureACRServicePrincipalAuthSecretRef defines the secret references for Azure Service Principal authentication.
 * It uses static credentials stored in a Kind=Secret.
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef
 */
export interface ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef {
    /**
     * The Azure clientId of the service principle used for authentication.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef#clientId
     */
    readonly clientId?: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId;
    /**
     * The Azure ClientSecret of the service principle used for authentication.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef#clientSecret
     */
    readonly clientSecret?: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef(obj: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountRef specified the service account
 * that should be used when authenticating with WorkloadIdentity.
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountSelector is a reference to a ServiceAccount resource.
 *
 * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef(obj: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * The AccessKeyID is used for authentication
 *
 * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef
 */
export interface ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef | undefined): Record<string, any> | undefined;
/**
 * The SecretAccessKey is used for authentication
 *
 * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef
 */
export interface ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * The SessionToken used for authentication
 * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
 * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
 *
 * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef
 */
export interface ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef(obj: ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef | undefined): Record<string, any> | undefined;
/**
 * The SecretAccessKey is used for authentication
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountSelector is a reference to a ServiceAccount resource.
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * awsSecurityCredentials is for configuring AWS region and credentials to use for obtaining the access token,
 * when using the AWS metadata server is not an option.
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials {
    /**
     * awsCredentialsSecretRef is the reference to the secret which holds the AWS credentials.
     * Secret should be created with below names for keys
     * - aws_access_key_id: Access Key ID, which is the unique identifier for the AWS account or the IAM user.
     * - aws_secret_access_key: Secret Access Key, which is used to authenticate requests made to AWS services.
     * - aws_session_token: Session Token, is the short-lived token to authenticate requests made to AWS services.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials#awsCredentialsSecretRef
     */
    readonly awsCredentialsSecretRef: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef;
    /**
     * region is for configuring the AWS region to be used.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials#region
     */
    readonly region: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials | undefined): Record<string, any> | undefined;
/**
 * credConfig holds the configmap reference containing the GCP external account credential configuration in JSON format and the key name containing the json data.
 * For using Kubernetes cluster as the identity provider, use serviceAccountRef instead. Operators mounted serviceaccount token cannot be used as the token source, instead
 * serviceAccountRef must be used by providing operators service account details.
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig {
    /**
     * key name holding the external account credential config.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig#key
     */
    readonly key: string;
    /**
     * name of the configmap.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig#name
     */
    readonly name: string;
    /**
     * namespace in which the configmap exists. If empty, configmap will looked up in local namespace.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig | undefined): Record<string, any> | undefined;
/**
 * serviceAccountRef is the reference to the kubernetes ServiceAccount to be used for obtaining the tokens,
 * when Kubernetes is configured as provider in workload identity pool.
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
 * In some instances, `key` is a required field.
 *
 * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef
 */
export interface ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef(obj: ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * A basic auth password used to authenticate against the Grafana instance.
 *
 * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword
 */
export interface ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword {
    /**
     * The key where the token is found.
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword#name
     */
    readonly name?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword(obj: ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountSelector is a reference to a ServiceAccount resource.
 *
 * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef(obj: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * The AccessKeyID is used for authentication
 *
 * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef
 */
export interface ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef | undefined): Record<string, any> | undefined;
/**
 * The SecretAccessKey is used for authentication
 *
 * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef
 */
export interface ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * The SessionToken used for authentication
 * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
 * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
 *
 * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef
 */
export interface ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef(obj: ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef | undefined): Record<string, any> | undefined;
/**
 * AppRole authenticates with Vault using the App Role auth mechanism,
 * with the role and secret stored in a Kubernetes Secret resource.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole {
    /**
     * Path where the App Role authentication backend is mounted
     * in Vault, e.g: "approle"
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole#path
     */
    readonly path: string;
    /**
     * RoleID configured in the App Role authentication backend when setting
     * up the authentication backend in Vault.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole#roleId
     */
    readonly roleId?: string;
    /**
     * Reference to a key in a Secret that contains the App Role ID used
     * to authenticate with Vault.
     * The `key` field must be specified and denotes which entry within the Secret
     * resource is used as the app role id.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole#roleRef
     */
    readonly roleRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef;
    /**
     * Reference to a key in a Secret that contains the App Role secret used
     * to authenticate with Vault.
     * The `key` field must be specified and denotes which entry within the Secret
     * resource is used as the app role secret.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole#secretRef
     */
    readonly secretRef: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole | undefined): Record<string, any> | undefined;
/**
 * Cert authenticates with TLS Certificates by passing client certificate, private key and ca certificate
 * Cert authentication method
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert {
    /**
     * ClientCert is a certificate to authenticate using the Cert Vault
     * authentication method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert#clientCert
     */
    readonly clientCert?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert;
    /**
     * Path where the Certificate authentication backend is mounted
     * in Vault, e.g: "cert"
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert#path
     */
    readonly path?: string;
    /**
     * SecretRef to a key in a Secret resource containing client private key to
     * authenticate with Vault using the Cert authentication method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert#secretRef
     */
    readonly secretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert | undefined): Record<string, any> | undefined;
/**
 * Gcp authenticates with Vault using Google Cloud Platform authentication method
 * GCP authentication method
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp {
    /**
     * Location optionally defines a location/region for the secret
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp#location
     */
    readonly location?: string;
    /**
     * Path where the GCP auth method is enabled in Vault, e.g: "gcp"
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp#path
     */
    readonly path?: string;
    /**
     * Project ID of the Google Cloud Platform project
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp#projectID
     */
    readonly projectId?: string;
    /**
     * Vault Role. In Vault, a role describes an identity with a set of permissions, groups, or policies you want to attach to a user of the secrets engine.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp#role
     */
    readonly role: string;
    /**
     * Specify credentials in a Secret object
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp#secretRef
     */
    readonly secretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRef;
    /**
     * ServiceAccountRef to a service account for impersonation
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp#serviceAccountRef
     */
    readonly serviceAccountRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpServiceAccountRef;
    /**
     * Specify a service account with Workload Identity
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp#workloadIdentity
     */
    readonly workloadIdentity?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcp | undefined): Record<string, any> | undefined;
/**
 * Iam authenticates with vault by passing a special AWS request signed with AWS IAM credentials
 * AWS IAM authentication method
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam {
    /**
     * AWS External ID set on assumed IAM roles
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam#externalID
     */
    readonly externalId?: string;
    /**
     * Specify a service account with IRSA enabled
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam#jwt
     */
    readonly jwt?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt;
    /**
     * Path where the AWS auth method is enabled in Vault, e.g: "aws"
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam#path
     */
    readonly path?: string;
    /**
     * AWS region
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam#region
     */
    readonly region?: string;
    /**
     * This is the AWS role to be assumed before talking to vault
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam#role
     */
    readonly role?: string;
    /**
     * Specify credentials in a Secret object
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam#secretRef
     */
    readonly secretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef;
    /**
     * X-Vault-AWS-IAM-Server-ID is an additional header used by Vault IAM auth method to mitigate against different types of replay attacks. More details here: https://developer.hashicorp.com/vault/docs/auth/aws
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam#vaultAwsIamServerID
     */
    readonly vaultAwsIamServerId?: string;
    /**
     * Vault Role. In vault, a role describes an identity with a set of permissions, groups, or policies you want to attach a user of the secrets engine
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam#vaultRole
     */
    readonly vaultRole: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam | undefined): Record<string, any> | undefined;
/**
 * Jwt authenticates with Vault by passing role and JWT token using the
 * JWT/OIDC authentication method
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt {
    /**
     * Optional ServiceAccountToken specifies the Kubernetes service account for which to request
     * a token for with the `TokenRequest` API.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt#kubernetesServiceAccountToken
     */
    readonly kubernetesServiceAccountToken?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken;
    /**
     * Path where the JWT authentication backend is mounted
     * in Vault, e.g: "jwt"
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt#path
     */
    readonly path: string;
    /**
     * Role is a JWT role to authenticate using the JWT/OIDC Vault
     * authentication method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt#role
     */
    readonly role?: string;
    /**
     * Optional SecretRef that refers to a key in a Secret resource containing JWT token to
     * authenticate with Vault using the JWT/OIDC authentication method.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt#secretRef
     */
    readonly secretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt | undefined): Record<string, any> | undefined;
/**
 * Kubernetes authenticates with Vault by passing the ServiceAccount
 * token stored in the named Secret resource to the Vault server.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes {
    /**
     * Path where the Kubernetes authentication backend is mounted in Vault, e.g:
     * "kubernetes"
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes#mountPath
     */
    readonly mountPath: string;
    /**
     * A required field containing the Vault Role to assume. A Role binds a
     * Kubernetes ServiceAccount with a set of Vault policies.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes#role
     */
    readonly role: string;
    /**
     * Optional secret field containing a Kubernetes ServiceAccount JWT used
     * for authenticating with Vault. If a name is specified without a key,
     * `token` is the default. If one is not specified, the one bound to
     * the controller will be used.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes#secretRef
     */
    readonly secretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef;
    /**
     * Optional service account field containing the name of a kubernetes ServiceAccount.
     * If the service account is specified, the service account secret token JWT will be used
     * for authenticating with Vault. If the service account selector is not supplied,
     * the secretRef will be used instead.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes#serviceAccountRef
     */
    readonly serviceAccountRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes | undefined): Record<string, any> | undefined;
/**
 * Ldap authenticates with Vault by passing username/password pair using
 * the LDAP authentication method
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap {
    /**
     * Path where the LDAP authentication backend is mounted
     * in Vault, e.g: "ldap"
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap#path
     */
    readonly path: string;
    /**
     * SecretRef to a key in a Secret resource containing password for the LDAP
     * user used to authenticate with Vault using the LDAP authentication
     * method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap#secretRef
     */
    readonly secretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef;
    /**
     * Username is an LDAP username used to authenticate using the LDAP Vault
     * authentication method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap#username
     */
    readonly username: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap | undefined): Record<string, any> | undefined;
/**
 * TokenSecretRef authenticates with Vault by presenting a token.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef | undefined): Record<string, any> | undefined;
/**
 * UserPass authenticates with Vault by passing username/password pair
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass {
    /**
     * Path where the UserPassword authentication backend is mounted
     * in Vault, e.g: "userpass"
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass#path
     */
    readonly path: string;
    /**
     * SecretRef to a key in a Secret resource containing password for the
     * user used to authenticate with Vault using the UserPass authentication
     * method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass#secretRef
     */
    readonly secretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef;
    /**
     * Username is a username used to authenticate using the UserPass Vault
     * authentication method
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass#username
     */
    readonly username: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass | undefined): Record<string, any> | undefined;
/**
 * The type of provider to use such as "Secret", or "ConfigMap".
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType
 */
export declare enum ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType {
    /** Secret */
    SECRET = "Secret",
    /** ConfigMap */
    CONFIG_MAP = "ConfigMap"
}
/**
 * CertSecretRef is a certificate added to the transport layer
 * when communicating with the Vault server.
 * If no key for the Secret is specified, external-secret will default to 'tls.crt'.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef | undefined): Record<string, any> | undefined;
/**
 * KeySecretRef to a key in a Secret resource containing client private key
 * added to the transport layer when communicating with the Vault server.
 * If no key for the Secret is specified, external-secret will default to 'tls.key'.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
 * In some instances, `key` is a required field.
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmPasswordSecret
 */
export interface ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmPasswordSecret {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmPasswordSecret#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmPasswordSecret#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmPasswordSecret#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmPasswordSecret' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmPasswordSecret(obj: ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmPasswordSecret | undefined): Record<string, any> | undefined;
/**
 * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
 * In some instances, `key` is a required field.
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmUsernameSecret
 */
export interface ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmUsernameSecret {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmUsernameSecret#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmUsernameSecret#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmUsernameSecret#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmUsernameSecret' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmUsernameSecret(obj: ClusterGeneratorSpecGeneratorWebhookSpecAuthNtlmUsernameSecret | undefined): Record<string, any> | undefined;
/**
 * The Azure clientId of the service principle used for authentication.
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId
 */
export interface ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId(obj: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId | undefined): Record<string, any> | undefined;
/**
 * The Azure ClientSecret of the service principle used for authentication.
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret
 */
export interface ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret(obj: ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret | undefined): Record<string, any> | undefined;
/**
 * awsCredentialsSecretRef is the reference to the secret which holds the AWS credentials.
 * Secret should be created with below names for keys
 * - aws_access_key_id: Access Key ID, which is the unique identifier for the AWS account or the IAM user.
 * - aws_secret_access_key: Secret Access Key, which is used to authenticate requests made to AWS services.
 * - aws_session_token: Session Token, is the short-lived token to authenticate requests made to AWS services.
 *
 * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef
 */
export interface ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef {
    /**
     * name of the secret.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef#name
     */
    readonly name: string;
    /**
     * namespace in which the secret exists. If empty, secret will looked up in local namespace.
     *
     * @schema ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef(obj: ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef | undefined): Record<string, any> | undefined;
/**
 * Reference to a key in a Secret that contains the App Role ID used
 * to authenticate with Vault.
 * The `key` field must be specified and denotes which entry within the Secret
 * resource is used as the app role id.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef | undefined): Record<string, any> | undefined;
/**
 * Reference to a key in a Secret that contains the App Role secret used
 * to authenticate with Vault.
 * The `key` field must be specified and denotes which entry within the Secret
 * resource is used as the app role secret.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef | undefined): Record<string, any> | undefined;
/**
 * ClientCert is a certificate to authenticate using the Cert Vault
 * authentication method
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert | undefined): Record<string, any> | undefined;
/**
 * SecretRef to a key in a Secret resource containing client private key to
 * authenticate with Vault using the Cert authentication method
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef | undefined): Record<string, any> | undefined;
/**
 * Specify credentials in a Secret object
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRef {
    /**
     * The SecretAccessKey is used for authentication
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRef#secretAccessKeySecretRef
     */
    readonly secretAccessKeySecretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountRef to a service account for impersonation
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpServiceAccountRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * Specify a service account with Workload Identity
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity {
    /**
     * ClusterLocation is the location of the cluster
     * If not specified, it fetches information from the metadata server
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity#clusterLocation
     */
    readonly clusterLocation?: string;
    /**
     * ClusterName is the name of the cluster
     * If not specified, it fetches information from the metadata server
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity#clusterName
     */
    readonly clusterName?: string;
    /**
     * ClusterProjectID is the project ID of the cluster
     * If not specified, it fetches information from the metadata server
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity#clusterProjectID
     */
    readonly clusterProjectId?: string;
    /**
     * ServiceAccountSelector is a reference to a ServiceAccount resource.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity#serviceAccountRef
     */
    readonly serviceAccountRef: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity | undefined): Record<string, any> | undefined;
/**
 * Specify a service account with IRSA enabled
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt {
    /**
     * ServiceAccountSelector is a reference to a ServiceAccount resource.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt#serviceAccountRef
     */
    readonly serviceAccountRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt | undefined): Record<string, any> | undefined;
/**
 * Specify credentials in a Secret object
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef {
    /**
     * The AccessKeyID is used for authentication
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef#accessKeyIDSecretRef
     */
    readonly accessKeyIdSecretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef;
    /**
     * The SecretAccessKey is used for authentication
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef#secretAccessKeySecretRef
     */
    readonly secretAccessKeySecretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef;
    /**
     * The SessionToken used for authentication
     * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
     * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef#sessionTokenSecretRef
     */
    readonly sessionTokenSecretRef?: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef | undefined): Record<string, any> | undefined;
/**
 * Optional ServiceAccountToken specifies the Kubernetes service account for which to request
 * a token for with the `TokenRequest` API.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken {
    /**
     * Optional audiences field that will be used to request a temporary Kubernetes service
     * account token for the service account referenced by `serviceAccountRef`.
     * Defaults to a single audience `vault` it not specified.
     * Deprecated: use serviceAccountRef.Audiences instead
     *
     * @default a single audience `vault` it not specified.
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken#audiences
     */
    readonly audiences?: string[];
    /**
     * Optional expiration time in seconds that will be used to request a temporary
     * Kubernetes service account token for the service account referenced by
     * `serviceAccountRef`.
     * Deprecated: this will be removed in the future.
     * Defaults to 10 minutes.
     *
     * @default 10 minutes.
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken#expirationSeconds
     */
    readonly expirationSeconds?: number;
    /**
     * Service account field containing the name of a kubernetes ServiceAccount.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken#serviceAccountRef
     */
    readonly serviceAccountRef: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken | undefined): Record<string, any> | undefined;
/**
 * Optional SecretRef that refers to a key in a Secret resource containing JWT token to
 * authenticate with Vault using the JWT/OIDC authentication method.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef | undefined): Record<string, any> | undefined;
/**
 * Optional secret field containing a Kubernetes ServiceAccount JWT used
 * for authenticating with Vault. If a name is specified without a key,
 * `token` is the default. If one is not specified, the one bound to
 * the controller will be used.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef | undefined): Record<string, any> | undefined;
/**
 * Optional service account field containing the name of a kubernetes ServiceAccount.
 * If the service account is specified, the service account secret token JWT will be used
 * for authenticating with Vault. If the service account selector is not supplied,
 * the secretRef will be used instead.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * SecretRef to a key in a Secret resource containing password for the LDAP
 * user used to authenticate with Vault using the LDAP authentication
 * method
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef | undefined): Record<string, any> | undefined;
/**
 * SecretRef to a key in a Secret resource containing password for the
 * user used to authenticate with Vault using the UserPass authentication
 * method
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef | undefined): Record<string, any> | undefined;
/**
 * The SecretAccessKey is used for authentication
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountSelector is a reference to a ServiceAccount resource.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountSelector is a reference to a ServiceAccount resource.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * The AccessKeyID is used for authentication
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef | undefined): Record<string, any> | undefined;
/**
 * The SecretAccessKey is used for authentication
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * The SessionToken used for authentication
 * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
 * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef | undefined): Record<string, any> | undefined;
/**
 * Service account field containing the name of a kubernetes ServiceAccount.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef
 */
export interface ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef' to JSON representation.
 */
export declare function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef(obj: ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * ECRAuthorizationToken uses the GetAuthorizationToken API to retrieve an authorization token.
The authorization token is valid for 12 hours.
The authorizationToken returned is a base64 encoded string that can be decoded
and used in a docker login command to authenticate to a registry.
For more information, see Registry authentication (https://docs.aws.amazon.com/AmazonECR/latest/userguide/Registries.html#registry_auth) in the Amazon Elastic Container Registry User Guide.
 *
 * @schema ECRAuthorizationToken
 */
export declare class EcrAuthorizationToken extends ApiObject {
    /**
     * Returns the apiVersion and kind for "ECRAuthorizationToken"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "ECRAuthorizationToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: EcrAuthorizationTokenProps): any;
    /**
     * Defines a "ECRAuthorizationToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: EcrAuthorizationTokenProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * ECRAuthorizationToken uses the GetAuthorizationToken API to retrieve an authorization token.
 * The authorization token is valid for 12 hours.
 * The authorizationToken returned is a base64 encoded string that can be decoded
 * and used in a docker login command to authenticate to a registry.
 * For more information, see Registry authentication (https://docs.aws.amazon.com/AmazonECR/latest/userguide/Registries.html#registry_auth) in the Amazon Elastic Container Registry User Guide.
 *
 * @schema ECRAuthorizationToken
 */
export interface EcrAuthorizationTokenProps {
    /**
     * @schema ECRAuthorizationToken#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * ECRAuthorizationTokenSpec defines the desired state to generate an AWS ECR authorization token.
     *
     * @schema ECRAuthorizationToken#spec
     */
    readonly spec?: EcrAuthorizationTokenSpec;
}
/**
 * Converts an object of type 'EcrAuthorizationTokenProps' to JSON representation.
 */
export declare function toJson_EcrAuthorizationTokenProps(obj: EcrAuthorizationTokenProps | undefined): Record<string, any> | undefined;
/**
 * ECRAuthorizationTokenSpec defines the desired state to generate an AWS ECR authorization token.
 *
 * @schema EcrAuthorizationTokenSpec
 */
export interface EcrAuthorizationTokenSpec {
    /**
     * Auth defines how to authenticate with AWS
     *
     * @schema EcrAuthorizationTokenSpec#auth
     */
    readonly auth?: EcrAuthorizationTokenSpecAuth;
    /**
     * Region specifies the region to operate in.
     *
     * @schema EcrAuthorizationTokenSpec#region
     */
    readonly region: string;
    /**
     * You can assume a role before making calls to the
     * desired AWS service.
     *
     * @schema EcrAuthorizationTokenSpec#role
     */
    readonly role?: string;
    /**
     * Scope specifies the ECR service scope.
     * Valid options are private and public.
     *
     * @schema EcrAuthorizationTokenSpec#scope
     */
    readonly scope?: string;
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpec' to JSON representation.
 */
export declare function toJson_EcrAuthorizationTokenSpec(obj: EcrAuthorizationTokenSpec | undefined): Record<string, any> | undefined;
/**
 * Auth defines how to authenticate with AWS
 *
 * @schema EcrAuthorizationTokenSpecAuth
 */
export interface EcrAuthorizationTokenSpecAuth {
    /**
     * AWSJWTAuth provides configuration to authenticate against AWS using service account tokens.
     *
     * @schema EcrAuthorizationTokenSpecAuth#jwt
     */
    readonly jwt?: EcrAuthorizationTokenSpecAuthJwt;
    /**
     * AWSAuthSecretRef holds secret references for AWS credentials
     * both AccessKeyID and SecretAccessKey must be defined in order to properly authenticate.
     *
     * @schema EcrAuthorizationTokenSpecAuth#secretRef
     */
    readonly secretRef?: EcrAuthorizationTokenSpecAuthSecretRef;
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuth' to JSON representation.
 */
export declare function toJson_EcrAuthorizationTokenSpecAuth(obj: EcrAuthorizationTokenSpecAuth | undefined): Record<string, any> | undefined;
/**
 * AWSJWTAuth provides configuration to authenticate against AWS using service account tokens.
 *
 * @schema EcrAuthorizationTokenSpecAuthJwt
 */
export interface EcrAuthorizationTokenSpecAuthJwt {
    /**
     * ServiceAccountSelector is a reference to a ServiceAccount resource.
     *
     * @schema EcrAuthorizationTokenSpecAuthJwt#serviceAccountRef
     */
    readonly serviceAccountRef?: EcrAuthorizationTokenSpecAuthJwtServiceAccountRef;
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthJwt' to JSON representation.
 */
export declare function toJson_EcrAuthorizationTokenSpecAuthJwt(obj: EcrAuthorizationTokenSpecAuthJwt | undefined): Record<string, any> | undefined;
/**
 * AWSAuthSecretRef holds secret references for AWS credentials
 * both AccessKeyID and SecretAccessKey must be defined in order to properly authenticate.
 *
 * @schema EcrAuthorizationTokenSpecAuthSecretRef
 */
export interface EcrAuthorizationTokenSpecAuthSecretRef {
    /**
     * The AccessKeyID is used for authentication
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRef#accessKeyIDSecretRef
     */
    readonly accessKeyIdSecretRef?: EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef;
    /**
     * The SecretAccessKey is used for authentication
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRef#secretAccessKeySecretRef
     */
    readonly secretAccessKeySecretRef?: EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef;
    /**
     * The SessionToken used for authentication
     * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
     * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRef#sessionTokenSecretRef
     */
    readonly sessionTokenSecretRef?: EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef;
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthSecretRef' to JSON representation.
 */
export declare function toJson_EcrAuthorizationTokenSpecAuthSecretRef(obj: EcrAuthorizationTokenSpecAuthSecretRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountSelector is a reference to a ServiceAccount resource.
 *
 * @schema EcrAuthorizationTokenSpecAuthJwtServiceAccountRef
 */
export interface EcrAuthorizationTokenSpecAuthJwtServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema EcrAuthorizationTokenSpecAuthJwtServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema EcrAuthorizationTokenSpecAuthJwtServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema EcrAuthorizationTokenSpecAuthJwtServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthJwtServiceAccountRef' to JSON representation.
 */
export declare function toJson_EcrAuthorizationTokenSpecAuthJwtServiceAccountRef(obj: EcrAuthorizationTokenSpecAuthJwtServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * The AccessKeyID is used for authentication
 *
 * @schema EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef
 */
export interface EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
export declare function toJson_EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj: EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef | undefined): Record<string, any> | undefined;
/**
 * The SecretAccessKey is used for authentication
 *
 * @schema EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef
 */
export interface EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
export declare function toJson_EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj: EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * The SessionToken used for authentication
 * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
 * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
 *
 * @schema EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef
 */
export interface EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef' to JSON representation.
 */
export declare function toJson_EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef(obj: EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef | undefined): Record<string, any> | undefined;
/**
 * Fake generator is used for testing. It lets you define
a static set of credentials that is always returned.
 *
 * @schema Fake
 */
export declare class Fake extends ApiObject {
    /**
     * Returns the apiVersion and kind for "Fake"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "Fake".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: FakeProps): any;
    /**
     * Defines a "Fake" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: FakeProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * Fake generator is used for testing. It lets you define
 * a static set of credentials that is always returned.
 *
 * @schema Fake
 */
export interface FakeProps {
    /**
     * @schema Fake#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * FakeSpec contains the static data.
     *
     * @schema Fake#spec
     */
    readonly spec?: FakeSpec;
}
/**
 * Converts an object of type 'FakeProps' to JSON representation.
 */
export declare function toJson_FakeProps(obj: FakeProps | undefined): Record<string, any> | undefined;
/**
 * FakeSpec contains the static data.
 *
 * @schema FakeSpec
 */
export interface FakeSpec {
    /**
     * Used to select the correct ESO controller (think: ingress.ingressClassName)
     * The ESO controller is instantiated with a specific controller name and filters VDS based on this property
     *
     * @schema FakeSpec#controller
     */
    readonly controller?: string;
    /**
     * Data defines the static data returned
     * by this generator.
     *
     * @schema FakeSpec#data
     */
    readonly data?: {
        [key: string]: string;
    };
}
/**
 * Converts an object of type 'FakeSpec' to JSON representation.
 */
export declare function toJson_FakeSpec(obj: FakeSpec | undefined): Record<string, any> | undefined;
/**
 * GCRAccessToken generates an GCP access token
that can be used to authenticate with GCR.
 *
 * @schema GCRAccessToken
 */
export declare class GcrAccessToken extends ApiObject {
    /**
     * Returns the apiVersion and kind for "GCRAccessToken"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "GCRAccessToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: GcrAccessTokenProps): any;
    /**
     * Defines a "GCRAccessToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: GcrAccessTokenProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * GCRAccessToken generates an GCP access token
 * that can be used to authenticate with GCR.
 *
 * @schema GCRAccessToken
 */
export interface GcrAccessTokenProps {
    /**
     * @schema GCRAccessToken#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * GCRAccessTokenSpec defines the desired state to generate a Google Container Registry access token.
     *
     * @schema GCRAccessToken#spec
     */
    readonly spec?: GcrAccessTokenSpec;
}
/**
 * Converts an object of type 'GcrAccessTokenProps' to JSON representation.
 */
export declare function toJson_GcrAccessTokenProps(obj: GcrAccessTokenProps | undefined): Record<string, any> | undefined;
/**
 * GCRAccessTokenSpec defines the desired state to generate a Google Container Registry access token.
 *
 * @schema GcrAccessTokenSpec
 */
export interface GcrAccessTokenSpec {
    /**
     * Auth defines the means for authenticating with GCP
     *
     * @schema GcrAccessTokenSpec#auth
     */
    readonly auth: GcrAccessTokenSpecAuth;
    /**
     * ProjectID defines which project to use to authenticate with
     *
     * @schema GcrAccessTokenSpec#projectID
     */
    readonly projectId: string;
}
/**
 * Converts an object of type 'GcrAccessTokenSpec' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpec(obj: GcrAccessTokenSpec | undefined): Record<string, any> | undefined;
/**
 * Auth defines the means for authenticating with GCP
 *
 * @schema GcrAccessTokenSpecAuth
 */
export interface GcrAccessTokenSpecAuth {
    /**
     * GCPSMAuthSecretRef defines the reference to a secret containing Google Cloud Platform credentials.
     *
     * @schema GcrAccessTokenSpecAuth#secretRef
     */
    readonly secretRef?: GcrAccessTokenSpecAuthSecretRef;
    /**
     * GCPWorkloadIdentity defines the configuration for using GCP Workload Identity authentication.
     *
     * @schema GcrAccessTokenSpecAuth#workloadIdentity
     */
    readonly workloadIdentity?: GcrAccessTokenSpecAuthWorkloadIdentity;
    /**
     * GCPWorkloadIdentityFederation holds the configurations required for generating federated access tokens.
     *
     * @schema GcrAccessTokenSpecAuth#workloadIdentityFederation
     */
    readonly workloadIdentityFederation?: GcrAccessTokenSpecAuthWorkloadIdentityFederation;
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuth' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpecAuth(obj: GcrAccessTokenSpecAuth | undefined): Record<string, any> | undefined;
/**
 * GCPSMAuthSecretRef defines the reference to a secret containing Google Cloud Platform credentials.
 *
 * @schema GcrAccessTokenSpecAuthSecretRef
 */
export interface GcrAccessTokenSpecAuthSecretRef {
    /**
     * The SecretAccessKey is used for authentication
     *
     * @schema GcrAccessTokenSpecAuthSecretRef#secretAccessKeySecretRef
     */
    readonly secretAccessKeySecretRef?: GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef;
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthSecretRef' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpecAuthSecretRef(obj: GcrAccessTokenSpecAuthSecretRef | undefined): Record<string, any> | undefined;
/**
 * GCPWorkloadIdentity defines the configuration for using GCP Workload Identity authentication.
 *
 * @schema GcrAccessTokenSpecAuthWorkloadIdentity
 */
export interface GcrAccessTokenSpecAuthWorkloadIdentity {
    /**
     * @schema GcrAccessTokenSpecAuthWorkloadIdentity#clusterLocation
     */
    readonly clusterLocation: string;
    /**
     * @schema GcrAccessTokenSpecAuthWorkloadIdentity#clusterName
     */
    readonly clusterName: string;
    /**
     * @schema GcrAccessTokenSpecAuthWorkloadIdentity#clusterProjectID
     */
    readonly clusterProjectId?: string;
    /**
     * ServiceAccountSelector is a reference to a ServiceAccount resource.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentity#serviceAccountRef
     */
    readonly serviceAccountRef: GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef;
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthWorkloadIdentity' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpecAuthWorkloadIdentity(obj: GcrAccessTokenSpecAuthWorkloadIdentity | undefined): Record<string, any> | undefined;
/**
 * GCPWorkloadIdentityFederation holds the configurations required for generating federated access tokens.
 *
 * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederation
 */
export interface GcrAccessTokenSpecAuthWorkloadIdentityFederation {
    /**
     * audience is the Secure Token Service (STS) audience which contains the resource name for the workload identity pool and the provider identifier in that pool.
     * If specified, Audience found in the external account credential config will be overridden with the configured value.
     * audience must be provided when serviceAccountRef or awsSecurityCredentials is configured.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederation#audience
     */
    readonly audience?: string;
    /**
     * awsSecurityCredentials is for configuring AWS region and credentials to use for obtaining the access token,
     * when using the AWS metadata server is not an option.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederation#awsSecurityCredentials
     */
    readonly awsSecurityCredentials?: GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials;
    /**
     * credConfig holds the configmap reference containing the GCP external account credential configuration in JSON format and the key name containing the json data.
     * For using Kubernetes cluster as the identity provider, use serviceAccountRef instead. Operators mounted serviceaccount token cannot be used as the token source, instead
     * serviceAccountRef must be used by providing operators service account details.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederation#credConfig
     */
    readonly credConfig?: GcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig;
    /**
     * externalTokenEndpoint is the endpoint explicitly set up to provide tokens, which will be matched against the
     * credential_source.url in the provided credConfig. This field is merely to double-check the external token source
     * URL is having the expected value.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederation#externalTokenEndpoint
     */
    readonly externalTokenEndpoint?: string;
    /**
     * serviceAccountRef is the reference to the kubernetes ServiceAccount to be used for obtaining the tokens,
     * when Kubernetes is configured as provider in workload identity pool.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederation#serviceAccountRef
     */
    readonly serviceAccountRef?: GcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef;
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthWorkloadIdentityFederation' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpecAuthWorkloadIdentityFederation(obj: GcrAccessTokenSpecAuthWorkloadIdentityFederation | undefined): Record<string, any> | undefined;
/**
 * The SecretAccessKey is used for authentication
 *
 * @schema GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef
 */
export interface GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj: GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountSelector is a reference to a ServiceAccount resource.
 *
 * @schema GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef
 */
export interface GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj: GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * awsSecurityCredentials is for configuring AWS region and credentials to use for obtaining the access token,
 * when using the AWS metadata server is not an option.
 *
 * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials
 */
export interface GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials {
    /**
     * awsCredentialsSecretRef is the reference to the secret which holds the AWS credentials.
     * Secret should be created with below names for keys
     * - aws_access_key_id: Access Key ID, which is the unique identifier for the AWS account or the IAM user.
     * - aws_secret_access_key: Secret Access Key, which is used to authenticate requests made to AWS services.
     * - aws_session_token: Session Token, is the short-lived token to authenticate requests made to AWS services.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials#awsCredentialsSecretRef
     */
    readonly awsCredentialsSecretRef: GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef;
    /**
     * region is for configuring the AWS region to be used.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials#region
     */
    readonly region: string;
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials(obj: GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentials | undefined): Record<string, any> | undefined;
/**
 * credConfig holds the configmap reference containing the GCP external account credential configuration in JSON format and the key name containing the json data.
 * For using Kubernetes cluster as the identity provider, use serviceAccountRef instead. Operators mounted serviceaccount token cannot be used as the token source, instead
 * serviceAccountRef must be used by providing operators service account details.
 *
 * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig
 */
export interface GcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig {
    /**
     * key name holding the external account credential config.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig#key
     */
    readonly key: string;
    /**
     * name of the configmap.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig#name
     */
    readonly name: string;
    /**
     * namespace in which the configmap exists. If empty, configmap will looked up in local namespace.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig(obj: GcrAccessTokenSpecAuthWorkloadIdentityFederationCredConfig | undefined): Record<string, any> | undefined;
/**
 * serviceAccountRef is the reference to the kubernetes ServiceAccount to be used for obtaining the tokens,
 * when Kubernetes is configured as provider in workload identity pool.
 *
 * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef
 */
export interface GcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef(obj: GcrAccessTokenSpecAuthWorkloadIdentityFederationServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * awsCredentialsSecretRef is the reference to the secret which holds the AWS credentials.
 * Secret should be created with below names for keys
 * - aws_access_key_id: Access Key ID, which is the unique identifier for the AWS account or the IAM user.
 * - aws_secret_access_key: Secret Access Key, which is used to authenticate requests made to AWS services.
 * - aws_session_token: Session Token, is the short-lived token to authenticate requests made to AWS services.
 *
 * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef
 */
export interface GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef {
    /**
     * name of the secret.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef#name
     */
    readonly name: string;
    /**
     * namespace in which the secret exists. If empty, secret will looked up in local namespace.
     *
     * @schema GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef' to JSON representation.
 */
export declare function toJson_GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef(obj: GcrAccessTokenSpecAuthWorkloadIdentityFederationAwsSecurityCredentialsAwsCredentialsSecretRef | undefined): Record<string, any> | undefined;
/**
 * GeneratorState represents the state created and managed by a generator resource.
 *
 * @schema GeneratorState
 */
export declare class GeneratorState extends ApiObject {
    /**
     * Returns the apiVersion and kind for "GeneratorState"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "GeneratorState".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: GeneratorStateProps): any;
    /**
     * Defines a "GeneratorState" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: GeneratorStateProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * GeneratorState represents the state created and managed by a generator resource.
 *
 * @schema GeneratorState
 */
export interface GeneratorStateProps {
    /**
     * @schema GeneratorState#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * GeneratorStateSpec defines the desired state of a generator state resource.
     *
     * @schema GeneratorState#spec
     */
    readonly spec?: GeneratorStateSpec;
}
/**
 * Converts an object of type 'GeneratorStateProps' to JSON representation.
 */
export declare function toJson_GeneratorStateProps(obj: GeneratorStateProps | undefined): Record<string, any> | undefined;
/**
 * GeneratorStateSpec defines the desired state of a generator state resource.
 *
 * @schema GeneratorStateSpec
 */
export interface GeneratorStateSpec {
    /**
     * GarbageCollectionDeadline is the time after which the generator state
     * will be deleted.
     * It is set by the controller which creates the generator state and
     * can be set configured by the user.
     * If the garbage collection deadline is not set the generator state will not be deleted.
     *
     * @schema GeneratorStateSpec#garbageCollectionDeadline
     */
    readonly garbageCollectionDeadline?: Date;
    /**
     * Resource is the generator manifest that produced the state.
     * It is a snapshot of the generator manifest at the time the state was produced.
     * This manifest will be used to delete the resource. Any configuration that is referenced
     * in the manifest should be available at the time of garbage collection. If that is not the case deletion will
     * be blocked by a finalizer.
     *
     * @schema GeneratorStateSpec#resource
     */
    readonly resource: any;
    /**
     * State is the state that was produced by the generator implementation.
     *
     * @schema GeneratorStateSpec#state
     */
    readonly state: any;
}
/**
 * Converts an object of type 'GeneratorStateSpec' to JSON representation.
 */
export declare function toJson_GeneratorStateSpec(obj: GeneratorStateSpec | undefined): Record<string, any> | undefined;
/**
 * GithubAccessToken generates ghs_ accessToken
 *
 * @schema GithubAccessToken
 */
export declare class GithubAccessToken extends ApiObject {
    /**
     * Returns the apiVersion and kind for "GithubAccessToken"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "GithubAccessToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: GithubAccessTokenProps): any;
    /**
     * Defines a "GithubAccessToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: GithubAccessTokenProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * GithubAccessToken generates ghs_ accessToken
 *
 * @schema GithubAccessToken
 */
export interface GithubAccessTokenProps {
    /**
     * @schema GithubAccessToken#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * GithubAccessTokenSpec defines the desired state to generate a GitHub access token.
     *
     * @schema GithubAccessToken#spec
     */
    readonly spec?: GithubAccessTokenSpec;
}
/**
 * Converts an object of type 'GithubAccessTokenProps' to JSON representation.
 */
export declare function toJson_GithubAccessTokenProps(obj: GithubAccessTokenProps | undefined): Record<string, any> | undefined;
/**
 * GithubAccessTokenSpec defines the desired state to generate a GitHub access token.
 *
 * @schema GithubAccessTokenSpec
 */
export interface GithubAccessTokenSpec {
    /**
     * @schema GithubAccessTokenSpec#appID
     */
    readonly appId: string;
    /**
     * Auth configures how ESO authenticates with a Github instance.
     *
     * @schema GithubAccessTokenSpec#auth
     */
    readonly auth: GithubAccessTokenSpecAuth;
    /**
     * @schema GithubAccessTokenSpec#installID
     */
    readonly installId: string;
    /**
     * Map of permissions the token will have. If omitted, defaults to all permissions the GitHub App has.
     *
     * @schema GithubAccessTokenSpec#permissions
     */
    readonly permissions?: {
        [key: string]: string;
    };
    /**
     * List of repositories the token will have access to. If omitted, defaults to all repositories the GitHub App
     * is installed to.
     *
     * @schema GithubAccessTokenSpec#repositories
     */
    readonly repositories?: string[];
    /**
     * URL configures the GitHub instance URL. Defaults to https://github.com/.
     *
     * @default https://github.com/.
     * @schema GithubAccessTokenSpec#url
     */
    readonly url?: string;
}
/**
 * Converts an object of type 'GithubAccessTokenSpec' to JSON representation.
 */
export declare function toJson_GithubAccessTokenSpec(obj: GithubAccessTokenSpec | undefined): Record<string, any> | undefined;
/**
 * Auth configures how ESO authenticates with a Github instance.
 *
 * @schema GithubAccessTokenSpecAuth
 */
export interface GithubAccessTokenSpecAuth {
    /**
     * GithubSecretRef references a secret containing GitHub credentials.
     *
     * @schema GithubAccessTokenSpecAuth#privateKey
     */
    readonly privateKey: GithubAccessTokenSpecAuthPrivateKey;
}
/**
 * Converts an object of type 'GithubAccessTokenSpecAuth' to JSON representation.
 */
export declare function toJson_GithubAccessTokenSpecAuth(obj: GithubAccessTokenSpecAuth | undefined): Record<string, any> | undefined;
/**
 * GithubSecretRef references a secret containing GitHub credentials.
 *
 * @schema GithubAccessTokenSpecAuthPrivateKey
 */
export interface GithubAccessTokenSpecAuthPrivateKey {
    /**
     * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
     * In some instances, `key` is a required field.
     *
     * @schema GithubAccessTokenSpecAuthPrivateKey#secretRef
     */
    readonly secretRef: GithubAccessTokenSpecAuthPrivateKeySecretRef;
}
/**
 * Converts an object of type 'GithubAccessTokenSpecAuthPrivateKey' to JSON representation.
 */
export declare function toJson_GithubAccessTokenSpecAuthPrivateKey(obj: GithubAccessTokenSpecAuthPrivateKey | undefined): Record<string, any> | undefined;
/**
 * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
 * In some instances, `key` is a required field.
 *
 * @schema GithubAccessTokenSpecAuthPrivateKeySecretRef
 */
export interface GithubAccessTokenSpecAuthPrivateKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema GithubAccessTokenSpecAuthPrivateKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema GithubAccessTokenSpecAuthPrivateKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema GithubAccessTokenSpecAuthPrivateKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'GithubAccessTokenSpecAuthPrivateKeySecretRef' to JSON representation.
 */
export declare function toJson_GithubAccessTokenSpecAuthPrivateKeySecretRef(obj: GithubAccessTokenSpecAuthPrivateKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * Grafana represents a generator for Grafana service account tokens.
 *
 * @schema Grafana
 */
export declare class Grafana extends ApiObject {
    /**
     * Returns the apiVersion and kind for "Grafana"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "Grafana".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: GrafanaProps): any;
    /**
     * Defines a "Grafana" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: GrafanaProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * Grafana represents a generator for Grafana service account tokens.
 *
 * @schema Grafana
 */
export interface GrafanaProps {
    /**
     * @schema Grafana#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * GrafanaSpec controls the behavior of the grafana generator.
     *
     * @schema Grafana#spec
     */
    readonly spec?: GrafanaSpec;
}
/**
 * Converts an object of type 'GrafanaProps' to JSON representation.
 */
export declare function toJson_GrafanaProps(obj: GrafanaProps | undefined): Record<string, any> | undefined;
/**
 * GrafanaSpec controls the behavior of the grafana generator.
 *
 * @schema GrafanaSpec
 */
export interface GrafanaSpec {
    /**
     * Auth is the authentication configuration to authenticate
     * against the Grafana instance.
     *
     * @schema GrafanaSpec#auth
     */
    readonly auth: GrafanaSpecAuth;
    /**
     * ServiceAccount is the configuration for the service account that
     * is supposed to be generated by the generator.
     *
     * @schema GrafanaSpec#serviceAccount
     */
    readonly serviceAccount: GrafanaSpecServiceAccount;
    /**
     * URL is the URL of the Grafana instance.
     *
     * @schema GrafanaSpec#url
     */
    readonly url: string;
}
/**
 * Converts an object of type 'GrafanaSpec' to JSON representation.
 */
export declare function toJson_GrafanaSpec(obj: GrafanaSpec | undefined): Record<string, any> | undefined;
/**
 * Auth is the authentication configuration to authenticate
 * against the Grafana instance.
 *
 * @schema GrafanaSpecAuth
 */
export interface GrafanaSpecAuth {
    /**
     * Basic auth credentials used to authenticate against the Grafana instance.
     * Note: you need a token which has elevated permissions to create service accounts.
     * See here for the documentation on basic roles offered by Grafana:
     * https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/access-control/rbac-fixed-basic-role-definitions/
     *
     * @schema GrafanaSpecAuth#basic
     */
    readonly basic?: GrafanaSpecAuthBasic;
    /**
     * A service account token used to authenticate against the Grafana instance.
     * Note: you need a token which has elevated permissions to create service accounts.
     * See here for the documentation on basic roles offered by Grafana:
     * https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/access-control/rbac-fixed-basic-role-definitions/
     *
     * @schema GrafanaSpecAuth#token
     */
    readonly token?: GrafanaSpecAuthToken;
}
/**
 * Converts an object of type 'GrafanaSpecAuth' to JSON representation.
 */
export declare function toJson_GrafanaSpecAuth(obj: GrafanaSpecAuth | undefined): Record<string, any> | undefined;
/**
 * ServiceAccount is the configuration for the service account that
 * is supposed to be generated by the generator.
 *
 * @schema GrafanaSpecServiceAccount
 */
export interface GrafanaSpecServiceAccount {
    /**
     * Name is the name of the service account that will be created by ESO.
     *
     * @schema GrafanaSpecServiceAccount#name
     */
    readonly name: string;
    /**
     * Role is the role of the service account.
     * See here for the documentation on basic roles offered by Grafana:
     * https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/access-control/rbac-fixed-basic-role-definitions/
     *
     * @schema GrafanaSpecServiceAccount#role
     */
    readonly role: string;
}
/**
 * Converts an object of type 'GrafanaSpecServiceAccount' to JSON representation.
 */
export declare function toJson_GrafanaSpecServiceAccount(obj: GrafanaSpecServiceAccount | undefined): Record<string, any> | undefined;
/**
 * Basic auth credentials used to authenticate against the Grafana instance.
 * Note: you need a token which has elevated permissions to create service accounts.
 * See here for the documentation on basic roles offered by Grafana:
 * https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/access-control/rbac-fixed-basic-role-definitions/
 *
 * @schema GrafanaSpecAuthBasic
 */
export interface GrafanaSpecAuthBasic {
    /**
     * A basic auth password used to authenticate against the Grafana instance.
     *
     * @schema GrafanaSpecAuthBasic#password
     */
    readonly password: GrafanaSpecAuthBasicPassword;
    /**
     * A basic auth username used to authenticate against the Grafana instance.
     *
     * @schema GrafanaSpecAuthBasic#username
     */
    readonly username: string;
}
/**
 * Converts an object of type 'GrafanaSpecAuthBasic' to JSON representation.
 */
export declare function toJson_GrafanaSpecAuthBasic(obj: GrafanaSpecAuthBasic | undefined): Record<string, any> | undefined;
/**
 * A service account token used to authenticate against the Grafana instance.
 * Note: you need a token which has elevated permissions to create service accounts.
 * See here for the documentation on basic roles offered by Grafana:
 * https://grafana.com/docs/grafana/latest/administration/roles-and-permissions/access-control/rbac-fixed-basic-role-definitions/
 *
 * @schema GrafanaSpecAuthToken
 */
export interface GrafanaSpecAuthToken {
    /**
     * The key where the token is found.
     *
     * @schema GrafanaSpecAuthToken#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema GrafanaSpecAuthToken#name
     */
    readonly name?: string;
}
/**
 * Converts an object of type 'GrafanaSpecAuthToken' to JSON representation.
 */
export declare function toJson_GrafanaSpecAuthToken(obj: GrafanaSpecAuthToken | undefined): Record<string, any> | undefined;
/**
 * A basic auth password used to authenticate against the Grafana instance.
 *
 * @schema GrafanaSpecAuthBasicPassword
 */
export interface GrafanaSpecAuthBasicPassword {
    /**
     * The key where the token is found.
     *
     * @schema GrafanaSpecAuthBasicPassword#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema GrafanaSpecAuthBasicPassword#name
     */
    readonly name?: string;
}
/**
 * Converts an object of type 'GrafanaSpecAuthBasicPassword' to JSON representation.
 */
export declare function toJson_GrafanaSpecAuthBasicPassword(obj: GrafanaSpecAuthBasicPassword | undefined): Record<string, any> | undefined;
/**
 * MFA generates a new TOTP token that is compliant with RFC 6238.
 *
 * @schema MFA
 */
export declare class Mfa extends ApiObject {
    /**
     * Returns the apiVersion and kind for "MFA"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "MFA".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: MfaProps): any;
    /**
     * Defines a "MFA" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: MfaProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * MFA generates a new TOTP token that is compliant with RFC 6238.
 *
 * @schema MFA
 */
export interface MfaProps {
    /**
     * @schema MFA#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * MFASpec controls the behavior of the mfa generator.
     *
     * @schema MFA#spec
     */
    readonly spec?: MfaSpec;
}
/**
 * Converts an object of type 'MfaProps' to JSON representation.
 */
export declare function toJson_MfaProps(obj: MfaProps | undefined): Record<string, any> | undefined;
/**
 * MFASpec controls the behavior of the mfa generator.
 *
 * @schema MfaSpec
 */
export interface MfaSpec {
    /**
     * Algorithm to use for encoding. Defaults to SHA1 as per the RFC.
     *
     * @default SHA1 as per the RFC.
     * @schema MfaSpec#algorithm
     */
    readonly algorithm?: string;
    /**
     * Length defines the token length. Defaults to 6 characters.
     *
     * @default 6 characters.
     * @schema MfaSpec#length
     */
    readonly length?: number;
    /**
     * Secret is a secret selector to a secret containing the seed secret to generate the TOTP value from.
     *
     * @schema MfaSpec#secret
     */
    readonly secret: MfaSpecSecret;
    /**
     * TimePeriod defines how long the token can be active. Defaults to 30 seconds.
     *
     * @default 30 seconds.
     * @schema MfaSpec#timePeriod
     */
    readonly timePeriod?: number;
    /**
     * When defines a time parameter that can be used to pin the origin time of the generated token.
     *
     * @schema MfaSpec#when
     */
    readonly when?: Date;
}
/**
 * Converts an object of type 'MfaSpec' to JSON representation.
 */
export declare function toJson_MfaSpec(obj: MfaSpec | undefined): Record<string, any> | undefined;
/**
 * Secret is a secret selector to a secret containing the seed secret to generate the TOTP value from.
 *
 * @schema MfaSpecSecret
 */
export interface MfaSpecSecret {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema MfaSpecSecret#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema MfaSpecSecret#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema MfaSpecSecret#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'MfaSpecSecret' to JSON representation.
 */
export declare function toJson_MfaSpecSecret(obj: MfaSpecSecret | undefined): Record<string, any> | undefined;
/**
 * Password generates a random password based on the
configuration parameters in spec.
You can specify the length, characterset and other attributes.
 *
 * @schema Password
 */
export declare class Password extends ApiObject {
    /**
     * Returns the apiVersion and kind for "Password"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "Password".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: PasswordProps): any;
    /**
     * Defines a "Password" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: PasswordProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * Password generates a random password based on the
 * configuration parameters in spec.
 * You can specify the length, characterset and other attributes.
 *
 * @schema Password
 */
export interface PasswordProps {
    /**
     * @schema Password#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * PasswordSpec controls the behavior of the password generator.
     *
     * @schema Password#spec
     */
    readonly spec?: PasswordSpec;
}
/**
 * Converts an object of type 'PasswordProps' to JSON representation.
 */
export declare function toJson_PasswordProps(obj: PasswordProps | undefined): Record<string, any> | undefined;
/**
 * PasswordSpec controls the behavior of the password generator.
 *
 * @schema PasswordSpec
 */
export interface PasswordSpec {
    /**
     * set AllowRepeat to true to allow repeating characters.
     *
     * @schema PasswordSpec#allowRepeat
     */
    readonly allowRepeat: boolean;
    /**
     * Digits specifies the number of digits in the generated
     * password. If omitted it defaults to 25% of the length of the password
     *
     * @schema PasswordSpec#digits
     */
    readonly digits?: number;
    /**
     * Encoding specifies the encoding of the generated password.
     * Valid values are:
     * - "raw" (default): no encoding
     * - "base64": standard base64 encoding
     * - "base64url": base64url encoding
     * - "base32": base32 encoding
     * - "hex": hexadecimal encoding
     *
     * @schema PasswordSpec#encoding
     */
    readonly encoding?: PasswordSpecEncoding;
    /**
     * Length of the password to be generated.
     * Defaults to 24
     *
     * @default 24
     * @schema PasswordSpec#length
     */
    readonly length: number;
    /**
     * Set NoUpper to disable uppercase characters
     *
     * @schema PasswordSpec#noUpper
     */
    readonly noUpper: boolean;
    /**
     * SecretKeys defines the keys that will be populated with generated passwords.
     * Defaults to "password" when not set.
     *
     * @default password" when not set.
     * @schema PasswordSpec#secretKeys
     */
    readonly secretKeys?: string[];
    /**
     * SymbolCharacters specifies the special characters that should be used
     * in the generated password.
     *
     * @schema PasswordSpec#symbolCharacters
     */
    readonly symbolCharacters?: string;
    /**
     * Symbols specifies the number of symbol characters in the generated
     * password. If omitted it defaults to 25% of the length of the password
     *
     * @schema PasswordSpec#symbols
     */
    readonly symbols?: number;
}
/**
 * Converts an object of type 'PasswordSpec' to JSON representation.
 */
export declare function toJson_PasswordSpec(obj: PasswordSpec | undefined): Record<string, any> | undefined;
/**
 * Encoding specifies the encoding of the generated password.
 * Valid values are:
 * - "raw" (default): no encoding
 * - "base64": standard base64 encoding
 * - "base64url": base64url encoding
 * - "base32": base32 encoding
 * - "hex": hexadecimal encoding
 *
 * @schema PasswordSpecEncoding
 */
export declare enum PasswordSpecEncoding {
    /** base64 */
    BASE64 = "base64",
    /** base64url */
    BASE64URL = "base64url",
    /** base32 */
    BASE32 = "base32",
    /** hex */
    HEX = "hex",
    /** raw */
    RAW = "raw"
}
/**
 * QuayAccessToken generates Quay oauth token for pulling/pushing images
 *
 * @schema QuayAccessToken
 */
export declare class QuayAccessToken extends ApiObject {
    /**
     * Returns the apiVersion and kind for "QuayAccessToken"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "QuayAccessToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: QuayAccessTokenProps): any;
    /**
     * Defines a "QuayAccessToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: QuayAccessTokenProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * QuayAccessToken generates Quay oauth token for pulling/pushing images
 *
 * @schema QuayAccessToken
 */
export interface QuayAccessTokenProps {
    /**
     * @schema QuayAccessToken#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * QuayAccessTokenSpec defines the desired state to generate a Quay access token.
     *
     * @schema QuayAccessToken#spec
     */
    readonly spec?: QuayAccessTokenSpec;
}
/**
 * Converts an object of type 'QuayAccessTokenProps' to JSON representation.
 */
export declare function toJson_QuayAccessTokenProps(obj: QuayAccessTokenProps | undefined): Record<string, any> | undefined;
/**
 * QuayAccessTokenSpec defines the desired state to generate a Quay access token.
 *
 * @schema QuayAccessTokenSpec
 */
export interface QuayAccessTokenSpec {
    /**
     * Name of the robot account you are federating with
     *
     * @schema QuayAccessTokenSpec#robotAccount
     */
    readonly robotAccount: string;
    /**
     * Name of the service account you are federating with
     *
     * @schema QuayAccessTokenSpec#serviceAccountRef
     */
    readonly serviceAccountRef: QuayAccessTokenSpecServiceAccountRef;
    /**
     * URL configures the Quay instance URL. Defaults to quay.io.
     *
     * @default quay.io.
     * @schema QuayAccessTokenSpec#url
     */
    readonly url?: string;
}
/**
 * Converts an object of type 'QuayAccessTokenSpec' to JSON representation.
 */
export declare function toJson_QuayAccessTokenSpec(obj: QuayAccessTokenSpec | undefined): Record<string, any> | undefined;
/**
 * Name of the service account you are federating with
 *
 * @schema QuayAccessTokenSpecServiceAccountRef
 */
export interface QuayAccessTokenSpecServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema QuayAccessTokenSpecServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema QuayAccessTokenSpecServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema QuayAccessTokenSpecServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'QuayAccessTokenSpecServiceAccountRef' to JSON representation.
 */
export declare function toJson_QuayAccessTokenSpecServiceAccountRef(obj: QuayAccessTokenSpecServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * SSHKey generates SSH key pairs.
 *
 * @schema SSHKey
 */
export declare class SshKey extends ApiObject {
    /**
     * Returns the apiVersion and kind for "SSHKey"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "SSHKey".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: SshKeyProps): any;
    /**
     * Defines a "SSHKey" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: SshKeyProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * SSHKey generates SSH key pairs.
 *
 * @schema SSHKey
 */
export interface SshKeyProps {
    /**
     * @schema SSHKey#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * SSHKeySpec controls the behavior of the ssh key generator.
     *
     * @schema SSHKey#spec
     */
    readonly spec?: SshKeySpec;
}
/**
 * Converts an object of type 'SshKeyProps' to JSON representation.
 */
export declare function toJson_SshKeyProps(obj: SshKeyProps | undefined): Record<string, any> | undefined;
/**
 * SSHKeySpec controls the behavior of the ssh key generator.
 *
 * @schema SshKeySpec
 */
export interface SshKeySpec {
    /**
     * Comment specifies an optional comment for the SSH key
     *
     * @schema SshKeySpec#comment
     */
    readonly comment?: string;
    /**
     * KeySize specifies the key size for RSA keys (default: 2048) and ECDSA keys (default: 256).
     * For RSA keys: 2048, 3072, 4096
     * For ECDSA keys: 256, 384, 521
     * Ignored for ed25519 keys
     *
     * @schema SshKeySpec#keySize
     */
    readonly keySize?: number;
    /**
     * KeyType specifies the SSH key type (rsa, ecdsa, ed25519)
     *
     * @schema SshKeySpec#keyType
     */
    readonly keyType?: SshKeySpecKeyType;
}
/**
 * Converts an object of type 'SshKeySpec' to JSON representation.
 */
export declare function toJson_SshKeySpec(obj: SshKeySpec | undefined): Record<string, any> | undefined;
/**
 * KeyType specifies the SSH key type (rsa, ecdsa, ed25519)
 *
 * @schema SshKeySpecKeyType
 */
export declare enum SshKeySpecKeyType {
    /** rsa */
    RSA = "rsa",
    /** ecdsa */
    ECDSA = "ecdsa",
    /** ed25519 */
    ED25519 = "ed25519"
}
/**
 * STSSessionToken uses the GetSessionToken API to retrieve an authorization token.
The authorization token is valid for 12 hours.
The authorizationToken returned is a base64 encoded string that can be decoded.
For more information, see GetSessionToken (https://docs.aws.amazon.com/STS/latest/APIReference/API_GetSessionToken.html).
 *
 * @schema STSSessionToken
 */
export declare class StsSessionToken extends ApiObject {
    /**
     * Returns the apiVersion and kind for "STSSessionToken"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "STSSessionToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: StsSessionTokenProps): any;
    /**
     * Defines a "STSSessionToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: StsSessionTokenProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * STSSessionToken uses the GetSessionToken API to retrieve an authorization token.
 * The authorization token is valid for 12 hours.
 * The authorizationToken returned is a base64 encoded string that can be decoded.
 * For more information, see GetSessionToken (https://docs.aws.amazon.com/STS/latest/APIReference/API_GetSessionToken.html).
 *
 * @schema STSSessionToken
 */
export interface StsSessionTokenProps {
    /**
     * @schema STSSessionToken#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * STSSessionTokenSpec defines the desired state to generate an AWS STS session token.
     *
     * @schema STSSessionToken#spec
     */
    readonly spec?: StsSessionTokenSpec;
}
/**
 * Converts an object of type 'StsSessionTokenProps' to JSON representation.
 */
export declare function toJson_StsSessionTokenProps(obj: StsSessionTokenProps | undefined): Record<string, any> | undefined;
/**
 * STSSessionTokenSpec defines the desired state to generate an AWS STS session token.
 *
 * @schema StsSessionTokenSpec
 */
export interface StsSessionTokenSpec {
    /**
     * Auth defines how to authenticate with AWS
     *
     * @schema StsSessionTokenSpec#auth
     */
    readonly auth?: StsSessionTokenSpecAuth;
    /**
     * Region specifies the region to operate in.
     *
     * @schema StsSessionTokenSpec#region
     */
    readonly region: string;
    /**
     * RequestParameters contains parameters that can be passed to the STS service.
     *
     * @schema StsSessionTokenSpec#requestParameters
     */
    readonly requestParameters?: StsSessionTokenSpecRequestParameters;
    /**
     * You can assume a role before making calls to the
     * desired AWS service.
     *
     * @schema StsSessionTokenSpec#role
     */
    readonly role?: string;
}
/**
 * Converts an object of type 'StsSessionTokenSpec' to JSON representation.
 */
export declare function toJson_StsSessionTokenSpec(obj: StsSessionTokenSpec | undefined): Record<string, any> | undefined;
/**
 * Auth defines how to authenticate with AWS
 *
 * @schema StsSessionTokenSpecAuth
 */
export interface StsSessionTokenSpecAuth {
    /**
     * AWSJWTAuth provides configuration to authenticate against AWS using service account tokens.
     *
     * @schema StsSessionTokenSpecAuth#jwt
     */
    readonly jwt?: StsSessionTokenSpecAuthJwt;
    /**
     * AWSAuthSecretRef holds secret references for AWS credentials
     * both AccessKeyID and SecretAccessKey must be defined in order to properly authenticate.
     *
     * @schema StsSessionTokenSpecAuth#secretRef
     */
    readonly secretRef?: StsSessionTokenSpecAuthSecretRef;
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuth' to JSON representation.
 */
export declare function toJson_StsSessionTokenSpecAuth(obj: StsSessionTokenSpecAuth | undefined): Record<string, any> | undefined;
/**
 * RequestParameters contains parameters that can be passed to the STS service.
 *
 * @schema StsSessionTokenSpecRequestParameters
 */
export interface StsSessionTokenSpecRequestParameters {
    /**
     * SerialNumber is the identification number of the MFA device that is associated with the IAM user who is making
     * the GetSessionToken call.
     * Possible values: hardware device (such as GAHT12345678) or an Amazon Resource Name (ARN) for a virtual device
     * (such as arn:aws:iam::123456789012:mfa/user)
     *
     * @schema StsSessionTokenSpecRequestParameters#serialNumber
     */
    readonly serialNumber?: string;
    /**
     * @schema StsSessionTokenSpecRequestParameters#sessionDuration
     */
    readonly sessionDuration?: number;
    /**
     * TokenCode is the value provided by the MFA device, if MFA is required.
     *
     * @schema StsSessionTokenSpecRequestParameters#tokenCode
     */
    readonly tokenCode?: string;
}
/**
 * Converts an object of type 'StsSessionTokenSpecRequestParameters' to JSON representation.
 */
export declare function toJson_StsSessionTokenSpecRequestParameters(obj: StsSessionTokenSpecRequestParameters | undefined): Record<string, any> | undefined;
/**
 * AWSJWTAuth provides configuration to authenticate against AWS using service account tokens.
 *
 * @schema StsSessionTokenSpecAuthJwt
 */
export interface StsSessionTokenSpecAuthJwt {
    /**
     * ServiceAccountSelector is a reference to a ServiceAccount resource.
     *
     * @schema StsSessionTokenSpecAuthJwt#serviceAccountRef
     */
    readonly serviceAccountRef?: StsSessionTokenSpecAuthJwtServiceAccountRef;
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthJwt' to JSON representation.
 */
export declare function toJson_StsSessionTokenSpecAuthJwt(obj: StsSessionTokenSpecAuthJwt | undefined): Record<string, any> | undefined;
/**
 * AWSAuthSecretRef holds secret references for AWS credentials
 * both AccessKeyID and SecretAccessKey must be defined in order to properly authenticate.
 *
 * @schema StsSessionTokenSpecAuthSecretRef
 */
export interface StsSessionTokenSpecAuthSecretRef {
    /**
     * The AccessKeyID is used for authentication
     *
     * @schema StsSessionTokenSpecAuthSecretRef#accessKeyIDSecretRef
     */
    readonly accessKeyIdSecretRef?: StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef;
    /**
     * The SecretAccessKey is used for authentication
     *
     * @schema StsSessionTokenSpecAuthSecretRef#secretAccessKeySecretRef
     */
    readonly secretAccessKeySecretRef?: StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef;
    /**
     * The SessionToken used for authentication
     * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
     * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
     *
     * @schema StsSessionTokenSpecAuthSecretRef#sessionTokenSecretRef
     */
    readonly sessionTokenSecretRef?: StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef;
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthSecretRef' to JSON representation.
 */
export declare function toJson_StsSessionTokenSpecAuthSecretRef(obj: StsSessionTokenSpecAuthSecretRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountSelector is a reference to a ServiceAccount resource.
 *
 * @schema StsSessionTokenSpecAuthJwtServiceAccountRef
 */
export interface StsSessionTokenSpecAuthJwtServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema StsSessionTokenSpecAuthJwtServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema StsSessionTokenSpecAuthJwtServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema StsSessionTokenSpecAuthJwtServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthJwtServiceAccountRef' to JSON representation.
 */
export declare function toJson_StsSessionTokenSpecAuthJwtServiceAccountRef(obj: StsSessionTokenSpecAuthJwtServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * The AccessKeyID is used for authentication
 *
 * @schema StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef
 */
export interface StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
export declare function toJson_StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj: StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef | undefined): Record<string, any> | undefined;
/**
 * The SecretAccessKey is used for authentication
 *
 * @schema StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef
 */
export interface StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
export declare function toJson_StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj: StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * The SessionToken used for authentication
 * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
 * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
 *
 * @schema StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef
 */
export interface StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef' to JSON representation.
 */
export declare function toJson_StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef(obj: StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef | undefined): Record<string, any> | undefined;
/**
 * UUID generates a version 1 UUID (e56657e3-764f-11ef-a397-65231a88c216).
 *
 * @schema UUID
 */
export declare class Uuid extends ApiObject {
    /**
     * Returns the apiVersion and kind for "UUID"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "UUID".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: UuidProps): any;
    /**
     * Defines a "UUID" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: UuidProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * UUID generates a version 1 UUID (e56657e3-764f-11ef-a397-65231a88c216).
 *
 * @schema UUID
 */
export interface UuidProps {
    /**
     * @schema UUID#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * UUIDSpec controls the behavior of the uuid generator.
     *
     * @schema UUID#spec
     */
    readonly spec?: any;
}
/**
 * Converts an object of type 'UuidProps' to JSON representation.
 */
export declare function toJson_UuidProps(obj: UuidProps | undefined): Record<string, any> | undefined;
/**
 * VaultDynamicSecret represents a generator that can create dynamic secrets from HashiCorp Vault.
 *
 * @schema VaultDynamicSecret
 */
export declare class VaultDynamicSecret extends ApiObject {
    /**
     * Returns the apiVersion and kind for "VaultDynamicSecret"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "VaultDynamicSecret".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: VaultDynamicSecretProps): any;
    /**
     * Defines a "VaultDynamicSecret" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: VaultDynamicSecretProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * VaultDynamicSecret represents a generator that can create dynamic secrets from HashiCorp Vault.
 *
 * @schema VaultDynamicSecret
 */
export interface VaultDynamicSecretProps {
    /**
     * @schema VaultDynamicSecret#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * VaultDynamicSecretSpec defines the desired spec of VaultDynamicSecret.
     *
     * @schema VaultDynamicSecret#spec
     */
    readonly spec?: VaultDynamicSecretSpec;
}
/**
 * Converts an object of type 'VaultDynamicSecretProps' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretProps(obj: VaultDynamicSecretProps | undefined): Record<string, any> | undefined;
/**
 * VaultDynamicSecretSpec defines the desired spec of VaultDynamicSecret.
 *
 * @schema VaultDynamicSecretSpec
 */
export interface VaultDynamicSecretSpec {
    /**
     * Do not fail if no secrets are found. Useful for requests where no data is expected.
     *
     * @schema VaultDynamicSecretSpec#allowEmptyResponse
     */
    readonly allowEmptyResponse?: boolean;
    /**
     * Used to select the correct ESO controller (think: ingress.ingressClassName)
     * The ESO controller is instantiated with a specific controller name and filters VDS based on this property
     *
     * @schema VaultDynamicSecretSpec#controller
     */
    readonly controller?: string;
    /**
     * Vault API method to use (GET/POST/other)
     *
     * @schema VaultDynamicSecretSpec#method
     */
    readonly method?: string;
    /**
     * Parameters to pass to Vault write (for non-GET methods)
     *
     * @schema VaultDynamicSecretSpec#parameters
     */
    readonly parameters?: any;
    /**
     * Vault path to obtain the dynamic secret from
     *
     * @schema VaultDynamicSecretSpec#path
     */
    readonly path: string;
    /**
     * Vault provider common spec
     *
     * @schema VaultDynamicSecretSpec#provider
     */
    readonly provider: VaultDynamicSecretSpecProvider;
    /**
     * Result type defines which data is returned from the generator.
     * By default, it is the "data" section of the Vault API response.
     * When using e.g. /auth/token/create the "data" section is empty but
     * the "auth" section contains the generated token.
     * Please refer to the vault docs regarding the result data structure.
     * Additionally, accessing the raw response is possibly by using "Raw" result type.
     *
     * @schema VaultDynamicSecretSpec#resultType
     */
    readonly resultType?: VaultDynamicSecretSpecResultType;
    /**
     * Used to configure http retries if failed
     *
     * @schema VaultDynamicSecretSpec#retrySettings
     */
    readonly retrySettings?: VaultDynamicSecretSpecRetrySettings;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpec' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpec(obj: VaultDynamicSecretSpec | undefined): Record<string, any> | undefined;
/**
 * Vault provider common spec
 *
 * @schema VaultDynamicSecretSpecProvider
 */
export interface VaultDynamicSecretSpecProvider {
    /**
     * Auth configures how secret-manager authenticates with the Vault server.
     *
     * @schema VaultDynamicSecretSpecProvider#auth
     */
    readonly auth?: VaultDynamicSecretSpecProviderAuth;
    /**
     * PEM encoded CA bundle used to validate Vault server certificate. Only used
     * if the Server URL is using HTTPS protocol. This parameter is ignored for
     * plain HTTP protocol connection. If not set the system root certificates
     * are used to validate the TLS connection.
     *
     * @schema VaultDynamicSecretSpecProvider#caBundle
     */
    readonly caBundle?: string;
    /**
     * The provider for the CA bundle to use to validate Vault server certificate.
     *
     * @schema VaultDynamicSecretSpecProvider#caProvider
     */
    readonly caProvider?: VaultDynamicSecretSpecProviderCaProvider;
    /**
     * CheckAndSet defines the Check-And-Set (CAS) settings for PushSecret operations.
     * Only applies to Vault KV v2 stores. When enabled, write operations must include
     * the current version of the secret to prevent unintentional overwrites.
     *
     * @schema VaultDynamicSecretSpecProvider#checkAndSet
     */
    readonly checkAndSet?: VaultDynamicSecretSpecProviderCheckAndSet;
    /**
     * ForwardInconsistent tells Vault to forward read-after-write requests to the Vault
     * leader instead of simply retrying within a loop. This can increase performance if
     * the option is enabled serverside.
     * https://www.vaultproject.io/docs/configuration/replication#allow_forwarding_via_header
     *
     * @schema VaultDynamicSecretSpecProvider#forwardInconsistent
     */
    readonly forwardInconsistent?: boolean;
    /**
     * Headers to be added in Vault request
     *
     * @schema VaultDynamicSecretSpecProvider#headers
     */
    readonly headers?: {
        [key: string]: string;
    };
    /**
     * Name of the vault namespace. Namespaces is a set of features within Vault Enterprise that allows
     * Vault environments to support Secure Multi-tenancy. e.g: "ns1".
     * More about namespaces can be found here https://www.vaultproject.io/docs/enterprise/namespaces
     *
     * @schema VaultDynamicSecretSpecProvider#namespace
     */
    readonly namespace?: string;
    /**
     * Path is the mount path of the Vault KV backend endpoint, e.g:
     * "secret". The v2 KV secret engine version specific "/data" path suffix
     * for fetching secrets from Vault is optional and will be appended
     * if not present in specified path.
     *
     * @schema VaultDynamicSecretSpecProvider#path
     */
    readonly path?: string;
    /**
     * ReadYourWrites ensures isolated read-after-write semantics by
     * providing discovered cluster replication states in each request.
     * More information about eventual consistency in Vault can be found here
     * https://www.vaultproject.io/docs/enterprise/consistency
     *
     * @schema VaultDynamicSecretSpecProvider#readYourWrites
     */
    readonly readYourWrites?: boolean;
    /**
     * Server is the connection address for the Vault server, e.g: "https://vault.example.com:8200".
     *
     * @schema VaultDynamicSecretSpecProvider#server
     */
    readonly server: string;
    /**
     * The configuration used for client side related TLS communication, when the Vault server
     * requires mutual authentication. Only used if the Server URL is using HTTPS protocol.
     * This parameter is ignored for plain HTTP protocol connection.
     * It's worth noting this configuration is different from the "TLS certificates auth method",
     * which is available under the `auth.cert` section.
     *
     * @schema VaultDynamicSecretSpecProvider#tls
     */
    readonly tls?: VaultDynamicSecretSpecProviderTls;
    /**
     * Version is the Vault KV secret engine version. This can be either "v1" or
     * "v2". Version defaults to "v2".
     *
     * @schema VaultDynamicSecretSpecProvider#version
     */
    readonly version?: VaultDynamicSecretSpecProviderVersion;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProvider' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProvider(obj: VaultDynamicSecretSpecProvider | undefined): Record<string, any> | undefined;
/**
 * Result type defines which data is returned from the generator.
 * By default, it is the "data" section of the Vault API response.
 * When using e.g. /auth/token/create the "data" section is empty but
 * the "auth" section contains the generated token.
 * Please refer to the vault docs regarding the result data structure.
 * Additionally, accessing the raw response is possibly by using "Raw" result type.
 *
 * @schema VaultDynamicSecretSpecResultType
 */
export declare enum VaultDynamicSecretSpecResultType {
    /** Data */
    DATA = "Data",
    /** Auth */
    AUTH = "Auth",
    /** Raw */
    RAW = "Raw"
}
/**
 * Used to configure http retries if failed
 *
 * @schema VaultDynamicSecretSpecRetrySettings
 */
export interface VaultDynamicSecretSpecRetrySettings {
    /**
     * @schema VaultDynamicSecretSpecRetrySettings#maxRetries
     */
    readonly maxRetries?: number;
    /**
     * @schema VaultDynamicSecretSpecRetrySettings#retryInterval
     */
    readonly retryInterval?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecRetrySettings' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecRetrySettings(obj: VaultDynamicSecretSpecRetrySettings | undefined): Record<string, any> | undefined;
/**
 * Auth configures how secret-manager authenticates with the Vault server.
 *
 * @schema VaultDynamicSecretSpecProviderAuth
 */
export interface VaultDynamicSecretSpecProviderAuth {
    /**
     * AppRole authenticates with Vault using the App Role auth mechanism,
     * with the role and secret stored in a Kubernetes Secret resource.
     *
     * @schema VaultDynamicSecretSpecProviderAuth#appRole
     */
    readonly appRole?: VaultDynamicSecretSpecProviderAuthAppRole;
    /**
     * Cert authenticates with TLS Certificates by passing client certificate, private key and ca certificate
     * Cert authentication method
     *
     * @schema VaultDynamicSecretSpecProviderAuth#cert
     */
    readonly cert?: VaultDynamicSecretSpecProviderAuthCert;
    /**
     * Gcp authenticates with Vault using Google Cloud Platform authentication method
     * GCP authentication method
     *
     * @schema VaultDynamicSecretSpecProviderAuth#gcp
     */
    readonly gcp?: VaultDynamicSecretSpecProviderAuthGcp;
    /**
     * Iam authenticates with vault by passing a special AWS request signed with AWS IAM credentials
     * AWS IAM authentication method
     *
     * @schema VaultDynamicSecretSpecProviderAuth#iam
     */
    readonly iam?: VaultDynamicSecretSpecProviderAuthIam;
    /**
     * Jwt authenticates with Vault by passing role and JWT token using the
     * JWT/OIDC authentication method
     *
     * @schema VaultDynamicSecretSpecProviderAuth#jwt
     */
    readonly jwt?: VaultDynamicSecretSpecProviderAuthJwt;
    /**
     * Kubernetes authenticates with Vault by passing the ServiceAccount
     * token stored in the named Secret resource to the Vault server.
     *
     * @schema VaultDynamicSecretSpecProviderAuth#kubernetes
     */
    readonly kubernetes?: VaultDynamicSecretSpecProviderAuthKubernetes;
    /**
     * Ldap authenticates with Vault by passing username/password pair using
     * the LDAP authentication method
     *
     * @schema VaultDynamicSecretSpecProviderAuth#ldap
     */
    readonly ldap?: VaultDynamicSecretSpecProviderAuthLdap;
    /**
     * Name of the vault namespace to authenticate to. This can be different than the namespace your secret is in.
     * Namespaces is a set of features within Vault Enterprise that allows
     * Vault environments to support Secure Multi-tenancy. e.g: "ns1".
     * More about namespaces can be found here https://www.vaultproject.io/docs/enterprise/namespaces
     * This will default to Vault.Namespace field if set, or empty otherwise
     *
     * @schema VaultDynamicSecretSpecProviderAuth#namespace
     */
    readonly namespace?: string;
    /**
     * TokenSecretRef authenticates with Vault by presenting a token.
     *
     * @schema VaultDynamicSecretSpecProviderAuth#tokenSecretRef
     */
    readonly tokenSecretRef?: VaultDynamicSecretSpecProviderAuthTokenSecretRef;
    /**
     * UserPass authenticates with Vault by passing username/password pair
     *
     * @schema VaultDynamicSecretSpecProviderAuth#userPass
     */
    readonly userPass?: VaultDynamicSecretSpecProviderAuthUserPass;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuth' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuth(obj: VaultDynamicSecretSpecProviderAuth | undefined): Record<string, any> | undefined;
/**
 * The provider for the CA bundle to use to validate Vault server certificate.
 *
 * @schema VaultDynamicSecretSpecProviderCaProvider
 */
export interface VaultDynamicSecretSpecProviderCaProvider {
    /**
     * The key where the CA certificate can be found in the Secret or ConfigMap.
     *
     * @schema VaultDynamicSecretSpecProviderCaProvider#key
     */
    readonly key?: string;
    /**
     * The name of the object located at the provider type.
     *
     * @schema VaultDynamicSecretSpecProviderCaProvider#name
     */
    readonly name: string;
    /**
     * The namespace the Provider type is in.
     * Can only be defined when used in a ClusterSecretStore.
     *
     * @schema VaultDynamicSecretSpecProviderCaProvider#namespace
     */
    readonly namespace?: string;
    /**
     * The type of provider to use such as "Secret", or "ConfigMap".
     *
     * @schema VaultDynamicSecretSpecProviderCaProvider#type
     */
    readonly type: VaultDynamicSecretSpecProviderCaProviderType;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderCaProvider' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderCaProvider(obj: VaultDynamicSecretSpecProviderCaProvider | undefined): Record<string, any> | undefined;
/**
 * CheckAndSet defines the Check-And-Set (CAS) settings for PushSecret operations.
 * Only applies to Vault KV v2 stores. When enabled, write operations must include
 * the current version of the secret to prevent unintentional overwrites.
 *
 * @schema VaultDynamicSecretSpecProviderCheckAndSet
 */
export interface VaultDynamicSecretSpecProviderCheckAndSet {
    /**
     * Required when true, all write operations must include a check-and-set parameter.
     * This helps prevent unintentional overwrites of secrets.
     *
     * @schema VaultDynamicSecretSpecProviderCheckAndSet#required
     */
    readonly required?: boolean;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderCheckAndSet' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderCheckAndSet(obj: VaultDynamicSecretSpecProviderCheckAndSet | undefined): Record<string, any> | undefined;
/**
 * The configuration used for client side related TLS communication, when the Vault server
 * requires mutual authentication. Only used if the Server URL is using HTTPS protocol.
 * This parameter is ignored for plain HTTP protocol connection.
 * It's worth noting this configuration is different from the "TLS certificates auth method",
 * which is available under the `auth.cert` section.
 *
 * @schema VaultDynamicSecretSpecProviderTls
 */
export interface VaultDynamicSecretSpecProviderTls {
    /**
     * CertSecretRef is a certificate added to the transport layer
     * when communicating with the Vault server.
     * If no key for the Secret is specified, external-secret will default to 'tls.crt'.
     *
     * @schema VaultDynamicSecretSpecProviderTls#certSecretRef
     */
    readonly certSecretRef?: VaultDynamicSecretSpecProviderTlsCertSecretRef;
    /**
     * KeySecretRef to a key in a Secret resource containing client private key
     * added to the transport layer when communicating with the Vault server.
     * If no key for the Secret is specified, external-secret will default to 'tls.key'.
     *
     * @schema VaultDynamicSecretSpecProviderTls#keySecretRef
     */
    readonly keySecretRef?: VaultDynamicSecretSpecProviderTlsKeySecretRef;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderTls' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderTls(obj: VaultDynamicSecretSpecProviderTls | undefined): Record<string, any> | undefined;
/**
 * Version is the Vault KV secret engine version. This can be either "v1" or
 * "v2". Version defaults to "v2".
 *
 * @schema VaultDynamicSecretSpecProviderVersion
 */
export declare enum VaultDynamicSecretSpecProviderVersion {
    /** v1 */
    V1 = "v1",
    /** v2 */
    V2 = "v2"
}
/**
 * AppRole authenticates with Vault using the App Role auth mechanism,
 * with the role and secret stored in a Kubernetes Secret resource.
 *
 * @schema VaultDynamicSecretSpecProviderAuthAppRole
 */
export interface VaultDynamicSecretSpecProviderAuthAppRole {
    /**
     * Path where the App Role authentication backend is mounted
     * in Vault, e.g: "approle"
     *
     * @schema VaultDynamicSecretSpecProviderAuthAppRole#path
     */
    readonly path: string;
    /**
     * RoleID configured in the App Role authentication backend when setting
     * up the authentication backend in Vault.
     *
     * @schema VaultDynamicSecretSpecProviderAuthAppRole#roleId
     */
    readonly roleId?: string;
    /**
     * Reference to a key in a Secret that contains the App Role ID used
     * to authenticate with Vault.
     * The `key` field must be specified and denotes which entry within the Secret
     * resource is used as the app role id.
     *
     * @schema VaultDynamicSecretSpecProviderAuthAppRole#roleRef
     */
    readonly roleRef?: VaultDynamicSecretSpecProviderAuthAppRoleRoleRef;
    /**
     * Reference to a key in a Secret that contains the App Role secret used
     * to authenticate with Vault.
     * The `key` field must be specified and denotes which entry within the Secret
     * resource is used as the app role secret.
     *
     * @schema VaultDynamicSecretSpecProviderAuthAppRole#secretRef
     */
    readonly secretRef: VaultDynamicSecretSpecProviderAuthAppRoleSecretRef;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthAppRole' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthAppRole(obj: VaultDynamicSecretSpecProviderAuthAppRole | undefined): Record<string, any> | undefined;
/**
 * Cert authenticates with TLS Certificates by passing client certificate, private key and ca certificate
 * Cert authentication method
 *
 * @schema VaultDynamicSecretSpecProviderAuthCert
 */
export interface VaultDynamicSecretSpecProviderAuthCert {
    /**
     * ClientCert is a certificate to authenticate using the Cert Vault
     * authentication method
     *
     * @schema VaultDynamicSecretSpecProviderAuthCert#clientCert
     */
    readonly clientCert?: VaultDynamicSecretSpecProviderAuthCertClientCert;
    /**
     * Path where the Certificate authentication backend is mounted
     * in Vault, e.g: "cert"
     *
     * @schema VaultDynamicSecretSpecProviderAuthCert#path
     */
    readonly path?: string;
    /**
     * SecretRef to a key in a Secret resource containing client private key to
     * authenticate with Vault using the Cert authentication method
     *
     * @schema VaultDynamicSecretSpecProviderAuthCert#secretRef
     */
    readonly secretRef?: VaultDynamicSecretSpecProviderAuthCertSecretRef;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthCert' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthCert(obj: VaultDynamicSecretSpecProviderAuthCert | undefined): Record<string, any> | undefined;
/**
 * Gcp authenticates with Vault using Google Cloud Platform authentication method
 * GCP authentication method
 *
 * @schema VaultDynamicSecretSpecProviderAuthGcp
 */
export interface VaultDynamicSecretSpecProviderAuthGcp {
    /**
     * Location optionally defines a location/region for the secret
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcp#location
     */
    readonly location?: string;
    /**
     * Path where the GCP auth method is enabled in Vault, e.g: "gcp"
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcp#path
     */
    readonly path?: string;
    /**
     * Project ID of the Google Cloud Platform project
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcp#projectID
     */
    readonly projectId?: string;
    /**
     * Vault Role. In Vault, a role describes an identity with a set of permissions, groups, or policies you want to attach to a user of the secrets engine.
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcp#role
     */
    readonly role: string;
    /**
     * Specify credentials in a Secret object
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcp#secretRef
     */
    readonly secretRef?: VaultDynamicSecretSpecProviderAuthGcpSecretRef;
    /**
     * ServiceAccountRef to a service account for impersonation
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcp#serviceAccountRef
     */
    readonly serviceAccountRef?: VaultDynamicSecretSpecProviderAuthGcpServiceAccountRef;
    /**
     * Specify a service account with Workload Identity
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcp#workloadIdentity
     */
    readonly workloadIdentity?: VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthGcp' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthGcp(obj: VaultDynamicSecretSpecProviderAuthGcp | undefined): Record<string, any> | undefined;
/**
 * Iam authenticates with vault by passing a special AWS request signed with AWS IAM credentials
 * AWS IAM authentication method
 *
 * @schema VaultDynamicSecretSpecProviderAuthIam
 */
export interface VaultDynamicSecretSpecProviderAuthIam {
    /**
     * AWS External ID set on assumed IAM roles
     *
     * @schema VaultDynamicSecretSpecProviderAuthIam#externalID
     */
    readonly externalId?: string;
    /**
     * Specify a service account with IRSA enabled
     *
     * @schema VaultDynamicSecretSpecProviderAuthIam#jwt
     */
    readonly jwt?: VaultDynamicSecretSpecProviderAuthIamJwt;
    /**
     * Path where the AWS auth method is enabled in Vault, e.g: "aws"
     *
     * @schema VaultDynamicSecretSpecProviderAuthIam#path
     */
    readonly path?: string;
    /**
     * AWS region
     *
     * @schema VaultDynamicSecretSpecProviderAuthIam#region
     */
    readonly region?: string;
    /**
     * This is the AWS role to be assumed before talking to vault
     *
     * @schema VaultDynamicSecretSpecProviderAuthIam#role
     */
    readonly role?: string;
    /**
     * Specify credentials in a Secret object
     *
     * @schema VaultDynamicSecretSpecProviderAuthIam#secretRef
     */
    readonly secretRef?: VaultDynamicSecretSpecProviderAuthIamSecretRef;
    /**
     * X-Vault-AWS-IAM-Server-ID is an additional header used by Vault IAM auth method to mitigate against different types of replay attacks. More details here: https://developer.hashicorp.com/vault/docs/auth/aws
     *
     * @schema VaultDynamicSecretSpecProviderAuthIam#vaultAwsIamServerID
     */
    readonly vaultAwsIamServerId?: string;
    /**
     * Vault Role. In vault, a role describes an identity with a set of permissions, groups, or policies you want to attach a user of the secrets engine
     *
     * @schema VaultDynamicSecretSpecProviderAuthIam#vaultRole
     */
    readonly vaultRole: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIam' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthIam(obj: VaultDynamicSecretSpecProviderAuthIam | undefined): Record<string, any> | undefined;
/**
 * Jwt authenticates with Vault by passing role and JWT token using the
 * JWT/OIDC authentication method
 *
 * @schema VaultDynamicSecretSpecProviderAuthJwt
 */
export interface VaultDynamicSecretSpecProviderAuthJwt {
    /**
     * Optional ServiceAccountToken specifies the Kubernetes service account for which to request
     * a token for with the `TokenRequest` API.
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwt#kubernetesServiceAccountToken
     */
    readonly kubernetesServiceAccountToken?: VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken;
    /**
     * Path where the JWT authentication backend is mounted
     * in Vault, e.g: "jwt"
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwt#path
     */
    readonly path: string;
    /**
     * Role is a JWT role to authenticate using the JWT/OIDC Vault
     * authentication method
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwt#role
     */
    readonly role?: string;
    /**
     * Optional SecretRef that refers to a key in a Secret resource containing JWT token to
     * authenticate with Vault using the JWT/OIDC authentication method.
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwt#secretRef
     */
    readonly secretRef?: VaultDynamicSecretSpecProviderAuthJwtSecretRef;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthJwt' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthJwt(obj: VaultDynamicSecretSpecProviderAuthJwt | undefined): Record<string, any> | undefined;
/**
 * Kubernetes authenticates with Vault by passing the ServiceAccount
 * token stored in the named Secret resource to the Vault server.
 *
 * @schema VaultDynamicSecretSpecProviderAuthKubernetes
 */
export interface VaultDynamicSecretSpecProviderAuthKubernetes {
    /**
     * Path where the Kubernetes authentication backend is mounted in Vault, e.g:
     * "kubernetes"
     *
     * @schema VaultDynamicSecretSpecProviderAuthKubernetes#mountPath
     */
    readonly mountPath: string;
    /**
     * A required field containing the Vault Role to assume. A Role binds a
     * Kubernetes ServiceAccount with a set of Vault policies.
     *
     * @schema VaultDynamicSecretSpecProviderAuthKubernetes#role
     */
    readonly role: string;
    /**
     * Optional secret field containing a Kubernetes ServiceAccount JWT used
     * for authenticating with Vault. If a name is specified without a key,
     * `token` is the default. If one is not specified, the one bound to
     * the controller will be used.
     *
     * @schema VaultDynamicSecretSpecProviderAuthKubernetes#secretRef
     */
    readonly secretRef?: VaultDynamicSecretSpecProviderAuthKubernetesSecretRef;
    /**
     * Optional service account field containing the name of a kubernetes ServiceAccount.
     * If the service account is specified, the service account secret token JWT will be used
     * for authenticating with Vault. If the service account selector is not supplied,
     * the secretRef will be used instead.
     *
     * @schema VaultDynamicSecretSpecProviderAuthKubernetes#serviceAccountRef
     */
    readonly serviceAccountRef?: VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthKubernetes' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthKubernetes(obj: VaultDynamicSecretSpecProviderAuthKubernetes | undefined): Record<string, any> | undefined;
/**
 * Ldap authenticates with Vault by passing username/password pair using
 * the LDAP authentication method
 *
 * @schema VaultDynamicSecretSpecProviderAuthLdap
 */
export interface VaultDynamicSecretSpecProviderAuthLdap {
    /**
     * Path where the LDAP authentication backend is mounted
     * in Vault, e.g: "ldap"
     *
     * @schema VaultDynamicSecretSpecProviderAuthLdap#path
     */
    readonly path: string;
    /**
     * SecretRef to a key in a Secret resource containing password for the LDAP
     * user used to authenticate with Vault using the LDAP authentication
     * method
     *
     * @schema VaultDynamicSecretSpecProviderAuthLdap#secretRef
     */
    readonly secretRef?: VaultDynamicSecretSpecProviderAuthLdapSecretRef;
    /**
     * Username is an LDAP username used to authenticate using the LDAP Vault
     * authentication method
     *
     * @schema VaultDynamicSecretSpecProviderAuthLdap#username
     */
    readonly username: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthLdap' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthLdap(obj: VaultDynamicSecretSpecProviderAuthLdap | undefined): Record<string, any> | undefined;
/**
 * TokenSecretRef authenticates with Vault by presenting a token.
 *
 * @schema VaultDynamicSecretSpecProviderAuthTokenSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthTokenSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthTokenSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthTokenSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthTokenSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthTokenSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthTokenSecretRef(obj: VaultDynamicSecretSpecProviderAuthTokenSecretRef | undefined): Record<string, any> | undefined;
/**
 * UserPass authenticates with Vault by passing username/password pair
 *
 * @schema VaultDynamicSecretSpecProviderAuthUserPass
 */
export interface VaultDynamicSecretSpecProviderAuthUserPass {
    /**
     * Path where the UserPassword authentication backend is mounted
     * in Vault, e.g: "userpass"
     *
     * @schema VaultDynamicSecretSpecProviderAuthUserPass#path
     */
    readonly path: string;
    /**
     * SecretRef to a key in a Secret resource containing password for the
     * user used to authenticate with Vault using the UserPass authentication
     * method
     *
     * @schema VaultDynamicSecretSpecProviderAuthUserPass#secretRef
     */
    readonly secretRef?: VaultDynamicSecretSpecProviderAuthUserPassSecretRef;
    /**
     * Username is a username used to authenticate using the UserPass Vault
     * authentication method
     *
     * @schema VaultDynamicSecretSpecProviderAuthUserPass#username
     */
    readonly username: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthUserPass' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthUserPass(obj: VaultDynamicSecretSpecProviderAuthUserPass | undefined): Record<string, any> | undefined;
/**
 * The type of provider to use such as "Secret", or "ConfigMap".
 *
 * @schema VaultDynamicSecretSpecProviderCaProviderType
 */
export declare enum VaultDynamicSecretSpecProviderCaProviderType {
    /** Secret */
    SECRET = "Secret",
    /** ConfigMap */
    CONFIG_MAP = "ConfigMap"
}
/**
 * CertSecretRef is a certificate added to the transport layer
 * when communicating with the Vault server.
 * If no key for the Secret is specified, external-secret will default to 'tls.crt'.
 *
 * @schema VaultDynamicSecretSpecProviderTlsCertSecretRef
 */
export interface VaultDynamicSecretSpecProviderTlsCertSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderTlsCertSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderTlsCertSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderTlsCertSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderTlsCertSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderTlsCertSecretRef(obj: VaultDynamicSecretSpecProviderTlsCertSecretRef | undefined): Record<string, any> | undefined;
/**
 * KeySecretRef to a key in a Secret resource containing client private key
 * added to the transport layer when communicating with the Vault server.
 * If no key for the Secret is specified, external-secret will default to 'tls.key'.
 *
 * @schema VaultDynamicSecretSpecProviderTlsKeySecretRef
 */
export interface VaultDynamicSecretSpecProviderTlsKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderTlsKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderTlsKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderTlsKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderTlsKeySecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderTlsKeySecretRef(obj: VaultDynamicSecretSpecProviderTlsKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * Reference to a key in a Secret that contains the App Role ID used
 * to authenticate with Vault.
 * The `key` field must be specified and denotes which entry within the Secret
 * resource is used as the app role id.
 *
 * @schema VaultDynamicSecretSpecProviderAuthAppRoleRoleRef
 */
export interface VaultDynamicSecretSpecProviderAuthAppRoleRoleRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthAppRoleRoleRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthAppRoleRoleRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthAppRoleRoleRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthAppRoleRoleRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthAppRoleRoleRef(obj: VaultDynamicSecretSpecProviderAuthAppRoleRoleRef | undefined): Record<string, any> | undefined;
/**
 * Reference to a key in a Secret that contains the App Role secret used
 * to authenticate with Vault.
 * The `key` field must be specified and denotes which entry within the Secret
 * resource is used as the app role secret.
 *
 * @schema VaultDynamicSecretSpecProviderAuthAppRoleSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthAppRoleSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthAppRoleSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthAppRoleSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthAppRoleSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthAppRoleSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthAppRoleSecretRef(obj: VaultDynamicSecretSpecProviderAuthAppRoleSecretRef | undefined): Record<string, any> | undefined;
/**
 * ClientCert is a certificate to authenticate using the Cert Vault
 * authentication method
 *
 * @schema VaultDynamicSecretSpecProviderAuthCertClientCert
 */
export interface VaultDynamicSecretSpecProviderAuthCertClientCert {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthCertClientCert#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthCertClientCert#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthCertClientCert#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthCertClientCert' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthCertClientCert(obj: VaultDynamicSecretSpecProviderAuthCertClientCert | undefined): Record<string, any> | undefined;
/**
 * SecretRef to a key in a Secret resource containing client private key to
 * authenticate with Vault using the Cert authentication method
 *
 * @schema VaultDynamicSecretSpecProviderAuthCertSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthCertSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthCertSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthCertSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthCertSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthCertSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthCertSecretRef(obj: VaultDynamicSecretSpecProviderAuthCertSecretRef | undefined): Record<string, any> | undefined;
/**
 * Specify credentials in a Secret object
 *
 * @schema VaultDynamicSecretSpecProviderAuthGcpSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthGcpSecretRef {
    /**
     * The SecretAccessKey is used for authentication
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpSecretRef#secretAccessKeySecretRef
     */
    readonly secretAccessKeySecretRef?: VaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthGcpSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthGcpSecretRef(obj: VaultDynamicSecretSpecProviderAuthGcpSecretRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountRef to a service account for impersonation
 *
 * @schema VaultDynamicSecretSpecProviderAuthGcpServiceAccountRef
 */
export interface VaultDynamicSecretSpecProviderAuthGcpServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthGcpServiceAccountRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthGcpServiceAccountRef(obj: VaultDynamicSecretSpecProviderAuthGcpServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * Specify a service account with Workload Identity
 *
 * @schema VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity
 */
export interface VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity {
    /**
     * ClusterLocation is the location of the cluster
     * If not specified, it fetches information from the metadata server
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity#clusterLocation
     */
    readonly clusterLocation?: string;
    /**
     * ClusterName is the name of the cluster
     * If not specified, it fetches information from the metadata server
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity#clusterName
     */
    readonly clusterName?: string;
    /**
     * ClusterProjectID is the project ID of the cluster
     * If not specified, it fetches information from the metadata server
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity#clusterProjectID
     */
    readonly clusterProjectId?: string;
    /**
     * ServiceAccountSelector is a reference to a ServiceAccount resource.
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity#serviceAccountRef
     */
    readonly serviceAccountRef: VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity(obj: VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentity | undefined): Record<string, any> | undefined;
/**
 * Specify a service account with IRSA enabled
 *
 * @schema VaultDynamicSecretSpecProviderAuthIamJwt
 */
export interface VaultDynamicSecretSpecProviderAuthIamJwt {
    /**
     * ServiceAccountSelector is a reference to a ServiceAccount resource.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamJwt#serviceAccountRef
     */
    readonly serviceAccountRef?: VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamJwt' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthIamJwt(obj: VaultDynamicSecretSpecProviderAuthIamJwt | undefined): Record<string, any> | undefined;
/**
 * Specify credentials in a Secret object
 *
 * @schema VaultDynamicSecretSpecProviderAuthIamSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthIamSecretRef {
    /**
     * The AccessKeyID is used for authentication
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRef#accessKeyIDSecretRef
     */
    readonly accessKeyIdSecretRef?: VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef;
    /**
     * The SecretAccessKey is used for authentication
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRef#secretAccessKeySecretRef
     */
    readonly secretAccessKeySecretRef?: VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef;
    /**
     * The SessionToken used for authentication
     * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
     * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRef#sessionTokenSecretRef
     */
    readonly sessionTokenSecretRef?: VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthIamSecretRef(obj: VaultDynamicSecretSpecProviderAuthIamSecretRef | undefined): Record<string, any> | undefined;
/**
 * Optional ServiceAccountToken specifies the Kubernetes service account for which to request
 * a token for with the `TokenRequest` API.
 *
 * @schema VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken
 */
export interface VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken {
    /**
     * Optional audiences field that will be used to request a temporary Kubernetes service
     * account token for the service account referenced by `serviceAccountRef`.
     * Defaults to a single audience `vault` it not specified.
     * Deprecated: use serviceAccountRef.Audiences instead
     *
     * @default a single audience `vault` it not specified.
     * @schema VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken#audiences
     */
    readonly audiences?: string[];
    /**
     * Optional expiration time in seconds that will be used to request a temporary
     * Kubernetes service account token for the service account referenced by
     * `serviceAccountRef`.
     * Deprecated: this will be removed in the future.
     * Defaults to 10 minutes.
     *
     * @default 10 minutes.
     * @schema VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken#expirationSeconds
     */
    readonly expirationSeconds?: number;
    /**
     * Service account field containing the name of a kubernetes ServiceAccount.
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken#serviceAccountRef
     */
    readonly serviceAccountRef: VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken(obj: VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken | undefined): Record<string, any> | undefined;
/**
 * Optional SecretRef that refers to a key in a Secret resource containing JWT token to
 * authenticate with Vault using the JWT/OIDC authentication method.
 *
 * @schema VaultDynamicSecretSpecProviderAuthJwtSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthJwtSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwtSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwtSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwtSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthJwtSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthJwtSecretRef(obj: VaultDynamicSecretSpecProviderAuthJwtSecretRef | undefined): Record<string, any> | undefined;
/**
 * Optional secret field containing a Kubernetes ServiceAccount JWT used
 * for authenticating with Vault. If a name is specified without a key,
 * `token` is the default. If one is not specified, the one bound to
 * the controller will be used.
 *
 * @schema VaultDynamicSecretSpecProviderAuthKubernetesSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthKubernetesSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthKubernetesSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthKubernetesSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthKubernetesSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthKubernetesSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthKubernetesSecretRef(obj: VaultDynamicSecretSpecProviderAuthKubernetesSecretRef | undefined): Record<string, any> | undefined;
/**
 * Optional service account field containing the name of a kubernetes ServiceAccount.
 * If the service account is specified, the service account secret token JWT will be used
 * for authenticating with Vault. If the service account selector is not supplied,
 * the secretRef will be used instead.
 *
 * @schema VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef
 */
export interface VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef(obj: VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * SecretRef to a key in a Secret resource containing password for the LDAP
 * user used to authenticate with Vault using the LDAP authentication
 * method
 *
 * @schema VaultDynamicSecretSpecProviderAuthLdapSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthLdapSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthLdapSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthLdapSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthLdapSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthLdapSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthLdapSecretRef(obj: VaultDynamicSecretSpecProviderAuthLdapSecretRef | undefined): Record<string, any> | undefined;
/**
 * SecretRef to a key in a Secret resource containing password for the
 * user used to authenticate with Vault using the UserPass authentication
 * method
 *
 * @schema VaultDynamicSecretSpecProviderAuthUserPassSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthUserPassSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthUserPassSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthUserPassSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthUserPassSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthUserPassSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthUserPassSecretRef(obj: VaultDynamicSecretSpecProviderAuthUserPassSecretRef | undefined): Record<string, any> | undefined;
/**
 * The SecretAccessKey is used for authentication
 *
 * @schema VaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef(obj: VaultDynamicSecretSpecProviderAuthGcpSecretRefSecretAccessKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountSelector is a reference to a ServiceAccount resource.
 *
 * @schema VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef
 */
export interface VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef(obj: VaultDynamicSecretSpecProviderAuthGcpWorkloadIdentityServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * ServiceAccountSelector is a reference to a ServiceAccount resource.
 *
 * @schema VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef
 */
export interface VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef(obj: VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * The AccessKeyID is used for authentication
 *
 * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef(obj: VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef | undefined): Record<string, any> | undefined;
/**
 * The SecretAccessKey is used for authentication
 *
 * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef(obj: VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef | undefined): Record<string, any> | undefined;
/**
 * The SessionToken used for authentication
 * This must be defined if AccessKeyID and SecretAccessKey are temporary credentials
 * see: https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp_use-resources.html
 *
 * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef
 */
export interface VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef(obj: VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef | undefined): Record<string, any> | undefined;
/**
 * Service account field containing the name of a kubernetes ServiceAccount.
 *
 * @schema VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef
 */
export interface VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef {
    /**
     * Audience specifies the `aud` claim for the service account token
     * If the service account uses a well-known annotation for e.g. IRSA or GCP Workload Identity
     * then this audiences will be appended to the list
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef#audiences
     */
    readonly audiences?: string[];
    /**
     * The name of the ServiceAccount resource being referred to.
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef#name
     */
    readonly name: string;
    /**
     * Namespace of the resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef' to JSON representation.
 */
export declare function toJson_VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef(obj: VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef | undefined): Record<string, any> | undefined;
/**
 * Webhook connects to a third party API server to handle the secrets generation
configuration parameters in spec.
You can specify the server, the token, and additional body parameters.
See documentation for the full API specification for requests and responses.
 *
 * @schema Webhook
 */
export declare class Webhook extends ApiObject {
    /**
     * Returns the apiVersion and kind for "Webhook"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "Webhook".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: WebhookProps): any;
    /**
     * Defines a "Webhook" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: WebhookProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * Webhook connects to a third party API server to handle the secrets generation
 * configuration parameters in spec.
 * You can specify the server, the token, and additional body parameters.
 * See documentation for the full API specification for requests and responses.
 *
 * @schema Webhook
 */
export interface WebhookProps {
    /**
     * @schema Webhook#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * WebhookSpec controls the behavior of the external generator. Any body parameters should be passed to the server through the parameters field.
     *
     * @schema Webhook#spec
     */
    readonly spec?: WebhookSpec;
}
/**
 * Converts an object of type 'WebhookProps' to JSON representation.
 */
export declare function toJson_WebhookProps(obj: WebhookProps | undefined): Record<string, any> | undefined;
/**
 * WebhookSpec controls the behavior of the external generator. Any body parameters should be passed to the server through the parameters field.
 *
 * @schema WebhookSpec
 */
export interface WebhookSpec {
    /**
     * Auth specifies a authorization protocol. Only one protocol may be set.
     *
     * @schema WebhookSpec#auth
     */
    readonly auth?: WebhookSpecAuth;
    /**
     * Body
     *
     * @schema WebhookSpec#body
     */
    readonly body?: string;
    /**
     * PEM encoded CA bundle used to validate webhook server certificate. Only used
     * if the Server URL is using HTTPS protocol. This parameter is ignored for
     * plain HTTP protocol connection. If not set the system root certificates
     * are used to validate the TLS connection.
     *
     * @schema WebhookSpec#caBundle
     */
    readonly caBundle?: string;
    /**
     * The provider for the CA bundle to use to validate webhook server certificate.
     *
     * @schema WebhookSpec#caProvider
     */
    readonly caProvider?: WebhookSpecCaProvider;
    /**
     * Headers
     *
     * @schema WebhookSpec#headers
     */
    readonly headers?: {
        [key: string]: string;
    };
    /**
     * Webhook Method
     *
     * @schema WebhookSpec#method
     */
    readonly method?: string;
    /**
     * Result formatting
     *
     * @schema WebhookSpec#result
     */
    readonly result: WebhookSpecResult;
    /**
     * Secrets to fill in templates
     * These secrets will be passed to the templating function as key value pairs under the given name
     *
     * @schema WebhookSpec#secrets
     */
    readonly secrets?: WebhookSpecSecrets[];
    /**
     * Timeout
     *
     * @schema WebhookSpec#timeout
     */
    readonly timeout?: string;
    /**
     * Webhook url to call
     *
     * @schema WebhookSpec#url
     */
    readonly url: string;
}
/**
 * Converts an object of type 'WebhookSpec' to JSON representation.
 */
export declare function toJson_WebhookSpec(obj: WebhookSpec | undefined): Record<string, any> | undefined;
/**
 * Auth specifies a authorization protocol. Only one protocol may be set.
 *
 * @schema WebhookSpecAuth
 */
export interface WebhookSpecAuth {
    /**
     * NTLMProtocol configures the store to use NTLM for auth
     *
     * @schema WebhookSpecAuth#ntlm
     */
    readonly ntlm?: WebhookSpecAuthNtlm;
}
/**
 * Converts an object of type 'WebhookSpecAuth' to JSON representation.
 */
export declare function toJson_WebhookSpecAuth(obj: WebhookSpecAuth | undefined): Record<string, any> | undefined;
/**
 * The provider for the CA bundle to use to validate webhook server certificate.
 *
 * @schema WebhookSpecCaProvider
 */
export interface WebhookSpecCaProvider {
    /**
     * The key where the CA certificate can be found in the Secret or ConfigMap.
     *
     * @schema WebhookSpecCaProvider#key
     */
    readonly key?: string;
    /**
     * The name of the object located at the provider type.
     *
     * @schema WebhookSpecCaProvider#name
     */
    readonly name: string;
    /**
     * The namespace the Provider type is in.
     *
     * @schema WebhookSpecCaProvider#namespace
     */
    readonly namespace?: string;
    /**
     * The type of provider to use such as "Secret", or "ConfigMap".
     *
     * @schema WebhookSpecCaProvider#type
     */
    readonly type: WebhookSpecCaProviderType;
}
/**
 * Converts an object of type 'WebhookSpecCaProvider' to JSON representation.
 */
export declare function toJson_WebhookSpecCaProvider(obj: WebhookSpecCaProvider | undefined): Record<string, any> | undefined;
/**
 * Result formatting
 *
 * @schema WebhookSpecResult
 */
export interface WebhookSpecResult {
    /**
     * Json path of return value
     *
     * @schema WebhookSpecResult#jsonPath
     */
    readonly jsonPath?: string;
}
/**
 * Converts an object of type 'WebhookSpecResult' to JSON representation.
 */
export declare function toJson_WebhookSpecResult(obj: WebhookSpecResult | undefined): Record<string, any> | undefined;
/**
 * WebhookSecret defines a secret reference that will be used in webhook templates.
 *
 * @schema WebhookSpecSecrets
 */
export interface WebhookSpecSecrets {
    /**
     * Name of this secret in templates
     *
     * @schema WebhookSpecSecrets#name
     */
    readonly name: string;
    /**
     * Secret ref to fill in credentials
     *
     * @schema WebhookSpecSecrets#secretRef
     */
    readonly secretRef: WebhookSpecSecretsSecretRef;
}
/**
 * Converts an object of type 'WebhookSpecSecrets' to JSON representation.
 */
export declare function toJson_WebhookSpecSecrets(obj: WebhookSpecSecrets | undefined): Record<string, any> | undefined;
/**
 * NTLMProtocol configures the store to use NTLM for auth
 *
 * @schema WebhookSpecAuthNtlm
 */
export interface WebhookSpecAuthNtlm {
    /**
     * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
     * In some instances, `key` is a required field.
     *
     * @schema WebhookSpecAuthNtlm#passwordSecret
     */
    readonly passwordSecret: WebhookSpecAuthNtlmPasswordSecret;
    /**
     * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
     * In some instances, `key` is a required field.
     *
     * @schema WebhookSpecAuthNtlm#usernameSecret
     */
    readonly usernameSecret: WebhookSpecAuthNtlmUsernameSecret;
}
/**
 * Converts an object of type 'WebhookSpecAuthNtlm' to JSON representation.
 */
export declare function toJson_WebhookSpecAuthNtlm(obj: WebhookSpecAuthNtlm | undefined): Record<string, any> | undefined;
/**
 * The type of provider to use such as "Secret", or "ConfigMap".
 *
 * @schema WebhookSpecCaProviderType
 */
export declare enum WebhookSpecCaProviderType {
    /** Secret */
    SECRET = "Secret",
    /** ConfigMap */
    CONFIG_MAP = "ConfigMap"
}
/**
 * Secret ref to fill in credentials
 *
 * @schema WebhookSpecSecretsSecretRef
 */
export interface WebhookSpecSecretsSecretRef {
    /**
     * The key where the token is found.
     *
     * @schema WebhookSpecSecretsSecretRef#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema WebhookSpecSecretsSecretRef#name
     */
    readonly name?: string;
}
/**
 * Converts an object of type 'WebhookSpecSecretsSecretRef' to JSON representation.
 */
export declare function toJson_WebhookSpecSecretsSecretRef(obj: WebhookSpecSecretsSecretRef | undefined): Record<string, any> | undefined;
/**
 * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
 * In some instances, `key` is a required field.
 *
 * @schema WebhookSpecAuthNtlmPasswordSecret
 */
export interface WebhookSpecAuthNtlmPasswordSecret {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema WebhookSpecAuthNtlmPasswordSecret#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema WebhookSpecAuthNtlmPasswordSecret#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema WebhookSpecAuthNtlmPasswordSecret#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'WebhookSpecAuthNtlmPasswordSecret' to JSON representation.
 */
export declare function toJson_WebhookSpecAuthNtlmPasswordSecret(obj: WebhookSpecAuthNtlmPasswordSecret | undefined): Record<string, any> | undefined;
/**
 * SecretKeySelector is a reference to a specific 'key' within a Secret resource.
 * In some instances, `key` is a required field.
 *
 * @schema WebhookSpecAuthNtlmUsernameSecret
 */
export interface WebhookSpecAuthNtlmUsernameSecret {
    /**
     * A key in the referenced Secret.
     * Some instances of this field may be defaulted, in others it may be required.
     *
     * @schema WebhookSpecAuthNtlmUsernameSecret#key
     */
    readonly key?: string;
    /**
     * The name of the Secret resource being referred to.
     *
     * @schema WebhookSpecAuthNtlmUsernameSecret#name
     */
    readonly name?: string;
    /**
     * The namespace of the Secret resource being referred to.
     * Ignored if referent is not cluster-scoped, otherwise defaults to the namespace of the referent.
     *
     * @schema WebhookSpecAuthNtlmUsernameSecret#namespace
     */
    readonly namespace?: string;
}
/**
 * Converts an object of type 'WebhookSpecAuthNtlmUsernameSecret' to JSON representation.
 */
export declare function toJson_WebhookSpecAuthNtlmUsernameSecret(obj: WebhookSpecAuthNtlmUsernameSecret | undefined): Record<string, any> | undefined;
