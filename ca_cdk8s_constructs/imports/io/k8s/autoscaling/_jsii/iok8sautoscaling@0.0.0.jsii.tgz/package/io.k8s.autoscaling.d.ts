import { ApiObject, ApiObjectMetadata, GroupVersionKind } from 'cdk8s';
import { Construct } from 'constructs';
/**
 * VerticalPodAutoscaler is the configuration for a vertical pod
autoscaler, which automatically manages pod resources based on historical and
real time resource utilization.
 *
 * @schema VerticalPodAutoscaler
 */
export declare class VerticalPodAutoscaler extends ApiObject {
    /**
     * Returns the apiVersion and kind for "VerticalPodAutoscaler"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "VerticalPodAutoscaler".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props: VerticalPodAutoscalerProps): any;
    /**
     * Defines a "VerticalPodAutoscaler" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props: VerticalPodAutoscalerProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * VerticalPodAutoscaler is the configuration for a vertical pod
 * autoscaler, which automatically manages pod resources based on historical and
 * real time resource utilization.
 *
 * @schema VerticalPodAutoscaler
 */
export interface VerticalPodAutoscalerProps {
    /**
     * @schema VerticalPodAutoscaler#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * Specification of the behavior of the autoscaler.
     * More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status.
     *
     * @schema VerticalPodAutoscaler#spec
     */
    readonly spec: VerticalPodAutoscalerSpec;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerProps' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerProps(obj: VerticalPodAutoscalerProps | undefined): Record<string, any> | undefined;
/**
 * Specification of the behavior of the autoscaler.
 * More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status.
 *
 * @schema VerticalPodAutoscalerSpec
 */
export interface VerticalPodAutoscalerSpec {
    /**
     * Recommender responsible for generating recommendation for this object.
     * List should be empty (then the default recommender will generate the
     * recommendation) or contain exactly one recommender.
     *
     * @schema VerticalPodAutoscalerSpec#recommenders
     */
    readonly recommenders?: VerticalPodAutoscalerSpecRecommenders[];
    /**
     * Controls how the autoscaler computes recommended resources.
     * The resource policy may be used to set constraints on the recommendations
     * for individual containers.
     * If any individual containers need to be excluded from getting the VPA recommendations, then
     * it must be disabled explicitly by setting mode to "Off" under containerPolicies.
     * If not specified, the autoscaler computes recommended resources for all containers in the pod,
     * without additional constraints.
     *
     * @schema VerticalPodAutoscalerSpec#resourcePolicy
     */
    readonly resourcePolicy?: VerticalPodAutoscalerSpecResourcePolicy;
    /**
     * TargetRef points to the controller managing the set of pods for the
     * autoscaler to control - e.g. Deployment, StatefulSet. VerticalPodAutoscaler
     * can be targeted at controller implementing scale subresource (the pod set is
     * retrieved from the controller's ScaleStatus) or some well known controllers
     * (e.g. for DaemonSet the pod set is read from the controller's spec).
     * If VerticalPodAutoscaler cannot use specified target it will report
     * ConfigUnsupported condition.
     * Note that VerticalPodAutoscaler does not require full implementation
     * of scale subresource - it will not use it to modify the replica count.
     * The only thing retrieved is a label selector matching pods grouped by
     * the target resource.
     *
     * @schema VerticalPodAutoscalerSpec#targetRef
     */
    readonly targetRef: VerticalPodAutoscalerSpecTargetRef;
    /**
     * Describes the rules on how changes are applied to the pods.
     * If not specified, all fields in the `PodUpdatePolicy` are set to their
     * default values.
     *
     * @schema VerticalPodAutoscalerSpec#updatePolicy
     */
    readonly updatePolicy?: VerticalPodAutoscalerSpecUpdatePolicy;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerSpec' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerSpec(obj: VerticalPodAutoscalerSpec | undefined): Record<string, any> | undefined;
/**
 * VerticalPodAutoscalerRecommenderSelector points to a specific Vertical Pod Autoscaler recommender.
 * In the future it might pass parameters to the recommender.
 *
 * @schema VerticalPodAutoscalerSpecRecommenders
 */
export interface VerticalPodAutoscalerSpecRecommenders {
    /**
     * Name of the recommender responsible for generating recommendation for this object.
     *
     * @schema VerticalPodAutoscalerSpecRecommenders#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerSpecRecommenders' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerSpecRecommenders(obj: VerticalPodAutoscalerSpecRecommenders | undefined): Record<string, any> | undefined;
/**
 * Controls how the autoscaler computes recommended resources.
 * The resource policy may be used to set constraints on the recommendations
 * for individual containers.
 * If any individual containers need to be excluded from getting the VPA recommendations, then
 * it must be disabled explicitly by setting mode to "Off" under containerPolicies.
 * If not specified, the autoscaler computes recommended resources for all containers in the pod,
 * without additional constraints.
 *
 * @schema VerticalPodAutoscalerSpecResourcePolicy
 */
export interface VerticalPodAutoscalerSpecResourcePolicy {
    /**
     * Per-container resource policies.
     *
     * @schema VerticalPodAutoscalerSpecResourcePolicy#containerPolicies
     */
    readonly containerPolicies?: VerticalPodAutoscalerSpecResourcePolicyContainerPolicies[];
}
/**
 * Converts an object of type 'VerticalPodAutoscalerSpecResourcePolicy' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerSpecResourcePolicy(obj: VerticalPodAutoscalerSpecResourcePolicy | undefined): Record<string, any> | undefined;
/**
 * TargetRef points to the controller managing the set of pods for the
 * autoscaler to control - e.g. Deployment, StatefulSet. VerticalPodAutoscaler
 * can be targeted at controller implementing scale subresource (the pod set is
 * retrieved from the controller's ScaleStatus) or some well known controllers
 * (e.g. for DaemonSet the pod set is read from the controller's spec).
 * If VerticalPodAutoscaler cannot use specified target it will report
 * ConfigUnsupported condition.
 * Note that VerticalPodAutoscaler does not require full implementation
 * of scale subresource - it will not use it to modify the replica count.
 * The only thing retrieved is a label selector matching pods grouped by
 * the target resource.
 *
 * @schema VerticalPodAutoscalerSpecTargetRef
 */
export interface VerticalPodAutoscalerSpecTargetRef {
    /**
     * apiVersion is the API version of the referent
     *
     * @schema VerticalPodAutoscalerSpecTargetRef#apiVersion
     */
    readonly apiVersion?: string;
    /**
     * kind is the kind of the referent; More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#types-kinds
     *
     * @schema VerticalPodAutoscalerSpecTargetRef#kind
     */
    readonly kind: string;
    /**
     * name is the name of the referent; More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema VerticalPodAutoscalerSpecTargetRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerSpecTargetRef' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerSpecTargetRef(obj: VerticalPodAutoscalerSpecTargetRef | undefined): Record<string, any> | undefined;
/**
 * Describes the rules on how changes are applied to the pods.
 * If not specified, all fields in the `PodUpdatePolicy` are set to their
 * default values.
 *
 * @schema VerticalPodAutoscalerSpecUpdatePolicy
 */
export interface VerticalPodAutoscalerSpecUpdatePolicy {
    /**
     * EvictionRequirements is a list of EvictionRequirements that need to
     * evaluate to true in order for a Pod to be evicted. If more than one
     * EvictionRequirement is specified, all of them need to be fulfilled to allow eviction.
     *
     * @schema VerticalPodAutoscalerSpecUpdatePolicy#evictionRequirements
     */
    readonly evictionRequirements?: VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirements[];
    /**
     * Minimal number of replicas which need to be alive for Updater to attempt
     * pod eviction (pending other checks like PDB). Only positive values are
     * allowed. Overrides global '--min-replicas' flag.
     *
     * @schema VerticalPodAutoscalerSpecUpdatePolicy#minReplicas
     */
    readonly minReplicas?: number;
    /**
     * Controls when autoscaler applies changes to the pod resources.
     * The default is 'Recreate'.
     *
     * @schema VerticalPodAutoscalerSpecUpdatePolicy#updateMode
     */
    readonly updateMode?: VerticalPodAutoscalerSpecUpdatePolicyUpdateMode;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerSpecUpdatePolicy' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerSpecUpdatePolicy(obj: VerticalPodAutoscalerSpecUpdatePolicy | undefined): Record<string, any> | undefined;
/**
 * ContainerResourcePolicy controls how autoscaler computes the recommended
 * resources for a specific container.
 *
 * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPolicies
 */
export interface VerticalPodAutoscalerSpecResourcePolicyContainerPolicies {
    /**
     * Name of the container or DefaultContainerResourcePolicy, in which
     * case the policy is used by the containers that don't have their own
     * policy specified.
     *
     * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPolicies#containerName
     */
    readonly containerName?: string;
    /**
     * Specifies the type of recommendations that will be computed
     * (and possibly applied) by VPA.
     * If not specified, the default of [ResourceCPU, ResourceMemory] will be used.
     *
     * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPolicies#controlledResources
     */
    readonly controlledResources?: string[];
    /**
     * Specifies which resource values should be controlled.
     * The default is "RequestsAndLimits".
     *
     * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPolicies#controlledValues
     */
    readonly controlledValues?: VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesControlledValues;
    /**
     * Specifies the maximum amount of resources that will be recommended
     * for the container. The default is no maximum.
     *
     * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPolicies#maxAllowed
     */
    readonly maxAllowed?: {
        [key: string]: VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMaxAllowed;
    };
    /**
     * Specifies the minimal amount of resources that will be recommended
     * for the container. The default is no minimum.
     *
     * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPolicies#minAllowed
     */
    readonly minAllowed?: {
        [key: string]: VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMinAllowed;
    };
    /**
     * Whether autoscaler is enabled for the container. The default is "Auto".
     *
     * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPolicies#mode
     */
    readonly mode?: VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMode;
    /**
     * oomBumpUpRatio is the ratio to increase memory when OOM is detected.
     *
     * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPolicies#oomBumpUpRatio
     */
    readonly oomBumpUpRatio?: VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesOomBumpUpRatio;
    /**
     * oomMinBumpUp is the minimum increase in memory when OOM is detected.
     *
     * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPolicies#oomMinBumpUp
     */
    readonly oomMinBumpUp?: VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesOomMinBumpUp;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerSpecResourcePolicyContainerPolicies' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerSpecResourcePolicyContainerPolicies(obj: VerticalPodAutoscalerSpecResourcePolicyContainerPolicies | undefined): Record<string, any> | undefined;
/**
 * EvictionRequirement defines a single condition which needs to be true in
 * order to evict a Pod
 *
 * @schema VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirements
 */
export interface VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirements {
    /**
     * EvictionChangeRequirement refers to the relationship between the new target recommendation for a Pod and its current requests, what kind of change is necessary for the Pod to be evicted
     *
     * @schema VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirements#changeRequirement
     */
    readonly changeRequirement: VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirementsChangeRequirement;
    /**
     * Resources is a list of one or more resources that the condition applies
     * to. If more than one resource is given, the EvictionRequirement is fulfilled
     * if at least one resource meets `changeRequirement`.
     *
     * @schema VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirements#resources
     */
    readonly resources: string[];
}
/**
 * Converts an object of type 'VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirements' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirements(obj: VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirements | undefined): Record<string, any> | undefined;
/**
 * Controls when autoscaler applies changes to the pod resources.
 * The default is 'Recreate'.
 *
 * @schema VerticalPodAutoscalerSpecUpdatePolicyUpdateMode
 */
export declare enum VerticalPodAutoscalerSpecUpdatePolicyUpdateMode {
    /** Off */
    OFF = "Off",
    /** Initial */
    INITIAL = "Initial",
    /** Recreate */
    RECREATE = "Recreate",
    /** InPlaceOrRecreate */
    IN_PLACE_OR_RECREATE = "InPlaceOrRecreate",
    /** Auto */
    AUTO = "Auto"
}
/**
 * Specifies which resource values should be controlled.
 * The default is "RequestsAndLimits".
 *
 * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesControlledValues
 */
export declare enum VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesControlledValues {
    /** RequestsAndLimits */
    REQUESTS_AND_LIMITS = "RequestsAndLimits",
    /** RequestsOnly */
    REQUESTS_ONLY = "RequestsOnly"
}
/**
 * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMaxAllowed
 */
export declare class VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMaxAllowed {
    readonly value: number | string;
    static fromNumber(value: number): VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMaxAllowed;
    static fromString(value: string): VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMaxAllowed;
    private constructor();
}
/**
 * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMinAllowed
 */
export declare class VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMinAllowed {
    readonly value: number | string;
    static fromNumber(value: number): VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMinAllowed;
    static fromString(value: string): VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMinAllowed;
    private constructor();
}
/**
 * Whether autoscaler is enabled for the container. The default is "Auto".
 *
 * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMode
 */
export declare enum VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesMode {
    /** Auto */
    AUTO = "Auto",
    /** Off */
    OFF = "Off"
}
/**
 * oomBumpUpRatio is the ratio to increase memory when OOM is detected.
 *
 * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesOomBumpUpRatio
 */
export declare class VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesOomBumpUpRatio {
    readonly value: number | string;
    static fromNumber(value: number): VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesOomBumpUpRatio;
    static fromString(value: string): VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesOomBumpUpRatio;
    private constructor();
}
/**
 * oomMinBumpUp is the minimum increase in memory when OOM is detected.
 *
 * @schema VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesOomMinBumpUp
 */
export declare class VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesOomMinBumpUp {
    readonly value: number | string;
    static fromNumber(value: number): VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesOomMinBumpUp;
    static fromString(value: string): VerticalPodAutoscalerSpecResourcePolicyContainerPoliciesOomMinBumpUp;
    private constructor();
}
/**
 * EvictionChangeRequirement refers to the relationship between the new target recommendation for a Pod and its current requests, what kind of change is necessary for the Pod to be evicted
 *
 * @schema VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirementsChangeRequirement
 */
export declare enum VerticalPodAutoscalerSpecUpdatePolicyEvictionRequirementsChangeRequirement {
    /** TargetHigherThanRequests */
    TARGET_HIGHER_THAN_REQUESTS = "TargetHigherThanRequests",
    /** TargetLowerThanRequests */
    TARGET_LOWER_THAN_REQUESTS = "TargetLowerThanRequests"
}
/**
 * VerticalPodAutoscaler is the configuration for a vertical pod
autoscaler, which automatically manages pod resources based on historical and
real time resource utilization.
 *
 * @schema VerticalPodAutoscalerV1Beta2
 */
export declare class VerticalPodAutoscalerV1Beta2 extends ApiObject {
    /**
     * Returns the apiVersion and kind for "VerticalPodAutoscalerV1Beta2"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "VerticalPodAutoscalerV1Beta2".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props: VerticalPodAutoscalerV1Beta2Props): any;
    /**
     * Defines a "VerticalPodAutoscalerV1Beta2" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props: VerticalPodAutoscalerV1Beta2Props);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * VerticalPodAutoscaler is the configuration for a vertical pod
 * autoscaler, which automatically manages pod resources based on historical and
 * real time resource utilization.
 *
 * @schema VerticalPodAutoscalerV1Beta2
 */
export interface VerticalPodAutoscalerV1Beta2Props {
    /**
     * @schema VerticalPodAutoscalerV1Beta2#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * Specification of the behavior of the autoscaler.
     * More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status.
     *
     * @schema VerticalPodAutoscalerV1Beta2#spec
     */
    readonly spec: VerticalPodAutoscalerV1Beta2Spec;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerV1Beta2Props' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerV1Beta2Props(obj: VerticalPodAutoscalerV1Beta2Props | undefined): Record<string, any> | undefined;
/**
 * Specification of the behavior of the autoscaler.
 * More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status.
 *
 * @schema VerticalPodAutoscalerV1Beta2Spec
 */
export interface VerticalPodAutoscalerV1Beta2Spec {
    /**
     * Controls how the autoscaler computes recommended resources.
     * The resource policy may be used to set constraints on the recommendations
     * for individual containers. If not specified, the autoscaler computes recommended
     * resources for all containers in the pod, without additional constraints.
     *
     * @schema VerticalPodAutoscalerV1Beta2Spec#resourcePolicy
     */
    readonly resourcePolicy?: VerticalPodAutoscalerV1Beta2SpecResourcePolicy;
    /**
     * TargetRef points to the controller managing the set of pods for the
     * autoscaler to control - e.g. Deployment, StatefulSet. VerticalPodAutoscaler
     * can be targeted at controller implementing scale subresource (the pod set is
     * retrieved from the controller's ScaleStatus) or some well known controllers
     * (e.g. for DaemonSet the pod set is read from the controller's spec).
     * If VerticalPodAutoscaler cannot use specified target it will report
     * ConfigUnsupported condition.
     * Note that VerticalPodAutoscaler does not require full implementation
     * of scale subresource - it will not use it to modify the replica count.
     * The only thing retrieved is a label selector matching pods grouped by
     * the target resource.
     *
     * @schema VerticalPodAutoscalerV1Beta2Spec#targetRef
     */
    readonly targetRef: VerticalPodAutoscalerV1Beta2SpecTargetRef;
    /**
     * Describes the rules on how changes are applied to the pods.
     * If not specified, all fields in the `PodUpdatePolicy` are set to their
     * default values.
     *
     * @schema VerticalPodAutoscalerV1Beta2Spec#updatePolicy
     */
    readonly updatePolicy?: VerticalPodAutoscalerV1Beta2SpecUpdatePolicy;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerV1Beta2Spec' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerV1Beta2Spec(obj: VerticalPodAutoscalerV1Beta2Spec | undefined): Record<string, any> | undefined;
/**
 * Controls how the autoscaler computes recommended resources.
 * The resource policy may be used to set constraints on the recommendations
 * for individual containers. If not specified, the autoscaler computes recommended
 * resources for all containers in the pod, without additional constraints.
 *
 * @schema VerticalPodAutoscalerV1Beta2SpecResourcePolicy
 */
export interface VerticalPodAutoscalerV1Beta2SpecResourcePolicy {
    /**
     * Per-container resource policies.
     *
     * @schema VerticalPodAutoscalerV1Beta2SpecResourcePolicy#containerPolicies
     */
    readonly containerPolicies?: VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPolicies[];
}
/**
 * Converts an object of type 'VerticalPodAutoscalerV1Beta2SpecResourcePolicy' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerV1Beta2SpecResourcePolicy(obj: VerticalPodAutoscalerV1Beta2SpecResourcePolicy | undefined): Record<string, any> | undefined;
/**
 * TargetRef points to the controller managing the set of pods for the
 * autoscaler to control - e.g. Deployment, StatefulSet. VerticalPodAutoscaler
 * can be targeted at controller implementing scale subresource (the pod set is
 * retrieved from the controller's ScaleStatus) or some well known controllers
 * (e.g. for DaemonSet the pod set is read from the controller's spec).
 * If VerticalPodAutoscaler cannot use specified target it will report
 * ConfigUnsupported condition.
 * Note that VerticalPodAutoscaler does not require full implementation
 * of scale subresource - it will not use it to modify the replica count.
 * The only thing retrieved is a label selector matching pods grouped by
 * the target resource.
 *
 * @schema VerticalPodAutoscalerV1Beta2SpecTargetRef
 */
export interface VerticalPodAutoscalerV1Beta2SpecTargetRef {
    /**
     * apiVersion is the API version of the referent
     *
     * @schema VerticalPodAutoscalerV1Beta2SpecTargetRef#apiVersion
     */
    readonly apiVersion?: string;
    /**
     * kind is the kind of the referent; More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#types-kinds
     *
     * @schema VerticalPodAutoscalerV1Beta2SpecTargetRef#kind
     */
    readonly kind: string;
    /**
     * name is the name of the referent; More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema VerticalPodAutoscalerV1Beta2SpecTargetRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerV1Beta2SpecTargetRef' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerV1Beta2SpecTargetRef(obj: VerticalPodAutoscalerV1Beta2SpecTargetRef | undefined): Record<string, any> | undefined;
/**
 * Describes the rules on how changes are applied to the pods.
 * If not specified, all fields in the `PodUpdatePolicy` are set to their
 * default values.
 *
 * @schema VerticalPodAutoscalerV1Beta2SpecUpdatePolicy
 */
export interface VerticalPodAutoscalerV1Beta2SpecUpdatePolicy {
    /**
     * Controls when autoscaler applies changes to the pod resources.
     * The default is 'Auto'.
     *
     * @schema VerticalPodAutoscalerV1Beta2SpecUpdatePolicy#updateMode
     */
    readonly updateMode?: VerticalPodAutoscalerV1Beta2SpecUpdatePolicyUpdateMode;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerV1Beta2SpecUpdatePolicy' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerV1Beta2SpecUpdatePolicy(obj: VerticalPodAutoscalerV1Beta2SpecUpdatePolicy | undefined): Record<string, any> | undefined;
/**
 * ContainerResourcePolicy controls how autoscaler computes the recommended
 * resources for a specific container.
 *
 * @schema VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPolicies
 */
export interface VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPolicies {
    /**
     * Name of the container or DefaultContainerResourcePolicy, in which
     * case the policy is used by the containers that don't have their own
     * policy specified.
     *
     * @schema VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPolicies#containerName
     */
    readonly containerName?: string;
    /**
     * Specifies the maximum amount of resources that will be recommended
     * for the container. The default is no maximum.
     *
     * @schema VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPolicies#maxAllowed
     */
    readonly maxAllowed?: {
        [key: string]: VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMaxAllowed;
    };
    /**
     * Specifies the minimal amount of resources that will be recommended
     * for the container. The default is no minimum.
     *
     * @schema VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPolicies#minAllowed
     */
    readonly minAllowed?: {
        [key: string]: VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMinAllowed;
    };
    /**
     * Whether autoscaler is enabled for the container. The default is "Auto".
     *
     * @schema VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPolicies#mode
     */
    readonly mode?: VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMode;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPolicies' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPolicies(obj: VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPolicies | undefined): Record<string, any> | undefined;
/**
 * Controls when autoscaler applies changes to the pod resources.
 * The default is 'Auto'.
 *
 * @schema VerticalPodAutoscalerV1Beta2SpecUpdatePolicyUpdateMode
 */
export declare enum VerticalPodAutoscalerV1Beta2SpecUpdatePolicyUpdateMode {
    /** Off */
    OFF = "Off",
    /** Initial */
    INITIAL = "Initial",
    /** Recreate */
    RECREATE = "Recreate",
    /** Auto */
    AUTO = "Auto"
}
/**
 * @schema VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMaxAllowed
 */
export declare class VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMaxAllowed {
    readonly value: number | string;
    static fromNumber(value: number): VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMaxAllowed;
    static fromString(value: string): VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMaxAllowed;
    private constructor();
}
/**
 * @schema VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMinAllowed
 */
export declare class VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMinAllowed {
    readonly value: number | string;
    static fromNumber(value: number): VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMinAllowed;
    static fromString(value: string): VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMinAllowed;
    private constructor();
}
/**
 * Whether autoscaler is enabled for the container. The default is "Auto".
 *
 * @schema VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMode
 */
export declare enum VerticalPodAutoscalerV1Beta2SpecResourcePolicyContainerPoliciesMode {
    /** Auto */
    AUTO = "Auto",
    /** Off */
    OFF = "Off"
}
/**
 * VerticalPodAutoscalerCheckpoint is the checkpoint of the internal state of VPA that
is used for recovery after recommender's restart.
 *
 * @schema VerticalPodAutoscalerCheckpoint
 */
export declare class VerticalPodAutoscalerCheckpoint extends ApiObject {
    /**
     * Returns the apiVersion and kind for "VerticalPodAutoscalerCheckpoint"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "VerticalPodAutoscalerCheckpoint".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: VerticalPodAutoscalerCheckpointProps): any;
    /**
     * Defines a "VerticalPodAutoscalerCheckpoint" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: VerticalPodAutoscalerCheckpointProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * VerticalPodAutoscalerCheckpoint is the checkpoint of the internal state of VPA that
 * is used for recovery after recommender's restart.
 *
 * @schema VerticalPodAutoscalerCheckpoint
 */
export interface VerticalPodAutoscalerCheckpointProps {
    /**
     * @schema VerticalPodAutoscalerCheckpoint#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * Specification of the checkpoint.
     * More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status.
     *
     * @schema VerticalPodAutoscalerCheckpoint#spec
     */
    readonly spec?: VerticalPodAutoscalerCheckpointSpec;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerCheckpointProps' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerCheckpointProps(obj: VerticalPodAutoscalerCheckpointProps | undefined): Record<string, any> | undefined;
/**
 * Specification of the checkpoint.
 * More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status.
 *
 * @schema VerticalPodAutoscalerCheckpointSpec
 */
export interface VerticalPodAutoscalerCheckpointSpec {
    /**
     * Name of the checkpointed container.
     *
     * @schema VerticalPodAutoscalerCheckpointSpec#containerName
     */
    readonly containerName?: string;
    /**
     * Name of the VPA object that stored VerticalPodAutoscalerCheckpoint object.
     *
     * @schema VerticalPodAutoscalerCheckpointSpec#vpaObjectName
     */
    readonly vpaObjectName?: string;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerCheckpointSpec' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerCheckpointSpec(obj: VerticalPodAutoscalerCheckpointSpec | undefined): Record<string, any> | undefined;
/**
 * VerticalPodAutoscalerCheckpoint is the checkpoint of the internal state of VPA that
is used for recovery after recommender's restart.
 *
 * @schema VerticalPodAutoscalerCheckpointV1Beta2
 */
export declare class VerticalPodAutoscalerCheckpointV1Beta2 extends ApiObject {
    /**
     * Returns the apiVersion and kind for "VerticalPodAutoscalerCheckpointV1Beta2"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "VerticalPodAutoscalerCheckpointV1Beta2".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: VerticalPodAutoscalerCheckpointV1Beta2Props): any;
    /**
     * Defines a "VerticalPodAutoscalerCheckpointV1Beta2" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: VerticalPodAutoscalerCheckpointV1Beta2Props);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * VerticalPodAutoscalerCheckpoint is the checkpoint of the internal state of VPA that
 * is used for recovery after recommender's restart.
 *
 * @schema VerticalPodAutoscalerCheckpointV1Beta2
 */
export interface VerticalPodAutoscalerCheckpointV1Beta2Props {
    /**
     * @schema VerticalPodAutoscalerCheckpointV1Beta2#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * Specification of the checkpoint.
     * More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status.
     *
     * @schema VerticalPodAutoscalerCheckpointV1Beta2#spec
     */
    readonly spec?: VerticalPodAutoscalerCheckpointV1Beta2Spec;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerCheckpointV1Beta2Props' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerCheckpointV1Beta2Props(obj: VerticalPodAutoscalerCheckpointV1Beta2Props | undefined): Record<string, any> | undefined;
/**
 * Specification of the checkpoint.
 * More info: https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status.
 *
 * @schema VerticalPodAutoscalerCheckpointV1Beta2Spec
 */
export interface VerticalPodAutoscalerCheckpointV1Beta2Spec {
    /**
     * Name of the checkpointed container.
     *
     * @schema VerticalPodAutoscalerCheckpointV1Beta2Spec#containerName
     */
    readonly containerName?: string;
    /**
     * Name of the VPA object that stored VerticalPodAutoscalerCheckpoint object.
     *
     * @schema VerticalPodAutoscalerCheckpointV1Beta2Spec#vpaObjectName
     */
    readonly vpaObjectName?: string;
}
/**
 * Converts an object of type 'VerticalPodAutoscalerCheckpointV1Beta2Spec' to JSON representation.
 */
export declare function toJson_VerticalPodAutoscalerCheckpointV1Beta2Spec(obj: VerticalPodAutoscalerCheckpointV1Beta2Spec | undefined): Record<string, any> | undefined;
