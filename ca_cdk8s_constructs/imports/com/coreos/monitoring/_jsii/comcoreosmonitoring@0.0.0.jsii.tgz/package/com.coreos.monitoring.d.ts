import { ApiObject, ApiObjectMetadata, GroupVersionKind } from 'cdk8s';
import { Construct } from 'constructs';
/**
 * The `Probe` custom resource definition (CRD) defines how to scrape metrics from prober exporters such as the [blackbox exporter](https://github.com/prometheus/blackbox_exporter).

The `Probe` resource needs 2 pieces of information:
* The list of probed addresses which can be defined statically or by discovering Kubernetes Ingress objects.
* The prober which exposes the availability of probed endpoints (over various protocols such HTTP, TCP, ICMP, ...) as Prometheus metrics.

`Prometheus` and `PrometheusAgent` objects select `Probe` objects using label and namespace selectors.
 *
 * @schema Probe
 */
export declare class Probe extends ApiObject {
    /**
     * Returns the apiVersion and kind for "Probe"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "Probe".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props: ProbeProps): any;
    /**
     * Defines a "Probe" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props: ProbeProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * The `Probe` custom resource definition (CRD) defines how to scrape metrics from prober exporters such as the [blackbox exporter](https://github.com/prometheus/blackbox_exporter).
 *
 * The `Probe` resource needs 2 pieces of information:
 * * The list of probed addresses which can be defined statically or by discovering Kubernetes Ingress objects.
 * * The prober which exposes the availability of probed endpoints (over various protocols such HTTP, TCP, ICMP, ...) as Prometheus metrics.
 *
 * `Prometheus` and `PrometheusAgent` objects select `Probe` objects using label and namespace selectors.
 *
 * @schema Probe
 */
export interface ProbeProps {
    /**
     * @schema Probe#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * spec defines the specification of desired Ingress selection for target discovery by Prometheus.
     *
     * @schema Probe#spec
     */
    readonly spec: ProbeSpec;
}
/**
 * Converts an object of type 'ProbeProps' to JSON representation.
 */
export declare function toJson_ProbeProps(obj: ProbeProps | undefined): Record<string, any> | undefined;
/**
 * spec defines the specification of desired Ingress selection for target discovery by Prometheus.
 *
 * @schema ProbeSpec
 */
export interface ProbeSpec {
    /**
     * authorization section for this endpoint
     *
     * @schema ProbeSpec#authorization
     */
    readonly authorization?: ProbeSpecAuthorization;
    /**
     * basicAuth allow an endpoint to authenticate over basic authentication.
     * More info: https://prometheus.io/docs/operating/configuration/#endpoint
     *
     * @schema ProbeSpec#basicAuth
     */
    readonly basicAuth?: ProbeSpecBasicAuth;
    /**
     * bearerTokenSecret defines the secret to mount to read bearer token for scraping targets. The secret
     * needs to be in the same namespace as the probe and accessible by
     * the Prometheus Operator.
     *
     * @schema ProbeSpec#bearerTokenSecret
     */
    readonly bearerTokenSecret?: ProbeSpecBearerTokenSecret;
    /**
     * convertClassicHistogramsToNHCB defines whether to convert all scraped classic histograms into a native histogram with custom buckets.
     * It requires Prometheus >= v3.0.0.
     *
     * @schema ProbeSpec#convertClassicHistogramsToNHCB
     */
    readonly convertClassicHistogramsToNhcb?: boolean;
    /**
     * fallbackScrapeProtocol defines the protocol to use if a scrape returns blank, unparseable, or otherwise invalid Content-Type.
     *
     * It requires Prometheus >= v3.0.0.
     *
     * @schema ProbeSpec#fallbackScrapeProtocol
     */
    readonly fallbackScrapeProtocol?: ProbeSpecFallbackScrapeProtocol;
    /**
     * interval at which targets are probed using the configured prober.
     * If not specified Prometheus' global scrape interval is used.
     *
     * @schema ProbeSpec#interval
     */
    readonly interval?: string;
    /**
     * jobName assigned to scraped metrics by default.
     *
     * @schema ProbeSpec#jobName
     */
    readonly jobName?: string;
    /**
     * keepDroppedTargets defines the per-scrape limit on the number of targets dropped by relabeling
     * that will be kept in memory. 0 means no limit.
     *
     * It requires Prometheus >= v2.47.0.
     *
     * @schema ProbeSpec#keepDroppedTargets
     */
    readonly keepDroppedTargets?: number;
    /**
     * labelLimit defines the per-scrape limit on number of labels that will be accepted for a sample.
     * Only valid in Prometheus versions 2.27.0 and newer.
     *
     * @schema ProbeSpec#labelLimit
     */
    readonly labelLimit?: number;
    /**
     * labelNameLengthLimit defines the per-scrape limit on length of labels name that will be accepted for a sample.
     * Only valid in Prometheus versions 2.27.0 and newer.
     *
     * @schema ProbeSpec#labelNameLengthLimit
     */
    readonly labelNameLengthLimit?: number;
    /**
     * labelValueLengthLimit defines the per-scrape limit on length of labels value that will be accepted for a sample.
     * Only valid in Prometheus versions 2.27.0 and newer.
     *
     * @schema ProbeSpec#labelValueLengthLimit
     */
    readonly labelValueLengthLimit?: number;
    /**
     * metricRelabelings defines the RelabelConfig to apply to samples before ingestion.
     *
     * @schema ProbeSpec#metricRelabelings
     */
    readonly metricRelabelings?: ProbeSpecMetricRelabelings[];
    /**
     * module to use for probing specifying how to probe the target.
     * Example module configuring in the blackbox exporter:
     * https://github.com/prometheus/blackbox_exporter/blob/master/example.yml
     *
     * @schema ProbeSpec#module
     */
    readonly module?: string;
    /**
     * nativeHistogramBucketLimit defines ff there are more than this many buckets in a native histogram,
     * buckets will be merged to stay within the limit.
     * It requires Prometheus >= v2.45.0.
     *
     * @schema ProbeSpec#nativeHistogramBucketLimit
     */
    readonly nativeHistogramBucketLimit?: number;
    /**
     * nativeHistogramMinBucketFactor defines if the growth factor of one bucket to the next is smaller than this,
     * buckets will be merged to increase the factor sufficiently.
     * It requires Prometheus >= v2.50.0.
     *
     * @schema ProbeSpec#nativeHistogramMinBucketFactor
     */
    readonly nativeHistogramMinBucketFactor?: ProbeSpecNativeHistogramMinBucketFactor;
    /**
     * oauth2 for the URL. Only valid in Prometheus versions 2.27.0 and newer.
     *
     * @schema ProbeSpec#oauth2
     */
    readonly oauth2?: ProbeSpecOauth2;
    /**
     * params defines the list of HTTP query parameters for the scrape.
     * Please note that the `.spec.module` field takes precedence over the `module` parameter from this list when both are defined.
     * The module name must be added using Module under ProbeSpec.
     *
     * @schema ProbeSpec#params
     */
    readonly params?: ProbeSpecParams[];
    /**
     * prober defines the specification for the prober to use for probing targets.
     * The prober.URL parameter is required. Targets cannot be probed if left empty.
     *
     * @schema ProbeSpec#prober
     */
    readonly prober?: ProbeSpecProber;
    /**
     * sampleLimit defines per-scrape limit on number of scraped samples that will be accepted.
     *
     * @schema ProbeSpec#sampleLimit
     */
    readonly sampleLimit?: number;
    /**
     * scrapeClass defines the scrape class to apply.
     *
     * @schema ProbeSpec#scrapeClass
     */
    readonly scrapeClass?: string;
    /**
     * scrapeClassicHistograms defines whether to scrape a classic histogram that is also exposed as a native histogram.
     * It requires Prometheus >= v2.45.0.
     *
     * Notice: `scrapeClassicHistograms` corresponds to the `always_scrape_classic_histograms` field in the Prometheus configuration.
     *
     * @schema ProbeSpec#scrapeClassicHistograms
     */
    readonly scrapeClassicHistograms?: boolean;
    /**
     * scrapeProtocols defines the protocols to negotiate during a scrape. It tells clients the
     * protocols supported by Prometheus in order of preference (from most to least preferred).
     *
     * If unset, Prometheus uses its default value.
     *
     * It requires Prometheus >= v2.49.0.
     *
     * @schema ProbeSpec#scrapeProtocols
     */
    readonly scrapeProtocols?: ProbeSpecScrapeProtocols[];
    /**
     * scrapeTimeout defines the timeout for scraping metrics from the Prometheus exporter.
     * If not specified, the Prometheus global scrape timeout is used.
     * The value cannot be greater than the scrape interval otherwise the operator will reject the resource.
     *
     * @schema ProbeSpec#scrapeTimeout
     */
    readonly scrapeTimeout?: string;
    /**
     * targetLimit defines a limit on the number of scraped targets that will be accepted.
     *
     * @schema ProbeSpec#targetLimit
     */
    readonly targetLimit?: number;
    /**
     * targets defines a set of static or dynamically discovered targets to probe.
     *
     * @schema ProbeSpec#targets
     */
    readonly targets?: ProbeSpecTargets;
    /**
     * tlsConfig defines the TLS configuration to use when scraping the endpoint.
     *
     * @schema ProbeSpec#tlsConfig
     */
    readonly tlsConfig?: ProbeSpecTlsConfig;
}
/**
 * Converts an object of type 'ProbeSpec' to JSON representation.
 */
export declare function toJson_ProbeSpec(obj: ProbeSpec | undefined): Record<string, any> | undefined;
/**
 * authorization section for this endpoint
 *
 * @schema ProbeSpecAuthorization
 */
export interface ProbeSpecAuthorization {
    /**
     * credentials defines a key of a Secret in the namespace that contains the credentials for authentication.
     *
     * @schema ProbeSpecAuthorization#credentials
     */
    readonly credentials?: ProbeSpecAuthorizationCredentials;
    /**
     * type defines the authentication type. The value is case-insensitive.
     *
     * "Basic" is not a supported value.
     *
     * Default: "Bearer"
     *
     * @schema ProbeSpecAuthorization#type
     */
    readonly type?: string;
}
/**
 * Converts an object of type 'ProbeSpecAuthorization' to JSON representation.
 */
export declare function toJson_ProbeSpecAuthorization(obj: ProbeSpecAuthorization | undefined): Record<string, any> | undefined;
/**
 * basicAuth allow an endpoint to authenticate over basic authentication.
 * More info: https://prometheus.io/docs/operating/configuration/#endpoint
 *
 * @schema ProbeSpecBasicAuth
 */
export interface ProbeSpecBasicAuth {
    /**
     * password defines a key of a Secret containing the password for
     * authentication.
     *
     * @schema ProbeSpecBasicAuth#password
     */
    readonly password?: ProbeSpecBasicAuthPassword;
    /**
     * username defines a key of a Secret containing the username for
     * authentication.
     *
     * @schema ProbeSpecBasicAuth#username
     */
    readonly username?: ProbeSpecBasicAuthUsername;
}
/**
 * Converts an object of type 'ProbeSpecBasicAuth' to JSON representation.
 */
export declare function toJson_ProbeSpecBasicAuth(obj: ProbeSpecBasicAuth | undefined): Record<string, any> | undefined;
/**
 * bearerTokenSecret defines the secret to mount to read bearer token for scraping targets. The secret
 * needs to be in the same namespace as the probe and accessible by
 * the Prometheus Operator.
 *
 * @schema ProbeSpecBearerTokenSecret
 */
export interface ProbeSpecBearerTokenSecret {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecBearerTokenSecret#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecBearerTokenSecret#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecBearerTokenSecret#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecBearerTokenSecret' to JSON representation.
 */
export declare function toJson_ProbeSpecBearerTokenSecret(obj: ProbeSpecBearerTokenSecret | undefined): Record<string, any> | undefined;
/**
 * fallbackScrapeProtocol defines the protocol to use if a scrape returns blank, unparseable, or otherwise invalid Content-Type.
 *
 * It requires Prometheus >= v3.0.0.
 *
 * @schema ProbeSpecFallbackScrapeProtocol
 */
export declare enum ProbeSpecFallbackScrapeProtocol {
    /** PrometheusProto */
    PROMETHEUS_PROTO = "PrometheusProto",
    /** OpenMetricsText0.0.1 */
    OPEN_METRICS_TEXT0_0_1 = "OpenMetricsText0.0.1",
    /** OpenMetricsText1.0.0 */
    OPEN_METRICS_TEXT1_0_0 = "OpenMetricsText1.0.0",
    /** PrometheusText0.0.4 */
    PROMETHEUS_TEXT0_0_4 = "PrometheusText0.0.4",
    /** PrometheusText1.0.0 */
    PROMETHEUS_TEXT1_0_0 = "PrometheusText1.0.0"
}
/**
 * RelabelConfig allows dynamic rewriting of the label set for targets, alerts,
 * scraped samples and remote write samples.
 *
 * More info: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#relabel_config
 *
 * @schema ProbeSpecMetricRelabelings
 */
export interface ProbeSpecMetricRelabelings {
    /**
     * action to perform based on the regex matching.
     *
     * `Uppercase` and `Lowercase` actions require Prometheus >= v2.36.0.
     * `DropEqual` and `KeepEqual` actions require Prometheus >= v2.41.0.
     *
     * Default: "Replace"
     *
     * @schema ProbeSpecMetricRelabelings#action
     */
    readonly action?: ProbeSpecMetricRelabelingsAction;
    /**
     * modulus to take of the hash of the source label values.
     *
     * Only applicable when the action is `HashMod`.
     *
     * @schema ProbeSpecMetricRelabelings#modulus
     */
    readonly modulus?: number;
    /**
     * regex defines the regular expression against which the extracted value is matched.
     *
     * @schema ProbeSpecMetricRelabelings#regex
     */
    readonly regex?: string;
    /**
     * replacement value against which a Replace action is performed if the
     * regular expression matches.
     *
     * Regex capture groups are available.
     *
     * @schema ProbeSpecMetricRelabelings#replacement
     */
    readonly replacement?: string;
    /**
     * separator defines the string between concatenated SourceLabels.
     *
     * @schema ProbeSpecMetricRelabelings#separator
     */
    readonly separator?: string;
    /**
     * sourceLabels defines the source labels select values from existing labels. Their content is
     * concatenated using the configured Separator and matched against the
     * configured regular expression.
     *
     * @schema ProbeSpecMetricRelabelings#sourceLabels
     */
    readonly sourceLabels?: string[];
    /**
     * targetLabel defines the label to which the resulting string is written in a replacement.
     *
     * It is mandatory for `Replace`, `HashMod`, `Lowercase`, `Uppercase`,
     * `KeepEqual` and `DropEqual` actions.
     *
     * Regex capture groups are available.
     *
     * @schema ProbeSpecMetricRelabelings#targetLabel
     */
    readonly targetLabel?: string;
}
/**
 * Converts an object of type 'ProbeSpecMetricRelabelings' to JSON representation.
 */
export declare function toJson_ProbeSpecMetricRelabelings(obj: ProbeSpecMetricRelabelings | undefined): Record<string, any> | undefined;
/**
 * nativeHistogramMinBucketFactor defines if the growth factor of one bucket to the next is smaller than this,
 * buckets will be merged to increase the factor sufficiently.
 * It requires Prometheus >= v2.50.0.
 *
 * @schema ProbeSpecNativeHistogramMinBucketFactor
 */
export declare class ProbeSpecNativeHistogramMinBucketFactor {
    readonly value: number | string;
    static fromNumber(value: number): ProbeSpecNativeHistogramMinBucketFactor;
    static fromString(value: string): ProbeSpecNativeHistogramMinBucketFactor;
    private constructor();
}
/**
 * oauth2 for the URL. Only valid in Prometheus versions 2.27.0 and newer.
 *
 * @schema ProbeSpecOauth2
 */
export interface ProbeSpecOauth2 {
    /**
     * clientId defines a key of a Secret or ConfigMap containing the
     * OAuth2 client's ID.
     *
     * @schema ProbeSpecOauth2#clientId
     */
    readonly clientId: ProbeSpecOauth2ClientId;
    /**
     * clientSecret defines a key of a Secret containing the OAuth2
     * client's secret.
     *
     * @schema ProbeSpecOauth2#clientSecret
     */
    readonly clientSecret: ProbeSpecOauth2ClientSecret;
    /**
     * endpointParams configures the HTTP parameters to append to the token
     * URL.
     *
     * @schema ProbeSpecOauth2#endpointParams
     */
    readonly endpointParams?: {
        [key: string]: string;
    };
    /**
     * noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names
     * that should be excluded from proxying. IP and domain names can
     * contain port numbers.
     *
     * It requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.
     *
     * @schema ProbeSpecOauth2#noProxy
     */
    readonly noProxy?: string;
    /**
     * proxyConnectHeader optionally specifies headers to send to
     * proxies during CONNECT requests.
     *
     * It requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.
     *
     * @schema ProbeSpecOauth2#proxyConnectHeader
     */
    readonly proxyConnectHeader?: {
        [key: string]: ProbeSpecOauth2ProxyConnectHeader[];
    };
    /**
     * proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).
     *
     * It requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.
     *
     * @schema ProbeSpecOauth2#proxyFromEnvironment
     */
    readonly proxyFromEnvironment?: boolean;
    /**
     * proxyUrl defines the HTTP proxy server to use.
     *
     * @schema ProbeSpecOauth2#proxyUrl
     */
    readonly proxyUrl?: string;
    /**
     * scopes defines the OAuth2 scopes used for the token request.
     *
     * @schema ProbeSpecOauth2#scopes
     */
    readonly scopes?: string[];
    /**
     * tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.
     * It requires Prometheus >= v2.43.0.
     *
     * @schema ProbeSpecOauth2#tlsConfig
     */
    readonly tlsConfig?: ProbeSpecOauth2TlsConfig;
    /**
     * tokenUrl defines the URL to fetch the token from.
     *
     * @schema ProbeSpecOauth2#tokenUrl
     */
    readonly tokenUrl: string;
}
/**
 * Converts an object of type 'ProbeSpecOauth2' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2(obj: ProbeSpecOauth2 | undefined): Record<string, any> | undefined;
/**
 * ProbeParam defines specification of extra parameters for a Probe.
 *
 * @schema ProbeSpecParams
 */
export interface ProbeSpecParams {
    /**
     * name defines the parameter name
     *
     * @schema ProbeSpecParams#name
     */
    readonly name: string;
    /**
     * values defines the parameter values
     *
     * @schema ProbeSpecParams#values
     */
    readonly values?: string[];
}
/**
 * Converts an object of type 'ProbeSpecParams' to JSON representation.
 */
export declare function toJson_ProbeSpecParams(obj: ProbeSpecParams | undefined): Record<string, any> | undefined;
/**
 * prober defines the specification for the prober to use for probing targets.
 * The prober.URL parameter is required. Targets cannot be probed if left empty.
 *
 * @schema ProbeSpecProber
 */
export interface ProbeSpecProber {
    /**
     * noProxy defines a comma-separated string that can contain IPs, CIDR notation, domain names
     * that should be excluded from proxying. IP and domain names can
     * contain port numbers.
     *
     * It requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.
     *
     * @schema ProbeSpecProber#noProxy
     */
    readonly noProxy?: string;
    /**
     * path to collect metrics from.
     * Defaults to `/probe`.
     *
     * @default probe`.
     * @schema ProbeSpecProber#path
     */
    readonly path?: string;
    /**
     * proxyConnectHeader optionally specifies headers to send to
     * proxies during CONNECT requests.
     *
     * It requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.
     *
     * @schema ProbeSpecProber#proxyConnectHeader
     */
    readonly proxyConnectHeader?: {
        [key: string]: ProbeSpecProberProxyConnectHeader[];
    };
    /**
     * proxyFromEnvironment defines whether to use the proxy configuration defined by environment variables (HTTP_PROXY, HTTPS_PROXY, and NO_PROXY).
     *
     * It requires Prometheus >= v2.43.0, Alertmanager >= v0.25.0 or Thanos >= v0.32.0.
     *
     * @schema ProbeSpecProber#proxyFromEnvironment
     */
    readonly proxyFromEnvironment?: boolean;
    /**
     * proxyUrl defines the HTTP proxy server to use.
     *
     * @schema ProbeSpecProber#proxyUrl
     */
    readonly proxyUrl?: string;
    /**
     * scheme defines the HTTP scheme to use when scraping the prober.
     *
     * @schema ProbeSpecProber#scheme
     */
    readonly scheme?: ProbeSpecProberScheme;
    /**
     * url defines the address of the prober.
     *
     * Unlike what the name indicates, the value should be in the form of
     * `address:port` without any scheme which should be specified in the
     * `scheme` field.
     *
     * @schema ProbeSpecProber#url
     */
    readonly url: string;
}
/**
 * Converts an object of type 'ProbeSpecProber' to JSON representation.
 */
export declare function toJson_ProbeSpecProber(obj: ProbeSpecProber | undefined): Record<string, any> | undefined;
/**
 * ScrapeProtocol represents a protocol used by Prometheus for scraping metrics.
 * Supported values are:
 * * `OpenMetricsText0.0.1`
 * * `OpenMetricsText1.0.0`
 * * `PrometheusProto`
 * * `PrometheusText0.0.4`
 * * `PrometheusText1.0.0`
 *
 * @schema ProbeSpecScrapeProtocols
 */
export declare enum ProbeSpecScrapeProtocols {
    /** PrometheusProto */
    PROMETHEUS_PROTO = "PrometheusProto",
    /** OpenMetricsText0.0.1 */
    OPEN_METRICS_TEXT0_0_1 = "OpenMetricsText0.0.1",
    /** OpenMetricsText1.0.0 */
    OPEN_METRICS_TEXT1_0_0 = "OpenMetricsText1.0.0",
    /** PrometheusText0.0.4 */
    PROMETHEUS_TEXT0_0_4 = "PrometheusText0.0.4",
    /** PrometheusText1.0.0 */
    PROMETHEUS_TEXT1_0_0 = "PrometheusText1.0.0"
}
/**
 * targets defines a set of static or dynamically discovered targets to probe.
 *
 * @schema ProbeSpecTargets
 */
export interface ProbeSpecTargets {
    /**
     * ingress defines the Ingress objects to probe and the relabeling
     * configuration.
     * If `staticConfig` is also defined, `staticConfig` takes precedence.
     *
     * @schema ProbeSpecTargets#ingress
     */
    readonly ingress?: ProbeSpecTargetsIngress;
    /**
     * staticConfig defines the static list of targets to probe and the
     * relabeling configuration.
     * If `ingress` is also defined, `staticConfig` takes precedence.
     * More info: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#static_config.
     *
     * @schema ProbeSpecTargets#staticConfig
     */
    readonly staticConfig?: ProbeSpecTargetsStaticConfig;
}
/**
 * Converts an object of type 'ProbeSpecTargets' to JSON representation.
 */
export declare function toJson_ProbeSpecTargets(obj: ProbeSpecTargets | undefined): Record<string, any> | undefined;
/**
 * tlsConfig defines the TLS configuration to use when scraping the endpoint.
 *
 * @schema ProbeSpecTlsConfig
 */
export interface ProbeSpecTlsConfig {
    /**
     * ca defines the Certificate authority used when verifying server certificates.
     *
     * @schema ProbeSpecTlsConfig#ca
     */
    readonly ca?: ProbeSpecTlsConfigCa;
    /**
     * cert defines the Client certificate to present when doing client-authentication.
     *
     * @schema ProbeSpecTlsConfig#cert
     */
    readonly cert?: ProbeSpecTlsConfigCert;
    /**
     * insecureSkipVerify defines how to disable target certificate validation.
     *
     * @schema ProbeSpecTlsConfig#insecureSkipVerify
     */
    readonly insecureSkipVerify?: boolean;
    /**
     * keySecret defines the Secret containing the client key file for the targets.
     *
     * @schema ProbeSpecTlsConfig#keySecret
     */
    readonly keySecret?: ProbeSpecTlsConfigKeySecret;
    /**
     * maxVersion defines the maximum acceptable TLS version.
     *
     * It requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.
     *
     * @schema ProbeSpecTlsConfig#maxVersion
     */
    readonly maxVersion?: ProbeSpecTlsConfigMaxVersion;
    /**
     * minVersion defines the minimum acceptable TLS version.
     *
     * It requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.
     *
     * @schema ProbeSpecTlsConfig#minVersion
     */
    readonly minVersion?: ProbeSpecTlsConfigMinVersion;
    /**
     * serverName is used to verify the hostname for the targets.
     *
     * @schema ProbeSpecTlsConfig#serverName
     */
    readonly serverName?: string;
}
/**
 * Converts an object of type 'ProbeSpecTlsConfig' to JSON representation.
 */
export declare function toJson_ProbeSpecTlsConfig(obj: ProbeSpecTlsConfig | undefined): Record<string, any> | undefined;
/**
 * credentials defines a key of a Secret in the namespace that contains the credentials for authentication.
 *
 * @schema ProbeSpecAuthorizationCredentials
 */
export interface ProbeSpecAuthorizationCredentials {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecAuthorizationCredentials#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecAuthorizationCredentials#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecAuthorizationCredentials#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecAuthorizationCredentials' to JSON representation.
 */
export declare function toJson_ProbeSpecAuthorizationCredentials(obj: ProbeSpecAuthorizationCredentials | undefined): Record<string, any> | undefined;
/**
 * password defines a key of a Secret containing the password for
 * authentication.
 *
 * @schema ProbeSpecBasicAuthPassword
 */
export interface ProbeSpecBasicAuthPassword {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecBasicAuthPassword#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecBasicAuthPassword#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecBasicAuthPassword#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecBasicAuthPassword' to JSON representation.
 */
export declare function toJson_ProbeSpecBasicAuthPassword(obj: ProbeSpecBasicAuthPassword | undefined): Record<string, any> | undefined;
/**
 * username defines a key of a Secret containing the username for
 * authentication.
 *
 * @schema ProbeSpecBasicAuthUsername
 */
export interface ProbeSpecBasicAuthUsername {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecBasicAuthUsername#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecBasicAuthUsername#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecBasicAuthUsername#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecBasicAuthUsername' to JSON representation.
 */
export declare function toJson_ProbeSpecBasicAuthUsername(obj: ProbeSpecBasicAuthUsername | undefined): Record<string, any> | undefined;
/**
 * action to perform based on the regex matching.
 *
 * `Uppercase` and `Lowercase` actions require Prometheus >= v2.36.0.
 * `DropEqual` and `KeepEqual` actions require Prometheus >= v2.41.0.
 *
 * Default: "Replace"
 *
 * @schema ProbeSpecMetricRelabelingsAction
 */
export declare enum ProbeSpecMetricRelabelingsAction {
    /** replace */
    REPLACE = "replace",
    /** keep */
    KEEP = "keep",
    /** drop */
    DROP = "drop",
    /** hashmod */
    HASHMOD = "hashmod",
    /** labelmap */
    LABELMAP = "labelmap",
    /** labeldrop */
    LABELDROP = "labeldrop",
    /** labelkeep */
    LABELKEEP = "labelkeep",
    /** lowercase */
    LOWERCASE = "lowercase",
    /** uppercase */
    UPPERCASE = "uppercase",
    /** keepequal */
    KEEPEQUAL = "keepequal",
    /** dropequal */
    DROPEQUAL = "dropequal"
}
/**
 * clientId defines a key of a Secret or ConfigMap containing the
 * OAuth2 client's ID.
 *
 * @schema ProbeSpecOauth2ClientId
 */
export interface ProbeSpecOauth2ClientId {
    /**
     * configMap defines the ConfigMap containing data to use for the targets.
     *
     * @schema ProbeSpecOauth2ClientId#configMap
     */
    readonly configMap?: ProbeSpecOauth2ClientIdConfigMap;
    /**
     * secret defines the Secret containing data to use for the targets.
     *
     * @schema ProbeSpecOauth2ClientId#secret
     */
    readonly secret?: ProbeSpecOauth2ClientIdSecret;
}
/**
 * Converts an object of type 'ProbeSpecOauth2ClientId' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2ClientId(obj: ProbeSpecOauth2ClientId | undefined): Record<string, any> | undefined;
/**
 * clientSecret defines a key of a Secret containing the OAuth2
 * client's secret.
 *
 * @schema ProbeSpecOauth2ClientSecret
 */
export interface ProbeSpecOauth2ClientSecret {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecOauth2ClientSecret#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecOauth2ClientSecret#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecOauth2ClientSecret#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecOauth2ClientSecret' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2ClientSecret(obj: ProbeSpecOauth2ClientSecret | undefined): Record<string, any> | undefined;
/**
 * SecretKeySelector selects a key of a Secret.
 *
 * @schema ProbeSpecOauth2ProxyConnectHeader
 */
export interface ProbeSpecOauth2ProxyConnectHeader {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecOauth2ProxyConnectHeader#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecOauth2ProxyConnectHeader#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecOauth2ProxyConnectHeader#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecOauth2ProxyConnectHeader' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2ProxyConnectHeader(obj: ProbeSpecOauth2ProxyConnectHeader | undefined): Record<string, any> | undefined;
/**
 * tlsConfig defines the TLS configuration to use when connecting to the OAuth2 server.
 * It requires Prometheus >= v2.43.0.
 *
 * @schema ProbeSpecOauth2TlsConfig
 */
export interface ProbeSpecOauth2TlsConfig {
    /**
     * ca defines the Certificate authority used when verifying server certificates.
     *
     * @schema ProbeSpecOauth2TlsConfig#ca
     */
    readonly ca?: ProbeSpecOauth2TlsConfigCa;
    /**
     * cert defines the Client certificate to present when doing client-authentication.
     *
     * @schema ProbeSpecOauth2TlsConfig#cert
     */
    readonly cert?: ProbeSpecOauth2TlsConfigCert;
    /**
     * insecureSkipVerify defines how to disable target certificate validation.
     *
     * @schema ProbeSpecOauth2TlsConfig#insecureSkipVerify
     */
    readonly insecureSkipVerify?: boolean;
    /**
     * keySecret defines the Secret containing the client key file for the targets.
     *
     * @schema ProbeSpecOauth2TlsConfig#keySecret
     */
    readonly keySecret?: ProbeSpecOauth2TlsConfigKeySecret;
    /**
     * maxVersion defines the maximum acceptable TLS version.
     *
     * It requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.
     *
     * @schema ProbeSpecOauth2TlsConfig#maxVersion
     */
    readonly maxVersion?: ProbeSpecOauth2TlsConfigMaxVersion;
    /**
     * minVersion defines the minimum acceptable TLS version.
     *
     * It requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.
     *
     * @schema ProbeSpecOauth2TlsConfig#minVersion
     */
    readonly minVersion?: ProbeSpecOauth2TlsConfigMinVersion;
    /**
     * serverName is used to verify the hostname for the targets.
     *
     * @schema ProbeSpecOauth2TlsConfig#serverName
     */
    readonly serverName?: string;
}
/**
 * Converts an object of type 'ProbeSpecOauth2TlsConfig' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2TlsConfig(obj: ProbeSpecOauth2TlsConfig | undefined): Record<string, any> | undefined;
/**
 * SecretKeySelector selects a key of a Secret.
 *
 * @schema ProbeSpecProberProxyConnectHeader
 */
export interface ProbeSpecProberProxyConnectHeader {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecProberProxyConnectHeader#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecProberProxyConnectHeader#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecProberProxyConnectHeader#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecProberProxyConnectHeader' to JSON representation.
 */
export declare function toJson_ProbeSpecProberProxyConnectHeader(obj: ProbeSpecProberProxyConnectHeader | undefined): Record<string, any> | undefined;
/**
 * scheme defines the HTTP scheme to use when scraping the prober.
 *
 * @schema ProbeSpecProberScheme
 */
export declare enum ProbeSpecProberScheme {
    /** http */
    HTTP = "http",
    /** https */
    HTTPS = "https"
}
/**
 * ingress defines the Ingress objects to probe and the relabeling
 * configuration.
 * If `staticConfig` is also defined, `staticConfig` takes precedence.
 *
 * @schema ProbeSpecTargetsIngress
 */
export interface ProbeSpecTargetsIngress {
    /**
     * namespaceSelector defines from which namespaces to select Ingress objects.
     *
     * @schema ProbeSpecTargetsIngress#namespaceSelector
     */
    readonly namespaceSelector?: ProbeSpecTargetsIngressNamespaceSelector;
    /**
     * relabelingConfigs to apply to the label set of the target before it gets
     * scraped.
     * The original ingress address is available via the
     * `__tmp_prometheus_ingress_address` label. It can be used to customize the
     * probed URL.
     * The original scrape job's name is available via the `__tmp_prometheus_job_name` label.
     * More info: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#relabel_config
     *
     * @schema ProbeSpecTargetsIngress#relabelingConfigs
     */
    readonly relabelingConfigs?: ProbeSpecTargetsIngressRelabelingConfigs[];
    /**
     * selector to select the Ingress objects.
     *
     * @schema ProbeSpecTargetsIngress#selector
     */
    readonly selector?: ProbeSpecTargetsIngressSelector;
}
/**
 * Converts an object of type 'ProbeSpecTargetsIngress' to JSON representation.
 */
export declare function toJson_ProbeSpecTargetsIngress(obj: ProbeSpecTargetsIngress | undefined): Record<string, any> | undefined;
/**
 * staticConfig defines the static list of targets to probe and the
 * relabeling configuration.
 * If `ingress` is also defined, `staticConfig` takes precedence.
 * More info: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#static_config.
 *
 * @schema ProbeSpecTargetsStaticConfig
 */
export interface ProbeSpecTargetsStaticConfig {
    /**
     * labels defines all labels assigned to all metrics scraped from the targets.
     *
     * @schema ProbeSpecTargetsStaticConfig#labels
     */
    readonly labels?: {
        [key: string]: string;
    };
    /**
     * relabelingConfigs defines relabelings to be apply to the label set of the targets before it gets
     * scraped.
     * More info: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#relabel_config
     *
     * @schema ProbeSpecTargetsStaticConfig#relabelingConfigs
     */
    readonly relabelingConfigs?: ProbeSpecTargetsStaticConfigRelabelingConfigs[];
    /**
     * static defines the list of hosts to probe.
     *
     * @schema ProbeSpecTargetsStaticConfig#static
     */
    readonly static?: string[];
}
/**
 * Converts an object of type 'ProbeSpecTargetsStaticConfig' to JSON representation.
 */
export declare function toJson_ProbeSpecTargetsStaticConfig(obj: ProbeSpecTargetsStaticConfig | undefined): Record<string, any> | undefined;
/**
 * ca defines the Certificate authority used when verifying server certificates.
 *
 * @schema ProbeSpecTlsConfigCa
 */
export interface ProbeSpecTlsConfigCa {
    /**
     * configMap defines the ConfigMap containing data to use for the targets.
     *
     * @schema ProbeSpecTlsConfigCa#configMap
     */
    readonly configMap?: ProbeSpecTlsConfigCaConfigMap;
    /**
     * secret defines the Secret containing data to use for the targets.
     *
     * @schema ProbeSpecTlsConfigCa#secret
     */
    readonly secret?: ProbeSpecTlsConfigCaSecret;
}
/**
 * Converts an object of type 'ProbeSpecTlsConfigCa' to JSON representation.
 */
export declare function toJson_ProbeSpecTlsConfigCa(obj: ProbeSpecTlsConfigCa | undefined): Record<string, any> | undefined;
/**
 * cert defines the Client certificate to present when doing client-authentication.
 *
 * @schema ProbeSpecTlsConfigCert
 */
export interface ProbeSpecTlsConfigCert {
    /**
     * configMap defines the ConfigMap containing data to use for the targets.
     *
     * @schema ProbeSpecTlsConfigCert#configMap
     */
    readonly configMap?: ProbeSpecTlsConfigCertConfigMap;
    /**
     * secret defines the Secret containing data to use for the targets.
     *
     * @schema ProbeSpecTlsConfigCert#secret
     */
    readonly secret?: ProbeSpecTlsConfigCertSecret;
}
/**
 * Converts an object of type 'ProbeSpecTlsConfigCert' to JSON representation.
 */
export declare function toJson_ProbeSpecTlsConfigCert(obj: ProbeSpecTlsConfigCert | undefined): Record<string, any> | undefined;
/**
 * keySecret defines the Secret containing the client key file for the targets.
 *
 * @schema ProbeSpecTlsConfigKeySecret
 */
export interface ProbeSpecTlsConfigKeySecret {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecTlsConfigKeySecret#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecTlsConfigKeySecret#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecTlsConfigKeySecret#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecTlsConfigKeySecret' to JSON representation.
 */
export declare function toJson_ProbeSpecTlsConfigKeySecret(obj: ProbeSpecTlsConfigKeySecret | undefined): Record<string, any> | undefined;
/**
 * maxVersion defines the maximum acceptable TLS version.
 *
 * It requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.
 *
 * @schema ProbeSpecTlsConfigMaxVersion
 */
export declare enum ProbeSpecTlsConfigMaxVersion {
    /** TLS10 */
    TLS10 = "TLS10",
    /** TLS11 */
    TLS11 = "TLS11",
    /** TLS12 */
    TLS12 = "TLS12",
    /** TLS13 */
    TLS13 = "TLS13"
}
/**
 * minVersion defines the minimum acceptable TLS version.
 *
 * It requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.
 *
 * @schema ProbeSpecTlsConfigMinVersion
 */
export declare enum ProbeSpecTlsConfigMinVersion {
    /** TLS10 */
    TLS10 = "TLS10",
    /** TLS11 */
    TLS11 = "TLS11",
    /** TLS12 */
    TLS12 = "TLS12",
    /** TLS13 */
    TLS13 = "TLS13"
}
/**
 * configMap defines the ConfigMap containing data to use for the targets.
 *
 * @schema ProbeSpecOauth2ClientIdConfigMap
 */
export interface ProbeSpecOauth2ClientIdConfigMap {
    /**
     * The key to select.
     *
     * @schema ProbeSpecOauth2ClientIdConfigMap#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecOauth2ClientIdConfigMap#name
     */
    readonly name?: string;
    /**
     * Specify whether the ConfigMap or its key must be defined
     *
     * @schema ProbeSpecOauth2ClientIdConfigMap#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecOauth2ClientIdConfigMap' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2ClientIdConfigMap(obj: ProbeSpecOauth2ClientIdConfigMap | undefined): Record<string, any> | undefined;
/**
 * secret defines the Secret containing data to use for the targets.
 *
 * @schema ProbeSpecOauth2ClientIdSecret
 */
export interface ProbeSpecOauth2ClientIdSecret {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecOauth2ClientIdSecret#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecOauth2ClientIdSecret#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecOauth2ClientIdSecret#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecOauth2ClientIdSecret' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2ClientIdSecret(obj: ProbeSpecOauth2ClientIdSecret | undefined): Record<string, any> | undefined;
/**
 * ca defines the Certificate authority used when verifying server certificates.
 *
 * @schema ProbeSpecOauth2TlsConfigCa
 */
export interface ProbeSpecOauth2TlsConfigCa {
    /**
     * configMap defines the ConfigMap containing data to use for the targets.
     *
     * @schema ProbeSpecOauth2TlsConfigCa#configMap
     */
    readonly configMap?: ProbeSpecOauth2TlsConfigCaConfigMap;
    /**
     * secret defines the Secret containing data to use for the targets.
     *
     * @schema ProbeSpecOauth2TlsConfigCa#secret
     */
    readonly secret?: ProbeSpecOauth2TlsConfigCaSecret;
}
/**
 * Converts an object of type 'ProbeSpecOauth2TlsConfigCa' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2TlsConfigCa(obj: ProbeSpecOauth2TlsConfigCa | undefined): Record<string, any> | undefined;
/**
 * cert defines the Client certificate to present when doing client-authentication.
 *
 * @schema ProbeSpecOauth2TlsConfigCert
 */
export interface ProbeSpecOauth2TlsConfigCert {
    /**
     * configMap defines the ConfigMap containing data to use for the targets.
     *
     * @schema ProbeSpecOauth2TlsConfigCert#configMap
     */
    readonly configMap?: ProbeSpecOauth2TlsConfigCertConfigMap;
    /**
     * secret defines the Secret containing data to use for the targets.
     *
     * @schema ProbeSpecOauth2TlsConfigCert#secret
     */
    readonly secret?: ProbeSpecOauth2TlsConfigCertSecret;
}
/**
 * Converts an object of type 'ProbeSpecOauth2TlsConfigCert' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2TlsConfigCert(obj: ProbeSpecOauth2TlsConfigCert | undefined): Record<string, any> | undefined;
/**
 * keySecret defines the Secret containing the client key file for the targets.
 *
 * @schema ProbeSpecOauth2TlsConfigKeySecret
 */
export interface ProbeSpecOauth2TlsConfigKeySecret {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecOauth2TlsConfigKeySecret#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecOauth2TlsConfigKeySecret#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecOauth2TlsConfigKeySecret#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecOauth2TlsConfigKeySecret' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2TlsConfigKeySecret(obj: ProbeSpecOauth2TlsConfigKeySecret | undefined): Record<string, any> | undefined;
/**
 * maxVersion defines the maximum acceptable TLS version.
 *
 * It requires Prometheus >= v2.41.0 or Thanos >= v0.31.0.
 *
 * @schema ProbeSpecOauth2TlsConfigMaxVersion
 */
export declare enum ProbeSpecOauth2TlsConfigMaxVersion {
    /** TLS10 */
    TLS10 = "TLS10",
    /** TLS11 */
    TLS11 = "TLS11",
    /** TLS12 */
    TLS12 = "TLS12",
    /** TLS13 */
    TLS13 = "TLS13"
}
/**
 * minVersion defines the minimum acceptable TLS version.
 *
 * It requires Prometheus >= v2.35.0 or Thanos >= v0.28.0.
 *
 * @schema ProbeSpecOauth2TlsConfigMinVersion
 */
export declare enum ProbeSpecOauth2TlsConfigMinVersion {
    /** TLS10 */
    TLS10 = "TLS10",
    /** TLS11 */
    TLS11 = "TLS11",
    /** TLS12 */
    TLS12 = "TLS12",
    /** TLS13 */
    TLS13 = "TLS13"
}
/**
 * namespaceSelector defines from which namespaces to select Ingress objects.
 *
 * @schema ProbeSpecTargetsIngressNamespaceSelector
 */
export interface ProbeSpecTargetsIngressNamespaceSelector {
    /**
     * any defines the boolean describing whether all namespaces are selected in contrast to a
     * list restricting them.
     *
     * @schema ProbeSpecTargetsIngressNamespaceSelector#any
     */
    readonly any?: boolean;
    /**
     * matchNames defines the list of namespace names to select from.
     *
     * @schema ProbeSpecTargetsIngressNamespaceSelector#matchNames
     */
    readonly matchNames?: string[];
}
/**
 * Converts an object of type 'ProbeSpecTargetsIngressNamespaceSelector' to JSON representation.
 */
export declare function toJson_ProbeSpecTargetsIngressNamespaceSelector(obj: ProbeSpecTargetsIngressNamespaceSelector | undefined): Record<string, any> | undefined;
/**
 * RelabelConfig allows dynamic rewriting of the label set for targets, alerts,
 * scraped samples and remote write samples.
 *
 * More info: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#relabel_config
 *
 * @schema ProbeSpecTargetsIngressRelabelingConfigs
 */
export interface ProbeSpecTargetsIngressRelabelingConfigs {
    /**
     * action to perform based on the regex matching.
     *
     * `Uppercase` and `Lowercase` actions require Prometheus >= v2.36.0.
     * `DropEqual` and `KeepEqual` actions require Prometheus >= v2.41.0.
     *
     * Default: "Replace"
     *
     * @schema ProbeSpecTargetsIngressRelabelingConfigs#action
     */
    readonly action?: ProbeSpecTargetsIngressRelabelingConfigsAction;
    /**
     * modulus to take of the hash of the source label values.
     *
     * Only applicable when the action is `HashMod`.
     *
     * @schema ProbeSpecTargetsIngressRelabelingConfigs#modulus
     */
    readonly modulus?: number;
    /**
     * regex defines the regular expression against which the extracted value is matched.
     *
     * @schema ProbeSpecTargetsIngressRelabelingConfigs#regex
     */
    readonly regex?: string;
    /**
     * replacement value against which a Replace action is performed if the
     * regular expression matches.
     *
     * Regex capture groups are available.
     *
     * @schema ProbeSpecTargetsIngressRelabelingConfigs#replacement
     */
    readonly replacement?: string;
    /**
     * separator defines the string between concatenated SourceLabels.
     *
     * @schema ProbeSpecTargetsIngressRelabelingConfigs#separator
     */
    readonly separator?: string;
    /**
     * sourceLabels defines the source labels select values from existing labels. Their content is
     * concatenated using the configured Separator and matched against the
     * configured regular expression.
     *
     * @schema ProbeSpecTargetsIngressRelabelingConfigs#sourceLabels
     */
    readonly sourceLabels?: string[];
    /**
     * targetLabel defines the label to which the resulting string is written in a replacement.
     *
     * It is mandatory for `Replace`, `HashMod`, `Lowercase`, `Uppercase`,
     * `KeepEqual` and `DropEqual` actions.
     *
     * Regex capture groups are available.
     *
     * @schema ProbeSpecTargetsIngressRelabelingConfigs#targetLabel
     */
    readonly targetLabel?: string;
}
/**
 * Converts an object of type 'ProbeSpecTargetsIngressRelabelingConfigs' to JSON representation.
 */
export declare function toJson_ProbeSpecTargetsIngressRelabelingConfigs(obj: ProbeSpecTargetsIngressRelabelingConfigs | undefined): Record<string, any> | undefined;
/**
 * selector to select the Ingress objects.
 *
 * @schema ProbeSpecTargetsIngressSelector
 */
export interface ProbeSpecTargetsIngressSelector {
    /**
     * matchExpressions is a list of label selector requirements. The requirements are ANDed.
     *
     * @schema ProbeSpecTargetsIngressSelector#matchExpressions
     */
    readonly matchExpressions?: ProbeSpecTargetsIngressSelectorMatchExpressions[];
    /**
     * matchLabels is a map of {key,value} pairs. A single {key,value} in the matchLabels
     * map is equivalent to an element of matchExpressions, whose key field is "key", the
     * operator is "In", and the values array contains only "value". The requirements are ANDed.
     *
     * @schema ProbeSpecTargetsIngressSelector#matchLabels
     */
    readonly matchLabels?: {
        [key: string]: string;
    };
}
/**
 * Converts an object of type 'ProbeSpecTargetsIngressSelector' to JSON representation.
 */
export declare function toJson_ProbeSpecTargetsIngressSelector(obj: ProbeSpecTargetsIngressSelector | undefined): Record<string, any> | undefined;
/**
 * RelabelConfig allows dynamic rewriting of the label set for targets, alerts,
 * scraped samples and remote write samples.
 *
 * More info: https://prometheus.io/docs/prometheus/latest/configuration/configuration/#relabel_config
 *
 * @schema ProbeSpecTargetsStaticConfigRelabelingConfigs
 */
export interface ProbeSpecTargetsStaticConfigRelabelingConfigs {
    /**
     * action to perform based on the regex matching.
     *
     * `Uppercase` and `Lowercase` actions require Prometheus >= v2.36.0.
     * `DropEqual` and `KeepEqual` actions require Prometheus >= v2.41.0.
     *
     * Default: "Replace"
     *
     * @schema ProbeSpecTargetsStaticConfigRelabelingConfigs#action
     */
    readonly action?: ProbeSpecTargetsStaticConfigRelabelingConfigsAction;
    /**
     * modulus to take of the hash of the source label values.
     *
     * Only applicable when the action is `HashMod`.
     *
     * @schema ProbeSpecTargetsStaticConfigRelabelingConfigs#modulus
     */
    readonly modulus?: number;
    /**
     * regex defines the regular expression against which the extracted value is matched.
     *
     * @schema ProbeSpecTargetsStaticConfigRelabelingConfigs#regex
     */
    readonly regex?: string;
    /**
     * replacement value against which a Replace action is performed if the
     * regular expression matches.
     *
     * Regex capture groups are available.
     *
     * @schema ProbeSpecTargetsStaticConfigRelabelingConfigs#replacement
     */
    readonly replacement?: string;
    /**
     * separator defines the string between concatenated SourceLabels.
     *
     * @schema ProbeSpecTargetsStaticConfigRelabelingConfigs#separator
     */
    readonly separator?: string;
    /**
     * sourceLabels defines the source labels select values from existing labels. Their content is
     * concatenated using the configured Separator and matched against the
     * configured regular expression.
     *
     * @schema ProbeSpecTargetsStaticConfigRelabelingConfigs#sourceLabels
     */
    readonly sourceLabels?: string[];
    /**
     * targetLabel defines the label to which the resulting string is written in a replacement.
     *
     * It is mandatory for `Replace`, `HashMod`, `Lowercase`, `Uppercase`,
     * `KeepEqual` and `DropEqual` actions.
     *
     * Regex capture groups are available.
     *
     * @schema ProbeSpecTargetsStaticConfigRelabelingConfigs#targetLabel
     */
    readonly targetLabel?: string;
}
/**
 * Converts an object of type 'ProbeSpecTargetsStaticConfigRelabelingConfigs' to JSON representation.
 */
export declare function toJson_ProbeSpecTargetsStaticConfigRelabelingConfigs(obj: ProbeSpecTargetsStaticConfigRelabelingConfigs | undefined): Record<string, any> | undefined;
/**
 * configMap defines the ConfigMap containing data to use for the targets.
 *
 * @schema ProbeSpecTlsConfigCaConfigMap
 */
export interface ProbeSpecTlsConfigCaConfigMap {
    /**
     * The key to select.
     *
     * @schema ProbeSpecTlsConfigCaConfigMap#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecTlsConfigCaConfigMap#name
     */
    readonly name?: string;
    /**
     * Specify whether the ConfigMap or its key must be defined
     *
     * @schema ProbeSpecTlsConfigCaConfigMap#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecTlsConfigCaConfigMap' to JSON representation.
 */
export declare function toJson_ProbeSpecTlsConfigCaConfigMap(obj: ProbeSpecTlsConfigCaConfigMap | undefined): Record<string, any> | undefined;
/**
 * secret defines the Secret containing data to use for the targets.
 *
 * @schema ProbeSpecTlsConfigCaSecret
 */
export interface ProbeSpecTlsConfigCaSecret {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecTlsConfigCaSecret#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecTlsConfigCaSecret#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecTlsConfigCaSecret#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecTlsConfigCaSecret' to JSON representation.
 */
export declare function toJson_ProbeSpecTlsConfigCaSecret(obj: ProbeSpecTlsConfigCaSecret | undefined): Record<string, any> | undefined;
/**
 * configMap defines the ConfigMap containing data to use for the targets.
 *
 * @schema ProbeSpecTlsConfigCertConfigMap
 */
export interface ProbeSpecTlsConfigCertConfigMap {
    /**
     * The key to select.
     *
     * @schema ProbeSpecTlsConfigCertConfigMap#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecTlsConfigCertConfigMap#name
     */
    readonly name?: string;
    /**
     * Specify whether the ConfigMap or its key must be defined
     *
     * @schema ProbeSpecTlsConfigCertConfigMap#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecTlsConfigCertConfigMap' to JSON representation.
 */
export declare function toJson_ProbeSpecTlsConfigCertConfigMap(obj: ProbeSpecTlsConfigCertConfigMap | undefined): Record<string, any> | undefined;
/**
 * secret defines the Secret containing data to use for the targets.
 *
 * @schema ProbeSpecTlsConfigCertSecret
 */
export interface ProbeSpecTlsConfigCertSecret {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecTlsConfigCertSecret#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecTlsConfigCertSecret#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecTlsConfigCertSecret#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecTlsConfigCertSecret' to JSON representation.
 */
export declare function toJson_ProbeSpecTlsConfigCertSecret(obj: ProbeSpecTlsConfigCertSecret | undefined): Record<string, any> | undefined;
/**
 * configMap defines the ConfigMap containing data to use for the targets.
 *
 * @schema ProbeSpecOauth2TlsConfigCaConfigMap
 */
export interface ProbeSpecOauth2TlsConfigCaConfigMap {
    /**
     * The key to select.
     *
     * @schema ProbeSpecOauth2TlsConfigCaConfigMap#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecOauth2TlsConfigCaConfigMap#name
     */
    readonly name?: string;
    /**
     * Specify whether the ConfigMap or its key must be defined
     *
     * @schema ProbeSpecOauth2TlsConfigCaConfigMap#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecOauth2TlsConfigCaConfigMap' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2TlsConfigCaConfigMap(obj: ProbeSpecOauth2TlsConfigCaConfigMap | undefined): Record<string, any> | undefined;
/**
 * secret defines the Secret containing data to use for the targets.
 *
 * @schema ProbeSpecOauth2TlsConfigCaSecret
 */
export interface ProbeSpecOauth2TlsConfigCaSecret {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecOauth2TlsConfigCaSecret#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecOauth2TlsConfigCaSecret#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecOauth2TlsConfigCaSecret#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecOauth2TlsConfigCaSecret' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2TlsConfigCaSecret(obj: ProbeSpecOauth2TlsConfigCaSecret | undefined): Record<string, any> | undefined;
/**
 * configMap defines the ConfigMap containing data to use for the targets.
 *
 * @schema ProbeSpecOauth2TlsConfigCertConfigMap
 */
export interface ProbeSpecOauth2TlsConfigCertConfigMap {
    /**
     * The key to select.
     *
     * @schema ProbeSpecOauth2TlsConfigCertConfigMap#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecOauth2TlsConfigCertConfigMap#name
     */
    readonly name?: string;
    /**
     * Specify whether the ConfigMap or its key must be defined
     *
     * @schema ProbeSpecOauth2TlsConfigCertConfigMap#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecOauth2TlsConfigCertConfigMap' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2TlsConfigCertConfigMap(obj: ProbeSpecOauth2TlsConfigCertConfigMap | undefined): Record<string, any> | undefined;
/**
 * secret defines the Secret containing data to use for the targets.
 *
 * @schema ProbeSpecOauth2TlsConfigCertSecret
 */
export interface ProbeSpecOauth2TlsConfigCertSecret {
    /**
     * The key of the secret to select from.  Must be a valid secret key.
     *
     * @schema ProbeSpecOauth2TlsConfigCertSecret#key
     */
    readonly key: string;
    /**
     * Name of the referent.
     * This field is effectively required, but due to backwards compatibility is
     * allowed to be empty. Instances of this type with an empty value here are
     * almost certainly wrong.
     * More info: https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#names
     *
     * @schema ProbeSpecOauth2TlsConfigCertSecret#name
     */
    readonly name?: string;
    /**
     * Specify whether the Secret or its key must be defined
     *
     * @schema ProbeSpecOauth2TlsConfigCertSecret#optional
     */
    readonly optional?: boolean;
}
/**
 * Converts an object of type 'ProbeSpecOauth2TlsConfigCertSecret' to JSON representation.
 */
export declare function toJson_ProbeSpecOauth2TlsConfigCertSecret(obj: ProbeSpecOauth2TlsConfigCertSecret | undefined): Record<string, any> | undefined;
/**
 * action to perform based on the regex matching.
 *
 * `Uppercase` and `Lowercase` actions require Prometheus >= v2.36.0.
 * `DropEqual` and `KeepEqual` actions require Prometheus >= v2.41.0.
 *
 * Default: "Replace"
 *
 * @schema ProbeSpecTargetsIngressRelabelingConfigsAction
 */
export declare enum ProbeSpecTargetsIngressRelabelingConfigsAction {
    /** replace */
    REPLACE = "replace",
    /** keep */
    KEEP = "keep",
    /** drop */
    DROP = "drop",
    /** hashmod */
    HASHMOD = "hashmod",
    /** labelmap */
    LABELMAP = "labelmap",
    /** labeldrop */
    LABELDROP = "labeldrop",
    /** labelkeep */
    LABELKEEP = "labelkeep",
    /** lowercase */
    LOWERCASE = "lowercase",
    /** uppercase */
    UPPERCASE = "uppercase",
    /** keepequal */
    KEEPEQUAL = "keepequal",
    /** dropequal */
    DROPEQUAL = "dropequal"
}
/**
 * A label selector requirement is a selector that contains values, a key, and an operator that
 * relates the key and values.
 *
 * @schema ProbeSpecTargetsIngressSelectorMatchExpressions
 */
export interface ProbeSpecTargetsIngressSelectorMatchExpressions {
    /**
     * key is the label key that the selector applies to.
     *
     * @schema ProbeSpecTargetsIngressSelectorMatchExpressions#key
     */
    readonly key: string;
    /**
     * operator represents a key's relationship to a set of values.
     * Valid operators are In, NotIn, Exists and DoesNotExist.
     *
     * @schema ProbeSpecTargetsIngressSelectorMatchExpressions#operator
     */
    readonly operator: string;
    /**
     * values is an array of string values. If the operator is In or NotIn,
     * the values array must be non-empty. If the operator is Exists or DoesNotExist,
     * the values array must be empty. This array is replaced during a strategic
     * merge patch.
     *
     * @schema ProbeSpecTargetsIngressSelectorMatchExpressions#values
     */
    readonly values?: string[];
}
/**
 * Converts an object of type 'ProbeSpecTargetsIngressSelectorMatchExpressions' to JSON representation.
 */
export declare function toJson_ProbeSpecTargetsIngressSelectorMatchExpressions(obj: ProbeSpecTargetsIngressSelectorMatchExpressions | undefined): Record<string, any> | undefined;
/**
 * action to perform based on the regex matching.
 *
 * `Uppercase` and `Lowercase` actions require Prometheus >= v2.36.0.
 * `DropEqual` and `KeepEqual` actions require Prometheus >= v2.41.0.
 *
 * Default: "Replace"
 *
 * @schema ProbeSpecTargetsStaticConfigRelabelingConfigsAction
 */
export declare enum ProbeSpecTargetsStaticConfigRelabelingConfigsAction {
    /** replace */
    REPLACE = "replace",
    /** keep */
    KEEP = "keep",
    /** drop */
    DROP = "drop",
    /** hashmod */
    HASHMOD = "hashmod",
    /** labelmap */
    LABELMAP = "labelmap",
    /** labeldrop */
    LABELDROP = "labeldrop",
    /** labelkeep */
    LABELKEEP = "labelkeep",
    /** lowercase */
    LOWERCASE = "lowercase",
    /** uppercase */
    UPPERCASE = "uppercase",
    /** keepequal */
    KEEPEQUAL = "keepequal",
    /** dropequal */
    DROPEQUAL = "dropequal"
}
