"use strict";
var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookSpecCaProviderType = exports.Webhook = exports.VaultDynamicSecretSpecProviderCaProviderType = exports.VaultDynamicSecretSpecProviderVersion = exports.VaultDynamicSecretSpecResultType = exports.VaultDynamicSecret = exports.Uuid = exports.StsSessionToken = exports.QuayAccessToken = exports.Password = exports.Grafana = exports.GithubAccessToken = exports.GeneratorState = exports.GcrAccessToken = exports.Fake = exports.EcrAuthorizationToken = exports.ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType = exports.ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType = exports.ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion = exports.ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType = exports.ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType = exports.ClusterGeneratorSpecKind = exports.ClusterGenerator = exports.AcrAccessTokenSpecEnvironmentType = exports.AcrAccessToken = void 0;
exports.toJson_AcrAccessTokenProps = toJson_AcrAccessTokenProps;
exports.toJson_AcrAccessTokenSpec = toJson_AcrAccessTokenSpec;
exports.toJson_AcrAccessTokenSpecAuth = toJson_AcrAccessTokenSpecAuth;
exports.toJson_AcrAccessTokenSpecAuthManagedIdentity = toJson_AcrAccessTokenSpecAuthManagedIdentity;
exports.toJson_AcrAccessTokenSpecAuthServicePrincipal = toJson_AcrAccessTokenSpecAuthServicePrincipal;
exports.toJson_AcrAccessTokenSpecAuthWorkloadIdentity = toJson_AcrAccessTokenSpecAuthWorkloadIdentity;
exports.toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRef = toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRef;
exports.toJson_AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef = toJson_AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef;
exports.toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId = toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId;
exports.toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret = toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret;
exports.toJson_ClusterGeneratorProps = toJson_ClusterGeneratorProps;
exports.toJson_ClusterGeneratorSpec = toJson_ClusterGeneratorSpec;
exports.toJson_ClusterGeneratorSpecGenerator = toJson_ClusterGeneratorSpecGenerator;
exports.toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpec = toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpec;
exports.toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec = toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec;
exports.toJson_ClusterGeneratorSpecGeneratorFakeSpec = toJson_ClusterGeneratorSpecGeneratorFakeSpec;
exports.toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpec = toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpec;
exports.toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpec = toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpec;
exports.toJson_ClusterGeneratorSpecGeneratorGrafanaSpec = toJson_ClusterGeneratorSpecGeneratorGrafanaSpec;
exports.toJson_ClusterGeneratorSpecGeneratorPasswordSpec = toJson_ClusterGeneratorSpecGeneratorPasswordSpec;
exports.toJson_ClusterGeneratorSpecGeneratorQuayAccessTokenSpec = toJson_ClusterGeneratorSpecGeneratorQuayAccessTokenSpec;
exports.toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpec = toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpec;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec;
exports.toJson_ClusterGeneratorSpecGeneratorWebhookSpec = toJson_ClusterGeneratorSpecGeneratorWebhookSpec;
exports.toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth = toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth;
exports.toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth = toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth;
exports.toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth = toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth;
exports.toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth = toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth;
exports.toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuth = toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuth;
exports.toJson_ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount = toJson_ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount;
exports.toJson_ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef = toJson_ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef;
exports.toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth = toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth;
exports.toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters = toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings;
exports.toJson_ClusterGeneratorSpecGeneratorWebhookSpecCaProvider = toJson_ClusterGeneratorSpecGeneratorWebhookSpecCaProvider;
exports.toJson_ClusterGeneratorSpecGeneratorWebhookSpecResult = toJson_ClusterGeneratorSpecGeneratorWebhookSpecResult;
exports.toJson_ClusterGeneratorSpecGeneratorWebhookSpecSecrets = toJson_ClusterGeneratorSpecGeneratorWebhookSpecSecrets;
exports.toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity = toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity;
exports.toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal = toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal;
exports.toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity = toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity;
exports.toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt = toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt;
exports.toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef = toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef = toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity = toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity;
exports.toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey = toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey;
exports.toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic = toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic;
exports.toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken = toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken;
exports.toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt = toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt;
exports.toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef = toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls;
exports.toJson_ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef = toJson_ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef = toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef = toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef;
exports.toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef = toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef;
exports.toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef = toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef = toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef = toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef = toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef = toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef;
exports.toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef = toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword = toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword;
exports.toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef = toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef;
exports.toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef = toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef = toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef = toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId = toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId;
exports.toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret = toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef;
exports.toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef = toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef;
exports.toJson_EcrAuthorizationTokenProps = toJson_EcrAuthorizationTokenProps;
exports.toJson_EcrAuthorizationTokenSpec = toJson_EcrAuthorizationTokenSpec;
exports.toJson_EcrAuthorizationTokenSpecAuth = toJson_EcrAuthorizationTokenSpecAuth;
exports.toJson_EcrAuthorizationTokenSpecAuthJwt = toJson_EcrAuthorizationTokenSpecAuthJwt;
exports.toJson_EcrAuthorizationTokenSpecAuthSecretRef = toJson_EcrAuthorizationTokenSpecAuthSecretRef;
exports.toJson_EcrAuthorizationTokenSpecAuthJwtServiceAccountRef = toJson_EcrAuthorizationTokenSpecAuthJwtServiceAccountRef;
exports.toJson_EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef = toJson_EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef;
exports.toJson_EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef = toJson_EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef;
exports.toJson_EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef = toJson_EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef;
exports.toJson_FakeProps = toJson_FakeProps;
exports.toJson_FakeSpec = toJson_FakeSpec;
exports.toJson_GcrAccessTokenProps = toJson_GcrAccessTokenProps;
exports.toJson_GcrAccessTokenSpec = toJson_GcrAccessTokenSpec;
exports.toJson_GcrAccessTokenSpecAuth = toJson_GcrAccessTokenSpecAuth;
exports.toJson_GcrAccessTokenSpecAuthSecretRef = toJson_GcrAccessTokenSpecAuthSecretRef;
exports.toJson_GcrAccessTokenSpecAuthWorkloadIdentity = toJson_GcrAccessTokenSpecAuthWorkloadIdentity;
exports.toJson_GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef = toJson_GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef;
exports.toJson_GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef = toJson_GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef;
exports.toJson_GeneratorStateProps = toJson_GeneratorStateProps;
exports.toJson_GeneratorStateSpec = toJson_GeneratorStateSpec;
exports.toJson_GithubAccessTokenProps = toJson_GithubAccessTokenProps;
exports.toJson_GithubAccessTokenSpec = toJson_GithubAccessTokenSpec;
exports.toJson_GithubAccessTokenSpecAuth = toJson_GithubAccessTokenSpecAuth;
exports.toJson_GithubAccessTokenSpecAuthPrivateKey = toJson_GithubAccessTokenSpecAuthPrivateKey;
exports.toJson_GithubAccessTokenSpecAuthPrivateKeySecretRef = toJson_GithubAccessTokenSpecAuthPrivateKeySecretRef;
exports.toJson_GrafanaProps = toJson_GrafanaProps;
exports.toJson_GrafanaSpec = toJson_GrafanaSpec;
exports.toJson_GrafanaSpecAuth = toJson_GrafanaSpecAuth;
exports.toJson_GrafanaSpecServiceAccount = toJson_GrafanaSpecServiceAccount;
exports.toJson_GrafanaSpecAuthBasic = toJson_GrafanaSpecAuthBasic;
exports.toJson_GrafanaSpecAuthToken = toJson_GrafanaSpecAuthToken;
exports.toJson_GrafanaSpecAuthBasicPassword = toJson_GrafanaSpecAuthBasicPassword;
exports.toJson_PasswordProps = toJson_PasswordProps;
exports.toJson_PasswordSpec = toJson_PasswordSpec;
exports.toJson_QuayAccessTokenProps = toJson_QuayAccessTokenProps;
exports.toJson_QuayAccessTokenSpec = toJson_QuayAccessTokenSpec;
exports.toJson_QuayAccessTokenSpecServiceAccountRef = toJson_QuayAccessTokenSpecServiceAccountRef;
exports.toJson_StsSessionTokenProps = toJson_StsSessionTokenProps;
exports.toJson_StsSessionTokenSpec = toJson_StsSessionTokenSpec;
exports.toJson_StsSessionTokenSpecAuth = toJson_StsSessionTokenSpecAuth;
exports.toJson_StsSessionTokenSpecRequestParameters = toJson_StsSessionTokenSpecRequestParameters;
exports.toJson_StsSessionTokenSpecAuthJwt = toJson_StsSessionTokenSpecAuthJwt;
exports.toJson_StsSessionTokenSpecAuthSecretRef = toJson_StsSessionTokenSpecAuthSecretRef;
exports.toJson_StsSessionTokenSpecAuthJwtServiceAccountRef = toJson_StsSessionTokenSpecAuthJwtServiceAccountRef;
exports.toJson_StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef = toJson_StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef;
exports.toJson_StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef = toJson_StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef;
exports.toJson_StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef = toJson_StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef;
exports.toJson_UuidProps = toJson_UuidProps;
exports.toJson_VaultDynamicSecretProps = toJson_VaultDynamicSecretProps;
exports.toJson_VaultDynamicSecretSpec = toJson_VaultDynamicSecretSpec;
exports.toJson_VaultDynamicSecretSpecProvider = toJson_VaultDynamicSecretSpecProvider;
exports.toJson_VaultDynamicSecretSpecRetrySettings = toJson_VaultDynamicSecretSpecRetrySettings;
exports.toJson_VaultDynamicSecretSpecProviderAuth = toJson_VaultDynamicSecretSpecProviderAuth;
exports.toJson_VaultDynamicSecretSpecProviderCaProvider = toJson_VaultDynamicSecretSpecProviderCaProvider;
exports.toJson_VaultDynamicSecretSpecProviderTls = toJson_VaultDynamicSecretSpecProviderTls;
exports.toJson_VaultDynamicSecretSpecProviderAuthAppRole = toJson_VaultDynamicSecretSpecProviderAuthAppRole;
exports.toJson_VaultDynamicSecretSpecProviderAuthCert = toJson_VaultDynamicSecretSpecProviderAuthCert;
exports.toJson_VaultDynamicSecretSpecProviderAuthIam = toJson_VaultDynamicSecretSpecProviderAuthIam;
exports.toJson_VaultDynamicSecretSpecProviderAuthJwt = toJson_VaultDynamicSecretSpecProviderAuthJwt;
exports.toJson_VaultDynamicSecretSpecProviderAuthKubernetes = toJson_VaultDynamicSecretSpecProviderAuthKubernetes;
exports.toJson_VaultDynamicSecretSpecProviderAuthLdap = toJson_VaultDynamicSecretSpecProviderAuthLdap;
exports.toJson_VaultDynamicSecretSpecProviderAuthTokenSecretRef = toJson_VaultDynamicSecretSpecProviderAuthTokenSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthUserPass = toJson_VaultDynamicSecretSpecProviderAuthUserPass;
exports.toJson_VaultDynamicSecretSpecProviderTlsCertSecretRef = toJson_VaultDynamicSecretSpecProviderTlsCertSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderTlsKeySecretRef = toJson_VaultDynamicSecretSpecProviderTlsKeySecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthAppRoleRoleRef = toJson_VaultDynamicSecretSpecProviderAuthAppRoleRoleRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthAppRoleSecretRef = toJson_VaultDynamicSecretSpecProviderAuthAppRoleSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthCertClientCert = toJson_VaultDynamicSecretSpecProviderAuthCertClientCert;
exports.toJson_VaultDynamicSecretSpecProviderAuthCertSecretRef = toJson_VaultDynamicSecretSpecProviderAuthCertSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthIamJwt = toJson_VaultDynamicSecretSpecProviderAuthIamJwt;
exports.toJson_VaultDynamicSecretSpecProviderAuthIamSecretRef = toJson_VaultDynamicSecretSpecProviderAuthIamSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken = toJson_VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken;
exports.toJson_VaultDynamicSecretSpecProviderAuthJwtSecretRef = toJson_VaultDynamicSecretSpecProviderAuthJwtSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthKubernetesSecretRef = toJson_VaultDynamicSecretSpecProviderAuthKubernetesSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef = toJson_VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthLdapSecretRef = toJson_VaultDynamicSecretSpecProviderAuthLdapSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthUserPassSecretRef = toJson_VaultDynamicSecretSpecProviderAuthUserPassSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef = toJson_VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef = toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef = toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef = toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef;
exports.toJson_VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef = toJson_VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef;
exports.toJson_WebhookProps = toJson_WebhookProps;
exports.toJson_WebhookSpec = toJson_WebhookSpec;
exports.toJson_WebhookSpecCaProvider = toJson_WebhookSpecCaProvider;
exports.toJson_WebhookSpecResult = toJson_WebhookSpecResult;
exports.toJson_WebhookSpecSecrets = toJson_WebhookSpecSecrets;
exports.toJson_WebhookSpecSecretsSecretRef = toJson_WebhookSpecSecretsSecretRef;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
// generated by cdk8s
const cdk8s_1 = require("cdk8s");
/**
 * ACRAccessToken returns an Azure Container Registry token
that can be used for pushing/pulling images.
Note: by default it will return an ACR Refresh Token with full access
(depending on the identity).
This can be scoped down to the repository level using .spec.scope.
In case scope is defined it will return an ACR Access Token.

See docs: https://github.com/Azure/acr/blob/main/docs/AAD-OAuth.md
 *
 * @schema ACRAccessToken
 */
class AcrAccessToken extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "ACRAccessToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...AcrAccessToken.GVK,
            ...toJson_AcrAccessTokenProps(props),
        };
    }
    /**
     * Defines a "ACRAccessToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...AcrAccessToken.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...AcrAccessToken.GVK,
            ...toJson_AcrAccessTokenProps(resolved),
        };
    }
}
exports.AcrAccessToken = AcrAccessToken;
_a = JSII_RTTI_SYMBOL_1;
AcrAccessToken[_a] = { fqn: "ioexternal-secretsgenerators.AcrAccessToken", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "ACRAccessToken"
 */
AcrAccessToken.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'ACRAccessToken',
};
/**
 * Converts an object of type 'AcrAccessTokenProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_AcrAccessTokenProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_AcrAccessTokenSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'AcrAccessTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_AcrAccessTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_AcrAccessTokenSpecAuth(obj.auth),
        'environmentType': obj.environmentType,
        'registry': obj.registry,
        'scope': obj.scope,
        'tenantId': obj.tenantId,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_AcrAccessTokenSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'managedIdentity': toJson_AcrAccessTokenSpecAuthManagedIdentity(obj.managedIdentity),
        'servicePrincipal': toJson_AcrAccessTokenSpecAuthServicePrincipal(obj.servicePrincipal),
        'workloadIdentity': toJson_AcrAccessTokenSpecAuthWorkloadIdentity(obj.workloadIdentity),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * EnvironmentType specifies the Azure cloud environment endpoints to use for
 * connecting and authenticating with Azure. By default it points to the public cloud AAD endpoint.
 * The following endpoints are available, also see here: https://github.com/Azure/go-autorest/blob/main/autorest/azure/environments.go#L152
 * PublicCloud, USGovernmentCloud, ChinaCloud, GermanCloud
 *
 * @schema AcrAccessTokenSpecEnvironmentType
 */
var AcrAccessTokenSpecEnvironmentType;
(function (AcrAccessTokenSpecEnvironmentType) {
    /** PublicCloud */
    AcrAccessTokenSpecEnvironmentType["PUBLIC_CLOUD"] = "PublicCloud";
    /** USGovernmentCloud */
    AcrAccessTokenSpecEnvironmentType["US_GOVERNMENT_CLOUD"] = "USGovernmentCloud";
    /** ChinaCloud */
    AcrAccessTokenSpecEnvironmentType["CHINA_CLOUD"] = "ChinaCloud";
    /** GermanCloud */
    AcrAccessTokenSpecEnvironmentType["GERMAN_CLOUD"] = "GermanCloud";
})(AcrAccessTokenSpecEnvironmentType || (exports.AcrAccessTokenSpecEnvironmentType = AcrAccessTokenSpecEnvironmentType = {}));
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthManagedIdentity' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_AcrAccessTokenSpecAuthManagedIdentity(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'identityId': obj.identityId,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthServicePrincipal' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_AcrAccessTokenSpecAuthServicePrincipal(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretRef': toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthWorkloadIdentity' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_AcrAccessTokenSpecAuthWorkloadIdentity(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'serviceAccountRef': toJson_AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthServicePrincipalSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'clientId': toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId(obj.clientId),
        'clientSecret': toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret(obj.clientSecret),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_AcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRefClientId(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_AcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * ClusterGenerator represents a cluster-wide generator which can be referenced as part of `generatorRef` fields.
 *
 * @schema ClusterGenerator
 */
class ClusterGenerator extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "ClusterGenerator".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...ClusterGenerator.GVK,
            ...toJson_ClusterGeneratorProps(props),
        };
    }
    /**
     * Defines a "ClusterGenerator" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...ClusterGenerator.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...ClusterGenerator.GVK,
            ...toJson_ClusterGeneratorProps(resolved),
        };
    }
}
exports.ClusterGenerator = ClusterGenerator;
_b = JSII_RTTI_SYMBOL_1;
ClusterGenerator[_b] = { fqn: "ioexternal-secretsgenerators.ClusterGenerator", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "ClusterGenerator"
 */
ClusterGenerator.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'ClusterGenerator',
};
/**
 * Converts an object of type 'ClusterGeneratorProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_ClusterGeneratorSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'generator': toJson_ClusterGeneratorSpecGenerator(obj.generator),
        'kind': obj.kind,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGenerator' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGenerator(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'acrAccessTokenSpec': toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpec(obj.acrAccessTokenSpec),
        'ecrAuthorizationTokenSpec': toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec(obj.ecrAuthorizationTokenSpec),
        'fakeSpec': toJson_ClusterGeneratorSpecGeneratorFakeSpec(obj.fakeSpec),
        'gcrAccessTokenSpec': toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpec(obj.gcrAccessTokenSpec),
        'githubAccessTokenSpec': toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpec(obj.githubAccessTokenSpec),
        'grafanaSpec': toJson_ClusterGeneratorSpecGeneratorGrafanaSpec(obj.grafanaSpec),
        'passwordSpec': toJson_ClusterGeneratorSpecGeneratorPasswordSpec(obj.passwordSpec),
        'quayAccessTokenSpec': toJson_ClusterGeneratorSpecGeneratorQuayAccessTokenSpec(obj.quayAccessTokenSpec),
        'stsSessionTokenSpec': toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpec(obj.stsSessionTokenSpec),
        'uuidSpec': obj.uuidSpec,
        'vaultDynamicSecretSpec': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec(obj.vaultDynamicSecretSpec),
        'webhookSpec': toJson_ClusterGeneratorSpecGeneratorWebhookSpec(obj.webhookSpec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * Kind the kind of this generator.
 *
 * @schema ClusterGeneratorSpecKind
 */
var ClusterGeneratorSpecKind;
(function (ClusterGeneratorSpecKind) {
    /** ACRAccessToken */
    ClusterGeneratorSpecKind["ACR_ACCESS_TOKEN"] = "ACRAccessToken";
    /** ECRAuthorizationToken */
    ClusterGeneratorSpecKind["ECR_AUTHORIZATION_TOKEN"] = "ECRAuthorizationToken";
    /** Fake */
    ClusterGeneratorSpecKind["FAKE"] = "Fake";
    /** GCRAccessToken */
    ClusterGeneratorSpecKind["GCR_ACCESS_TOKEN"] = "GCRAccessToken";
    /** GithubAccessToken */
    ClusterGeneratorSpecKind["GITHUB_ACCESS_TOKEN"] = "GithubAccessToken";
    /** QuayAccessToken */
    ClusterGeneratorSpecKind["QUAY_ACCESS_TOKEN"] = "QuayAccessToken";
    /** Password */
    ClusterGeneratorSpecKind["PASSWORD"] = "Password";
    /** STSSessionToken */
    ClusterGeneratorSpecKind["STS_SESSION_TOKEN"] = "STSSessionToken";
    /** UUID */
    ClusterGeneratorSpecKind["UUID"] = "UUID";
    /** VaultDynamicSecret */
    ClusterGeneratorSpecKind["VAULT_DYNAMIC_SECRET"] = "VaultDynamicSecret";
    /** Webhook */
    ClusterGeneratorSpecKind["WEBHOOK"] = "Webhook";
    /** Grafana */
    ClusterGeneratorSpecKind["GRAFANA"] = "Grafana";
})(ClusterGeneratorSpecKind || (exports.ClusterGeneratorSpecKind = ClusterGeneratorSpecKind = {}));
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth(obj.auth),
        'environmentType': obj.environmentType,
        'registry': obj.registry,
        'scope': obj.scope,
        'tenantId': obj.tenantId,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth(obj.auth),
        'region': obj.region,
        'role': obj.role,
        'scope': obj.scope,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorFakeSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorFakeSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'controller': obj.controller,
        'data': ((obj.data) === undefined) ? undefined : (Object.entries(obj.data).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth(obj.auth),
        'projectID': obj.projectId,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGithubAccessTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'appID': obj.appId,
        'auth': toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth(obj.auth),
        'installID': obj.installId,
        'permissions': ((obj.permissions) === undefined) ? undefined : (Object.entries(obj.permissions).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
        'repositories': obj.repositories?.map(y => y),
        'url': obj.url,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGrafanaSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuth(obj.auth),
        'serviceAccount': toJson_ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount(obj.serviceAccount),
        'url': obj.url,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorPasswordSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorPasswordSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'allowRepeat': obj.allowRepeat,
        'digits': obj.digits,
        'length': obj.length,
        'noUpper': obj.noUpper,
        'symbolCharacters': obj.symbolCharacters,
        'symbols': obj.symbols,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorQuayAccessTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorQuayAccessTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'robotAccount': obj.robotAccount,
        'serviceAccountRef': toJson_ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef(obj.serviceAccountRef),
        'url': obj.url,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth(obj.auth),
        'region': obj.region,
        'requestParameters': toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters(obj.requestParameters),
        'role': obj.role,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'allowEmptyResponse': obj.allowEmptyResponse,
        'controller': obj.controller,
        'method': obj.method,
        'parameters': obj.parameters,
        'path': obj.path,
        'provider': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider(obj.provider),
        'resultType': obj.resultType,
        'retrySettings': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings(obj.retrySettings),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorWebhookSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'body': obj.body,
        'caBundle': obj.caBundle,
        'caProvider': toJson_ClusterGeneratorSpecGeneratorWebhookSpecCaProvider(obj.caProvider),
        'headers': ((obj.headers) === undefined) ? undefined : (Object.entries(obj.headers).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
        'method': obj.method,
        'result': toJson_ClusterGeneratorSpecGeneratorWebhookSpecResult(obj.result),
        'secrets': obj.secrets?.map(y => toJson_ClusterGeneratorSpecGeneratorWebhookSpecSecrets(y)),
        'timeout': obj.timeout,
        'url': obj.url,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'managedIdentity': toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity(obj.managedIdentity),
        'servicePrincipal': toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal(obj.servicePrincipal),
        'workloadIdentity': toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity(obj.workloadIdentity),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * EnvironmentType specifies the Azure cloud environment endpoints to use for
 * connecting and authenticating with Azure. By default it points to the public cloud AAD endpoint.
 * The following endpoints are available, also see here: https://github.com/Azure/go-autorest/blob/main/autorest/azure/environments.go#L152
 * PublicCloud, USGovernmentCloud, ChinaCloud, GermanCloud
 *
 * @schema ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType
 */
var ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType;
(function (ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType) {
    /** PublicCloud */
    ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType["PUBLIC_CLOUD"] = "PublicCloud";
    /** USGovernmentCloud */
    ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType["US_GOVERNMENT_CLOUD"] = "USGovernmentCloud";
    /** ChinaCloud */
    ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType["CHINA_CLOUD"] = "ChinaCloud";
    /** GermanCloud */
    ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType["GERMAN_CLOUD"] = "GermanCloud";
})(ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType || (exports.ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType = ClusterGeneratorSpecGeneratorAcrAccessTokenSpecEnvironmentType = {}));
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'jwt': toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt(obj.jwt),
        'secretRef': toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretRef': toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef(obj.secretRef),
        'workloadIdentity': toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity(obj.workloadIdentity),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'privateKey': toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey(obj.privateKey),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'basic': toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic(obj.basic),
        'token': toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken(obj.token),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGrafanaSpecServiceAccount(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'role': obj.role,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorQuayAccessTokenSpecServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'jwt': toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt(obj.jwt),
        'secretRef': toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecRequestParameters(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'serialNumber': obj.serialNumber,
        'sessionDuration': obj.sessionDuration,
        'tokenCode': obj.tokenCode,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProvider(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth(obj.auth),
        'caBundle': obj.caBundle,
        'caProvider': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider(obj.caProvider),
        'forwardInconsistent': obj.forwardInconsistent,
        'headers': ((obj.headers) === undefined) ? undefined : (Object.entries(obj.headers).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
        'namespace': obj.namespace,
        'path': obj.path,
        'readYourWrites': obj.readYourWrites,
        'server': obj.server,
        'tls': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls(obj.tls),
        'version': obj.version,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * Result type defines which data is returned from the generator.
 * By default it is the "data" section of the Vault API response.
 * When using e.g. /auth/token/create the "data" section is empty but
 * the "auth" section contains the generated token.
 * Please refer to the vault docs regarding the result data structure.
 * Additionally, accessing the raw response is possibly by using "Raw" result type.
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType
 */
var ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType;
(function (ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType) {
    /** Data */
    ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType["DATA"] = "Data";
    /** Auth */
    ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType["AUTH"] = "Auth";
    /** Raw */
    ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType["RAW"] = "Raw";
})(ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType || (exports.ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType = ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecResultType = {}));
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecRetrySettings(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'maxRetries': obj.maxRetries,
        'retryInterval': obj.retryInterval,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecCaProvider' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorWebhookSpecCaProvider(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
        'type': obj.type,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecResult' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorWebhookSpecResult(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'jsonPath': obj.jsonPath,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecSecrets' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorWebhookSpecSecrets(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'secretRef': toJson_ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthManagedIdentity(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'identityId': obj.identityId,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipal(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretRef': toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentity(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'serviceAccountRef': toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwt(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'serviceAccountRef': toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'accessKeyIDSecretRef': toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj.accessKeyIdSecretRef),
        'secretAccessKeySecretRef': toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj.secretAccessKeySecretRef),
        'sessionTokenSecretRef': toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef(obj.sessionTokenSecretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretAccessKeySecretRef': toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj.secretAccessKeySecretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentity(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'clusterLocation': obj.clusterLocation,
        'clusterName': obj.clusterName,
        'clusterProjectID': obj.clusterProjectId,
        'serviceAccountRef': toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKey(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretRef': toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasic(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'password': toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword(obj.password),
        'username': obj.username,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthToken(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwt(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'serviceAccountRef': toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'accessKeyIDSecretRef': toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj.accessKeyIdSecretRef),
        'secretAccessKeySecretRef': toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj.secretAccessKeySecretRef),
        'sessionTokenSecretRef': toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef(obj.sessionTokenSecretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'appRole': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole(obj.appRole),
        'cert': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert(obj.cert),
        'iam': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam(obj.iam),
        'jwt': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt(obj.jwt),
        'kubernetes': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes(obj.kubernetes),
        'ldap': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap(obj.ldap),
        'namespace': obj.namespace,
        'tokenSecretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef(obj.tokenSecretRef),
        'userPass': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass(obj.userPass),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProvider(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
        'type': obj.type,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTls(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'certSecretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef(obj.certSecretRef),
        'keySecretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef(obj.keySecretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * Version is the Vault KV secret engine version. This can be either "v1" or
 * "v2". Version defaults to "v2".
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion
 */
var ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion;
(function (ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion) {
    /** v1 */
    ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion["V1"] = "v1";
    /** v2 */
    ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion["V2"] = "v2";
})(ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion || (exports.ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion = ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderVersion = {}));
/**
 * The type of provider to use such as "Secret", or "ConfigMap".
 *
 * @schema ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType
 */
var ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType;
(function (ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType) {
    /** Secret */
    ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType["SECRET"] = "Secret";
    /** ConfigMap */
    ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType["CONFIG_MAP"] = "ConfigMap";
})(ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType || (exports.ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType = ClusterGeneratorSpecGeneratorWebhookSpecCaProviderType = {}));
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorWebhookSpecSecretsSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'clientId': toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId(obj.clientId),
        'clientSecret': toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret(obj.clientSecret),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthJwtServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorEcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGithubAccessTokenSpecAuthPrivateKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorGrafanaSpecAuthBasicPassword(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthJwtServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorStsSessionTokenSpecAuthSecretRefSessionTokenSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRole(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'path': obj.path,
        'roleId': obj.roleId,
        'roleRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef(obj.roleRef),
        'secretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCert(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'clientCert': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert(obj.clientCert),
        'secretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIam(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'externalID': obj.externalId,
        'jwt': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt(obj.jwt),
        'path': obj.path,
        'region': obj.region,
        'role': obj.role,
        'secretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef(obj.secretRef),
        'vaultAwsIamServerID': obj.vaultAwsIamServerId,
        'vaultRole': obj.vaultRole,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwt(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'kubernetesServiceAccountToken': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken(obj.kubernetesServiceAccountToken),
        'path': obj.path,
        'role': obj.role,
        'secretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetes(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'mountPath': obj.mountPath,
        'role': obj.role,
        'secretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef(obj.secretRef),
        'serviceAccountRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdap(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'path': obj.path,
        'secretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef(obj.secretRef),
        'username': obj.username,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthTokenSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPass(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'path': obj.path,
        'secretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef(obj.secretRef),
        'username': obj.username,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * The type of provider to use such as "Secret", or "ConfigMap".
 *
 * @schema ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType
 */
var ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType;
(function (ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType) {
    /** Secret */
    ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType["SECRET"] = "Secret";
    /** ConfigMap */
    ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType["CONFIG_MAP"] = "ConfigMap";
})(ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType || (exports.ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType = ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderCaProviderType = {}));
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsCertSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderTlsKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientId(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorAcrAccessTokenSpecAuthServicePrincipalSecretRefClientSecret(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleRoleRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthAppRoleSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertClientCert(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthCertSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwt(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'serviceAccountRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'accessKeyIDSecretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef(obj.accessKeyIdSecretRef),
        'secretAccessKeySecretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef(obj.secretAccessKeySecretRef),
        'sessionTokenSecretRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef(obj.sessionTokenSecretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'expirationSeconds': obj.expirationSeconds,
        'serviceAccountRef': toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthLdapSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthUserPassSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_ClusterGeneratorSpecGeneratorVaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * ECRAuthorizationTokenSpec uses the GetAuthorizationToken API to retrieve an
authorization token.
The authorization token is valid for 12 hours.
The authorizationToken returned is a base64 encoded string that can be decoded
and used in a docker login command to authenticate to a registry.
For more information, see Registry authentication (https://docs.aws.amazon.com/AmazonECR/latest/userguide/Registries.html#registry_auth) in the Amazon Elastic Container Registry User Guide.
 *
 * @schema ECRAuthorizationToken
 */
class EcrAuthorizationToken extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "ECRAuthorizationToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...EcrAuthorizationToken.GVK,
            ...toJson_EcrAuthorizationTokenProps(props),
        };
    }
    /**
     * Defines a "ECRAuthorizationToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...EcrAuthorizationToken.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...EcrAuthorizationToken.GVK,
            ...toJson_EcrAuthorizationTokenProps(resolved),
        };
    }
}
exports.EcrAuthorizationToken = EcrAuthorizationToken;
_c = JSII_RTTI_SYMBOL_1;
EcrAuthorizationToken[_c] = { fqn: "ioexternal-secretsgenerators.EcrAuthorizationToken", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "ECRAuthorizationToken"
 */
EcrAuthorizationToken.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'ECRAuthorizationToken',
};
/**
 * Converts an object of type 'EcrAuthorizationTokenProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_EcrAuthorizationTokenProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_EcrAuthorizationTokenSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_EcrAuthorizationTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_EcrAuthorizationTokenSpecAuth(obj.auth),
        'region': obj.region,
        'role': obj.role,
        'scope': obj.scope,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_EcrAuthorizationTokenSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'jwt': toJson_EcrAuthorizationTokenSpecAuthJwt(obj.jwt),
        'secretRef': toJson_EcrAuthorizationTokenSpecAuthSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthJwt' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_EcrAuthorizationTokenSpecAuthJwt(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'serviceAccountRef': toJson_EcrAuthorizationTokenSpecAuthJwtServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_EcrAuthorizationTokenSpecAuthSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'accessKeyIDSecretRef': toJson_EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj.accessKeyIdSecretRef),
        'secretAccessKeySecretRef': toJson_EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj.secretAccessKeySecretRef),
        'sessionTokenSecretRef': toJson_EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef(obj.sessionTokenSecretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthJwtServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_EcrAuthorizationTokenSpecAuthJwtServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_EcrAuthorizationTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_EcrAuthorizationTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_EcrAuthorizationTokenSpecAuthSecretRefSessionTokenSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * Fake generator is used for testing. It lets you define
a static set of credentials that is always returned.
 *
 * @schema Fake
 */
class Fake extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "Fake".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...Fake.GVK,
            ...toJson_FakeProps(props),
        };
    }
    /**
     * Defines a "Fake" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...Fake.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...Fake.GVK,
            ...toJson_FakeProps(resolved),
        };
    }
}
exports.Fake = Fake;
_d = JSII_RTTI_SYMBOL_1;
Fake[_d] = { fqn: "ioexternal-secretsgenerators.Fake", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "Fake"
 */
Fake.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'Fake',
};
/**
 * Converts an object of type 'FakeProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_FakeProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_FakeSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'FakeSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_FakeSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'controller': obj.controller,
        'data': ((obj.data) === undefined) ? undefined : (Object.entries(obj.data).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * GCRAccessToken generates an GCP access token
that can be used to authenticate with GCR.
 *
 * @schema GCRAccessToken
 */
class GcrAccessToken extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "GCRAccessToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...GcrAccessToken.GVK,
            ...toJson_GcrAccessTokenProps(props),
        };
    }
    /**
     * Defines a "GCRAccessToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...GcrAccessToken.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...GcrAccessToken.GVK,
            ...toJson_GcrAccessTokenProps(resolved),
        };
    }
}
exports.GcrAccessToken = GcrAccessToken;
_e = JSII_RTTI_SYMBOL_1;
GcrAccessToken[_e] = { fqn: "ioexternal-secretsgenerators.GcrAccessToken", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "GCRAccessToken"
 */
GcrAccessToken.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'GCRAccessToken',
};
/**
 * Converts an object of type 'GcrAccessTokenProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GcrAccessTokenProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_GcrAccessTokenSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GcrAccessTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GcrAccessTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_GcrAccessTokenSpecAuth(obj.auth),
        'projectID': obj.projectId,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GcrAccessTokenSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretRef': toJson_GcrAccessTokenSpecAuthSecretRef(obj.secretRef),
        'workloadIdentity': toJson_GcrAccessTokenSpecAuthWorkloadIdentity(obj.workloadIdentity),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GcrAccessTokenSpecAuthSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretAccessKeySecretRef': toJson_GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj.secretAccessKeySecretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthWorkloadIdentity' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GcrAccessTokenSpecAuthWorkloadIdentity(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'clusterLocation': obj.clusterLocation,
        'clusterName': obj.clusterName,
        'clusterProjectID': obj.clusterProjectId,
        'serviceAccountRef': toJson_GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GcrAccessTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GcrAccessTokenSpecAuthWorkloadIdentityServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 *
 *
 * @schema GeneratorState
 */
class GeneratorState extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "GeneratorState".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...GeneratorState.GVK,
            ...toJson_GeneratorStateProps(props),
        };
    }
    /**
     * Defines a "GeneratorState" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...GeneratorState.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...GeneratorState.GVK,
            ...toJson_GeneratorStateProps(resolved),
        };
    }
}
exports.GeneratorState = GeneratorState;
_f = JSII_RTTI_SYMBOL_1;
GeneratorState[_f] = { fqn: "ioexternal-secretsgenerators.GeneratorState", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "GeneratorState"
 */
GeneratorState.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'GeneratorState',
};
/**
 * Converts an object of type 'GeneratorStateProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GeneratorStateProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_GeneratorStateSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GeneratorStateSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GeneratorStateSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'garbageCollectionDeadline': obj.garbageCollectionDeadline?.toISOString(),
        'resource': obj.resource,
        'state': obj.state,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * GithubAccessToken generates ghs_ accessToken
 *
 * @schema GithubAccessToken
 */
class GithubAccessToken extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "GithubAccessToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...GithubAccessToken.GVK,
            ...toJson_GithubAccessTokenProps(props),
        };
    }
    /**
     * Defines a "GithubAccessToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...GithubAccessToken.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...GithubAccessToken.GVK,
            ...toJson_GithubAccessTokenProps(resolved),
        };
    }
}
exports.GithubAccessToken = GithubAccessToken;
_g = JSII_RTTI_SYMBOL_1;
GithubAccessToken[_g] = { fqn: "ioexternal-secretsgenerators.GithubAccessToken", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "GithubAccessToken"
 */
GithubAccessToken.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'GithubAccessToken',
};
/**
 * Converts an object of type 'GithubAccessTokenProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GithubAccessTokenProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_GithubAccessTokenSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GithubAccessTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GithubAccessTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'appID': obj.appId,
        'auth': toJson_GithubAccessTokenSpecAuth(obj.auth),
        'installID': obj.installId,
        'permissions': ((obj.permissions) === undefined) ? undefined : (Object.entries(obj.permissions).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
        'repositories': obj.repositories?.map(y => y),
        'url': obj.url,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GithubAccessTokenSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GithubAccessTokenSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'privateKey': toJson_GithubAccessTokenSpecAuthPrivateKey(obj.privateKey),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GithubAccessTokenSpecAuthPrivateKey' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GithubAccessTokenSpecAuthPrivateKey(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretRef': toJson_GithubAccessTokenSpecAuthPrivateKeySecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GithubAccessTokenSpecAuthPrivateKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GithubAccessTokenSpecAuthPrivateKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 *
 *
 * @schema Grafana
 */
class Grafana extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "Grafana".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...Grafana.GVK,
            ...toJson_GrafanaProps(props),
        };
    }
    /**
     * Defines a "Grafana" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...Grafana.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...Grafana.GVK,
            ...toJson_GrafanaProps(resolved),
        };
    }
}
exports.Grafana = Grafana;
_h = JSII_RTTI_SYMBOL_1;
Grafana[_h] = { fqn: "ioexternal-secretsgenerators.Grafana", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "Grafana"
 */
Grafana.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'Grafana',
};
/**
 * Converts an object of type 'GrafanaProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GrafanaProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_GrafanaSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GrafanaSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GrafanaSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_GrafanaSpecAuth(obj.auth),
        'serviceAccount': toJson_GrafanaSpecServiceAccount(obj.serviceAccount),
        'url': obj.url,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GrafanaSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GrafanaSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'basic': toJson_GrafanaSpecAuthBasic(obj.basic),
        'token': toJson_GrafanaSpecAuthToken(obj.token),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GrafanaSpecServiceAccount' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GrafanaSpecServiceAccount(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'role': obj.role,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GrafanaSpecAuthBasic' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GrafanaSpecAuthBasic(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'password': toJson_GrafanaSpecAuthBasicPassword(obj.password),
        'username': obj.username,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GrafanaSpecAuthToken' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GrafanaSpecAuthToken(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'GrafanaSpecAuthBasicPassword' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_GrafanaSpecAuthBasicPassword(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * Password generates a random password based on the
configuration parameters in spec.
You can specify the length, characterset and other attributes.
 *
 * @schema Password
 */
class Password extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "Password".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...Password.GVK,
            ...toJson_PasswordProps(props),
        };
    }
    /**
     * Defines a "Password" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...Password.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...Password.GVK,
            ...toJson_PasswordProps(resolved),
        };
    }
}
exports.Password = Password;
_j = JSII_RTTI_SYMBOL_1;
Password[_j] = { fqn: "ioexternal-secretsgenerators.Password", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "Password"
 */
Password.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'Password',
};
/**
 * Converts an object of type 'PasswordProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_PasswordProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_PasswordSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'PasswordSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_PasswordSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'allowRepeat': obj.allowRepeat,
        'digits': obj.digits,
        'length': obj.length,
        'noUpper': obj.noUpper,
        'symbolCharacters': obj.symbolCharacters,
        'symbols': obj.symbols,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * QuayAccessToken generates Quay oauth token for pulling/pushing images
 *
 * @schema QuayAccessToken
 */
class QuayAccessToken extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "QuayAccessToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...QuayAccessToken.GVK,
            ...toJson_QuayAccessTokenProps(props),
        };
    }
    /**
     * Defines a "QuayAccessToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...QuayAccessToken.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...QuayAccessToken.GVK,
            ...toJson_QuayAccessTokenProps(resolved),
        };
    }
}
exports.QuayAccessToken = QuayAccessToken;
_k = JSII_RTTI_SYMBOL_1;
QuayAccessToken[_k] = { fqn: "ioexternal-secretsgenerators.QuayAccessToken", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "QuayAccessToken"
 */
QuayAccessToken.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'QuayAccessToken',
};
/**
 * Converts an object of type 'QuayAccessTokenProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_QuayAccessTokenProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_QuayAccessTokenSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'QuayAccessTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_QuayAccessTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'robotAccount': obj.robotAccount,
        'serviceAccountRef': toJson_QuayAccessTokenSpecServiceAccountRef(obj.serviceAccountRef),
        'url': obj.url,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'QuayAccessTokenSpecServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_QuayAccessTokenSpecServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * STSSessionToken uses the GetSessionToken API to retrieve an authorization token.
The authorization token is valid for 12 hours.
The authorizationToken returned is a base64 encoded string that can be decoded.
For more information, see GetSessionToken (https://docs.aws.amazon.com/STS/latest/APIReference/API_GetSessionToken.html).
 *
 * @schema STSSessionToken
 */
class StsSessionToken extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "STSSessionToken".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...StsSessionToken.GVK,
            ...toJson_StsSessionTokenProps(props),
        };
    }
    /**
     * Defines a "STSSessionToken" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...StsSessionToken.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...StsSessionToken.GVK,
            ...toJson_StsSessionTokenProps(resolved),
        };
    }
}
exports.StsSessionToken = StsSessionToken;
_l = JSII_RTTI_SYMBOL_1;
StsSessionToken[_l] = { fqn: "ioexternal-secretsgenerators.StsSessionToken", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "STSSessionToken"
 */
StsSessionToken.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'STSSessionToken',
};
/**
 * Converts an object of type 'StsSessionTokenProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_StsSessionTokenProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_StsSessionTokenSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'StsSessionTokenSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_StsSessionTokenSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_StsSessionTokenSpecAuth(obj.auth),
        'region': obj.region,
        'requestParameters': toJson_StsSessionTokenSpecRequestParameters(obj.requestParameters),
        'role': obj.role,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_StsSessionTokenSpecAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'jwt': toJson_StsSessionTokenSpecAuthJwt(obj.jwt),
        'secretRef': toJson_StsSessionTokenSpecAuthSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'StsSessionTokenSpecRequestParameters' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_StsSessionTokenSpecRequestParameters(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'serialNumber': obj.serialNumber,
        'sessionDuration': obj.sessionDuration,
        'tokenCode': obj.tokenCode,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthJwt' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_StsSessionTokenSpecAuthJwt(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'serviceAccountRef': toJson_StsSessionTokenSpecAuthJwtServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_StsSessionTokenSpecAuthSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'accessKeyIDSecretRef': toJson_StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj.accessKeyIdSecretRef),
        'secretAccessKeySecretRef': toJson_StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj.secretAccessKeySecretRef),
        'sessionTokenSecretRef': toJson_StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef(obj.sessionTokenSecretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthJwtServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_StsSessionTokenSpecAuthJwtServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_StsSessionTokenSpecAuthSecretRefAccessKeyIdSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_StsSessionTokenSpecAuthSecretRefSecretAccessKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_StsSessionTokenSpecAuthSecretRefSessionTokenSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * UUID generates a version 1 UUID (e56657e3-764f-11ef-a397-65231a88c216).
 *
 * @schema UUID
 */
class Uuid extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "UUID".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...Uuid.GVK,
            ...toJson_UuidProps(props),
        };
    }
    /**
     * Defines a "UUID" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...Uuid.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...Uuid.GVK,
            ...toJson_UuidProps(resolved),
        };
    }
}
exports.Uuid = Uuid;
_m = JSII_RTTI_SYMBOL_1;
Uuid[_m] = { fqn: "ioexternal-secretsgenerators.Uuid", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "UUID"
 */
Uuid.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'UUID',
};
/**
 * Converts an object of type 'UuidProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_UuidProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': obj.spec,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 *
 *
 * @schema VaultDynamicSecret
 */
class VaultDynamicSecret extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "VaultDynamicSecret".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...VaultDynamicSecret.GVK,
            ...toJson_VaultDynamicSecretProps(props),
        };
    }
    /**
     * Defines a "VaultDynamicSecret" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...VaultDynamicSecret.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...VaultDynamicSecret.GVK,
            ...toJson_VaultDynamicSecretProps(resolved),
        };
    }
}
exports.VaultDynamicSecret = VaultDynamicSecret;
_o = JSII_RTTI_SYMBOL_1;
VaultDynamicSecret[_o] = { fqn: "ioexternal-secretsgenerators.VaultDynamicSecret", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "VaultDynamicSecret"
 */
VaultDynamicSecret.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'VaultDynamicSecret',
};
/**
 * Converts an object of type 'VaultDynamicSecretProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_VaultDynamicSecretSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'allowEmptyResponse': obj.allowEmptyResponse,
        'controller': obj.controller,
        'method': obj.method,
        'parameters': obj.parameters,
        'path': obj.path,
        'provider': toJson_VaultDynamicSecretSpecProvider(obj.provider),
        'resultType': obj.resultType,
        'retrySettings': toJson_VaultDynamicSecretSpecRetrySettings(obj.retrySettings),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProvider' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProvider(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_VaultDynamicSecretSpecProviderAuth(obj.auth),
        'caBundle': obj.caBundle,
        'caProvider': toJson_VaultDynamicSecretSpecProviderCaProvider(obj.caProvider),
        'forwardInconsistent': obj.forwardInconsistent,
        'headers': ((obj.headers) === undefined) ? undefined : (Object.entries(obj.headers).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
        'namespace': obj.namespace,
        'path': obj.path,
        'readYourWrites': obj.readYourWrites,
        'server': obj.server,
        'tls': toJson_VaultDynamicSecretSpecProviderTls(obj.tls),
        'version': obj.version,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * Result type defines which data is returned from the generator.
 * By default it is the "data" section of the Vault API response.
 * When using e.g. /auth/token/create the "data" section is empty but
 * the "auth" section contains the generated token.
 * Please refer to the vault docs regarding the result data structure.
 * Additionally, accessing the raw response is possibly by using "Raw" result type.
 *
 * @schema VaultDynamicSecretSpecResultType
 */
var VaultDynamicSecretSpecResultType;
(function (VaultDynamicSecretSpecResultType) {
    /** Data */
    VaultDynamicSecretSpecResultType["DATA"] = "Data";
    /** Auth */
    VaultDynamicSecretSpecResultType["AUTH"] = "Auth";
    /** Raw */
    VaultDynamicSecretSpecResultType["RAW"] = "Raw";
})(VaultDynamicSecretSpecResultType || (exports.VaultDynamicSecretSpecResultType = VaultDynamicSecretSpecResultType = {}));
/**
 * Converts an object of type 'VaultDynamicSecretSpecRetrySettings' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecRetrySettings(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'maxRetries': obj.maxRetries,
        'retryInterval': obj.retryInterval,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuth' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'appRole': toJson_VaultDynamicSecretSpecProviderAuthAppRole(obj.appRole),
        'cert': toJson_VaultDynamicSecretSpecProviderAuthCert(obj.cert),
        'iam': toJson_VaultDynamicSecretSpecProviderAuthIam(obj.iam),
        'jwt': toJson_VaultDynamicSecretSpecProviderAuthJwt(obj.jwt),
        'kubernetes': toJson_VaultDynamicSecretSpecProviderAuthKubernetes(obj.kubernetes),
        'ldap': toJson_VaultDynamicSecretSpecProviderAuthLdap(obj.ldap),
        'namespace': obj.namespace,
        'tokenSecretRef': toJson_VaultDynamicSecretSpecProviderAuthTokenSecretRef(obj.tokenSecretRef),
        'userPass': toJson_VaultDynamicSecretSpecProviderAuthUserPass(obj.userPass),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderCaProvider' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderCaProvider(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
        'type': obj.type,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderTls' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderTls(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'certSecretRef': toJson_VaultDynamicSecretSpecProviderTlsCertSecretRef(obj.certSecretRef),
        'keySecretRef': toJson_VaultDynamicSecretSpecProviderTlsKeySecretRef(obj.keySecretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * Version is the Vault KV secret engine version. This can be either "v1" or
 * "v2". Version defaults to "v2".
 *
 * @schema VaultDynamicSecretSpecProviderVersion
 */
var VaultDynamicSecretSpecProviderVersion;
(function (VaultDynamicSecretSpecProviderVersion) {
    /** v1 */
    VaultDynamicSecretSpecProviderVersion["V1"] = "v1";
    /** v2 */
    VaultDynamicSecretSpecProviderVersion["V2"] = "v2";
})(VaultDynamicSecretSpecProviderVersion || (exports.VaultDynamicSecretSpecProviderVersion = VaultDynamicSecretSpecProviderVersion = {}));
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthAppRole' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthAppRole(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'path': obj.path,
        'roleId': obj.roleId,
        'roleRef': toJson_VaultDynamicSecretSpecProviderAuthAppRoleRoleRef(obj.roleRef),
        'secretRef': toJson_VaultDynamicSecretSpecProviderAuthAppRoleSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthCert' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthCert(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'clientCert': toJson_VaultDynamicSecretSpecProviderAuthCertClientCert(obj.clientCert),
        'secretRef': toJson_VaultDynamicSecretSpecProviderAuthCertSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIam' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthIam(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'externalID': obj.externalId,
        'jwt': toJson_VaultDynamicSecretSpecProviderAuthIamJwt(obj.jwt),
        'path': obj.path,
        'region': obj.region,
        'role': obj.role,
        'secretRef': toJson_VaultDynamicSecretSpecProviderAuthIamSecretRef(obj.secretRef),
        'vaultAwsIamServerID': obj.vaultAwsIamServerId,
        'vaultRole': obj.vaultRole,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthJwt' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthJwt(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'kubernetesServiceAccountToken': toJson_VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken(obj.kubernetesServiceAccountToken),
        'path': obj.path,
        'role': obj.role,
        'secretRef': toJson_VaultDynamicSecretSpecProviderAuthJwtSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthKubernetes' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthKubernetes(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'mountPath': obj.mountPath,
        'role': obj.role,
        'secretRef': toJson_VaultDynamicSecretSpecProviderAuthKubernetesSecretRef(obj.secretRef),
        'serviceAccountRef': toJson_VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthLdap' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthLdap(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'path': obj.path,
        'secretRef': toJson_VaultDynamicSecretSpecProviderAuthLdapSecretRef(obj.secretRef),
        'username': obj.username,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthTokenSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthTokenSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthUserPass' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthUserPass(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'path': obj.path,
        'secretRef': toJson_VaultDynamicSecretSpecProviderAuthUserPassSecretRef(obj.secretRef),
        'username': obj.username,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * The type of provider to use such as "Secret", or "ConfigMap".
 *
 * @schema VaultDynamicSecretSpecProviderCaProviderType
 */
var VaultDynamicSecretSpecProviderCaProviderType;
(function (VaultDynamicSecretSpecProviderCaProviderType) {
    /** Secret */
    VaultDynamicSecretSpecProviderCaProviderType["SECRET"] = "Secret";
    /** ConfigMap */
    VaultDynamicSecretSpecProviderCaProviderType["CONFIG_MAP"] = "ConfigMap";
})(VaultDynamicSecretSpecProviderCaProviderType || (exports.VaultDynamicSecretSpecProviderCaProviderType = VaultDynamicSecretSpecProviderCaProviderType = {}));
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderTlsCertSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderTlsCertSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderTlsKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderTlsKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthAppRoleRoleRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthAppRoleRoleRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthAppRoleSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthAppRoleSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthCertClientCert' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthCertClientCert(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthCertSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthCertSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamJwt' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthIamJwt(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'serviceAccountRef': toJson_VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthIamSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'accessKeyIDSecretRef': toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef(obj.accessKeyIdSecretRef),
        'secretAccessKeySecretRef': toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef(obj.secretAccessKeySecretRef),
        'sessionTokenSecretRef': toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef(obj.sessionTokenSecretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountToken(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'expirationSeconds': obj.expirationSeconds,
        'serviceAccountRef': toJson_VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef(obj.serviceAccountRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthJwtSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthJwtSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthKubernetesSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthKubernetesSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthKubernetesServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthLdapSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthLdapSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthUserPassSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthUserPassSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthIamJwtServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefAccessKeyIdSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefSecretAccessKeySecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthIamSecretRefSessionTokenSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_VaultDynamicSecretSpecProviderAuthJwtKubernetesServiceAccountTokenServiceAccountRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audiences': obj.audiences?.map(y => y),
        'name': obj.name,
        'namespace': obj.namespace,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * Webhook connects to a third party API server to handle the secrets generation
configuration parameters in spec.
You can specify the server, the token, and additional body parameters.
See documentation for the full API specification for requests and responses.
 *
 * @schema Webhook
 */
class Webhook extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "Webhook".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...Webhook.GVK,
            ...toJson_WebhookProps(props),
        };
    }
    /**
     * Defines a "Webhook" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...Webhook.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...Webhook.GVK,
            ...toJson_WebhookProps(resolved),
        };
    }
}
exports.Webhook = Webhook;
_p = JSII_RTTI_SYMBOL_1;
Webhook[_p] = { fqn: "ioexternal-secretsgenerators.Webhook", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "Webhook"
 */
Webhook.GVK = {
    apiVersion: 'generators.external-secrets.io/v1alpha1',
    kind: 'Webhook',
};
/**
 * Converts an object of type 'WebhookProps' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_WebhookProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_WebhookSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'WebhookSpec' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_WebhookSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'body': obj.body,
        'caBundle': obj.caBundle,
        'caProvider': toJson_WebhookSpecCaProvider(obj.caProvider),
        'headers': ((obj.headers) === undefined) ? undefined : (Object.entries(obj.headers).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
        'method': obj.method,
        'result': toJson_WebhookSpecResult(obj.result),
        'secrets': obj.secrets?.map(y => toJson_WebhookSpecSecrets(y)),
        'timeout': obj.timeout,
        'url': obj.url,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'WebhookSpecCaProvider' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_WebhookSpecCaProvider(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
        'namespace': obj.namespace,
        'type': obj.type,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'WebhookSpecResult' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_WebhookSpecResult(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'jsonPath': obj.jsonPath,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'WebhookSpecSecrets' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_WebhookSpecSecrets(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'secretRef': toJson_WebhookSpecSecretsSecretRef(obj.secretRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, quote-props */
/**
 * The type of provider to use such as "Secret", or "ConfigMap".
 *
 * @schema WebhookSpecCaProviderType
 */
var WebhookSpecCaProviderType;
(function (WebhookSpecCaProviderType) {
    /** Secret */
    WebhookSpecCaProviderType["SECRET"] = "Secret";
    /** ConfigMap */
    WebhookSpecCaProviderType["CONFIG_MAP"] = "ConfigMap";
})(WebhookSpecCaProviderType || (exports.WebhookSpecCaProviderType = WebhookSpecCaProviderType = {}));
/**
 * Converts an object of type 'WebhookSpecSecretsSecretRef' to JSON representation.
 */
/* eslint-disable max-len, quote-props */
function toJson_WebhookSpecSecretsSecretRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW8uZXh0ZXJuYWwtc2VjcmV0cy5nZW5lcmF0b3JzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaW8uZXh0ZXJuYWwtc2VjcmV0cy5nZW5lcmF0b3JzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFtR0EsZ0VBUUM7QUE4REQsOERBV0M7QUFrQ0Qsc0VBU0M7QUF5Q0Qsb0dBT0M7QUF1QkQsc0dBT0M7QUF1QkQsc0dBT0M7QUE4QkQsd0hBUUM7QUF3Q0Qsd0lBU0M7QUFzQ0Qsd0lBU0M7QUFzQ0QsZ0pBU0M7QUFnRkQsb0VBUUM7QUEyQkQsa0VBUUM7QUF5RkQsb0ZBa0JDO0FBOEZELHdIQVdDO0FBMkNELHNJQVVDO0FBK0JELG9HQVFDO0FBMkJELHdIQVFDO0FBcURELDhIQVlDO0FBc0NELDBHQVNDO0FBOERELDRHQVlDO0FBbUNELDBIQVNDO0FBMENELDBIQVVDO0FBMkVELGdJQWNDO0FBa0ZELDBHQWVDO0FBa0NELGdJQVNDO0FBaURELDhJQVFDO0FBeUJELGdJQVFDO0FBb0JELHNJQU9DO0FBb0NELGtIQVFDO0FBZ0NELHNJQVFDO0FBdUNELDRKQVNDO0FBOEJELGtJQVFDO0FBeUNELDRKQVNDO0FBK0dELGdKQWlCQztBQTRDRCwwSkFRQztBQTJDRCw4SEFVQztBQXNCRCxzSEFPQztBQTJCRCx3SEFRQztBQXNCRCw4SkFPQztBQXVCRCxnS0FPQztBQXVCRCxnS0FPQztBQXNCRCxvSkFPQztBQXVDRCxnS0FTQztBQW9CRCxrSkFPQztBQW1DRCxnS0FVQztBQXFCRCwwSkFPQztBQWdDRCw0SEFRQztBQWdDRCw0SEFRQztBQXNCRCx3SUFPQztBQXVDRCxvSkFTQztBQXdGRCx3SkFlQztBQTRDRCxvS0FVQztBQXFDRCxzSkFRQztBQXNERCwwSUFRQztBQThCRCxrTEFRQztBQXdDRCxrTUFTQztBQXVDRCxzTEFTQztBQXNDRCx3TUFTQztBQXNDRCxnTkFTQztBQXdDRCwwTUFTQztBQXNDRCxrTUFTQztBQXVDRCxrTUFTQztBQXVDRCw0S0FTQztBQTZCRCw0SUFRQztBQXVDRCwwS0FTQztBQXNDRCw0TEFTQztBQXNDRCxvTUFTQztBQXdDRCw4TEFTQztBQW9ERCxzS0FVQztBQWdDRCxnS0FRQztBQXdFRCw4SkFjQztBQWdERCw4SkFVQztBQW9ERCw0S0FVQztBQXlDRCxnS0FTQztBQXNDRCxvTEFTQztBQXdDRCx3S0FTQztBQW9ERCxnTEFTQztBQXdDRCw4S0FTQztBQXNDRCxrTUFTQztBQXNDRCwwTUFTQztBQXlDRCxvTEFTQztBQXlDRCx3TEFTQztBQXVDRCxvTEFTQztBQXVDRCxrTEFTQztBQXNCRCxvS0FPQztBQXNDRCxnTEFTQztBQThDRCx3TkFTQztBQXVDRCxnTEFTQztBQXlDRCw4TEFTQztBQTBDRCw4TUFTQztBQXdDRCxrTEFTQztBQXdDRCwwTEFTQztBQXVDRCxzTUFTQztBQXNDRCx3TkFTQztBQXNDRCxnT0FTQztBQXdDRCwwTkFTQztBQXVDRCwwUEFTQztBQTBGRCw4RUFRQztBQTJDRCw0RUFVQztBQThCRCxvRkFRQztBQXNCRCwwRkFPQztBQXVDRCxzR0FTQztBQXVDRCw0SEFTQztBQXNDRCw4SUFTQztBQXNDRCxzSkFTQztBQXdDRCxnSkFTQztBQW9GRCw0Q0FRQztBQStCRCwwQ0FRQztBQWtGRCxnRUFRQztBQTJCRCw4REFRQztBQXlCRCxzRUFRQztBQW9CRCx3RkFPQztBQW1DRCxzR0FVQztBQXNDRCx3SUFTQztBQXVDRCx3SUFTQztBQThFRCxnRUFRQztBQTBDRCw4REFTQztBQWdGRCxzRUFRQztBQXFERCxvRUFZQztBQW9CRCw0RUFPQztBQXFCRCxnR0FPQztBQXVDRCxrSEFTQztBQWdGRCxrREFRQztBQXNDRCxnREFTQztBQW9DRCx3REFRQztBQWdDRCw0RUFRQztBQWdDRCxrRUFRQztBQWdDRCxrRUFRQztBQTZCRCxrRkFRQztBQXNGRCxvREFRQztBQThERCxrREFZQztBQWdGRCxrRUFRQztBQW1DRCxnRUFTQztBQXVDRCxrR0FTQztBQXNGRCxrRUFRQztBQTBDRCxnRUFVQztBQThCRCx3RUFRQztBQXlDRCxrR0FTQztBQXNCRCw4RUFPQztBQXVDRCwwRkFTQztBQXVDRCxnSEFTQztBQXNDRCxrSUFTQztBQXNDRCwwSUFTQztBQXdDRCxvSUFTQztBQWtGRCw0Q0FRQztBQThFRCx3RUFRQztBQTJFRCxzRUFjQztBQStHRCxzRkFpQkM7QUE0Q0QsZ0dBUUM7QUF3RkQsOEZBZUM7QUE0Q0QsMEdBVUM7QUFxQ0QsNEZBUUM7QUFpRUQsNEdBVUM7QUFnQ0Qsc0dBUUM7QUF3RUQsb0dBY0M7QUFnREQsb0dBVUM7QUFvREQsa0hBVUM7QUF5Q0Qsc0dBU0M7QUFzQ0QsMEhBU0M7QUF3Q0QsOEdBU0M7QUFvREQsc0hBU0M7QUF3Q0Qsb0hBU0M7QUF5Q0QsMEhBU0M7QUF5Q0QsOEhBU0M7QUF1Q0QsMEhBU0M7QUF1Q0Qsd0hBU0M7QUFzQkQsMEdBT0M7QUFzQ0Qsc0hBU0M7QUE4Q0QsOEpBU0M7QUF1Q0Qsc0hBU0M7QUF5Q0Qsb0lBU0M7QUEwQ0Qsb0pBU0M7QUF3Q0Qsd0hBU0M7QUF3Q0QsZ0lBU0M7QUF1Q0QsNElBU0M7QUFzQ0QsOEpBU0M7QUFzQ0Qsc0tBU0M7QUF3Q0QsZ0tBU0M7QUF1Q0QsZ01BU0M7QUF3RkQsa0RBUUM7QUFrRkQsZ0RBZUM7QUEyQ0Qsb0VBVUM7QUFzQkQsNERBT0M7QUEyQkQsOERBUUM7QUF5Q0QsZ0ZBUUM7O0FBdGxURCxxQkFBcUI7QUFDckIsaUNBQXVFO0FBSXZFOzs7Ozs7Ozs7OztHQVdHO0FBQ0gsTUFBYSxjQUFlLFNBQVEsaUJBQVM7SUFTM0M7Ozs7OztPQU1HO0lBQ0ksTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUE2QixFQUFFO1FBQ3BELE9BQU87WUFDTCxHQUFHLGNBQWMsQ0FBQyxHQUFHO1lBQ3JCLEdBQUcsMEJBQTBCLENBQUMsS0FBSyxDQUFDO1NBQ3JDLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxZQUFtQixLQUFnQixFQUFFLEVBQVUsRUFBRSxRQUE2QixFQUFFO1FBQzlFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFO1lBQ2YsR0FBRyxjQUFjLENBQUMsR0FBRztZQUNyQixHQUFHLEtBQUs7U0FDVCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxNQUFNO1FBQ1gsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRWhDLE9BQU87WUFDTCxHQUFHLGNBQWMsQ0FBQyxHQUFHO1lBQ3JCLEdBQUcsMEJBQTBCLENBQUMsUUFBUSxDQUFDO1NBQ3hDLENBQUM7SUFDSixDQUFDOztBQTlDSCx3Q0ErQ0M7OztBQTlDQzs7R0FFRztBQUNvQixrQkFBRyxHQUFxQjtJQUM3QyxVQUFVLEVBQUUseUNBQXlDO0lBQ3JELElBQUksRUFBRSxnQkFBZ0I7Q0FDdkIsQ0FBQTtBQXVFSDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwwQkFBMEIsQ0FBQyxHQUFvQztJQUM3RSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixNQUFNLEVBQUUseUJBQXlCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztLQUM1QyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUEwREQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IseUJBQXlCLENBQUMsR0FBbUM7SUFDM0UsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsNkJBQTZCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUMvQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsZUFBZTtRQUN0QyxVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO1FBQ2xCLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtLQUN6QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUE4QkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNkJBQTZCLENBQUMsR0FBdUM7SUFDbkYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixpQkFBaUIsRUFBRSw0Q0FBNEMsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDO1FBQ3BGLGtCQUFrQixFQUFFLDZDQUE2QyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztRQUN2RixrQkFBa0IsRUFBRSw2Q0FBNkMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7S0FDeEYsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBQ0Qsd0NBQXdDO0FBRXhDOzs7Ozs7O0dBT0c7QUFDSCxJQUFZLGlDQVNYO0FBVEQsV0FBWSxpQ0FBaUM7SUFDM0Msa0JBQWtCO0lBQ2xCLGlFQUE0QixDQUFBO0lBQzVCLHdCQUF3QjtJQUN4Qiw4RUFBeUMsQ0FBQTtJQUN6QyxpQkFBaUI7SUFDakIsK0RBQTBCLENBQUE7SUFDMUIsa0JBQWtCO0lBQ2xCLGlFQUE0QixDQUFBO0FBQzlCLENBQUMsRUFUVyxpQ0FBaUMsaURBQWpDLGlDQUFpQyxRQVM1QztBQWlCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw0Q0FBNEMsQ0FBQyxHQUFzRDtJQUNqSCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFlBQVksRUFBRSxHQUFHLENBQUMsVUFBVTtLQUM3QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNkNBQTZDLENBQUMsR0FBdUQ7SUFDbkgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixXQUFXLEVBQUUsc0RBQXNELENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztLQUNuRixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNkNBQTZDLENBQUMsR0FBdUQ7SUFDbkgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixtQkFBbUIsRUFBRSw4REFBOEQsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7S0FDM0csQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBMEJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHNEQUFzRCxDQUFDLEdBQWdFO0lBQ3JJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsVUFBVSxFQUFFLDhEQUE4RCxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDeEYsY0FBYyxFQUFFLGtFQUFrRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7S0FDckcsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBb0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDhEQUE4RCxDQUFDLEdBQXdFO0lBQ3JKLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDhEQUE4RCxDQUFDLEdBQXdFO0lBQ3JKLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isa0VBQWtFLENBQUMsR0FBNEU7SUFDN0osSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELHdDQUF3QztBQUd4Qzs7OztHQUlHO0FBQ0gsTUFBYSxnQkFBaUIsU0FBUSxpQkFBUztJQVM3Qzs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQStCLEVBQUU7UUFDdEQsT0FBTztZQUNMLEdBQUcsZ0JBQWdCLENBQUMsR0FBRztZQUN2QixHQUFHLDRCQUE0QixDQUFDLEtBQUssQ0FBQztTQUN2QyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsUUFBK0IsRUFBRTtRQUNoRixLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLEdBQUcsZ0JBQWdCLENBQUMsR0FBRztZQUN2QixHQUFHLEtBQUs7U0FDVCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxNQUFNO1FBQ1gsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRWhDLE9BQU87WUFDTCxHQUFHLGdCQUFnQixDQUFDLEdBQUc7WUFDdkIsR0FBRyw0QkFBNEIsQ0FBQyxRQUFRLENBQUM7U0FDMUMsQ0FBQztJQUNKLENBQUM7O0FBOUNILDRDQStDQzs7O0FBOUNDOztHQUVHO0FBQ29CLG9CQUFHLEdBQXFCO0lBQzdDLFVBQVUsRUFBRSx5Q0FBeUM7SUFDckQsSUFBSSxFQUFFLGtCQUFrQjtDQUN6QixDQUFBO0FBNERIOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDRCQUE0QixDQUFDLEdBQXNDO0lBQ2pGLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLE1BQU0sRUFBRSwyQkFBMkIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0tBQzlDLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXVCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwyQkFBMkIsQ0FBQyxHQUFxQztJQUMvRSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFdBQVcsRUFBRSxvQ0FBb0MsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQ2hFLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFxRkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isb0NBQW9DLENBQUMsR0FBOEM7SUFDakcsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixvQkFBb0IsRUFBRSxzREFBc0QsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUM7UUFDcEcsMkJBQTJCLEVBQUUsNkRBQTZELENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDO1FBQ3pILFVBQVUsRUFBRSw0Q0FBNEMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO1FBQ3RFLG9CQUFvQixFQUFFLHNEQUFzRCxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztRQUNwRyx1QkFBdUIsRUFBRSx5REFBeUQsQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUM7UUFDN0csYUFBYSxFQUFFLCtDQUErQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFDL0UsY0FBYyxFQUFFLGdEQUFnRCxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7UUFDbEYscUJBQXFCLEVBQUUsdURBQXVELENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDO1FBQ3ZHLHFCQUFxQixFQUFFLHVEQUF1RCxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQztRQUN2RyxVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsd0JBQXdCLEVBQUUsMERBQTBELENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDO1FBQ2hILGFBQWEsRUFBRSwrQ0FBK0MsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO0tBQ2hGLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELHdDQUF3QztBQUV4Qzs7OztHQUlHO0FBQ0gsSUFBWSx3QkF5Qlg7QUF6QkQsV0FBWSx3QkFBd0I7SUFDbEMscUJBQXFCO0lBQ3JCLCtEQUFtQyxDQUFBO0lBQ25DLDRCQUE0QjtJQUM1Qiw2RUFBaUQsQ0FBQTtJQUNqRCxXQUFXO0lBQ1gseUNBQWEsQ0FBQTtJQUNiLHFCQUFxQjtJQUNyQiwrREFBbUMsQ0FBQTtJQUNuQyx3QkFBd0I7SUFDeEIscUVBQXlDLENBQUE7SUFDekMsc0JBQXNCO0lBQ3RCLGlFQUFxQyxDQUFBO0lBQ3JDLGVBQWU7SUFDZixpREFBcUIsQ0FBQTtJQUNyQixzQkFBc0I7SUFDdEIsaUVBQXFDLENBQUE7SUFDckMsV0FBVztJQUNYLHlDQUFhLENBQUE7SUFDYix5QkFBeUI7SUFDekIsdUVBQTJDLENBQUE7SUFDM0MsY0FBYztJQUNkLCtDQUFtQixDQUFBO0lBQ25CLGNBQWM7SUFDZCwrQ0FBbUIsQ0FBQTtBQUNyQixDQUFDLEVBekJXLHdCQUF3Qix3Q0FBeEIsd0JBQXdCLFFBeUJuQztBQXlERDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixzREFBc0QsQ0FBQyxHQUFnRTtJQUNySSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE1BQU0sRUFBRSwwREFBMEQsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQzVFLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxlQUFlO1FBQ3RDLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUs7UUFDbEIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO0tBQ3pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXVDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw2REFBNkQsQ0FBQyxHQUF1RTtJQUNuSixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE1BQU0sRUFBRSxpRUFBaUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ25GLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO0tBQ25CLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTJCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw0Q0FBNEMsQ0FBQyxHQUFzRDtJQUNqSCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFlBQVksRUFBRSxHQUFHLENBQUMsVUFBVTtRQUM1QixNQUFNLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7S0FDdEosQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBdUJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHNEQUFzRCxDQUFDLEdBQWdFO0lBQ3JJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLDBEQUEwRCxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDNUUsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWlERDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix5REFBeUQsQ0FBQyxHQUFtRTtJQUMzSSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztRQUNsQixNQUFNLEVBQUUsNkRBQTZELENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUMvRSxXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7UUFDMUIsYUFBYSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzFLLGNBQWMsRUFBRSxHQUFHLENBQUMsWUFBWSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM3QyxLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7S0FDZixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsK0NBQStDLENBQUMsR0FBeUQ7SUFDdkgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsbURBQW1ELENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNyRSxnQkFBZ0IsRUFBRSw2REFBNkQsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO1FBQ25HLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztLQUNmLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTBERDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixnREFBZ0QsQ0FBQyxHQUEwRDtJQUN6SCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGFBQWEsRUFBRSxHQUFHLENBQUMsV0FBVztRQUM5QixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU07UUFDcEIsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztRQUN0QixrQkFBa0IsRUFBRSxHQUFHLENBQUMsZ0JBQWdCO1FBQ3hDLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztLQUN2QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUErQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsdURBQXVELENBQUMsR0FBaUU7SUFDdkksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixjQUFjLEVBQUUsR0FBRyxDQUFDLFlBQVk7UUFDaEMsbUJBQW1CLEVBQUUsd0VBQXdFLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDO1FBQ3BILEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztLQUNmLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXNDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix1REFBdUQsQ0FBQyxHQUFpRTtJQUN2SSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE1BQU0sRUFBRSwyREFBMkQsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQzdFLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixtQkFBbUIsRUFBRSx3RUFBd0UsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7UUFDcEgsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXVFRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwwREFBMEQsQ0FBQyxHQUFvRTtJQUM3SSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLG9CQUFvQixFQUFFLEdBQUcsQ0FBQyxrQkFBa0I7UUFDNUMsWUFBWSxFQUFFLEdBQUcsQ0FBQyxVQUFVO1FBQzVCLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixZQUFZLEVBQUUsR0FBRyxDQUFDLFVBQVU7UUFDNUIsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFVBQVUsRUFBRSxrRUFBa0UsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO1FBQzVGLFlBQVksRUFBRSxHQUFHLENBQUMsVUFBVTtRQUM1QixlQUFlLEVBQUUsdUVBQXVFLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQztLQUM1RyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUE4RUQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsK0NBQStDLENBQUMsR0FBeUQ7SUFDdkgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLFlBQVksRUFBRSx5REFBeUQsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQ3ZGLFNBQVMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM5SixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU07UUFDcEIsUUFBUSxFQUFFLHFEQUFxRCxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7UUFDM0UsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsc0RBQXNELENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0YsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO1FBQ3RCLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztLQUNmLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQThCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwwREFBMEQsQ0FBQyxHQUFvRTtJQUM3SSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGlCQUFpQixFQUFFLHlFQUF5RSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUM7UUFDakgsa0JBQWtCLEVBQUUsMEVBQTBFLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO1FBQ3BILGtCQUFrQixFQUFFLDBFQUEwRSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztLQUNySCxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCx3Q0FBd0M7QUFFeEM7Ozs7Ozs7R0FPRztBQUNILElBQVksOERBU1g7QUFURCxXQUFZLDhEQUE4RDtJQUN4RSxrQkFBa0I7SUFDbEIsOEZBQTRCLENBQUE7SUFDNUIsd0JBQXdCO0lBQ3hCLDJHQUF5QyxDQUFBO0lBQ3pDLGlCQUFpQjtJQUNqQiw0RkFBMEIsQ0FBQTtJQUMxQixrQkFBa0I7SUFDbEIsOEZBQTRCLENBQUE7QUFDOUIsQ0FBQyxFQVRXLDhEQUE4RCw4RUFBOUQsOERBQThELFFBU3pFO0FBeUJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGlFQUFpRSxDQUFDLEdBQTJFO0lBQzNKLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLG9FQUFvRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7UUFDcEYsV0FBVyxFQUFFLDBFQUEwRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7S0FDdkcsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBcUJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDBEQUEwRCxDQUFDLEdBQW9FO0lBQzdJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFLG1FQUFtRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7UUFDL0Ysa0JBQWtCLEVBQUUsMEVBQTBFLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0tBQ3JILENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWdCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw2REFBNkQsQ0FBQyxHQUF1RTtJQUNuSixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFlBQVksRUFBRSx1RUFBdUUsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO0tBQ3RHLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWdDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixtREFBbUQsQ0FBQyxHQUE2RDtJQUMvSCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE9BQU8sRUFBRSx3REFBd0QsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQzVFLE9BQU8sRUFBRSx3REFBd0QsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0tBQzdFLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTRCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw2REFBNkQsQ0FBQyxHQUF1RTtJQUNuSixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHdFQUF3RSxDQUFDLEdBQWtGO0lBQ3pLLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBMEJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDJEQUEyRCxDQUFDLEdBQXFFO0lBQy9JLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLDhEQUE4RCxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7UUFDOUUsV0FBVyxFQUFFLG9FQUFvRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7S0FDakcsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBcUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHdFQUF3RSxDQUFDLEdBQWtGO0lBQ3pLLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsY0FBYyxFQUFFLEdBQUcsQ0FBQyxZQUFZO1FBQ2hDLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxlQUFlO1FBQ3RDLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUEyR0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isa0VBQWtFLENBQUMsR0FBNEU7SUFDN0osSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsc0VBQXNFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUN4RixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsWUFBWSxFQUFFLDRFQUE0RSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFDMUcscUJBQXFCLEVBQUUsR0FBRyxDQUFDLG1CQUFtQjtRQUM5QyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDOUosV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1FBQzFCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixnQkFBZ0IsRUFBRSxHQUFHLENBQUMsY0FBYztRQUNwQyxRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU07UUFDcEIsS0FBSyxFQUFFLHFFQUFxRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7UUFDckYsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO0tBQ3ZCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELHdDQUF3QztBQUV4Qzs7Ozs7Ozs7O0dBU0c7QUFDSCxJQUFZLDZEQU9YO0FBUEQsV0FBWSw2REFBNkQ7SUFDdkUsV0FBVztJQUNYLDhFQUFhLENBQUE7SUFDYixXQUFXO0lBQ1gsOEVBQWEsQ0FBQTtJQUNiLFVBQVU7SUFDViw0RUFBVyxDQUFBO0FBQ2IsQ0FBQyxFQVBXLDZEQUE2RCw2RUFBN0QsNkRBQTZELFFBT3hFO0FBb0JEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHVFQUF1RSxDQUFDLEdBQWlGO0lBQ3ZLLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsWUFBWSxFQUFFLEdBQUcsQ0FBQyxVQUFVO1FBQzVCLGVBQWUsRUFBRSxHQUFHLENBQUMsYUFBYTtLQUNuQyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF1Q0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IseURBQXlELENBQUMsR0FBbUU7SUFDM0ksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1FBQzFCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IscURBQXFELENBQUMsR0FBK0Q7SUFDbkksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7S0FDekIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBdUJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHNEQUFzRCxDQUFDLEdBQWdFO0lBQ3JJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSwrREFBK0QsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO0tBQzVGLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWtCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix5RUFBeUUsQ0FBQyxHQUFtRjtJQUMzSyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFlBQVksRUFBRSxHQUFHLENBQUMsVUFBVTtLQUM3QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsMEVBQTBFLENBQUMsR0FBb0Y7SUFDN0ssSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixXQUFXLEVBQUUsbUZBQW1GLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztLQUNoSCxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsMEVBQTBFLENBQUMsR0FBb0Y7SUFDN0ssSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixtQkFBbUIsRUFBRSwyRkFBMkYsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7S0FDeEksQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0JEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLG9FQUFvRSxDQUFDLEdBQThFO0lBQ2pLLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsbUJBQW1CLEVBQUUscUZBQXFGLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDO0tBQ2xJLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwwRUFBMEUsQ0FBQyxHQUFvRjtJQUM3SyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLHNCQUFzQixFQUFFLDhGQUE4RixDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQztRQUNoSiwwQkFBMEIsRUFBRSxrR0FBa0csQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUM7UUFDNUosdUJBQXVCLEVBQUUsK0ZBQStGLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDO0tBQ3BKLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWdCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixtRUFBbUUsQ0FBQyxHQUE2RTtJQUMvSixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLDBCQUEwQixFQUFFLDJGQUEyRixDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQztLQUN0SixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUErQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsMEVBQTBFLENBQUMsR0FBb0Y7SUFDN0ssSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixpQkFBaUIsRUFBRSxHQUFHLENBQUMsZUFBZTtRQUN0QyxhQUFhLEVBQUUsR0FBRyxDQUFDLFdBQVc7UUFDOUIsa0JBQWtCLEVBQUUsR0FBRyxDQUFDLGdCQUFnQjtRQUN4QyxtQkFBbUIsRUFBRSwyRkFBMkYsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7S0FDeEksQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBaUJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHVFQUF1RSxDQUFDLEdBQWlGO0lBQ3ZLLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFLGdGQUFnRixDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7S0FDN0csQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBNEJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHdEQUF3RCxDQUFDLEdBQWtFO0lBQ3pJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsVUFBVSxFQUFFLGdFQUFnRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDMUYsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO0tBQ3pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTRCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix3REFBd0QsQ0FBQyxHQUFrRTtJQUN6SSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsOERBQThELENBQUMsR0FBd0U7SUFDckosSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixtQkFBbUIsRUFBRSwrRUFBK0UsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7S0FDNUgsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLG9FQUFvRSxDQUFDLEdBQThFO0lBQ2pLLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2Isc0JBQXNCLEVBQUUsd0ZBQXdGLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDO1FBQzFJLDBCQUEwQixFQUFFLDRGQUE0RixDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQztRQUN0Six1QkFBdUIsRUFBRSx5RkFBeUYsQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUM7S0FDOUksQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBb0ZEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHNFQUFzRSxDQUFDLEdBQWdGO0lBQ3JLLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsU0FBUyxFQUFFLDZFQUE2RSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7UUFDckcsTUFBTSxFQUFFLDBFQUEwRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDNUYsS0FBSyxFQUFFLHlFQUF5RSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7UUFDekYsS0FBSyxFQUFFLHlFQUF5RSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7UUFDekYsWUFBWSxFQUFFLGdGQUFnRixDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFDOUcsTUFBTSxFQUFFLDBFQUEwRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDNUYsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1FBQzFCLGdCQUFnQixFQUFFLG9GQUFvRixDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7UUFDMUgsVUFBVSxFQUFFLDhFQUE4RSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7S0FDekcsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBd0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDRFQUE0RSxDQUFDLEdBQXNGO0lBQ2pMLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztRQUMxQixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBaUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHFFQUFxRSxDQUFDLEdBQStFO0lBQ25LLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsZUFBZSxFQUFFLGtGQUFrRixDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFDdEgsY0FBYyxFQUFFLGlGQUFpRixDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7S0FDcEgsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBQ0Qsd0NBQXdDO0FBRXhDOzs7OztHQUtHO0FBQ0gsSUFBWSxrRUFLWDtBQUxELFdBQVksa0VBQWtFO0lBQzVFLFNBQVM7SUFDVCwrRUFBUyxDQUFBO0lBQ1QsU0FBUztJQUNULCtFQUFTLENBQUE7QUFDWCxDQUFDLEVBTFcsa0VBQWtFLGtGQUFsRSxrRUFBa0UsUUFLN0U7QUFFRDs7OztHQUlHO0FBQ0gsSUFBWSxzREFLWDtBQUxELFdBQVksc0RBQXNEO0lBQ2hFLGFBQWE7SUFDYiwyRUFBaUIsQ0FBQTtJQUNqQixnQkFBZ0I7SUFDaEIsa0ZBQXdCLENBQUE7QUFDMUIsQ0FBQyxFQUxXLHNEQUFzRCxzRUFBdEQsc0RBQXNELFFBS2pFO0FBd0JEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLCtEQUErRCxDQUFDLEdBQXlFO0lBQ3ZKLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTBCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixtRkFBbUYsQ0FBQyxHQUE2RjtJQUMvTCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSwyRkFBMkYsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO1FBQ3JILGNBQWMsRUFBRSwrRkFBK0YsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDO0tBQ2xJLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW9DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwyRkFBMkYsQ0FBQyxHQUFxRztJQUMvTSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN2QyxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixxRkFBcUYsQ0FBQyxHQUErRjtJQUNuTSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN2QyxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWtDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw4RkFBOEYsQ0FBQyxHQUF3RztJQUNyTixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGtHQUFrRyxDQUFDLEdBQTRHO0lBQzdOLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFvQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsK0ZBQStGLENBQUMsR0FBeUc7SUFDdk4sSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWtDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwyRkFBMkYsQ0FBQyxHQUFxRztJQUMvTSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDJGQUEyRixDQUFDLEdBQXFHO0lBQy9NLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGdGQUFnRixDQUFDLEdBQTBGO0lBQ3pMLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF5QkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsZ0VBQWdFLENBQUMsR0FBMEU7SUFDekosSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLCtFQUErRSxDQUFDLEdBQXlGO0lBQ3ZMLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHdGQUF3RixDQUFDLEdBQWtHO0lBQ3pNLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNEZBQTRGLENBQUMsR0FBc0c7SUFDak4sSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW9DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix5RkFBeUYsQ0FBQyxHQUFtRztJQUMzTSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBZ0REOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDZFQUE2RSxDQUFDLEdBQXVGO0lBQ25MLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixTQUFTLEVBQUUsb0ZBQW9GLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztRQUM1RyxXQUFXLEVBQUUsc0ZBQXNGLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztLQUNuSCxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUE0QkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsMEVBQTBFLENBQUMsR0FBb0Y7SUFDN0ssSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixZQUFZLEVBQUUsb0ZBQW9GLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUNsSCxXQUFXLEVBQUUsbUZBQW1GLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztLQUNoSCxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFvRUQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IseUVBQXlFLENBQUMsR0FBbUY7SUFDM0ssSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixZQUFZLEVBQUUsR0FBRyxDQUFDLFVBQVU7UUFDNUIsS0FBSyxFQUFFLDRFQUE0RSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7UUFDNUYsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLGtGQUFrRixDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7UUFDOUcscUJBQXFCLEVBQUUsR0FBRyxDQUFDLG1CQUFtQjtRQUM5QyxXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBNENEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHlFQUF5RSxDQUFDLEdBQW1GO0lBQzNLLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsK0JBQStCLEVBQUUsc0dBQXNHLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDO1FBQzFLLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLGtGQUFrRixDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7S0FDL0csQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBZ0REOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGdGQUFnRixDQUFDLEdBQTBGO0lBQ3pMLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1FBQzFCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUseUZBQXlGLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUNySCxtQkFBbUIsRUFBRSxpR0FBaUcsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7S0FDOUksQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBcUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDBFQUEwRSxDQUFDLEdBQW9GO0lBQzdLLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxtRkFBbUYsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQy9HLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtLQUN6QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isb0ZBQW9GLENBQUMsR0FBOEY7SUFDak0sSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW9DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw4RUFBOEUsQ0FBQyxHQUF3RjtJQUNyTCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsdUZBQXVGLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUNuSCxVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7S0FDekIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBQ0Qsd0NBQXdDO0FBRXhDOzs7O0dBSUc7QUFDSCxJQUFZLHlFQUtYO0FBTEQsV0FBWSx5RUFBeUU7SUFDbkYsYUFBYTtJQUNiLDhGQUFpQixDQUFBO0lBQ2pCLGdCQUFnQjtJQUNoQixxR0FBd0IsQ0FBQTtBQUMxQixDQUFDLEVBTFcseUVBQXlFLHlGQUF6RSx5RUFBeUUsUUFLcEY7QUFtQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isa0ZBQWtGLENBQUMsR0FBNEY7SUFDN0wsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW9DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixpRkFBaUYsQ0FBQyxHQUEyRjtJQUMzTCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDJGQUEyRixDQUFDLEdBQXFHO0lBQy9NLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsK0ZBQStGLENBQUMsR0FBeUc7SUFDdk4sSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXFDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixvRkFBb0YsQ0FBQyxHQUE4RjtJQUNqTSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBcUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHNGQUFzRixDQUFDLEdBQWdHO0lBQ3JNLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isb0ZBQW9GLENBQUMsR0FBOEY7SUFDak0sSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixtRkFBbUYsQ0FBQyxHQUE2RjtJQUMvTCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0JEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDRFQUE0RSxDQUFDLEdBQXNGO0lBQ2pMLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsbUJBQW1CLEVBQUUsNkZBQTZGLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDO0tBQzFJLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWtDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixrRkFBa0YsQ0FBQyxHQUE0RjtJQUM3TCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLHNCQUFzQixFQUFFLHNHQUFzRyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQztRQUN4SiwwQkFBMEIsRUFBRSwwR0FBMEcsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUM7UUFDcEssdUJBQXVCLEVBQUUsdUdBQXVHLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDO0tBQzVKLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTBDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixzR0FBc0csQ0FBQyxHQUFnSDtJQUNyTyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN2QyxtQkFBbUIsRUFBRSxHQUFHLENBQUMsaUJBQWlCO1FBQzFDLG1CQUFtQixFQUFFLHVIQUF1SCxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQztLQUNwSyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isa0ZBQWtGLENBQUMsR0FBNEY7SUFDN0wsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXFDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix5RkFBeUYsQ0FBQyxHQUFtRztJQUMzTSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBc0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGlHQUFpRyxDQUFDLEdBQTJHO0lBQzNOLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBb0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLG1GQUFtRixDQUFDLEdBQTZGO0lBQy9MLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFvQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsdUZBQXVGLENBQUMsR0FBaUc7SUFDdk0sSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw2RkFBNkYsQ0FBQyxHQUF1RztJQUNuTixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN2QyxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWtDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixzR0FBc0csQ0FBQyxHQUFnSDtJQUNyTyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDBHQUEwRyxDQUFDLEdBQW9IO0lBQzdPLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFvQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsdUdBQXVHLENBQUMsR0FBaUg7SUFDdk8sSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix1SEFBdUgsQ0FBQyxHQUFpSTtJQUN2USxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN2QyxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELHdDQUF3QztBQUd4Qzs7Ozs7Ozs7O0dBU0c7QUFDSCxNQUFhLHFCQUFzQixTQUFRLGlCQUFTO0lBU2xEOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBb0MsRUFBRTtRQUMzRCxPQUFPO1lBQ0wsR0FBRyxxQkFBcUIsQ0FBQyxHQUFHO1lBQzVCLEdBQUcsaUNBQWlDLENBQUMsS0FBSyxDQUFDO1NBQzVDLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxZQUFtQixLQUFnQixFQUFFLEVBQVUsRUFBRSxRQUFvQyxFQUFFO1FBQ3JGLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFO1lBQ2YsR0FBRyxxQkFBcUIsQ0FBQyxHQUFHO1lBQzVCLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLE1BQU07UUFDWCxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFaEMsT0FBTztZQUNMLEdBQUcscUJBQXFCLENBQUMsR0FBRztZQUM1QixHQUFHLGlDQUFpQyxDQUFDLFFBQVEsQ0FBQztTQUMvQyxDQUFDO0lBQ0osQ0FBQzs7QUE5Q0gsc0RBK0NDOzs7QUE5Q0M7O0dBRUc7QUFDb0IseUJBQUcsR0FBcUI7SUFDN0MsVUFBVSxFQUFFLHlDQUF5QztJQUNyRCxJQUFJLEVBQUUsdUJBQXVCO0NBQzlCLENBQUE7QUFpRUg7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsaUNBQWlDLENBQUMsR0FBMkM7SUFDM0YsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsTUFBTSxFQUFFLGdDQUFnQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7S0FDbkQsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBdUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGdDQUFnQyxDQUFDLEdBQTBDO0lBQ3pGLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLG9DQUFvQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDdEQsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUs7S0FDbkIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBMEJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLG9DQUFvQyxDQUFDLEdBQThDO0lBQ2pHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLHVDQUF1QyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7UUFDdkQsV0FBVyxFQUFFLDZDQUE2QyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7S0FDMUUsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0JEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHVDQUF1QyxDQUFDLEdBQWlEO0lBQ3ZHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsbUJBQW1CLEVBQUUsd0RBQXdELENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDO0tBQ3JHLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw2Q0FBNkMsQ0FBQyxHQUF1RDtJQUNuSCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLHNCQUFzQixFQUFFLGlFQUFpRSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQztRQUNuSCwwQkFBMEIsRUFBRSxxRUFBcUUsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUM7UUFDL0gsdUJBQXVCLEVBQUUsa0VBQWtFLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDO0tBQ3ZILENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix3REFBd0QsQ0FBQyxHQUFrRTtJQUN6SSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN2QyxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWtDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixpRUFBaUUsQ0FBQyxHQUEyRTtJQUMzSixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHFFQUFxRSxDQUFDLEdBQStFO0lBQ25LLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFvQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isa0VBQWtFLENBQUMsR0FBNEU7SUFDN0osSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELHdDQUF3QztBQUd4Qzs7Ozs7R0FLRztBQUNILE1BQWEsSUFBSyxTQUFRLGlCQUFTO0lBU2pDOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBbUIsRUFBRTtRQUMxQyxPQUFPO1lBQ0wsR0FBRyxJQUFJLENBQUMsR0FBRztZQUNYLEdBQUcsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO1NBQzNCLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxZQUFtQixLQUFnQixFQUFFLEVBQVUsRUFBRSxRQUFtQixFQUFFO1FBQ3BFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFO1lBQ2YsR0FBRyxJQUFJLENBQUMsR0FBRztZQUNYLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLE1BQU07UUFDWCxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFaEMsT0FBTztZQUNMLEdBQUcsSUFBSSxDQUFDLEdBQUc7WUFDWCxHQUFHLGdCQUFnQixDQUFDLFFBQVEsQ0FBQztTQUM5QixDQUFDO0lBQ0osQ0FBQzs7QUE5Q0gsb0JBK0NDOzs7QUE5Q0M7O0dBRUc7QUFDb0IsUUFBRyxHQUFxQjtJQUM3QyxVQUFVLEVBQUUseUNBQXlDO0lBQ3JELElBQUksRUFBRSxNQUFNO0NBQ2IsQ0FBQTtBQStESDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixnQkFBZ0IsQ0FBQyxHQUEwQjtJQUN6RCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixNQUFNLEVBQUUsZUFBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7S0FDbEMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBMkJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGVBQWUsQ0FBQyxHQUF5QjtJQUN2RCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFlBQVksRUFBRSxHQUFHLENBQUMsVUFBVTtRQUM1QixNQUFNLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7S0FDdEosQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBQ0Qsd0NBQXdDO0FBR3hDOzs7OztHQUtHO0FBQ0gsTUFBYSxjQUFlLFNBQVEsaUJBQVM7SUFTM0M7Ozs7OztPQU1HO0lBQ0ksTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUE2QixFQUFFO1FBQ3BELE9BQU87WUFDTCxHQUFHLGNBQWMsQ0FBQyxHQUFHO1lBQ3JCLEdBQUcsMEJBQTBCLENBQUMsS0FBSyxDQUFDO1NBQ3JDLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxZQUFtQixLQUFnQixFQUFFLEVBQVUsRUFBRSxRQUE2QixFQUFFO1FBQzlFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFO1lBQ2YsR0FBRyxjQUFjLENBQUMsR0FBRztZQUNyQixHQUFHLEtBQUs7U0FDVCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxNQUFNO1FBQ1gsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRWhDLE9BQU87WUFDTCxHQUFHLGNBQWMsQ0FBQyxHQUFHO1lBQ3JCLEdBQUcsMEJBQTBCLENBQUMsUUFBUSxDQUFDO1NBQ3hDLENBQUM7SUFDSixDQUFDOztBQTlDSCx3Q0ErQ0M7OztBQTlDQzs7R0FFRztBQUNvQixrQkFBRyxHQUFxQjtJQUM3QyxVQUFVLEVBQUUseUNBQXlDO0lBQ3JELElBQUksRUFBRSxnQkFBZ0I7Q0FDdkIsQ0FBQTtBQTZESDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwwQkFBMEIsQ0FBQyxHQUFvQztJQUM3RSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixNQUFNLEVBQUUseUJBQXlCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztLQUM1QyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF1QkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IseUJBQXlCLENBQUMsR0FBbUM7SUFDM0UsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsNkJBQTZCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUMvQyxXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBcUJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDZCQUE2QixDQUFDLEdBQXVDO0lBQ25GLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFLHNDQUFzQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7UUFDbEUsa0JBQWtCLEVBQUUsNkNBQTZDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0tBQ3hGLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWdCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixzQ0FBc0MsQ0FBQyxHQUFnRDtJQUNyRyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLDBCQUEwQixFQUFFLDhEQUE4RCxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQztLQUN6SCxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUErQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNkNBQTZDLENBQUMsR0FBdUQ7SUFDbkgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixpQkFBaUIsRUFBRSxHQUFHLENBQUMsZUFBZTtRQUN0QyxhQUFhLEVBQUUsR0FBRyxDQUFDLFdBQVc7UUFDOUIsa0JBQWtCLEVBQUUsR0FBRyxDQUFDLGdCQUFnQjtRQUN4QyxtQkFBbUIsRUFBRSw4REFBOEQsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7S0FDM0csQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDhEQUE4RCxDQUFDLEdBQXdFO0lBQ3JKLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsOERBQThELENBQUMsR0FBd0U7SUFDckosSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDdkMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCx3Q0FBd0M7QUFHeEM7Ozs7R0FJRztBQUNILE1BQWEsY0FBZSxTQUFRLGlCQUFTO0lBUzNDOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBNkIsRUFBRTtRQUNwRCxPQUFPO1lBQ0wsR0FBRyxjQUFjLENBQUMsR0FBRztZQUNyQixHQUFHLDBCQUEwQixDQUFDLEtBQUssQ0FBQztTQUNyQyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsUUFBNkIsRUFBRTtRQUM5RSxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLEdBQUcsY0FBYyxDQUFDLEdBQUc7WUFDckIsR0FBRyxLQUFLO1NBQ1QsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksTUFBTTtRQUNYLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVoQyxPQUFPO1lBQ0wsR0FBRyxjQUFjLENBQUMsR0FBRztZQUNyQixHQUFHLDBCQUEwQixDQUFDLFFBQVEsQ0FBQztTQUN4QyxDQUFDO0lBQ0osQ0FBQzs7QUE5Q0gsd0NBK0NDOzs7QUE5Q0M7O0dBRUc7QUFDb0Isa0JBQUcsR0FBcUI7SUFDN0MsVUFBVSxFQUFFLHlDQUF5QztJQUNyRCxJQUFJLEVBQUUsZ0JBQWdCO0NBQ3ZCLENBQUE7QUEwREg7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsMEJBQTBCLENBQUMsR0FBb0M7SUFDN0UsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsTUFBTSxFQUFFLHlCQUF5QixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7S0FDNUMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBc0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHlCQUF5QixDQUFDLEdBQW1DO0lBQzNFLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsMkJBQTJCLEVBQUUsR0FBRyxDQUFDLHlCQUF5QixFQUFFLFdBQVcsRUFBRTtRQUN6RSxVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO0tBQ25CLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELHdDQUF3QztBQUd4Qzs7OztHQUlHO0FBQ0gsTUFBYSxpQkFBa0IsU0FBUSxpQkFBUztJQVM5Qzs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQWdDLEVBQUU7UUFDdkQsT0FBTztZQUNMLEdBQUcsaUJBQWlCLENBQUMsR0FBRztZQUN4QixHQUFHLDZCQUE2QixDQUFDLEtBQUssQ0FBQztTQUN4QyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsUUFBZ0MsRUFBRTtRQUNqRixLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLEdBQUcsaUJBQWlCLENBQUMsR0FBRztZQUN4QixHQUFHLEtBQUs7U0FDVCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxNQUFNO1FBQ1gsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRWhDLE9BQU87WUFDTCxHQUFHLGlCQUFpQixDQUFDLEdBQUc7WUFDeEIsR0FBRyw2QkFBNkIsQ0FBQyxRQUFRLENBQUM7U0FDM0MsQ0FBQztJQUNKLENBQUM7O0FBOUNILDhDQStDQzs7O0FBOUNDOztHQUVHO0FBQ29CLHFCQUFHLEdBQXFCO0lBQzdDLFVBQVUsRUFBRSx5Q0FBeUM7SUFDckQsSUFBSSxFQUFFLG1CQUFtQjtDQUMxQixDQUFBO0FBNERIOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDZCQUE2QixDQUFDLEdBQXVDO0lBQ25GLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLE1BQU0sRUFBRSw0QkFBNEIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0tBQy9DLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWlERDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw0QkFBNEIsQ0FBQyxHQUFzQztJQUNqRixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztRQUNsQixNQUFNLEVBQUUsZ0NBQWdDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNsRCxXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7UUFDMUIsYUFBYSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzFLLGNBQWMsRUFBRSxHQUFHLENBQUMsWUFBWSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM3QyxLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7S0FDZixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFnQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsZ0NBQWdDLENBQUMsR0FBMEM7SUFDekYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixZQUFZLEVBQUUsMENBQTBDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztLQUN6RSxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFpQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsMENBQTBDLENBQUMsR0FBb0Q7SUFDN0csSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixXQUFXLEVBQUUsbURBQW1ELENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztLQUNoRixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsbURBQW1ELENBQUMsR0FBNkQ7SUFDL0gsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELHdDQUF3QztBQUd4Qzs7OztHQUlHO0FBQ0gsTUFBYSxPQUFRLFNBQVEsaUJBQVM7SUFTcEM7Ozs7OztPQU1HO0lBQ0ksTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFzQixFQUFFO1FBQzdDLE9BQU87WUFDTCxHQUFHLE9BQU8sQ0FBQyxHQUFHO1lBQ2QsR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLENBQUM7U0FDOUIsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQW1CLEtBQWdCLEVBQUUsRUFBVSxFQUFFLFFBQXNCLEVBQUU7UUFDdkUsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixHQUFHLE9BQU8sQ0FBQyxHQUFHO1lBQ2QsR0FBRyxLQUFLO1NBQ1QsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksTUFBTTtRQUNYLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVoQyxPQUFPO1lBQ0wsR0FBRyxPQUFPLENBQUMsR0FBRztZQUNkLEdBQUcsbUJBQW1CLENBQUMsUUFBUSxDQUFDO1NBQ2pDLENBQUM7SUFDSixDQUFDOztBQTlDSCwwQkErQ0M7OztBQTlDQzs7R0FFRztBQUNvQixXQUFHLEdBQXFCO0lBQzdDLFVBQVUsRUFBRSx5Q0FBeUM7SUFDckQsSUFBSSxFQUFFLFNBQVM7Q0FDaEIsQ0FBQTtBQTRESDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixtQkFBbUIsQ0FBQyxHQUE2QjtJQUMvRCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixNQUFNLEVBQUUsa0JBQWtCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztLQUNyQyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isa0JBQWtCLENBQUMsR0FBNEI7SUFDN0QsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUN4QyxnQkFBZ0IsRUFBRSxnQ0FBZ0MsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO1FBQ3RFLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztLQUNmLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWdDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixzQkFBc0IsQ0FBQyxHQUFnQztJQUNyRSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE9BQU8sRUFBRSwyQkFBMkIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQy9DLE9BQU8sRUFBRSwyQkFBMkIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0tBQ2hELENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTRCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixnQ0FBZ0MsQ0FBQyxHQUEwQztJQUN6RixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBNEJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDJCQUEyQixDQUFDLEdBQXFDO0lBQy9FLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsVUFBVSxFQUFFLG1DQUFtQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDN0QsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO0tBQ3pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTRCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwyQkFBMkIsQ0FBQyxHQUFxQztJQUMvRSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF5QkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsbUNBQW1DLENBQUMsR0FBNkM7SUFDL0YsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBQ0Qsd0NBQXdDO0FBR3hDOzs7Ozs7R0FNRztBQUNILE1BQWEsUUFBUyxTQUFRLGlCQUFTO0lBU3JDOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBdUIsRUFBRTtRQUM5QyxPQUFPO1lBQ0wsR0FBRyxRQUFRLENBQUMsR0FBRztZQUNmLEdBQUcsb0JBQW9CLENBQUMsS0FBSyxDQUFDO1NBQy9CLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxZQUFtQixLQUFnQixFQUFFLEVBQVUsRUFBRSxRQUF1QixFQUFFO1FBQ3hFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFO1lBQ2YsR0FBRyxRQUFRLENBQUMsR0FBRztZQUNmLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLE1BQU07UUFDWCxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFaEMsT0FBTztZQUNMLEdBQUcsUUFBUSxDQUFDLEdBQUc7WUFDZixHQUFHLG9CQUFvQixDQUFDLFFBQVEsQ0FBQztTQUNsQyxDQUFDO0lBQ0osQ0FBQzs7QUE5Q0gsNEJBK0NDOzs7QUE5Q0M7O0dBRUc7QUFDb0IsWUFBRyxHQUFxQjtJQUM3QyxVQUFVLEVBQUUseUNBQXlDO0lBQ3JELElBQUksRUFBRSxVQUFVO0NBQ2pCLENBQUE7QUFnRUg7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isb0JBQW9CLENBQUMsR0FBOEI7SUFDakUsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsTUFBTSxFQUFFLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7S0FDdEMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBMEREOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLG1CQUFtQixDQUFDLEdBQTZCO0lBQy9ELElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsYUFBYSxFQUFFLEdBQUcsQ0FBQyxXQUFXO1FBQzlCLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU07UUFDcEIsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO1FBQ3RCLGtCQUFrQixFQUFFLEdBQUcsQ0FBQyxnQkFBZ0I7UUFDeEMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO0tBQ3ZCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELHdDQUF3QztBQUd4Qzs7OztHQUlHO0FBQ0gsTUFBYSxlQUFnQixTQUFRLGlCQUFTO0lBUzVDOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBOEIsRUFBRTtRQUNyRCxPQUFPO1lBQ0wsR0FBRyxlQUFlLENBQUMsR0FBRztZQUN0QixHQUFHLDJCQUEyQixDQUFDLEtBQUssQ0FBQztTQUN0QyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsUUFBOEIsRUFBRTtRQUMvRSxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLEdBQUcsZUFBZSxDQUFDLEdBQUc7WUFDdEIsR0FBRyxLQUFLO1NBQ1QsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksTUFBTTtRQUNYLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVoQyxPQUFPO1lBQ0wsR0FBRyxlQUFlLENBQUMsR0FBRztZQUN0QixHQUFHLDJCQUEyQixDQUFDLFFBQVEsQ0FBQztTQUN6QyxDQUFDO0lBQ0osQ0FBQzs7QUE5Q0gsMENBK0NDOzs7QUE5Q0M7O0dBRUc7QUFDb0IsbUJBQUcsR0FBcUI7SUFDN0MsVUFBVSxFQUFFLHlDQUF5QztJQUNyRCxJQUFJLEVBQUUsaUJBQWlCO0NBQ3hCLENBQUE7QUE0REg7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsMkJBQTJCLENBQUMsR0FBcUM7SUFDL0UsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsTUFBTSxFQUFFLDBCQUEwQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7S0FDN0MsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBK0JEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDBCQUEwQixDQUFDLEdBQW9DO0lBQzdFLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsY0FBYyxFQUFFLEdBQUcsQ0FBQyxZQUFZO1FBQ2hDLG1CQUFtQixFQUFFLDJDQUEyQyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQztRQUN2RixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7S0FDZixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsMkNBQTJDLENBQUMsR0FBcUQ7SUFDL0csSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDdkMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCx3Q0FBd0M7QUFHeEM7Ozs7Ozs7R0FPRztBQUNILE1BQWEsZUFBZ0IsU0FBUSxpQkFBUztJQVM1Qzs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQThCLEVBQUU7UUFDckQsT0FBTztZQUNMLEdBQUcsZUFBZSxDQUFDLEdBQUc7WUFDdEIsR0FBRywyQkFBMkIsQ0FBQyxLQUFLLENBQUM7U0FDdEMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQW1CLEtBQWdCLEVBQUUsRUFBVSxFQUFFLFFBQThCLEVBQUU7UUFDL0UsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixHQUFHLGVBQWUsQ0FBQyxHQUFHO1lBQ3RCLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLE1BQU07UUFDWCxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFaEMsT0FBTztZQUNMLEdBQUcsZUFBZSxDQUFDLEdBQUc7WUFDdEIsR0FBRywyQkFBMkIsQ0FBQyxRQUFRLENBQUM7U0FDekMsQ0FBQztJQUNKLENBQUM7O0FBOUNILDBDQStDQzs7O0FBOUNDOztHQUVHO0FBQ29CLG1CQUFHLEdBQXFCO0lBQzdDLFVBQVUsRUFBRSx5Q0FBeUM7SUFDckQsSUFBSSxFQUFFLGlCQUFpQjtDQUN4QixDQUFBO0FBK0RIOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDJCQUEyQixDQUFDLEdBQXFDO0lBQy9FLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLE1BQU0sRUFBRSwwQkFBMEIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0tBQzdDLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXNDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwwQkFBMEIsQ0FBQyxHQUFvQztJQUM3RSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE1BQU0sRUFBRSw4QkFBOEIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ2hELFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixtQkFBbUIsRUFBRSwyQ0FBMkMsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7UUFDdkYsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTBCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw4QkFBOEIsQ0FBQyxHQUF3QztJQUNyRixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxpQ0FBaUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO1FBQ2pELFdBQVcsRUFBRSx1Q0FBdUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO0tBQ3BFLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXFDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwyQ0FBMkMsQ0FBQyxHQUFxRDtJQUMvRyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGNBQWMsRUFBRSxHQUFHLENBQUMsWUFBWTtRQUNoQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsZUFBZTtRQUN0QyxXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0JEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGlDQUFpQyxDQUFDLEdBQTJDO0lBQzNGLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsbUJBQW1CLEVBQUUsa0RBQWtELENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDO0tBQy9GLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix1Q0FBdUMsQ0FBQyxHQUFpRDtJQUN2RyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLHNCQUFzQixFQUFFLDJEQUEyRCxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQztRQUM3RywwQkFBMEIsRUFBRSwrREFBK0QsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUM7UUFDekgsdUJBQXVCLEVBQUUsNERBQTRELENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDO0tBQ2pILENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixrREFBa0QsQ0FBQyxHQUE0RDtJQUM3SCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN2QyxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWtDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwyREFBMkQsQ0FBQyxHQUFxRTtJQUMvSSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLCtEQUErRCxDQUFDLEdBQXlFO0lBQ3ZKLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFvQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNERBQTRELENBQUMsR0FBc0U7SUFDakosSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELHdDQUF3QztBQUd4Qzs7OztHQUlHO0FBQ0gsTUFBYSxJQUFLLFNBQVEsaUJBQVM7SUFTakM7Ozs7OztPQU1HO0lBQ0ksTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFtQixFQUFFO1FBQzFDLE9BQU87WUFDTCxHQUFHLElBQUksQ0FBQyxHQUFHO1lBQ1gsR0FBRyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUM7U0FDM0IsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQW1CLEtBQWdCLEVBQUUsRUFBVSxFQUFFLFFBQW1CLEVBQUU7UUFDcEUsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixHQUFHLElBQUksQ0FBQyxHQUFHO1lBQ1gsR0FBRyxLQUFLO1NBQ1QsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksTUFBTTtRQUNYLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVoQyxPQUFPO1lBQ0wsR0FBRyxJQUFJLENBQUMsR0FBRztZQUNYLEdBQUcsZ0JBQWdCLENBQUMsUUFBUSxDQUFDO1NBQzlCLENBQUM7SUFDSixDQUFDOztBQTlDSCxvQkErQ0M7OztBQTlDQzs7R0FFRztBQUNvQixRQUFHLEdBQXFCO0lBQzdDLFVBQVUsRUFBRSx5Q0FBeUM7SUFDckQsSUFBSSxFQUFFLE1BQU07Q0FDYixDQUFBO0FBOERIOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGdCQUFnQixDQUFDLEdBQTBCO0lBQ3pELElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCx3Q0FBd0M7QUFHeEM7Ozs7R0FJRztBQUNILE1BQWEsa0JBQW1CLFNBQVEsaUJBQVM7SUFTL0M7Ozs7OztPQU1HO0lBQ0ksTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFpQyxFQUFFO1FBQ3hELE9BQU87WUFDTCxHQUFHLGtCQUFrQixDQUFDLEdBQUc7WUFDekIsR0FBRyw4QkFBOEIsQ0FBQyxLQUFLLENBQUM7U0FDekMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQW1CLEtBQWdCLEVBQUUsRUFBVSxFQUFFLFFBQWlDLEVBQUU7UUFDbEYsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixHQUFHLGtCQUFrQixDQUFDLEdBQUc7WUFDekIsR0FBRyxLQUFLO1NBQ1QsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ksTUFBTTtRQUNYLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVoQyxPQUFPO1lBQ0wsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHO1lBQ3pCLEdBQUcsOEJBQThCLENBQUMsUUFBUSxDQUFDO1NBQzVDLENBQUM7SUFDSixDQUFDOztBQTlDSCxnREErQ0M7OztBQTlDQzs7R0FFRztBQUNvQixzQkFBRyxHQUFxQjtJQUM3QyxVQUFVLEVBQUUseUNBQXlDO0lBQ3JELElBQUksRUFBRSxvQkFBb0I7Q0FDM0IsQ0FBQTtBQTBESDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw4QkFBOEIsQ0FBQyxHQUF3QztJQUNyRixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixNQUFNLEVBQUUsNkJBQTZCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztLQUNoRCxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF1RUQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNkJBQTZCLENBQUMsR0FBdUM7SUFDbkYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixvQkFBb0IsRUFBRSxHQUFHLENBQUMsa0JBQWtCO1FBQzVDLFlBQVksRUFBRSxHQUFHLENBQUMsVUFBVTtRQUM1QixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU07UUFDcEIsWUFBWSxFQUFFLEdBQUcsQ0FBQyxVQUFVO1FBQzVCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixVQUFVLEVBQUUscUNBQXFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztRQUMvRCxZQUFZLEVBQUUsR0FBRyxDQUFDLFVBQVU7UUFDNUIsZUFBZSxFQUFFLDBDQUEwQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUM7S0FDL0UsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBMkdEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHFDQUFxQyxDQUFDLEdBQStDO0lBQ25HLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLHlDQUF5QyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDM0QsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLFlBQVksRUFBRSwrQ0FBK0MsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQzdFLHFCQUFxQixFQUFFLEdBQUcsQ0FBQyxtQkFBbUI7UUFDOUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzlKLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztRQUMxQixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsZ0JBQWdCLEVBQUUsR0FBRyxDQUFDLGNBQWM7UUFDcEMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLEtBQUssRUFBRSx3Q0FBd0MsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO1FBQ3hELFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztLQUN2QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCx3Q0FBd0M7QUFFeEM7Ozs7Ozs7OztHQVNHO0FBQ0gsSUFBWSxnQ0FPWDtBQVBELFdBQVksZ0NBQWdDO0lBQzFDLFdBQVc7SUFDWCxpREFBYSxDQUFBO0lBQ2IsV0FBVztJQUNYLGlEQUFhLENBQUE7SUFDYixVQUFVO0lBQ1YsK0NBQVcsQ0FBQTtBQUNiLENBQUMsRUFQVyxnQ0FBZ0MsZ0RBQWhDLGdDQUFnQyxRQU8zQztBQW9CRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwwQ0FBMEMsQ0FBQyxHQUFvRDtJQUM3RyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFlBQVksRUFBRSxHQUFHLENBQUMsVUFBVTtRQUM1QixlQUFlLEVBQUUsR0FBRyxDQUFDLGFBQWE7S0FDbkMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBb0ZEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHlDQUF5QyxDQUFDLEdBQW1EO0lBQzNHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsU0FBUyxFQUFFLGdEQUFnRCxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7UUFDeEUsTUFBTSxFQUFFLDZDQUE2QyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDL0QsS0FBSyxFQUFFLDRDQUE0QyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7UUFDNUQsS0FBSyxFQUFFLDRDQUE0QyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7UUFDNUQsWUFBWSxFQUFFLG1EQUFtRCxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFDakYsTUFBTSxFQUFFLDZDQUE2QyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDL0QsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1FBQzFCLGdCQUFnQixFQUFFLHVEQUF1RCxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7UUFDN0YsVUFBVSxFQUFFLGlEQUFpRCxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7S0FDNUUsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBd0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLCtDQUErQyxDQUFDLEdBQXlEO0lBQ3ZILElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztRQUMxQixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBaUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHdDQUF3QyxDQUFDLEdBQWtEO0lBQ3pHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsZUFBZSxFQUFFLHFEQUFxRCxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFDekYsY0FBYyxFQUFFLG9EQUFvRCxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7S0FDdkYsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBQ0Qsd0NBQXdDO0FBRXhDOzs7OztHQUtHO0FBQ0gsSUFBWSxxQ0FLWDtBQUxELFdBQVkscUNBQXFDO0lBQy9DLFNBQVM7SUFDVCxrREFBUyxDQUFBO0lBQ1QsU0FBUztJQUNULGtEQUFTLENBQUE7QUFDWCxDQUFDLEVBTFcscUNBQXFDLHFEQUFyQyxxQ0FBcUMsUUFLaEQ7QUErQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsZ0RBQWdELENBQUMsR0FBMEQ7SUFDekgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLFNBQVMsRUFBRSx1REFBdUQsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDO1FBQy9FLFdBQVcsRUFBRSx5REFBeUQsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO0tBQ3RGLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTRCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw2Q0FBNkMsQ0FBQyxHQUF1RDtJQUNuSCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFlBQVksRUFBRSx1REFBdUQsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQ3JGLFdBQVcsRUFBRSxzREFBc0QsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO0tBQ25GLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW9FRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw0Q0FBNEMsQ0FBQyxHQUFzRDtJQUNqSCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFlBQVksRUFBRSxHQUFHLENBQUMsVUFBVTtRQUM1QixLQUFLLEVBQUUsK0NBQStDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztRQUMvRCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUscURBQXFELENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUNqRixxQkFBcUIsRUFBRSxHQUFHLENBQUMsbUJBQW1CO1FBQzlDLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUE0Q0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNENBQTRDLENBQUMsR0FBc0Q7SUFDakgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYiwrQkFBK0IsRUFBRSx5RUFBeUUsQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUM7UUFDN0ksTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUscURBQXFELENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztLQUNsRixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFnREQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsbURBQW1ELENBQUMsR0FBNkQ7SUFDL0gsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7UUFDMUIsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSw0REFBNEQsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQ3hGLG1CQUFtQixFQUFFLG9FQUFvRSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQztLQUNqSCxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFxQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNkNBQTZDLENBQUMsR0FBdUQ7SUFDbkgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLHNEQUFzRCxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7UUFDbEYsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO0tBQ3pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWtDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix1REFBdUQsQ0FBQyxHQUFpRTtJQUN2SSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBb0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGlEQUFpRCxDQUFDLEdBQTJEO0lBQzNILElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSwwREFBMEQsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQ3RGLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtLQUN6QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCx3Q0FBd0M7QUFFeEM7Ozs7R0FJRztBQUNILElBQVksNENBS1g7QUFMRCxXQUFZLDRDQUE0QztJQUN0RCxhQUFhO0lBQ2IsaUVBQWlCLENBQUE7SUFDakIsZ0JBQWdCO0lBQ2hCLHdFQUF3QixDQUFBO0FBQzFCLENBQUMsRUFMVyw0Q0FBNEMsNERBQTVDLDRDQUE0QyxRQUt2RDtBQW1DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixxREFBcUQsQ0FBQyxHQUErRDtJQUNuSSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBb0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLG9EQUFvRCxDQUFDLEdBQThEO0lBQ2pJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFxQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsdURBQXVELENBQUMsR0FBaUU7SUFDdkksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXFDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQix5REFBeUQsQ0FBQyxHQUFtRTtJQUMzSSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHVEQUF1RCxDQUFDLEdBQWlFO0lBQ3ZJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isc0RBQXNELENBQUMsR0FBZ0U7SUFDckksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWtCRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiwrQ0FBK0MsQ0FBQyxHQUF5RDtJQUN2SCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLG1CQUFtQixFQUFFLGdFQUFnRSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQztLQUM3RyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IscURBQXFELENBQUMsR0FBK0Q7SUFDbkksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixzQkFBc0IsRUFBRSx5RUFBeUUsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUM7UUFDM0gsMEJBQTBCLEVBQUUsNkVBQTZFLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDO1FBQ3ZJLHVCQUF1QixFQUFFLDBFQUEwRSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQztLQUMvSCxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUEwQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IseUVBQXlFLENBQUMsR0FBbUY7SUFDM0ssSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDdkMsbUJBQW1CLEVBQUUsR0FBRyxDQUFDLGlCQUFpQjtRQUMxQyxtQkFBbUIsRUFBRSwwRkFBMEYsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7S0FDdkksQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUNEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHFEQUFxRCxDQUFDLEdBQStEO0lBQ25JLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFxQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNERBQTRELENBQUMsR0FBc0U7SUFDakosSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXNDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixvRUFBb0UsQ0FBQyxHQUE4RTtJQUNqSyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN2QyxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW9DRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQixzREFBc0QsQ0FBQyxHQUFnRTtJQUNySSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBb0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDBEQUEwRCxDQUFDLEdBQW9FO0lBQzdJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsZ0VBQWdFLENBQUMsR0FBMEU7SUFDekosSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDdkMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IseUVBQXlFLENBQUMsR0FBbUY7SUFDM0ssSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWtDRDs7R0FFRztBQUNILHlDQUF5QztBQUN6QyxTQUFnQiw2RUFBNkUsQ0FBQyxHQUF1RjtJQUNuTCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVM7S0FDM0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBb0NEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLDBFQUEwRSxDQUFDLEdBQW9GO0lBQzdLLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQ0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsMEZBQTBGLENBQUMsR0FBb0c7SUFDN00sSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixXQUFXLEVBQUUsR0FBRyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDdkMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxHQUFHLENBQUMsU0FBUztLQUMzQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCx3Q0FBd0M7QUFHeEM7Ozs7Ozs7R0FPRztBQUNILE1BQWEsT0FBUSxTQUFRLGlCQUFTO0lBU3BDOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBc0IsRUFBRTtRQUM3QyxPQUFPO1lBQ0wsR0FBRyxPQUFPLENBQUMsR0FBRztZQUNkLEdBQUcsbUJBQW1CLENBQUMsS0FBSyxDQUFDO1NBQzlCLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxZQUFtQixLQUFnQixFQUFFLEVBQVUsRUFBRSxRQUFzQixFQUFFO1FBQ3ZFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFO1lBQ2YsR0FBRyxPQUFPLENBQUMsR0FBRztZQUNkLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNJLE1BQU07UUFDWCxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFaEMsT0FBTztZQUNMLEdBQUcsT0FBTyxDQUFDLEdBQUc7WUFDZCxHQUFHLG1CQUFtQixDQUFDLFFBQVEsQ0FBQztTQUNqQyxDQUFDO0lBQ0osQ0FBQzs7QUE5Q0gsMEJBK0NDOzs7QUE5Q0M7O0dBRUc7QUFDb0IsV0FBRyxHQUFxQjtJQUM3QyxVQUFVLEVBQUUseUNBQXlDO0lBQ3JELElBQUksRUFBRSxTQUFTO0NBQ2hCLENBQUE7QUFpRUg7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsbUJBQW1CLENBQUMsR0FBNkI7SUFDL0QsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsTUFBTSxFQUFFLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7S0FDckMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBOEVEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGtCQUFrQixDQUFDLEdBQTRCO0lBQzdELElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixZQUFZLEVBQUUsNEJBQTRCLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUMxRCxTQUFTLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDOUosUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLFFBQVEsRUFBRSx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO1FBQzlDLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzlELFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztRQUN0QixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7S0FDZixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF1Q0Q7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0IsNEJBQTRCLENBQUMsR0FBc0M7SUFDakYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1FBQzFCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQkQ7O0dBRUc7QUFDSCx5Q0FBeUM7QUFDekMsU0FBZ0Isd0JBQXdCLENBQUMsR0FBa0M7SUFDekUsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7S0FDekIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBdUJEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLHlCQUF5QixDQUFDLEdBQW1DO0lBQzNFLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLFdBQVcsRUFBRSxrQ0FBa0MsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO0tBQy9ELENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELHdDQUF3QztBQUV4Qzs7OztHQUlHO0FBQ0gsSUFBWSx5QkFLWDtBQUxELFdBQVkseUJBQXlCO0lBQ25DLGFBQWE7SUFDYiw4Q0FBaUIsQ0FBQTtJQUNqQixnQkFBZ0I7SUFDaEIscURBQXdCLENBQUE7QUFDMUIsQ0FBQyxFQUxXLHlCQUF5Qix5Q0FBekIseUJBQXlCLFFBS3BDO0FBd0JEOztHQUVHO0FBQ0gseUNBQXlDO0FBQ3pDLFNBQWdCLGtDQUFrQyxDQUFDLEdBQTRDO0lBQzdGLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGdlbmVyYXRlZCBieSBjZGs4c1xuaW1wb3J0IHsgQXBpT2JqZWN0LCBBcGlPYmplY3RNZXRhZGF0YSwgR3JvdXBWZXJzaW9uS2luZCB9IGZyb20gJ2NkazhzJztcbmltcG9ydCB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuXG5cbi8qKlxuICogQUNSQWNjZXNzVG9rZW4gcmV0dXJucyBhbiBBenVyZSBDb250YWluZXIgUmVnaXN0cnkgdG9rZW5cbnRoYXQgY2FuIGJlIHVzZWQgZm9yIHB1c2hpbmcvcHVsbGluZyBpbWFnZXMuXG5Ob3RlOiBieSBkZWZhdWx0IGl0IHdpbGwgcmV0dXJuIGFuIEFDUiBSZWZyZXNoIFRva2VuIHdpdGggZnVsbCBhY2Nlc3NcbihkZXBlbmRpbmcgb24gdGhlIGlkZW50aXR5KS5cblRoaXMgY2FuIGJlIHNjb3BlZCBkb3duIHRvIHRoZSByZXBvc2l0b3J5IGxldmVsIHVzaW5nIC5zcGVjLnNjb3BlLlxuSW4gY2FzZSBzY29wZSBpcyBkZWZpbmVkIGl0IHdpbGwgcmV0dXJuIGFuIEFDUiBBY2Nlc3MgVG9rZW4uXG5cblNlZSBkb2NzOiBodHRwczovL2dpdGh1Yi5jb20vQXp1cmUvYWNyL2Jsb2IvbWFpbi9kb2NzL0FBRC1PQXV0aC5tZFxuICpcbiAqIEBzY2hlbWEgQUNSQWNjZXNzVG9rZW5cbiAqL1xuZXhwb3J0IGNsYXNzIEFjckFjY2Vzc1Rva2VuIGV4dGVuZHMgQXBpT2JqZWN0IHtcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGFwaVZlcnNpb24gYW5kIGtpbmQgZm9yIFwiQUNSQWNjZXNzVG9rZW5cIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2dlbmVyYXRvcnMuZXh0ZXJuYWwtc2VjcmV0cy5pby92MWFscGhhMScsXG4gICAga2luZDogJ0FDUkFjY2Vzc1Rva2VuJyxcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIGEgS3ViZXJuZXRlcyBtYW5pZmVzdCBmb3IgXCJBQ1JBY2Nlc3NUb2tlblwiLlxuICAgKlxuICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGlubGluZSByZXNvdXJjZSBtYW5pZmVzdHMgaW5zaWRlIG90aGVyIG9iamVjdHMgKGUuZy4gYXMgdGVtcGxhdGVzKS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1hbmlmZXN0KHByb3BzOiBBY3JBY2Nlc3NUb2tlblByb3BzID0ge30pOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5BY3JBY2Nlc3NUb2tlbi5HVkssXG4gICAgICAuLi50b0pzb25fQWNyQWNjZXNzVG9rZW5Qcm9wcyhwcm9wcyksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgXCJBQ1JBY2Nlc3NUb2tlblwiIEFQSSBvYmplY3RcbiAgICogQHBhcmFtIHNjb3BlIHRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBvYmplY3RcbiAgICogQHBhcmFtIGlkIGEgc2NvcGUtbG9jYWwgbmFtZSBmb3IgdGhlIG9iamVjdFxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogQWNyQWNjZXNzVG9rZW5Qcm9wcyA9IHt9KSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICAuLi5BY3JBY2Nlc3NUb2tlbi5HVkssXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBvYmplY3QgdG8gS3ViZXJuZXRlcyBKU09OLlxuICAgKi9cbiAgcHVibGljIHRvSnNvbigpOiBhbnkge1xuICAgIGNvbnN0IHJlc29sdmVkID0gc3VwZXIudG9Kc29uKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uQWNyQWNjZXNzVG9rZW4uR1ZLLFxuICAgICAgLi4udG9Kc29uX0FjckFjY2Vzc1Rva2VuUHJvcHMocmVzb2x2ZWQpLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBBQ1JBY2Nlc3NUb2tlbiByZXR1cm5zIGFuIEF6dXJlIENvbnRhaW5lciBSZWdpc3RyeSB0b2tlblxuICogdGhhdCBjYW4gYmUgdXNlZCBmb3IgcHVzaGluZy9wdWxsaW5nIGltYWdlcy5cbiAqIE5vdGU6IGJ5IGRlZmF1bHQgaXQgd2lsbCByZXR1cm4gYW4gQUNSIFJlZnJlc2ggVG9rZW4gd2l0aCBmdWxsIGFjY2Vzc1xuICogKGRlcGVuZGluZyBvbiB0aGUgaWRlbnRpdHkpLlxuICogVGhpcyBjYW4gYmUgc2NvcGVkIGRvd24gdG8gdGhlIHJlcG9zaXRvcnkgbGV2ZWwgdXNpbmcgLnNwZWMuc2NvcGUuXG4gKiBJbiBjYXNlIHNjb3BlIGlzIGRlZmluZWQgaXQgd2lsbCByZXR1cm4gYW4gQUNSIEFjY2VzcyBUb2tlbi5cbiAqXG4gKiBTZWUgZG9jczogaHR0cHM6Ly9naXRodWIuY29tL0F6dXJlL2Fjci9ibG9iL21haW4vZG9jcy9BQUQtT0F1dGgubWRcbiAqXG4gKiBAc2NoZW1hIEFDUkFjY2Vzc1Rva2VuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQWNyQWNjZXNzVG9rZW5Qcm9wcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIEFDUkFjY2Vzc1Rva2VuI21ldGFkYXRhXG4gICAqL1xuICByZWFkb25seSBtZXRhZGF0YT86IEFwaU9iamVjdE1ldGFkYXRhO1xuXG4gIC8qKlxuICAgKiBBQ1JBY2Nlc3NUb2tlblNwZWMgZGVmaW5lcyBob3cgdG8gZ2VuZXJhdGUgdGhlIGFjY2VzcyB0b2tlblxuICAgKiBlLmcuIGhvdyB0byBhdXRoZW50aWNhdGUgYW5kIHdoaWNoIHJlZ2lzdHJ5IHRvIHVzZS5cbiAgICogc2VlOiBodHRwczovL2dpdGh1Yi5jb20vQXp1cmUvYWNyL2Jsb2IvbWFpbi9kb2NzL0FBRC1PQXV0aC5tZCNvdmVydmlld1xuICAgKlxuICAgKiBAc2NoZW1hIEFDUkFjY2Vzc1Rva2VuI3NwZWNcbiAgICovXG4gIHJlYWRvbmx5IHNwZWM/OiBBY3JBY2Nlc3NUb2tlblNwZWM7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQWNyQWNjZXNzVG9rZW5Qcm9wcycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQWNyQWNjZXNzVG9rZW5Qcm9wcyhvYmo6IEFjckFjY2Vzc1Rva2VuUHJvcHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtZXRhZGF0YSc6IG9iai5tZXRhZGF0YSxcbiAgICAnc3BlYyc6IHRvSnNvbl9BY3JBY2Nlc3NUb2tlblNwZWMob2JqLnNwZWMpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEFDUkFjY2Vzc1Rva2VuU3BlYyBkZWZpbmVzIGhvdyB0byBnZW5lcmF0ZSB0aGUgYWNjZXNzIHRva2VuXG4gKiBlLmcuIGhvdyB0byBhdXRoZW50aWNhdGUgYW5kIHdoaWNoIHJlZ2lzdHJ5IHRvIHVzZS5cbiAqIHNlZTogaHR0cHM6Ly9naXRodWIuY29tL0F6dXJlL2Fjci9ibG9iL21haW4vZG9jcy9BQUQtT0F1dGgubWQjb3ZlcnZpZXdcbiAqXG4gKiBAc2NoZW1hIEFjckFjY2Vzc1Rva2VuU3BlY1xuICovXG5leHBvcnQgaW50ZXJmYWNlIEFjckFjY2Vzc1Rva2VuU3BlYyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIEFjckFjY2Vzc1Rva2VuU3BlYyNhdXRoXG4gICAqL1xuICByZWFkb25seSBhdXRoOiBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoO1xuXG4gIC8qKlxuICAgKiBFbnZpcm9ubWVudFR5cGUgc3BlY2lmaWVzIHRoZSBBenVyZSBjbG91ZCBlbnZpcm9ubWVudCBlbmRwb2ludHMgdG8gdXNlIGZvclxuICAgKiBjb25uZWN0aW5nIGFuZCBhdXRoZW50aWNhdGluZyB3aXRoIEF6dXJlLiBCeSBkZWZhdWx0IGl0IHBvaW50cyB0byB0aGUgcHVibGljIGNsb3VkIEFBRCBlbmRwb2ludC5cbiAgICogVGhlIGZvbGxvd2luZyBlbmRwb2ludHMgYXJlIGF2YWlsYWJsZSwgYWxzbyBzZWUgaGVyZTogaHR0cHM6Ly9naXRodWIuY29tL0F6dXJlL2dvLWF1dG9yZXN0L2Jsb2IvbWFpbi9hdXRvcmVzdC9henVyZS9lbnZpcm9ubWVudHMuZ28jTDE1MlxuICAgKiBQdWJsaWNDbG91ZCwgVVNHb3Zlcm5tZW50Q2xvdWQsIENoaW5hQ2xvdWQsIEdlcm1hbkNsb3VkXG4gICAqXG4gICAqIEBzY2hlbWEgQWNyQWNjZXNzVG9rZW5TcGVjI2Vudmlyb25tZW50VHlwZVxuICAgKi9cbiAgcmVhZG9ubHkgZW52aXJvbm1lbnRUeXBlPzogQWNyQWNjZXNzVG9rZW5TcGVjRW52aXJvbm1lbnRUeXBlO1xuXG4gIC8qKlxuICAgKiB0aGUgZG9tYWluIG5hbWUgb2YgdGhlIEFDUiByZWdpc3RyeVxuICAgKiBlLmcuIGZvb2JhcmV4YW1wbGUuYXp1cmVjci5pb1xuICAgKlxuICAgKiBAc2NoZW1hIEFjckFjY2Vzc1Rva2VuU3BlYyNyZWdpc3RyeVxuICAgKi9cbiAgcmVhZG9ubHkgcmVnaXN0cnk6IHN0cmluZztcblxuICAvKipcbiAgICogRGVmaW5lIHRoZSBzY29wZSBmb3IgdGhlIGFjY2VzcyB0b2tlbiwgZS5nLiBwdWxsL3B1c2ggYWNjZXNzIGZvciBhIHJlcG9zaXRvcnkuXG4gICAqIGlmIG5vdCBwcm92aWRlZCBpdCB3aWxsIHJldHVybiBhIHJlZnJlc2ggdG9rZW4gdGhhdCBoYXMgZnVsbCBzY29wZS5cbiAgICogTm90ZTogeW91IG5lZWQgdG8gcGluIGl0IGRvd24gdG8gdGhlIHJlcG9zaXRvcnkgbGV2ZWwsIHRoZXJlIGlzIG5vIHdpbGRjYXJkIGF2YWlsYWJsZS5cbiAgICpcbiAgICogZXhhbXBsZXM6XG4gICAqIHJlcG9zaXRvcnk6bXktcmVwb3NpdG9yeTpwdWxsLHB1c2hcbiAgICogcmVwb3NpdG9yeTpteS1yZXBvc2l0b3J5OnB1bGxcbiAgICpcbiAgICogc2VlIGRvY3MgZm9yIGRldGFpbHM6IGh0dHBzOi8vZG9jcy5kb2NrZXIuY29tL3JlZ2lzdHJ5L3NwZWMvYXV0aC9zY29wZS9cbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWMjc2NvcGVcbiAgICovXG4gIHJlYWRvbmx5IHNjb3BlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUZW5hbnRJRCBjb25maWd1cmVzIHRoZSBBenVyZSBUZW5hbnQgdG8gc2VuZCByZXF1ZXN0cyB0by4gUmVxdWlyZWQgZm9yIFNlcnZpY2VQcmluY2lwYWwgYXV0aCB0eXBlLlxuICAgKlxuICAgKiBAc2NoZW1hIEFjckFjY2Vzc1Rva2VuU3BlYyN0ZW5hbnRJZFxuICAgKi9cbiAgcmVhZG9ubHkgdGVuYW50SWQ/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQWNyQWNjZXNzVG9rZW5TcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9BY3JBY2Nlc3NUb2tlblNwZWMob2JqOiBBY3JBY2Nlc3NUb2tlblNwZWMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhdXRoJzogdG9Kc29uX0FjckFjY2Vzc1Rva2VuU3BlY0F1dGgob2JqLmF1dGgpLFxuICAgICdlbnZpcm9ubWVudFR5cGUnOiBvYmouZW52aXJvbm1lbnRUeXBlLFxuICAgICdyZWdpc3RyeSc6IG9iai5yZWdpc3RyeSxcbiAgICAnc2NvcGUnOiBvYmouc2NvcGUsXG4gICAgJ3RlbmFudElkJzogb2JqLnRlbmFudElkLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFjckFjY2Vzc1Rva2VuU3BlY0F1dGgge1xuICAvKipcbiAgICogTWFuYWdlZElkZW50aXR5IHVzZXMgQXp1cmUgTWFuYWdlZCBJZGVudGl0eSB0byBhdXRoZW50aWNhdGUgd2l0aCBBenVyZS5cbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoI21hbmFnZWRJZGVudGl0eVxuICAgKi9cbiAgcmVhZG9ubHkgbWFuYWdlZElkZW50aXR5PzogQWNyQWNjZXNzVG9rZW5TcGVjQXV0aE1hbmFnZWRJZGVudGl0eTtcblxuICAvKipcbiAgICogU2VydmljZVByaW5jaXBhbCB1c2VzIEF6dXJlIFNlcnZpY2UgUHJpbmNpcGFsIGNyZWRlbnRpYWxzIHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEF6dXJlLlxuICAgKlxuICAgKiBAc2NoZW1hIEFjckFjY2Vzc1Rva2VuU3BlY0F1dGgjc2VydmljZVByaW5jaXBhbFxuICAgKi9cbiAgcmVhZG9ubHkgc2VydmljZVByaW5jaXBhbD86IEFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsO1xuXG4gIC8qKlxuICAgKiBXb3JrbG9hZElkZW50aXR5IHVzZXMgQXp1cmUgV29ya2xvYWQgSWRlbnRpdHkgdG8gYXV0aGVudGljYXRlIHdpdGggQXp1cmUuXG4gICAqXG4gICAqIEBzY2hlbWEgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aCN3b3JrbG9hZElkZW50aXR5XG4gICAqL1xuICByZWFkb25seSB3b3JrbG9hZElkZW50aXR5PzogQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHk7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQWNyQWNjZXNzVG9rZW5TcGVjQXV0aCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQWNyQWNjZXNzVG9rZW5TcGVjQXV0aChvYmo6IEFjckFjY2Vzc1Rva2VuU3BlY0F1dGggfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtYW5hZ2VkSWRlbnRpdHknOiB0b0pzb25fQWNyQWNjZXNzVG9rZW5TcGVjQXV0aE1hbmFnZWRJZGVudGl0eShvYmoubWFuYWdlZElkZW50aXR5KSxcbiAgICAnc2VydmljZVByaW5jaXBhbCc6IHRvSnNvbl9BY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbChvYmouc2VydmljZVByaW5jaXBhbCksXG4gICAgJ3dvcmtsb2FkSWRlbnRpdHknOiB0b0pzb25fQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkob2JqLndvcmtsb2FkSWRlbnRpdHkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEVudmlyb25tZW50VHlwZSBzcGVjaWZpZXMgdGhlIEF6dXJlIGNsb3VkIGVudmlyb25tZW50IGVuZHBvaW50cyB0byB1c2UgZm9yXG4gKiBjb25uZWN0aW5nIGFuZCBhdXRoZW50aWNhdGluZyB3aXRoIEF6dXJlLiBCeSBkZWZhdWx0IGl0IHBvaW50cyB0byB0aGUgcHVibGljIGNsb3VkIEFBRCBlbmRwb2ludC5cbiAqIFRoZSBmb2xsb3dpbmcgZW5kcG9pbnRzIGFyZSBhdmFpbGFibGUsIGFsc28gc2VlIGhlcmU6IGh0dHBzOi8vZ2l0aHViLmNvbS9BenVyZS9nby1hdXRvcmVzdC9ibG9iL21haW4vYXV0b3Jlc3QvYXp1cmUvZW52aXJvbm1lbnRzLmdvI0wxNTJcbiAqIFB1YmxpY0Nsb3VkLCBVU0dvdmVybm1lbnRDbG91ZCwgQ2hpbmFDbG91ZCwgR2VybWFuQ2xvdWRcbiAqXG4gKiBAc2NoZW1hIEFjckFjY2Vzc1Rva2VuU3BlY0Vudmlyb25tZW50VHlwZVxuICovXG5leHBvcnQgZW51bSBBY3JBY2Nlc3NUb2tlblNwZWNFbnZpcm9ubWVudFR5cGUge1xuICAvKiogUHVibGljQ2xvdWQgKi9cbiAgUFVCTElDX0NMT1VEID0gXCJQdWJsaWNDbG91ZFwiLFxuICAvKiogVVNHb3Zlcm5tZW50Q2xvdWQgKi9cbiAgVVNfR09WRVJOTUVOVF9DTE9VRCA9IFwiVVNHb3Zlcm5tZW50Q2xvdWRcIixcbiAgLyoqIENoaW5hQ2xvdWQgKi9cbiAgQ0hJTkFfQ0xPVUQgPSBcIkNoaW5hQ2xvdWRcIixcbiAgLyoqIEdlcm1hbkNsb3VkICovXG4gIEdFUk1BTl9DTE9VRCA9IFwiR2VybWFuQ2xvdWRcIixcbn1cblxuLyoqXG4gKiBNYW5hZ2VkSWRlbnRpdHkgdXNlcyBBenVyZSBNYW5hZ2VkIElkZW50aXR5IHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEF6dXJlLlxuICpcbiAqIEBzY2hlbWEgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aE1hbmFnZWRJZGVudGl0eVxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFjckFjY2Vzc1Rva2VuU3BlY0F1dGhNYW5hZ2VkSWRlbnRpdHkge1xuICAvKipcbiAgICogSWYgbXVsdGlwbGUgTWFuYWdlZCBJZGVudGl0eSBpcyBhc3NpZ25lZCB0byB0aGUgcG9kLCB5b3UgY2FuIHNlbGVjdCB0aGUgb25lIHRvIGJlIHVzZWRcbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoTWFuYWdlZElkZW50aXR5I2lkZW50aXR5SWRcbiAgICovXG4gIHJlYWRvbmx5IGlkZW50aXR5SWQ/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQWNyQWNjZXNzVG9rZW5TcGVjQXV0aE1hbmFnZWRJZGVudGl0eScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQWNyQWNjZXNzVG9rZW5TcGVjQXV0aE1hbmFnZWRJZGVudGl0eShvYmo6IEFjckFjY2Vzc1Rva2VuU3BlY0F1dGhNYW5hZ2VkSWRlbnRpdHkgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdpZGVudGl0eUlkJzogb2JqLmlkZW50aXR5SWQsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VydmljZVByaW5jaXBhbCB1c2VzIEF6dXJlIFNlcnZpY2UgUHJpbmNpcGFsIGNyZWRlbnRpYWxzIHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEF6dXJlLlxuICpcbiAqIEBzY2hlbWEgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbCB7XG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIHVzZWQgdG8gYXV0aGVudGljYXRlIHdpdGggQXp1cmUgdXNpbmcgc3RhdGljXG4gICAqIGNyZWRlbnRpYWxzIHN0b3JlZCBpbiBhIEtpbmQ9U2VjcmV0LlxuICAgKlxuICAgKiBAc2NoZW1hIEFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsI3NlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0UmVmOiBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWwob2JqOiBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3NlY3JldFJlZic6IHRvSnNvbl9BY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZihvYmouc2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBXb3JrbG9hZElkZW50aXR5IHVzZXMgQXp1cmUgV29ya2xvYWQgSWRlbnRpdHkgdG8gYXV0aGVudGljYXRlIHdpdGggQXp1cmUuXG4gKlxuICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5IHtcbiAgLyoqXG4gICAqIFNlcnZpY2VBY2NvdW50UmVmIHNwZWNpZmllZCB0aGUgc2VydmljZSBhY2NvdW50XG4gICAqIHRoYXQgc2hvdWxkIGJlIHVzZWQgd2hlbiBhdXRoZW50aWNhdGluZyB3aXRoIFdvcmtsb2FkSWRlbnRpdHkuXG4gICAqXG4gICAqIEBzY2hlbWEgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkjc2VydmljZUFjY291bnRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlcnZpY2VBY2NvdW50UmVmPzogQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkob2JqOiBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eSB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3NlcnZpY2VBY2NvdW50UmVmJzogdG9Kc29uX0FjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5U2VydmljZUFjY291bnRSZWYob2JqLnNlcnZpY2VBY2NvdW50UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBDb25maWd1cmF0aW9uIHVzZWQgdG8gYXV0aGVudGljYXRlIHdpdGggQXp1cmUgdXNpbmcgc3RhdGljXG4gKiBjcmVkZW50aWFscyBzdG9yZWQgaW4gYSBLaW5kPVNlY3JldC5cbiAqXG4gKiBAc2NoZW1hIEFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWYge1xuICAvKipcbiAgICogVGhlIEF6dXJlIGNsaWVudElkIG9mIHRoZSBzZXJ2aWNlIHByaW5jaXBsZSB1c2VkIGZvciBhdXRoZW50aWNhdGlvbi5cbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZiNjbGllbnRJZFxuICAgKi9cbiAgcmVhZG9ubHkgY2xpZW50SWQ/OiBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudElkO1xuXG4gIC8qKlxuICAgKiBUaGUgQXp1cmUgQ2xpZW50U2VjcmV0IG9mIHRoZSBzZXJ2aWNlIHByaW5jaXBsZSB1c2VkIGZvciBhdXRoZW50aWNhdGlvbi5cbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZiNjbGllbnRTZWNyZXRcbiAgICovXG4gIHJlYWRvbmx5IGNsaWVudFNlY3JldD86IEFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50U2VjcmV0O1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0FjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9BY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZihvYmo6IEFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnY2xpZW50SWQnOiB0b0pzb25fQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRJZChvYmouY2xpZW50SWQpLFxuICAgICdjbGllbnRTZWNyZXQnOiB0b0pzb25fQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRTZWNyZXQob2JqLmNsaWVudFNlY3JldCksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VydmljZUFjY291bnRSZWYgc3BlY2lmaWVkIHRoZSBzZXJ2aWNlIGFjY291bnRcbiAqIHRoYXQgc2hvdWxkIGJlIHVzZWQgd2hlbiBhdXRoZW50aWNhdGluZyB3aXRoIFdvcmtsb2FkSWRlbnRpdHkuXG4gKlxuICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZiB7XG4gIC8qKlxuICAgKiBBdWRpZW5jZSBzcGVjaWZpZXMgdGhlIGBhdWRgIGNsYWltIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHRva2VuXG4gICAqIElmIHRoZSBzZXJ2aWNlIGFjY291bnQgdXNlcyBhIHdlbGwta25vd24gYW5ub3RhdGlvbiBmb3IgZS5nLiBJUlNBIG9yIEdDUCBXb3JrbG9hZCBJZGVudGl0eVxuICAgKiB0aGVuIHRoaXMgYXVkaWVuY2VzIHdpbGwgYmUgYXBwZW5kZWQgdG8gdGhlIGxpc3RcbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmI2F1ZGllbmNlc1xuICAgKi9cbiAgcmVhZG9ubHkgYXVkaWVuY2VzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZXNwYWNlIG9mIHRoZSByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0FjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5U2VydmljZUFjY291bnRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0FjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5U2VydmljZUFjY291bnRSZWYob2JqOiBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXVkaWVuY2VzJzogb2JqLmF1ZGllbmNlcz8ubWFwKHkgPT4geSksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgQXp1cmUgY2xpZW50SWQgb2YgdGhlIHNlcnZpY2UgcHJpbmNpcGxlIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uLlxuICpcbiAqIEBzY2hlbWEgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRJZFxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50SWQge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRJZCNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudElkI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudElkI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0FjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50SWQnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0FjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50SWQob2JqOiBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudElkIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBBenVyZSBDbGllbnRTZWNyZXQgb2YgdGhlIHNlcnZpY2UgcHJpbmNpcGxlIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uLlxuICpcbiAqIEBzY2hlbWEgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRTZWNyZXRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudFNlY3JldCB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudFNlY3JldCNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudFNlY3JldCNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRTZWNyZXQjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRTZWNyZXQnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0FjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50U2VjcmV0KG9iajogQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRTZWNyZXQgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cblxuLyoqXG4gKiBDbHVzdGVyR2VuZXJhdG9yIHJlcHJlc2VudHMgYSBjbHVzdGVyLXdpZGUgZ2VuZXJhdG9yIHdoaWNoIGNhbiBiZSByZWZlcmVuY2VkIGFzIHBhcnQgb2YgYGdlbmVyYXRvclJlZmAgZmllbGRzLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclxuICovXG5leHBvcnQgY2xhc3MgQ2x1c3RlckdlbmVyYXRvciBleHRlbmRzIEFwaU9iamVjdCB7XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBhcGlWZXJzaW9uIGFuZCBraW5kIGZvciBcIkNsdXN0ZXJHZW5lcmF0b3JcIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2dlbmVyYXRvcnMuZXh0ZXJuYWwtc2VjcmV0cy5pby92MWFscGhhMScsXG4gICAga2luZDogJ0NsdXN0ZXJHZW5lcmF0b3InLFxuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgYSBLdWJlcm5ldGVzIG1hbmlmZXN0IGZvciBcIkNsdXN0ZXJHZW5lcmF0b3JcIi5cbiAgICpcbiAgICogVGhpcyBjYW4gYmUgdXNlZCB0byBpbmxpbmUgcmVzb3VyY2UgbWFuaWZlc3RzIGluc2lkZSBvdGhlciBvYmplY3RzIChlLmcuIGFzIHRlbXBsYXRlcykuXG4gICAqXG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtYW5pZmVzdChwcm9wczogQ2x1c3RlckdlbmVyYXRvclByb3BzID0ge30pOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5DbHVzdGVyR2VuZXJhdG9yLkdWSyxcbiAgICAgIC4uLnRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yUHJvcHMocHJvcHMpLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyBhIFwiQ2x1c3RlckdlbmVyYXRvclwiIEFQSSBvYmplY3RcbiAgICogQHBhcmFtIHNjb3BlIHRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBvYmplY3RcbiAgICogQHBhcmFtIGlkIGEgc2NvcGUtbG9jYWwgbmFtZSBmb3IgdGhlIG9iamVjdFxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogQ2x1c3RlckdlbmVyYXRvclByb3BzID0ge30pIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIC4uLkNsdXN0ZXJHZW5lcmF0b3IuR1ZLLFxuICAgICAgLi4ucHJvcHMsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyB0aGUgb2JqZWN0IHRvIEt1YmVybmV0ZXMgSlNPTi5cbiAgICovXG4gIHB1YmxpYyB0b0pzb24oKTogYW55IHtcbiAgICBjb25zdCByZXNvbHZlZCA9IHN1cGVyLnRvSnNvbigpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLkNsdXN0ZXJHZW5lcmF0b3IuR1ZLLFxuICAgICAgLi4udG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JQcm9wcyhyZXNvbHZlZCksXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIENsdXN0ZXJHZW5lcmF0b3IgcmVwcmVzZW50cyBhIGNsdXN0ZXItd2lkZSBnZW5lcmF0b3Igd2hpY2ggY2FuIGJlIHJlZmVyZW5jZWQgYXMgcGFydCBvZiBgZ2VuZXJhdG9yUmVmYCBmaWVsZHMuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclByb3BzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvciNtZXRhZGF0YVxuICAgKi9cbiAgcmVhZG9ubHkgbWV0YWRhdGE/OiBBcGlPYmplY3RNZXRhZGF0YTtcblxuICAvKipcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yI3NwZWNcbiAgICovXG4gIHJlYWRvbmx5IHNwZWM/OiBDbHVzdGVyR2VuZXJhdG9yU3BlYztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yUHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JQcm9wcyhvYmo6IENsdXN0ZXJHZW5lcmF0b3JQcm9wcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ21ldGFkYXRhJzogb2JqLm1ldGFkYXRhLFxuICAgICdzcGVjJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjKG9iai5zcGVjKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWMge1xuICAvKipcbiAgICogR2VuZXJhdG9yIHRoZSBzcGVjIGZvciB0aGlzIGdlbmVyYXRvciwgbXVzdCBtYXRjaCB0aGUga2luZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlYyNnZW5lcmF0b3JcbiAgICovXG4gIHJlYWRvbmx5IGdlbmVyYXRvcjogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3I7XG5cbiAgLyoqXG4gICAqIEtpbmQgdGhlIGtpbmQgb2YgdGhpcyBnZW5lcmF0b3IuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWMja2luZFxuICAgKi9cbiAgcmVhZG9ubHkga2luZDogQ2x1c3RlckdlbmVyYXRvclNwZWNLaW5kO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlYyhvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZ2VuZXJhdG9yJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yKG9iai5nZW5lcmF0b3IpLFxuICAgICdraW5kJzogb2JqLmtpbmQsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogR2VuZXJhdG9yIHRoZSBzcGVjIGZvciB0aGlzIGdlbmVyYXRvciwgbXVzdCBtYXRjaCB0aGUga2luZC5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3Ige1xuICAvKipcbiAgICogQUNSQWNjZXNzVG9rZW5TcGVjIGRlZmluZXMgaG93IHRvIGdlbmVyYXRlIHRoZSBhY2Nlc3MgdG9rZW5cbiAgICogZS5nLiBob3cgdG8gYXV0aGVudGljYXRlIGFuZCB3aGljaCByZWdpc3RyeSB0byB1c2UuXG4gICAqIHNlZTogaHR0cHM6Ly9naXRodWIuY29tL0F6dXJlL2Fjci9ibG9iL21haW4vZG9jcy9BQUQtT0F1dGgubWQjb3ZlcnZpZXdcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvciNhY3JBY2Nlc3NUb2tlblNwZWNcbiAgICovXG4gIHJlYWRvbmx5IGFjckFjY2Vzc1Rva2VuU3BlYz86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yI2VjckF1dGhvcml6YXRpb25Ub2tlblNwZWNcbiAgICovXG4gIHJlYWRvbmx5IGVjckF1dGhvcml6YXRpb25Ub2tlblNwZWM/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWM7XG5cbiAgLyoqXG4gICAqIEZha2VTcGVjIGNvbnRhaW5zIHRoZSBzdGF0aWMgZGF0YS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvciNmYWtlU3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgZmFrZVNwZWM/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckZha2VTcGVjO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yI2djckFjY2Vzc1Rva2VuU3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgZ2NyQWNjZXNzVG9rZW5TcGVjPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWM7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3IjZ2l0aHViQWNjZXNzVG9rZW5TcGVjXG4gICAqL1xuICByZWFkb25seSBnaXRodWJBY2Nlc3NUb2tlblNwZWM/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlYztcblxuICAvKipcbiAgICogR3JhZmFuYVNwZWMgY29udHJvbHMgdGhlIGJlaGF2aW9yIG9mIHRoZSBncmFmYW5hIGdlbmVyYXRvci5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvciNncmFmYW5hU3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgZ3JhZmFuYVNwZWM/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjO1xuXG4gIC8qKlxuICAgKiBQYXNzd29yZFNwZWMgY29udHJvbHMgdGhlIGJlaGF2aW9yIG9mIHRoZSBwYXNzd29yZCBnZW5lcmF0b3IuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3IjcGFzc3dvcmRTcGVjXG4gICAqL1xuICByZWFkb25seSBwYXNzd29yZFNwZWM/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclBhc3N3b3JkU3BlYztcblxuICAvKipcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvciNxdWF5QWNjZXNzVG9rZW5TcGVjXG4gICAqL1xuICByZWFkb25seSBxdWF5QWNjZXNzVG9rZW5TcGVjPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JRdWF5QWNjZXNzVG9rZW5TcGVjO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yI3N0c1Nlc3Npb25Ub2tlblNwZWNcbiAgICovXG4gIHJlYWRvbmx5IHN0c1Nlc3Npb25Ub2tlblNwZWM/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWM7XG5cbiAgLyoqXG4gICAqIFVVSURTcGVjIGNvbnRyb2xzIHRoZSBiZWhhdmlvciBvZiB0aGUgdXVpZCBnZW5lcmF0b3IuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3IjdXVpZFNwZWNcbiAgICovXG4gIHJlYWRvbmx5IHV1aWRTcGVjPzogYW55O1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yI3ZhdWx0RHluYW1pY1NlY3JldFNwZWNcbiAgICovXG4gIHJlYWRvbmx5IHZhdWx0RHluYW1pY1NlY3JldFNwZWM/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWM7XG5cbiAgLyoqXG4gICAqIFdlYmhvb2tTcGVjIGNvbnRyb2xzIHRoZSBiZWhhdmlvciBvZiB0aGUgZXh0ZXJuYWwgZ2VuZXJhdG9yLiBBbnkgYm9keSBwYXJhbWV0ZXJzIHNob3VsZCBiZSBwYXNzZWQgdG8gdGhlIHNlcnZlciB0aHJvdWdoIHRoZSBwYXJhbWV0ZXJzIGZpZWxkLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yI3dlYmhvb2tTcGVjXG4gICAqL1xuICByZWFkb25seSB3ZWJob29rU3BlYz86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWM7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3InIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3IgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhY3JBY2Nlc3NUb2tlblNwZWMnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWMob2JqLmFjckFjY2Vzc1Rva2VuU3BlYyksXG4gICAgJ2VjckF1dGhvcml6YXRpb25Ub2tlblNwZWMnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjKG9iai5lY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjKSxcbiAgICAnZmFrZVNwZWMnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JGYWtlU3BlYyhvYmouZmFrZVNwZWMpLFxuICAgICdnY3JBY2Nlc3NUb2tlblNwZWMnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWMob2JqLmdjckFjY2Vzc1Rva2VuU3BlYyksXG4gICAgJ2dpdGh1YkFjY2Vzc1Rva2VuU3BlYyc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlYyhvYmouZ2l0aHViQWNjZXNzVG9rZW5TcGVjKSxcbiAgICAnZ3JhZmFuYVNwZWMnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlYyhvYmouZ3JhZmFuYVNwZWMpLFxuICAgICdwYXNzd29yZFNwZWMnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JQYXNzd29yZFNwZWMob2JqLnBhc3N3b3JkU3BlYyksXG4gICAgJ3F1YXlBY2Nlc3NUb2tlblNwZWMnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JRdWF5QWNjZXNzVG9rZW5TcGVjKG9iai5xdWF5QWNjZXNzVG9rZW5TcGVjKSxcbiAgICAnc3RzU2Vzc2lvblRva2VuU3BlYyc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWMob2JqLnN0c1Nlc3Npb25Ub2tlblNwZWMpLFxuICAgICd1dWlkU3BlYyc6IG9iai51dWlkU3BlYyxcbiAgICAndmF1bHREeW5hbWljU2VjcmV0U3BlYyc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWMob2JqLnZhdWx0RHluYW1pY1NlY3JldFNwZWMpLFxuICAgICd3ZWJob29rU3BlYyc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjKG9iai53ZWJob29rU3BlYyksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogS2luZCB0aGUga2luZCBvZiB0aGlzIGdlbmVyYXRvci5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjS2luZFxuICovXG5leHBvcnQgZW51bSBDbHVzdGVyR2VuZXJhdG9yU3BlY0tpbmQge1xuICAvKiogQUNSQWNjZXNzVG9rZW4gKi9cbiAgQUNSX0FDQ0VTU19UT0tFTiA9IFwiQUNSQWNjZXNzVG9rZW5cIixcbiAgLyoqIEVDUkF1dGhvcml6YXRpb25Ub2tlbiAqL1xuICBFQ1JfQVVUSE9SSVpBVElPTl9UT0tFTiA9IFwiRUNSQXV0aG9yaXphdGlvblRva2VuXCIsXG4gIC8qKiBGYWtlICovXG4gIEZBS0UgPSBcIkZha2VcIixcbiAgLyoqIEdDUkFjY2Vzc1Rva2VuICovXG4gIEdDUl9BQ0NFU1NfVE9LRU4gPSBcIkdDUkFjY2Vzc1Rva2VuXCIsXG4gIC8qKiBHaXRodWJBY2Nlc3NUb2tlbiAqL1xuICBHSVRIVUJfQUNDRVNTX1RPS0VOID0gXCJHaXRodWJBY2Nlc3NUb2tlblwiLFxuICAvKiogUXVheUFjY2Vzc1Rva2VuICovXG4gIFFVQVlfQUNDRVNTX1RPS0VOID0gXCJRdWF5QWNjZXNzVG9rZW5cIixcbiAgLyoqIFBhc3N3b3JkICovXG4gIFBBU1NXT1JEID0gXCJQYXNzd29yZFwiLFxuICAvKiogU1RTU2Vzc2lvblRva2VuICovXG4gIFNUU19TRVNTSU9OX1RPS0VOID0gXCJTVFNTZXNzaW9uVG9rZW5cIixcbiAgLyoqIFVVSUQgKi9cbiAgVVVJRCA9IFwiVVVJRFwiLFxuICAvKiogVmF1bHREeW5hbWljU2VjcmV0ICovXG4gIFZBVUxUX0RZTkFNSUNfU0VDUkVUID0gXCJWYXVsdER5bmFtaWNTZWNyZXRcIixcbiAgLyoqIFdlYmhvb2sgKi9cbiAgV0VCSE9PSyA9IFwiV2ViaG9va1wiLFxuICAvKiogR3JhZmFuYSAqL1xuICBHUkFGQU5BID0gXCJHcmFmYW5hXCIsXG59XG5cbi8qKlxuICogQUNSQWNjZXNzVG9rZW5TcGVjIGRlZmluZXMgaG93IHRvIGdlbmVyYXRlIHRoZSBhY2Nlc3MgdG9rZW5cbiAqIGUuZy4gaG93IHRvIGF1dGhlbnRpY2F0ZSBhbmQgd2hpY2ggcmVnaXN0cnkgdG8gdXNlLlxuICogc2VlOiBodHRwczovL2dpdGh1Yi5jb20vQXp1cmUvYWNyL2Jsb2IvbWFpbi9kb2NzL0FBRC1PQXV0aC5tZCNvdmVydmlld1xuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlYyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjI2F1dGhcbiAgICovXG4gIHJlYWRvbmx5IGF1dGg6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aDtcblxuICAvKipcbiAgICogRW52aXJvbm1lbnRUeXBlIHNwZWNpZmllcyB0aGUgQXp1cmUgY2xvdWQgZW52aXJvbm1lbnQgZW5kcG9pbnRzIHRvIHVzZSBmb3JcbiAgICogY29ubmVjdGluZyBhbmQgYXV0aGVudGljYXRpbmcgd2l0aCBBenVyZS4gQnkgZGVmYXVsdCBpdCBwb2ludHMgdG8gdGhlIHB1YmxpYyBjbG91ZCBBQUQgZW5kcG9pbnQuXG4gICAqIFRoZSBmb2xsb3dpbmcgZW5kcG9pbnRzIGFyZSBhdmFpbGFibGUsIGFsc28gc2VlIGhlcmU6IGh0dHBzOi8vZ2l0aHViLmNvbS9BenVyZS9nby1hdXRvcmVzdC9ibG9iL21haW4vYXV0b3Jlc3QvYXp1cmUvZW52aXJvbm1lbnRzLmdvI0wxNTJcbiAgICogUHVibGljQ2xvdWQsIFVTR292ZXJubWVudENsb3VkLCBDaGluYUNsb3VkLCBHZXJtYW5DbG91ZFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjI2Vudmlyb25tZW50VHlwZVxuICAgKi9cbiAgcmVhZG9ubHkgZW52aXJvbm1lbnRUeXBlPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNFbnZpcm9ubWVudFR5cGU7XG5cbiAgLyoqXG4gICAqIHRoZSBkb21haW4gbmFtZSBvZiB0aGUgQUNSIHJlZ2lzdHJ5XG4gICAqIGUuZy4gZm9vYmFyZXhhbXBsZS5henVyZWNyLmlvXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWMjcmVnaXN0cnlcbiAgICovXG4gIHJlYWRvbmx5IHJlZ2lzdHJ5OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIERlZmluZSB0aGUgc2NvcGUgZm9yIHRoZSBhY2Nlc3MgdG9rZW4sIGUuZy4gcHVsbC9wdXNoIGFjY2VzcyBmb3IgYSByZXBvc2l0b3J5LlxuICAgKiBpZiBub3QgcHJvdmlkZWQgaXQgd2lsbCByZXR1cm4gYSByZWZyZXNoIHRva2VuIHRoYXQgaGFzIGZ1bGwgc2NvcGUuXG4gICAqIE5vdGU6IHlvdSBuZWVkIHRvIHBpbiBpdCBkb3duIHRvIHRoZSByZXBvc2l0b3J5IGxldmVsLCB0aGVyZSBpcyBubyB3aWxkY2FyZCBhdmFpbGFibGUuXG4gICAqXG4gICAqIGV4YW1wbGVzOlxuICAgKiByZXBvc2l0b3J5Om15LXJlcG9zaXRvcnk6cHVsbCxwdXNoXG4gICAqIHJlcG9zaXRvcnk6bXktcmVwb3NpdG9yeTpwdWxsXG4gICAqXG4gICAqIHNlZSBkb2NzIGZvciBkZXRhaWxzOiBodHRwczovL2RvY3MuZG9ja2VyLmNvbS9yZWdpc3RyeS9zcGVjL2F1dGgvc2NvcGUvXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWMjc2NvcGVcbiAgICovXG4gIHJlYWRvbmx5IHNjb3BlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUZW5hbnRJRCBjb25maWd1cmVzIHRoZSBBenVyZSBUZW5hbnQgdG8gc2VuZCByZXF1ZXN0cyB0by4gUmVxdWlyZWQgZm9yIFNlcnZpY2VQcmluY2lwYWwgYXV0aCB0eXBlLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjI3RlbmFudElkXG4gICAqL1xuICByZWFkb25seSB0ZW5hbnRJZD86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlYycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWMob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1dGgnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoKG9iai5hdXRoKSxcbiAgICAnZW52aXJvbm1lbnRUeXBlJzogb2JqLmVudmlyb25tZW50VHlwZSxcbiAgICAncmVnaXN0cnknOiBvYmoucmVnaXN0cnksXG4gICAgJ3Njb3BlJzogb2JqLnNjb3BlLFxuICAgICd0ZW5hbnRJZCc6IG9iai50ZW5hbnRJZCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlYyB7XG4gIC8qKlxuICAgKiBBdXRoIGRlZmluZXMgaG93IHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEFXU1xuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlYyNhdXRoXG4gICAqL1xuICByZWFkb25seSBhdXRoPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aDtcblxuICAvKipcbiAgICogUmVnaW9uIHNwZWNpZmllcyB0aGUgcmVnaW9uIHRvIG9wZXJhdGUgaW4uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjI3JlZ2lvblxuICAgKi9cbiAgcmVhZG9ubHkgcmVnaW9uOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFlvdSBjYW4gYXNzdW1lIGEgcm9sZSBiZWZvcmUgbWFraW5nIGNhbGxzIHRvIHRoZVxuICAgKiBkZXNpcmVkIEFXUyBzZXJ2aWNlLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlYyNyb2xlXG4gICAqL1xuICByZWFkb25seSByb2xlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTY29wZSBzcGVjaWZpZXMgdGhlIEVDUiBzZXJ2aWNlIHNjb3BlLlxuICAgKiBWYWxpZCBvcHRpb25zIGFyZSBwcml2YXRlIGFuZCBwdWJsaWMuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjI3Njb3BlXG4gICAqL1xuICByZWFkb25seSBzY29wZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlYyhvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1dGgnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aChvYmouYXV0aCksXG4gICAgJ3JlZ2lvbic6IG9iai5yZWdpb24sXG4gICAgJ3JvbGUnOiBvYmoucm9sZSxcbiAgICAnc2NvcGUnOiBvYmouc2NvcGUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogRmFrZVNwZWMgY29udGFpbnMgdGhlIHN0YXRpYyBkYXRhLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JGYWtlU3BlY1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRmFrZVNwZWMge1xuICAvKipcbiAgICogVXNlZCB0byBzZWxlY3QgdGhlIGNvcnJlY3QgRVNPIGNvbnRyb2xsZXIgKHRoaW5rOiBpbmdyZXNzLmluZ3Jlc3NDbGFzc05hbWUpXG4gICAqIFRoZSBFU08gY29udHJvbGxlciBpcyBpbnN0YW50aWF0ZWQgd2l0aCBhIHNwZWNpZmljIGNvbnRyb2xsZXIgbmFtZSBhbmQgZmlsdGVycyBWRFMgYmFzZWQgb24gdGhpcyBwcm9wZXJ0eVxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRmFrZVNwZWMjY29udHJvbGxlclxuICAgKi9cbiAgcmVhZG9ubHkgY29udHJvbGxlcj86IHN0cmluZztcblxuICAvKipcbiAgICogRGF0YSBkZWZpbmVzIHRoZSBzdGF0aWMgZGF0YSByZXR1cm5lZFxuICAgKiBieSB0aGlzIGdlbmVyYXRvci5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckZha2VTcGVjI2RhdGFcbiAgICovXG4gIHJlYWRvbmx5IGRhdGE/OiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9O1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRmFrZVNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRmFrZVNwZWMob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckZha2VTcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnY29udHJvbGxlcic6IG9iai5jb250cm9sbGVyLFxuICAgICdkYXRhJzogKChvYmouZGF0YSkgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLmRhdGEpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlYyB7XG4gIC8qKlxuICAgKiBBdXRoIGRlZmluZXMgdGhlIG1lYW5zIGZvciBhdXRoZW50aWNhdGluZyB3aXRoIEdDUFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjI2F1dGhcbiAgICovXG4gIHJlYWRvbmx5IGF1dGg6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aDtcblxuICAvKipcbiAgICogUHJvamVjdElEIGRlZmluZXMgd2hpY2ggcHJvamVjdCB0byB1c2UgdG8gYXV0aGVudGljYXRlIHdpdGhcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlYyNwcm9qZWN0SURcbiAgICovXG4gIHJlYWRvbmx5IHByb2plY3RJZDogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlYyhvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXV0aCc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGgob2JqLmF1dGgpLFxuICAgICdwcm9qZWN0SUQnOiBvYmoucHJvamVjdElkLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHaXRodWJBY2Nlc3NUb2tlblNwZWNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlYyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjI2FwcElEXG4gICAqL1xuICByZWFkb25seSBhcHBJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBBdXRoIGNvbmZpZ3VyZXMgaG93IEVTTyBhdXRoZW50aWNhdGVzIHdpdGggYSBHaXRodWIgaW5zdGFuY2UuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHaXRodWJBY2Nlc3NUb2tlblNwZWMjYXV0aFxuICAgKi9cbiAgcmVhZG9ubHkgYXV0aDogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjI2luc3RhbGxJRFxuICAgKi9cbiAgcmVhZG9ubHkgaW5zdGFsbElkOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIE1hcCBvZiBwZXJtaXNzaW9ucyB0aGUgdG9rZW4gd2lsbCBoYXZlLiBJZiBvbWl0dGVkLCBkZWZhdWx0cyB0byBhbGwgcGVybWlzc2lvbnMgdGhlIEdpdEh1YiBBcHAgaGFzLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjI3Blcm1pc3Npb25zXG4gICAqL1xuICByZWFkb25seSBwZXJtaXNzaW9ucz86IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH07XG5cbiAgLyoqXG4gICAqIExpc3Qgb2YgcmVwb3NpdG9yaWVzIHRoZSB0b2tlbiB3aWxsIGhhdmUgYWNjZXNzIHRvLiBJZiBvbWl0dGVkLCBkZWZhdWx0cyB0byBhbGwgcmVwb3NpdG9yaWVzIHRoZSBHaXRIdWIgQXBwXG4gICAqIGlzIGluc3RhbGxlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlYyNyZXBvc2l0b3JpZXNcbiAgICovXG4gIHJlYWRvbmx5IHJlcG9zaXRvcmllcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBVUkwgY29uZmlndXJlcyB0aGUgR2l0aHViIGluc3RhbmNlIFVSTC4gRGVmYXVsdHMgdG8gaHR0cHM6Ly9naXRodWIuY29tLy5cbiAgICpcbiAgICogQGRlZmF1bHQgaHR0cHM6Ly9naXRodWIuY29tLy5cbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlYyN1cmxcbiAgICovXG4gIHJlYWRvbmx5IHVybD86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlYycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHaXRodWJBY2Nlc3NUb2tlblNwZWMob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2FwcElEJzogb2JqLmFwcElkLFxuICAgICdhdXRoJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aChvYmouYXV0aCksXG4gICAgJ2luc3RhbGxJRCc6IG9iai5pbnN0YWxsSWQsXG4gICAgJ3Blcm1pc3Npb25zJzogKChvYmoucGVybWlzc2lvbnMpID09PSB1bmRlZmluZWQpID8gdW5kZWZpbmVkIDogKE9iamVjdC5lbnRyaWVzKG9iai5wZXJtaXNzaW9ucykucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KSksXG4gICAgJ3JlcG9zaXRvcmllcyc6IG9iai5yZXBvc2l0b3JpZXM/Lm1hcCh5ID0+IHkpLFxuICAgICd1cmwnOiBvYmoudXJsLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEdyYWZhbmFTcGVjIGNvbnRyb2xzIHRoZSBiZWhhdmlvciBvZiB0aGUgZ3JhZmFuYSBnZW5lcmF0b3IuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlYyB7XG4gIC8qKlxuICAgKiBBdXRoIGlzIHRoZSBhdXRoZW50aWNhdGlvbiBjb25maWd1cmF0aW9uIHRvIGF1dGhlbnRpY2F0ZVxuICAgKiBhZ2FpbnN0IHRoZSBHcmFmYW5hIGluc3RhbmNlLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWMjYXV0aFxuICAgKi9cbiAgcmVhZG9ubHkgYXV0aDogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGg7XG5cbiAgLyoqXG4gICAqIFNlcnZpY2VBY2NvdW50IGlzIHRoZSBjb25maWd1cmF0aW9uIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHRoYXRcbiAgICogaXMgc3VwcG9zZWQgdG8gYmUgZ2VuZXJhdGVkIGJ5IHRoZSBnZW5lcmF0b3IuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlYyNzZXJ2aWNlQWNjb3VudFxuICAgKi9cbiAgcmVhZG9ubHkgc2VydmljZUFjY291bnQ6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudDtcblxuICAvKipcbiAgICogVVJMIGlzIHRoZSBVUkwgb2YgdGhlIEdyYWZhbmEgaW5zdGFuY2UuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlYyN1cmxcbiAgICovXG4gIHJlYWRvbmx5IHVybDogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWMob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXV0aCc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjQXV0aChvYmouYXV0aCksXG4gICAgJ3NlcnZpY2VBY2NvdW50JzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudChvYmouc2VydmljZUFjY291bnQpLFxuICAgICd1cmwnOiBvYmoudXJsLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFBhc3N3b3JkU3BlYyBjb250cm9scyB0aGUgYmVoYXZpb3Igb2YgdGhlIHBhc3N3b3JkIGdlbmVyYXRvci5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yUGFzc3dvcmRTcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JQYXNzd29yZFNwZWMge1xuICAvKipcbiAgICogc2V0IEFsbG93UmVwZWF0IHRvIHRydWUgdG8gYWxsb3cgcmVwZWF0aW5nIGNoYXJhY3RlcnMuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JQYXNzd29yZFNwZWMjYWxsb3dSZXBlYXRcbiAgICovXG4gIHJlYWRvbmx5IGFsbG93UmVwZWF0OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBEaWdpdHMgc3BlY2lmaWVzIHRoZSBudW1iZXIgb2YgZGlnaXRzIGluIHRoZSBnZW5lcmF0ZWRcbiAgICogcGFzc3dvcmQuIElmIG9taXR0ZWQgaXQgZGVmYXVsdHMgdG8gMjUlIG9mIHRoZSBsZW5ndGggb2YgdGhlIHBhc3N3b3JkXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JQYXNzd29yZFNwZWMjZGlnaXRzXG4gICAqL1xuICByZWFkb25seSBkaWdpdHM/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIExlbmd0aCBvZiB0aGUgcGFzc3dvcmQgdG8gYmUgZ2VuZXJhdGVkLlxuICAgKiBEZWZhdWx0cyB0byAyNFxuICAgKlxuICAgKiBAZGVmYXVsdCAyNFxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yUGFzc3dvcmRTcGVjI2xlbmd0aFxuICAgKi9cbiAgcmVhZG9ubHkgbGVuZ3RoOiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIFNldCBOb1VwcGVyIHRvIGRpc2FibGUgdXBwZXJjYXNlIGNoYXJhY3RlcnNcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclBhc3N3b3JkU3BlYyNub1VwcGVyXG4gICAqL1xuICByZWFkb25seSBub1VwcGVyOiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBTeW1ib2xDaGFyYWN0ZXJzIHNwZWNpZmllcyB0aGUgc3BlY2lhbCBjaGFyYWN0ZXJzIHRoYXQgc2hvdWxkIGJlIHVzZWRcbiAgICogaW4gdGhlIGdlbmVyYXRlZCBwYXNzd29yZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclBhc3N3b3JkU3BlYyNzeW1ib2xDaGFyYWN0ZXJzXG4gICAqL1xuICByZWFkb25seSBzeW1ib2xDaGFyYWN0ZXJzPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTeW1ib2xzIHNwZWNpZmllcyB0aGUgbnVtYmVyIG9mIHN5bWJvbCBjaGFyYWN0ZXJzIGluIHRoZSBnZW5lcmF0ZWRcbiAgICogcGFzc3dvcmQuIElmIG9taXR0ZWQgaXQgZGVmYXVsdHMgdG8gMjUlIG9mIHRoZSBsZW5ndGggb2YgdGhlIHBhc3N3b3JkXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JQYXNzd29yZFNwZWMjc3ltYm9sc1xuICAgKi9cbiAgcmVhZG9ubHkgc3ltYm9scz86IG51bWJlcjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclBhc3N3b3JkU3BlYycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JQYXNzd29yZFNwZWMob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclBhc3N3b3JkU3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2FsbG93UmVwZWF0Jzogb2JqLmFsbG93UmVwZWF0LFxuICAgICdkaWdpdHMnOiBvYmouZGlnaXRzLFxuICAgICdsZW5ndGgnOiBvYmoubGVuZ3RoLFxuICAgICdub1VwcGVyJzogb2JqLm5vVXBwZXIsXG4gICAgJ3N5bWJvbENoYXJhY3RlcnMnOiBvYmouc3ltYm9sQ2hhcmFjdGVycyxcbiAgICAnc3ltYm9scyc6IG9iai5zeW1ib2xzLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JRdWF5QWNjZXNzVG9rZW5TcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JRdWF5QWNjZXNzVG9rZW5TcGVjIHtcbiAgLyoqXG4gICAqIE5hbWUgb2YgdGhlIHJvYm90IGFjY291bnQgeW91IGFyZSBmZWRlcmF0aW5nIHdpdGhcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclF1YXlBY2Nlc3NUb2tlblNwZWMjcm9ib3RBY2NvdW50XG4gICAqL1xuICByZWFkb25seSByb2JvdEFjY291bnQ6IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZSBvZiB0aGUgc2VydmljZSBhY2NvdW50IHlvdSBhcmUgZmVkZXJhdGluZyB3aXRoXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JRdWF5QWNjZXNzVG9rZW5TcGVjI3NlcnZpY2VBY2NvdW50UmVmXG4gICAqL1xuICByZWFkb25seSBzZXJ2aWNlQWNjb3VudFJlZjogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JRdWF5QWNjZXNzVG9rZW5TcGVjU2VydmljZUFjY291bnRSZWY7XG5cbiAgLyoqXG4gICAqIFVSTCBjb25maWd1cmVzIHRoZSBRdWF5IGluc3RhbmNlIFVSTC4gRGVmYXVsdHMgdG8gcXVheS5pby5cbiAgICpcbiAgICogQGRlZmF1bHQgcXVheS5pby5cbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclF1YXlBY2Nlc3NUb2tlblNwZWMjdXJsXG4gICAqL1xuICByZWFkb25seSB1cmw/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JRdWF5QWNjZXNzVG9rZW5TcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclF1YXlBY2Nlc3NUb2tlblNwZWMob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclF1YXlBY2Nlc3NUb2tlblNwZWMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdyb2JvdEFjY291bnQnOiBvYmoucm9ib3RBY2NvdW50LFxuICAgICdzZXJ2aWNlQWNjb3VudFJlZic6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclF1YXlBY2Nlc3NUb2tlblNwZWNTZXJ2aWNlQWNjb3VudFJlZihvYmouc2VydmljZUFjY291bnRSZWYpLFxuICAgICd1cmwnOiBvYmoudXJsLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjIHtcbiAgLyoqXG4gICAqIEF1dGggZGVmaW5lcyBob3cgdG8gYXV0aGVudGljYXRlIHdpdGggQVdTXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjI2F1dGhcbiAgICovXG4gIHJlYWRvbmx5IGF1dGg/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoO1xuXG4gIC8qKlxuICAgKiBSZWdpb24gc3BlY2lmaWVzIHRoZSByZWdpb24gdG8gb3BlcmF0ZSBpbi5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWMjcmVnaW9uXG4gICAqL1xuICByZWFkb25seSByZWdpb246IHN0cmluZztcblxuICAvKipcbiAgICogUmVxdWVzdFBhcmFtZXRlcnMgY29udGFpbnMgcGFyYW1ldGVycyB0aGF0IGNhbiBiZSBwYXNzZWQgdG8gdGhlIFNUUyBzZXJ2aWNlLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlYyNyZXF1ZXN0UGFyYW1ldGVyc1xuICAgKi9cbiAgcmVhZG9ubHkgcmVxdWVzdFBhcmFtZXRlcnM/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNSZXF1ZXN0UGFyYW1ldGVycztcblxuICAvKipcbiAgICogWW91IGNhbiBhc3N1bWUgYSByb2xlIGJlZm9yZSBtYWtpbmcgY2FsbHMgdG8gdGhlXG4gICAqIGRlc2lyZWQgQVdTIHNlcnZpY2UuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjI3JvbGVcbiAgICovXG4gIHJlYWRvbmx5IHJvbGU/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWMob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhdXRoJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGgob2JqLmF1dGgpLFxuICAgICdyZWdpb24nOiBvYmoucmVnaW9uLFxuICAgICdyZXF1ZXN0UGFyYW1ldGVycyc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNSZXF1ZXN0UGFyYW1ldGVycyhvYmoucmVxdWVzdFBhcmFtZXRlcnMpLFxuICAgICdyb2xlJzogb2JqLnJvbGUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWMge1xuICAvKipcbiAgICogRG8gbm90IGZhaWwgaWYgbm8gc2VjcmV0cyBhcmUgZm91bmQuIFVzZWZ1bCBmb3IgcmVxdWVzdHMgd2hlcmUgbm8gZGF0YSBpcyBleHBlY3RlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWMjYWxsb3dFbXB0eVJlc3BvbnNlXG4gICAqL1xuICByZWFkb25seSBhbGxvd0VtcHR5UmVzcG9uc2U/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBVc2VkIHRvIHNlbGVjdCB0aGUgY29ycmVjdCBFU08gY29udHJvbGxlciAodGhpbms6IGluZ3Jlc3MuaW5ncmVzc0NsYXNzTmFtZSlcbiAgICogVGhlIEVTTyBjb250cm9sbGVyIGlzIGluc3RhbnRpYXRlZCB3aXRoIGEgc3BlY2lmaWMgY29udHJvbGxlciBuYW1lIGFuZCBmaWx0ZXJzIFZEUyBiYXNlZCBvbiB0aGlzIHByb3BlcnR5XG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjI2NvbnRyb2xsZXJcbiAgICovXG4gIHJlYWRvbmx5IGNvbnRyb2xsZXI/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFZhdWx0IEFQSSBtZXRob2QgdG8gdXNlIChHRVQvUE9TVC9vdGhlcilcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWMjbWV0aG9kXG4gICAqL1xuICByZWFkb25seSBtZXRob2Q/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFBhcmFtZXRlcnMgdG8gcGFzcyB0byBWYXVsdCB3cml0ZSAoZm9yIG5vbi1HRVQgbWV0aG9kcylcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWMjcGFyYW1ldGVyc1xuICAgKi9cbiAgcmVhZG9ubHkgcGFyYW1ldGVycz86IGFueTtcblxuICAvKipcbiAgICogVmF1bHQgcGF0aCB0byBvYnRhaW4gdGhlIGR5bmFtaWMgc2VjcmV0IGZyb21cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWMjcGF0aFxuICAgKi9cbiAgcmVhZG9ubHkgcGF0aDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBWYXVsdCBwcm92aWRlciBjb21tb24gc3BlY1xuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlYyNwcm92aWRlclxuICAgKi9cbiAgcmVhZG9ubHkgcHJvdmlkZXI6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyO1xuXG4gIC8qKlxuICAgKiBSZXN1bHQgdHlwZSBkZWZpbmVzIHdoaWNoIGRhdGEgaXMgcmV0dXJuZWQgZnJvbSB0aGUgZ2VuZXJhdG9yLlxuICAgKiBCeSBkZWZhdWx0IGl0IGlzIHRoZSBcImRhdGFcIiBzZWN0aW9uIG9mIHRoZSBWYXVsdCBBUEkgcmVzcG9uc2UuXG4gICAqIFdoZW4gdXNpbmcgZS5nLiAvYXV0aC90b2tlbi9jcmVhdGUgdGhlIFwiZGF0YVwiIHNlY3Rpb24gaXMgZW1wdHkgYnV0XG4gICAqIHRoZSBcImF1dGhcIiBzZWN0aW9uIGNvbnRhaW5zIHRoZSBnZW5lcmF0ZWQgdG9rZW4uXG4gICAqIFBsZWFzZSByZWZlciB0byB0aGUgdmF1bHQgZG9jcyByZWdhcmRpbmcgdGhlIHJlc3VsdCBkYXRhIHN0cnVjdHVyZS5cbiAgICogQWRkaXRpb25hbGx5LCBhY2Nlc3NpbmcgdGhlIHJhdyByZXNwb25zZSBpcyBwb3NzaWJseSBieSB1c2luZyBcIlJhd1wiIHJlc3VsdCB0eXBlLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlYyNyZXN1bHRUeXBlXG4gICAqL1xuICByZWFkb25seSByZXN1bHRUeXBlPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUmVzdWx0VHlwZTtcblxuICAvKipcbiAgICogVXNlZCB0byBjb25maWd1cmUgaHR0cCByZXRyaWVzIGlmIGZhaWxlZFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlYyNyZXRyeVNldHRpbmdzXG4gICAqL1xuICByZWFkb25seSByZXRyeVNldHRpbmdzPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUmV0cnlTZXR0aW5ncztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlYyhvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2FsbG93RW1wdHlSZXNwb25zZSc6IG9iai5hbGxvd0VtcHR5UmVzcG9uc2UsXG4gICAgJ2NvbnRyb2xsZXInOiBvYmouY29udHJvbGxlcixcbiAgICAnbWV0aG9kJzogb2JqLm1ldGhvZCxcbiAgICAncGFyYW1ldGVycyc6IG9iai5wYXJhbWV0ZXJzLFxuICAgICdwYXRoJzogb2JqLnBhdGgsXG4gICAgJ3Byb3ZpZGVyJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyKG9iai5wcm92aWRlciksXG4gICAgJ3Jlc3VsdFR5cGUnOiBvYmoucmVzdWx0VHlwZSxcbiAgICAncmV0cnlTZXR0aW5ncyc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNSZXRyeVNldHRpbmdzKG9iai5yZXRyeVNldHRpbmdzKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBXZWJob29rU3BlYyBjb250cm9scyB0aGUgYmVoYXZpb3Igb2YgdGhlIGV4dGVybmFsIGdlbmVyYXRvci4gQW55IGJvZHkgcGFyYW1ldGVycyBzaG91bGQgYmUgcGFzc2VkIHRvIHRoZSBzZXJ2ZXIgdGhyb3VnaCB0aGUgcGFyYW1ldGVycyBmaWVsZC5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjIHtcbiAgLyoqXG4gICAqIEJvZHlcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjI2JvZHlcbiAgICovXG4gIHJlYWRvbmx5IGJvZHk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFBFTSBlbmNvZGVkIENBIGJ1bmRsZSB1c2VkIHRvIHZhbGlkYXRlIHdlYmhvb2sgc2VydmVyIGNlcnRpZmljYXRlLiBPbmx5IHVzZWRcbiAgICogaWYgdGhlIFNlcnZlciBVUkwgaXMgdXNpbmcgSFRUUFMgcHJvdG9jb2wuIFRoaXMgcGFyYW1ldGVyIGlzIGlnbm9yZWQgZm9yXG4gICAqIHBsYWluIEhUVFAgcHJvdG9jb2wgY29ubmVjdGlvbi4gSWYgbm90IHNldCB0aGUgc3lzdGVtIHJvb3QgY2VydGlmaWNhdGVzXG4gICAqIGFyZSB1c2VkIHRvIHZhbGlkYXRlIHRoZSBUTFMgY29ubmVjdGlvbi5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjI2NhQnVuZGxlXG4gICAqL1xuICByZWFkb25seSBjYUJ1bmRsZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHByb3ZpZGVyIGZvciB0aGUgQ0EgYnVuZGxlIHRvIHVzZSB0byB2YWxpZGF0ZSB3ZWJob29rIHNlcnZlciBjZXJ0aWZpY2F0ZS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjI2NhUHJvdmlkZXJcbiAgICovXG4gIHJlYWRvbmx5IGNhUHJvdmlkZXI/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjQ2FQcm92aWRlcjtcblxuICAvKipcbiAgICogSGVhZGVyc1xuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWMjaGVhZGVyc1xuICAgKi9cbiAgcmVhZG9ubHkgaGVhZGVycz86IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH07XG5cbiAgLyoqXG4gICAqIFdlYmhvb2sgTWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlYyNtZXRob2RcbiAgICovXG4gIHJlYWRvbmx5IG1ldGhvZD86IHN0cmluZztcblxuICAvKipcbiAgICogUmVzdWx0IGZvcm1hdHRpbmdcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjI3Jlc3VsdFxuICAgKi9cbiAgcmVhZG9ubHkgcmVzdWx0OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjUmVzdWx0O1xuXG4gIC8qKlxuICAgKiBTZWNyZXRzIHRvIGZpbGwgaW4gdGVtcGxhdGVzXG4gICAqIFRoZXNlIHNlY3JldHMgd2lsbCBiZSBwYXNzZWQgdG8gdGhlIHRlbXBsYXRpbmcgZnVuY3Rpb24gYXMga2V5IHZhbHVlIHBhaXJzIHVuZGVyIHRoZSBnaXZlbiBuYW1lXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlYyNzZWNyZXRzXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRzPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY1NlY3JldHNbXTtcblxuICAvKipcbiAgICogVGltZW91dFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWMjdGltZW91dFxuICAgKi9cbiAgcmVhZG9ubHkgdGltZW91dD86IHN0cmluZztcblxuICAvKipcbiAgICogV2ViaG9vayB1cmwgdG8gY2FsbFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWMjdXJsXG4gICAqL1xuICByZWFkb25seSB1cmw6IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2JvZHknOiBvYmouYm9keSxcbiAgICAnY2FCdW5kbGUnOiBvYmouY2FCdW5kbGUsXG4gICAgJ2NhUHJvdmlkZXInOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY0NhUHJvdmlkZXIob2JqLmNhUHJvdmlkZXIpLFxuICAgICdoZWFkZXJzJzogKChvYmouaGVhZGVycykgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLmhlYWRlcnMpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSkpLFxuICAgICdtZXRob2QnOiBvYmoubWV0aG9kLFxuICAgICdyZXN1bHQnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY1Jlc3VsdChvYmoucmVzdWx0KSxcbiAgICAnc2VjcmV0cyc6IG9iai5zZWNyZXRzPy5tYXAoeSA9PiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY1NlY3JldHMoeSkpLFxuICAgICd0aW1lb3V0Jzogb2JqLnRpbWVvdXQsXG4gICAgJ3VybCc6IG9iai51cmwsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGgge1xuICAvKipcbiAgICogTWFuYWdlZElkZW50aXR5IHVzZXMgQXp1cmUgTWFuYWdlZCBJZGVudGl0eSB0byBhdXRoZW50aWNhdGUgd2l0aCBBenVyZS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGgjbWFuYWdlZElkZW50aXR5XG4gICAqL1xuICByZWFkb25seSBtYW5hZ2VkSWRlbnRpdHk/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhNYW5hZ2VkSWRlbnRpdHk7XG5cbiAgLyoqXG4gICAqIFNlcnZpY2VQcmluY2lwYWwgdXNlcyBBenVyZSBTZXJ2aWNlIFByaW5jaXBhbCBjcmVkZW50aWFscyB0byBhdXRoZW50aWNhdGUgd2l0aCBBenVyZS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGgjc2VydmljZVByaW5jaXBhbFxuICAgKi9cbiAgcmVhZG9ubHkgc2VydmljZVByaW5jaXBhbD86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWw7XG5cbiAgLyoqXG4gICAqIFdvcmtsb2FkSWRlbnRpdHkgdXNlcyBBenVyZSBXb3JrbG9hZCBJZGVudGl0eSB0byBhdXRoZW50aWNhdGUgd2l0aCBBenVyZS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGgjd29ya2xvYWRJZGVudGl0eVxuICAgKi9cbiAgcmVhZG9ubHkgd29ya2xvYWRJZGVudGl0eT86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHk7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGgob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGggfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtYW5hZ2VkSWRlbnRpdHknOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoTWFuYWdlZElkZW50aXR5KG9iai5tYW5hZ2VkSWRlbnRpdHkpLFxuICAgICdzZXJ2aWNlUHJpbmNpcGFsJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWwob2JqLnNlcnZpY2VQcmluY2lwYWwpLFxuICAgICd3b3JrbG9hZElkZW50aXR5JzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkob2JqLndvcmtsb2FkSWRlbnRpdHkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEVudmlyb25tZW50VHlwZSBzcGVjaWZpZXMgdGhlIEF6dXJlIGNsb3VkIGVudmlyb25tZW50IGVuZHBvaW50cyB0byB1c2UgZm9yXG4gKiBjb25uZWN0aW5nIGFuZCBhdXRoZW50aWNhdGluZyB3aXRoIEF6dXJlLiBCeSBkZWZhdWx0IGl0IHBvaW50cyB0byB0aGUgcHVibGljIGNsb3VkIEFBRCBlbmRwb2ludC5cbiAqIFRoZSBmb2xsb3dpbmcgZW5kcG9pbnRzIGFyZSBhdmFpbGFibGUsIGFsc28gc2VlIGhlcmU6IGh0dHBzOi8vZ2l0aHViLmNvbS9BenVyZS9nby1hdXRvcmVzdC9ibG9iL21haW4vYXV0b3Jlc3QvYXp1cmUvZW52aXJvbm1lbnRzLmdvI0wxNTJcbiAqIFB1YmxpY0Nsb3VkLCBVU0dvdmVybm1lbnRDbG91ZCwgQ2hpbmFDbG91ZCwgR2VybWFuQ2xvdWRcbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjRW52aXJvbm1lbnRUeXBlXG4gKi9cbmV4cG9ydCBlbnVtIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjRW52aXJvbm1lbnRUeXBlIHtcbiAgLyoqIFB1YmxpY0Nsb3VkICovXG4gIFBVQkxJQ19DTE9VRCA9IFwiUHVibGljQ2xvdWRcIixcbiAgLyoqIFVTR292ZXJubWVudENsb3VkICovXG4gIFVTX0dPVkVSTk1FTlRfQ0xPVUQgPSBcIlVTR292ZXJubWVudENsb3VkXCIsXG4gIC8qKiBDaGluYUNsb3VkICovXG4gIENISU5BX0NMT1VEID0gXCJDaGluYUNsb3VkXCIsXG4gIC8qKiBHZXJtYW5DbG91ZCAqL1xuICBHRVJNQU5fQ0xPVUQgPSBcIkdlcm1hbkNsb3VkXCIsXG59XG5cbi8qKlxuICogQXV0aCBkZWZpbmVzIGhvdyB0byBhdXRoZW50aWNhdGUgd2l0aCBBV1NcbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoIHtcbiAgLyoqXG4gICAqIEF1dGhlbnRpY2F0ZSBhZ2FpbnN0IEFXUyB1c2luZyBzZXJ2aWNlIGFjY291bnQgdG9rZW5zLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGgjand0XG4gICAqL1xuICByZWFkb25seSBqd3Q/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0O1xuXG4gIC8qKlxuICAgKiBBV1NBdXRoU2VjcmV0UmVmIGhvbGRzIHNlY3JldCByZWZlcmVuY2VzIGZvciBBV1MgY3JlZGVudGlhbHNcbiAgICogYm90aCBBY2Nlc3NLZXlJRCBhbmQgU2VjcmV0QWNjZXNzS2V5IG11c3QgYmUgZGVmaW5lZCBpbiBvcmRlciB0byBwcm9wZXJseSBhdXRoZW50aWNhdGUuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aCNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aChvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGggfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdqd3QnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dChvYmouand0KSxcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQXV0aCBkZWZpbmVzIHRoZSBtZWFucyBmb3IgYXV0aGVudGljYXRpbmcgd2l0aCBHQ1BcbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aCB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aCNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZjtcblxuICAvKipcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGgjd29ya2xvYWRJZGVudGl0eVxuICAgKi9cbiAgcmVhZG9ubHkgd29ya2xvYWRJZGVudGl0eT86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHk7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGgob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGggfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdzZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmKG9iai5zZWNyZXRSZWYpLFxuICAgICd3b3JrbG9hZElkZW50aXR5JzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkob2JqLndvcmtsb2FkSWRlbnRpdHkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEF1dGggY29uZmlndXJlcyBob3cgRVNPIGF1dGhlbnRpY2F0ZXMgd2l0aCBhIEdpdGh1YiBpbnN0YW5jZS5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aCB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aCNwcml2YXRlS2V5XG4gICAqL1xuICByZWFkb25seSBwcml2YXRlS2V5OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5O1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAncHJpdmF0ZUtleSc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5KG9iai5wcml2YXRlS2V5KSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBdXRoIGlzIHRoZSBhdXRoZW50aWNhdGlvbiBjb25maWd1cmF0aW9uIHRvIGF1dGhlbnRpY2F0ZVxuICogYWdhaW5zdCB0aGUgR3JhZmFuYSBpbnN0YW5jZS5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGgge1xuICAvKipcbiAgICogQmFzaWMgYXV0aCBjcmVkZW50aWFscyB1c2VkIHRvIGF1dGhlbnRpY2F0ZSBhZ2FpbnN0IHRoZSBHcmFmYW5hIGluc3RhbmNlLlxuICAgKiBOb3RlOiB5b3UgbmVlZCBhIHRva2VuIHdoaWNoIGhhcyBlbGV2YXRlZCBwZXJtaXNzaW9ucyB0byBjcmVhdGUgc2VydmljZSBhY2NvdW50cy5cbiAgICogU2VlIGhlcmUgZm9yIHRoZSBkb2N1bWVudGF0aW9uIG9uIGJhc2ljIHJvbGVzIG9mZmVyZWQgYnkgR3JhZmFuYTpcbiAgICogaHR0cHM6Ly9ncmFmYW5hLmNvbS9kb2NzL2dyYWZhbmEvbGF0ZXN0L2FkbWluaXN0cmF0aW9uL3JvbGVzLWFuZC1wZXJtaXNzaW9ucy9hY2Nlc3MtY29udHJvbC9yYmFjLWZpeGVkLWJhc2ljLXJvbGUtZGVmaW5pdGlvbnMvXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGgjYmFzaWNcbiAgICovXG4gIHJlYWRvbmx5IGJhc2ljPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGhCYXNpYztcblxuICAvKipcbiAgICogQSBzZXJ2aWNlIGFjY291bnQgdG9rZW4gdXNlZCB0byBhdXRoZW50aWNhdGUgYWdhaW5zdCB0aGUgR3JhZmFuYSBpbnN0YW5jZS5cbiAgICogTm90ZTogeW91IG5lZWQgYSB0b2tlbiB3aGljaCBoYXMgZWxldmF0ZWQgcGVybWlzc2lvbnMgdG8gY3JlYXRlIHNlcnZpY2UgYWNjb3VudHMuXG4gICAqIFNlZSBoZXJlIGZvciB0aGUgZG9jdW1lbnRhdGlvbiBvbiBiYXNpYyByb2xlcyBvZmZlcmVkIGJ5IEdyYWZhbmE6XG4gICAqIGh0dHBzOi8vZ3JhZmFuYS5jb20vZG9jcy9ncmFmYW5hL2xhdGVzdC9hZG1pbmlzdHJhdGlvbi9yb2xlcy1hbmQtcGVybWlzc2lvbnMvYWNjZXNzLWNvbnRyb2wvcmJhYy1maXhlZC1iYXNpYy1yb2xlLWRlZmluaXRpb25zL1xuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoI3Rva2VuXG4gICAqL1xuICByZWFkb25seSB0b2tlbj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoVG9rZW47XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGgnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGggfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdiYXNpYyc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjQXV0aEJhc2ljKG9iai5iYXNpYyksXG4gICAgJ3Rva2VuJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoVG9rZW4ob2JqLnRva2VuKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBTZXJ2aWNlQWNjb3VudCBpcyB0aGUgY29uZmlndXJhdGlvbiBmb3IgdGhlIHNlcnZpY2UgYWNjb3VudCB0aGF0XG4gKiBpcyBzdXBwb3NlZCB0byBiZSBnZW5lcmF0ZWQgYnkgdGhlIGdlbmVyYXRvci5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudCB7XG4gIC8qKlxuICAgKiBOYW1lIGlzIHRoZSBuYW1lIG9mIHRoZSBzZXJ2aWNlIGFjY291bnQgdGhhdCB3aWxsIGJlIGNyZWF0ZWQgYnkgRVNPLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudCNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFJvbGUgaXMgdGhlIHJvbGUgb2YgdGhlIHNlcnZpY2UgYWNjb3VudC5cbiAgICogU2VlIGhlcmUgZm9yIHRoZSBkb2N1bWVudGF0aW9uIG9uIGJhc2ljIHJvbGVzIG9mZmVyZWQgYnkgR3JhZmFuYTpcbiAgICogaHR0cHM6Ly9ncmFmYW5hLmNvbS9kb2NzL2dyYWZhbmEvbGF0ZXN0L2FkbWluaXN0cmF0aW9uL3JvbGVzLWFuZC1wZXJtaXNzaW9ucy9hY2Nlc3MtY29udHJvbC9yYmFjLWZpeGVkLWJhc2ljLXJvbGUtZGVmaW5pdGlvbnMvXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY1NlcnZpY2VBY2NvdW50I3JvbGVcbiAgICovXG4gIHJlYWRvbmx5IHJvbGU6IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjU2VydmljZUFjY291bnQnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudChvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAncm9sZSc6IG9iai5yb2xlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE5hbWUgb2YgdGhlIHNlcnZpY2UgYWNjb3VudCB5b3UgYXJlIGZlZGVyYXRpbmcgd2l0aFxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JRdWF5QWNjZXNzVG9rZW5TcGVjU2VydmljZUFjY291bnRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclF1YXlBY2Nlc3NUb2tlblNwZWNTZXJ2aWNlQWNjb3VudFJlZiB7XG4gIC8qKlxuICAgKiBBdWRpZW5jZSBzcGVjaWZpZXMgdGhlIGBhdWRgIGNsYWltIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHRva2VuXG4gICAqIElmIHRoZSBzZXJ2aWNlIGFjY291bnQgdXNlcyBhIHdlbGwta25vd24gYW5ub3RhdGlvbiBmb3IgZS5nLiBJUlNBIG9yIEdDUCBXb3JrbG9hZCBJZGVudGl0eVxuICAgKiB0aGVuIHRoaXMgYXVkaWVuY2VzIHdpbGwgYmUgYXBwZW5kZWQgdG8gdGhlIGxpc3RcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclF1YXlBY2Nlc3NUb2tlblNwZWNTZXJ2aWNlQWNjb3VudFJlZiNhdWRpZW5jZXNcbiAgICovXG4gIHJlYWRvbmx5IGF1ZGllbmNlcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VydmljZUFjY291bnQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JRdWF5QWNjZXNzVG9rZW5TcGVjU2VydmljZUFjY291bnRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBOYW1lc3BhY2Ugb2YgdGhlIHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yUXVheUFjY2Vzc1Rva2VuU3BlY1NlcnZpY2VBY2NvdW50UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yUXVheUFjY2Vzc1Rva2VuU3BlY1NlcnZpY2VBY2NvdW50UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclF1YXlBY2Nlc3NUb2tlblNwZWNTZXJ2aWNlQWNjb3VudFJlZihvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yUXVheUFjY2Vzc1Rva2VuU3BlY1NlcnZpY2VBY2NvdW50UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXVkaWVuY2VzJzogb2JqLmF1ZGllbmNlcz8ubWFwKHkgPT4geSksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBdXRoIGRlZmluZXMgaG93IHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEFXU1xuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGgge1xuICAvKipcbiAgICogQXV0aGVudGljYXRlIGFnYWluc3QgQVdTIHVzaW5nIHNlcnZpY2UgYWNjb3VudCB0b2tlbnMuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aCNqd3RcbiAgICovXG4gIHJlYWRvbmx5IGp3dD86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhKd3Q7XG5cbiAgLyoqXG4gICAqIEFXU0F1dGhTZWNyZXRSZWYgaG9sZHMgc2VjcmV0IHJlZmVyZW5jZXMgZm9yIEFXUyBjcmVkZW50aWFsc1xuICAgKiBib3RoIEFjY2Vzc0tleUlEIGFuZCBTZWNyZXRBY2Nlc3NLZXkgbXVzdCBiZSBkZWZpbmVkIGluIG9yZGVyIHRvIHByb3Blcmx5IGF1dGhlbnRpY2F0ZS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoI3NlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0UmVmPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2p3dCc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0KG9iai5qd3QpLFxuICAgICdzZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZihvYmouc2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBSZXF1ZXN0UGFyYW1ldGVycyBjb250YWlucyBwYXJhbWV0ZXJzIHRoYXQgY2FuIGJlIHBhc3NlZCB0byB0aGUgU1RTIHNlcnZpY2UuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNSZXF1ZXN0UGFyYW1ldGVyc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzIHtcbiAgLyoqXG4gICAqIFNlcmlhbE51bWJlciBpcyB0aGUgaWRlbnRpZmljYXRpb24gbnVtYmVyIG9mIHRoZSBNRkEgZGV2aWNlIHRoYXQgaXMgYXNzb2NpYXRlZCB3aXRoIHRoZSBJQU0gdXNlciB3aG8gaXMgbWFraW5nXG4gICAqIHRoZSBHZXRTZXNzaW9uVG9rZW4gY2FsbC5cbiAgICogUG9zc2libGUgdmFsdWVzOiBoYXJkd2FyZSBkZXZpY2UgKHN1Y2ggYXMgR0FIVDEyMzQ1Njc4KSBvciBhbiBBbWF6b24gUmVzb3VyY2UgTmFtZSAoQVJOKSBmb3IgYSB2aXJ0dWFsIGRldmljZVxuICAgKiAoc3VjaCBhcyBhcm46YXdzOmlhbTo6MTIzNDU2Nzg5MDEyOm1mYS91c2VyKVxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzI3NlcmlhbE51bWJlclxuICAgKi9cbiAgcmVhZG9ubHkgc2VyaWFsTnVtYmVyPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTZXNzaW9uRHVyYXRpb24gVGhlIGR1cmF0aW9uLCBpbiBzZWNvbmRzLCB0aGF0IHRoZSBjcmVkZW50aWFscyBzaG91bGQgcmVtYWluIHZhbGlkLiBBY2NlcHRhYmxlIGR1cmF0aW9ucyBmb3JcbiAgICogSUFNIHVzZXIgc2Vzc2lvbnMgcmFuZ2UgZnJvbSA5MDAgc2Vjb25kcyAoMTUgbWludXRlcykgdG8gMTI5LDYwMCBzZWNvbmRzICgzNiBob3VycyksIHdpdGggNDMsMjAwIHNlY29uZHNcbiAgICogKDEyIGhvdXJzKSBhcyB0aGUgZGVmYXVsdC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNSZXF1ZXN0UGFyYW1ldGVycyNzZXNzaW9uRHVyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IHNlc3Npb25EdXJhdGlvbj86IG51bWJlcjtcblxuICAvKipcbiAgICogVG9rZW5Db2RlIGlzIHRoZSB2YWx1ZSBwcm92aWRlZCBieSB0aGUgTUZBIGRldmljZSwgaWYgTUZBIGlzIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzI3Rva2VuQ29kZVxuICAgKi9cbiAgcmVhZG9ubHkgdG9rZW5Db2RlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNSZXF1ZXN0UGFyYW1ldGVycyhvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VyaWFsTnVtYmVyJzogb2JqLnNlcmlhbE51bWJlcixcbiAgICAnc2Vzc2lvbkR1cmF0aW9uJzogb2JqLnNlc3Npb25EdXJhdGlvbixcbiAgICAndG9rZW5Db2RlJzogb2JqLnRva2VuQ29kZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBWYXVsdCBwcm92aWRlciBjb21tb24gc3BlY1xuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlciB7XG4gIC8qKlxuICAgKiBBdXRoIGNvbmZpZ3VyZXMgaG93IHNlY3JldC1tYW5hZ2VyIGF1dGhlbnRpY2F0ZXMgd2l0aCB0aGUgVmF1bHQgc2VydmVyLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyI2F1dGhcbiAgICovXG4gIHJlYWRvbmx5IGF1dGg/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGg7XG5cbiAgLyoqXG4gICAqIFBFTSBlbmNvZGVkIENBIGJ1bmRsZSB1c2VkIHRvIHZhbGlkYXRlIFZhdWx0IHNlcnZlciBjZXJ0aWZpY2F0ZS4gT25seSB1c2VkXG4gICAqIGlmIHRoZSBTZXJ2ZXIgVVJMIGlzIHVzaW5nIEhUVFBTIHByb3RvY29sLiBUaGlzIHBhcmFtZXRlciBpcyBpZ25vcmVkIGZvclxuICAgKiBwbGFpbiBIVFRQIHByb3RvY29sIGNvbm5lY3Rpb24uIElmIG5vdCBzZXQgdGhlIHN5c3RlbSByb290IGNlcnRpZmljYXRlc1xuICAgKiBhcmUgdXNlZCB0byB2YWxpZGF0ZSB0aGUgVExTIGNvbm5lY3Rpb24uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXIjY2FCdW5kbGVcbiAgICovXG4gIHJlYWRvbmx5IGNhQnVuZGxlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgcHJvdmlkZXIgZm9yIHRoZSBDQSBidW5kbGUgdG8gdXNlIHRvIHZhbGlkYXRlIFZhdWx0IHNlcnZlciBjZXJ0aWZpY2F0ZS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlciNjYVByb3ZpZGVyXG4gICAqL1xuICByZWFkb25seSBjYVByb3ZpZGVyPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyO1xuXG4gIC8qKlxuICAgKiBGb3J3YXJkSW5jb25zaXN0ZW50IHRlbGxzIFZhdWx0IHRvIGZvcndhcmQgcmVhZC1hZnRlci13cml0ZSByZXF1ZXN0cyB0byB0aGUgVmF1bHRcbiAgICogbGVhZGVyIGluc3RlYWQgb2Ygc2ltcGx5IHJldHJ5aW5nIHdpdGhpbiBhIGxvb3AuIFRoaXMgY2FuIGluY3JlYXNlIHBlcmZvcm1hbmNlIGlmXG4gICAqIHRoZSBvcHRpb24gaXMgZW5hYmxlZCBzZXJ2ZXJzaWRlLlxuICAgKiBodHRwczovL3d3dy52YXVsdHByb2plY3QuaW8vZG9jcy9jb25maWd1cmF0aW9uL3JlcGxpY2F0aW9uI2FsbG93X2ZvcndhcmRpbmdfdmlhX2hlYWRlclxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyI2ZvcndhcmRJbmNvbnNpc3RlbnRcbiAgICovXG4gIHJlYWRvbmx5IGZvcndhcmRJbmNvbnNpc3RlbnQ/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBIZWFkZXJzIHRvIGJlIGFkZGVkIGluIFZhdWx0IHJlcXVlc3RcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlciNoZWFkZXJzXG4gICAqL1xuICByZWFkb25seSBoZWFkZXJzPzogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcblxuICAvKipcbiAgICogTmFtZSBvZiB0aGUgdmF1bHQgbmFtZXNwYWNlLiBOYW1lc3BhY2VzIGlzIGEgc2V0IG9mIGZlYXR1cmVzIHdpdGhpbiBWYXVsdCBFbnRlcnByaXNlIHRoYXQgYWxsb3dzXG4gICAqIFZhdWx0IGVudmlyb25tZW50cyB0byBzdXBwb3J0IFNlY3VyZSBNdWx0aS10ZW5hbmN5LiBlLmc6IFwibnMxXCIuXG4gICAqIE1vcmUgYWJvdXQgbmFtZXNwYWNlcyBjYW4gYmUgZm91bmQgaGVyZSBodHRwczovL3d3dy52YXVsdHByb2plY3QuaW8vZG9jcy9lbnRlcnByaXNlL25hbWVzcGFjZXNcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlciNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxuICAvKipcbiAgICogUGF0aCBpcyB0aGUgbW91bnQgcGF0aCBvZiB0aGUgVmF1bHQgS1YgYmFja2VuZCBlbmRwb2ludCwgZS5nOlxuICAgKiBcInNlY3JldFwiLiBUaGUgdjIgS1Ygc2VjcmV0IGVuZ2luZSB2ZXJzaW9uIHNwZWNpZmljIFwiL2RhdGFcIiBwYXRoIHN1ZmZpeFxuICAgKiBmb3IgZmV0Y2hpbmcgc2VjcmV0cyBmcm9tIFZhdWx0IGlzIG9wdGlvbmFsIGFuZCB3aWxsIGJlIGFwcGVuZGVkXG4gICAqIGlmIG5vdCBwcmVzZW50IGluIHNwZWNpZmllZCBwYXRoLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyI3BhdGhcbiAgICovXG4gIHJlYWRvbmx5IHBhdGg/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFJlYWRZb3VyV3JpdGVzIGVuc3VyZXMgaXNvbGF0ZWQgcmVhZC1hZnRlci13cml0ZSBzZW1hbnRpY3MgYnlcbiAgICogcHJvdmlkaW5nIGRpc2NvdmVyZWQgY2x1c3RlciByZXBsaWNhdGlvbiBzdGF0ZXMgaW4gZWFjaCByZXF1ZXN0LlxuICAgKiBNb3JlIGluZm9ybWF0aW9uIGFib3V0IGV2ZW50dWFsIGNvbnNpc3RlbmN5IGluIFZhdWx0IGNhbiBiZSBmb3VuZCBoZXJlXG4gICAqIGh0dHBzOi8vd3d3LnZhdWx0cHJvamVjdC5pby9kb2NzL2VudGVycHJpc2UvY29uc2lzdGVuY3lcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlciNyZWFkWW91cldyaXRlc1xuICAgKi9cbiAgcmVhZG9ubHkgcmVhZFlvdXJXcml0ZXM/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBTZXJ2ZXIgaXMgdGhlIGNvbm5lY3Rpb24gYWRkcmVzcyBmb3IgdGhlIFZhdWx0IHNlcnZlciwgZS5nOiBcImh0dHBzOi8vdmF1bHQuZXhhbXBsZS5jb206ODIwMFwiLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyI3NlcnZlclxuICAgKi9cbiAgcmVhZG9ubHkgc2VydmVyOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBjb25maWd1cmF0aW9uIHVzZWQgZm9yIGNsaWVudCBzaWRlIHJlbGF0ZWQgVExTIGNvbW11bmljYXRpb24sIHdoZW4gdGhlIFZhdWx0IHNlcnZlclxuICAgKiByZXF1aXJlcyBtdXR1YWwgYXV0aGVudGljYXRpb24uIE9ubHkgdXNlZCBpZiB0aGUgU2VydmVyIFVSTCBpcyB1c2luZyBIVFRQUyBwcm90b2NvbC5cbiAgICogVGhpcyBwYXJhbWV0ZXIgaXMgaWdub3JlZCBmb3IgcGxhaW4gSFRUUCBwcm90b2NvbCBjb25uZWN0aW9uLlxuICAgKiBJdCdzIHdvcnRoIG5vdGluZyB0aGlzIGNvbmZpZ3VyYXRpb24gaXMgZGlmZmVyZW50IGZyb20gdGhlIFwiVExTIGNlcnRpZmljYXRlcyBhdXRoIG1ldGhvZFwiLFxuICAgKiB3aGljaCBpcyBhdmFpbGFibGUgdW5kZXIgdGhlIGBhdXRoLmNlcnRgIHNlY3Rpb24uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXIjdGxzXG4gICAqL1xuICByZWFkb25seSB0bHM/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRscztcblxuICAvKipcbiAgICogVmVyc2lvbiBpcyB0aGUgVmF1bHQgS1Ygc2VjcmV0IGVuZ2luZSB2ZXJzaW9uLiBUaGlzIGNhbiBiZSBlaXRoZXIgXCJ2MVwiIG9yXG4gICAqIFwidjJcIi4gVmVyc2lvbiBkZWZhdWx0cyB0byBcInYyXCIuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXIjdmVyc2lvblxuICAgKi9cbiAgcmVhZG9ubHkgdmVyc2lvbj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVmVyc2lvbjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlcicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXIob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlciB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1dGgnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoKG9iai5hdXRoKSxcbiAgICAnY2FCdW5kbGUnOiBvYmouY2FCdW5kbGUsXG4gICAgJ2NhUHJvdmlkZXInOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyKG9iai5jYVByb3ZpZGVyKSxcbiAgICAnZm9yd2FyZEluY29uc2lzdGVudCc6IG9iai5mb3J3YXJkSW5jb25zaXN0ZW50LFxuICAgICdoZWFkZXJzJzogKChvYmouaGVhZGVycykgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLmhlYWRlcnMpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSkpLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICAgICdwYXRoJzogb2JqLnBhdGgsXG4gICAgJ3JlYWRZb3VyV3JpdGVzJzogb2JqLnJlYWRZb3VyV3JpdGVzLFxuICAgICdzZXJ2ZXInOiBvYmouc2VydmVyLFxuICAgICd0bHMnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHMob2JqLnRscyksXG4gICAgJ3ZlcnNpb24nOiBvYmoudmVyc2lvbixcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBSZXN1bHQgdHlwZSBkZWZpbmVzIHdoaWNoIGRhdGEgaXMgcmV0dXJuZWQgZnJvbSB0aGUgZ2VuZXJhdG9yLlxuICogQnkgZGVmYXVsdCBpdCBpcyB0aGUgXCJkYXRhXCIgc2VjdGlvbiBvZiB0aGUgVmF1bHQgQVBJIHJlc3BvbnNlLlxuICogV2hlbiB1c2luZyBlLmcuIC9hdXRoL3Rva2VuL2NyZWF0ZSB0aGUgXCJkYXRhXCIgc2VjdGlvbiBpcyBlbXB0eSBidXRcbiAqIHRoZSBcImF1dGhcIiBzZWN0aW9uIGNvbnRhaW5zIHRoZSBnZW5lcmF0ZWQgdG9rZW4uXG4gKiBQbGVhc2UgcmVmZXIgdG8gdGhlIHZhdWx0IGRvY3MgcmVnYXJkaW5nIHRoZSByZXN1bHQgZGF0YSBzdHJ1Y3R1cmUuXG4gKiBBZGRpdGlvbmFsbHksIGFjY2Vzc2luZyB0aGUgcmF3IHJlc3BvbnNlIGlzIHBvc3NpYmx5IGJ5IHVzaW5nIFwiUmF3XCIgcmVzdWx0IHR5cGUuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNSZXN1bHRUeXBlXG4gKi9cbmV4cG9ydCBlbnVtIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Jlc3VsdFR5cGUge1xuICAvKiogRGF0YSAqL1xuICBEQVRBID0gXCJEYXRhXCIsXG4gIC8qKiBBdXRoICovXG4gIEFVVEggPSBcIkF1dGhcIixcbiAgLyoqIFJhdyAqL1xuICBSQVcgPSBcIlJhd1wiLFxufVxuXG4vKipcbiAqIFVzZWQgdG8gY29uZmlndXJlIGh0dHAgcmV0cmllcyBpZiBmYWlsZWRcbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1JldHJ5U2V0dGluZ3NcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNSZXRyeVNldHRpbmdzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUmV0cnlTZXR0aW5ncyNtYXhSZXRyaWVzXG4gICAqL1xuICByZWFkb25seSBtYXhSZXRyaWVzPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1JldHJ5U2V0dGluZ3MjcmV0cnlJbnRlcnZhbFxuICAgKi9cbiAgcmVhZG9ubHkgcmV0cnlJbnRlcnZhbD86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNSZXRyeVNldHRpbmdzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNSZXRyeVNldHRpbmdzKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUmV0cnlTZXR0aW5ncyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ21heFJldHJpZXMnOiBvYmoubWF4UmV0cmllcyxcbiAgICAncmV0cnlJbnRlcnZhbCc6IG9iai5yZXRyeUludGVydmFsLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBwcm92aWRlciBmb3IgdGhlIENBIGJ1bmRsZSB0byB1c2UgdG8gdmFsaWRhdGUgd2ViaG9vayBzZXJ2ZXIgY2VydGlmaWNhdGUuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjQ2FQcm92aWRlclxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNDYVByb3ZpZGVyIHtcbiAgLyoqXG4gICAqIFRoZSBrZXkgd2hlcmUgdGhlIENBIGNlcnRpZmljYXRlIGNhbiBiZSBmb3VuZCBpbiB0aGUgU2VjcmV0IG9yIENvbmZpZ01hcC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjQ2FQcm92aWRlciNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIG9iamVjdCBsb2NhdGVkIGF0IHRoZSBwcm92aWRlciB0eXBlLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNDYVByb3ZpZGVyI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSB0aGUgUHJvdmlkZXIgdHlwZSBpcyBpbi5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjQ2FQcm92aWRlciNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHR5cGUgb2YgcHJvdmlkZXIgdG8gdXNlIHN1Y2ggYXMgXCJTZWNyZXRcIiwgb3IgXCJDb25maWdNYXBcIi5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjQ2FQcm92aWRlciN0eXBlXG4gICAqL1xuICByZWFkb25seSB0eXBlOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjQ2FQcm92aWRlclR5cGU7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY0NhUHJvdmlkZXInIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNDYVByb3ZpZGVyKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY0NhUHJvdmlkZXIgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gICAgJ3R5cGUnOiBvYmoudHlwZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBSZXN1bHQgZm9ybWF0dGluZ1xuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY1Jlc3VsdFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNSZXN1bHQge1xuICAvKipcbiAgICogSnNvbiBwYXRoIG9mIHJldHVybiB2YWx1ZVxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNSZXN1bHQjanNvblBhdGhcbiAgICovXG4gIHJlYWRvbmx5IGpzb25QYXRoPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNSZXN1bHQnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNSZXN1bHQob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjUmVzdWx0IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnanNvblBhdGgnOiBvYmouanNvblBhdGgsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjU2VjcmV0c1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNTZWNyZXRzIHtcbiAgLyoqXG4gICAqIE5hbWUgb2YgdGhpcyBzZWNyZXQgaW4gdGVtcGxhdGVzXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY1NlY3JldHMjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTZWNyZXQgcmVmIHRvIGZpbGwgaW4gY3JlZGVudGlhbHNcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjU2VjcmV0cyNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZjogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY1NlY3JldHNTZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY1NlY3JldHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNTZWNyZXRzKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY1NlY3JldHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ3NlY3JldFJlZic6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjU2VjcmV0c1NlY3JldFJlZihvYmouc2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBNYW5hZ2VkSWRlbnRpdHkgdXNlcyBBenVyZSBNYW5hZ2VkIElkZW50aXR5IHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEF6dXJlLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoTWFuYWdlZElkZW50aXR5XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoTWFuYWdlZElkZW50aXR5IHtcbiAgLyoqXG4gICAqIElmIG11bHRpcGxlIE1hbmFnZWQgSWRlbnRpdHkgaXMgYXNzaWduZWQgdG8gdGhlIHBvZCwgeW91IGNhbiBzZWxlY3QgdGhlIG9uZSB0byBiZSB1c2VkXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoTWFuYWdlZElkZW50aXR5I2lkZW50aXR5SWRcbiAgICovXG4gIHJlYWRvbmx5IGlkZW50aXR5SWQ/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoTWFuYWdlZElkZW50aXR5JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhNYW5hZ2VkSWRlbnRpdHkob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhNYW5hZ2VkSWRlbnRpdHkgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdpZGVudGl0eUlkJzogb2JqLmlkZW50aXR5SWQsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VydmljZVByaW5jaXBhbCB1c2VzIEF6dXJlIFNlcnZpY2UgUHJpbmNpcGFsIGNyZWRlbnRpYWxzIHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEF6dXJlLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWwge1xuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiB1c2VkIHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEF6dXJlIHVzaW5nIHN0YXRpY1xuICAgKiBjcmVkZW50aWFscyBzdG9yZWQgaW4gYSBLaW5kPVNlY3JldC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsI3NlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0UmVmOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWwnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWwob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogV29ya2xvYWRJZGVudGl0eSB1c2VzIEF6dXJlIFdvcmtsb2FkIElkZW50aXR5IHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEF6dXJlLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkge1xuICAvKipcbiAgICogU2VydmljZUFjY291bnRSZWYgc3BlY2lmaWVkIHRoZSBzZXJ2aWNlIGFjY291bnRcbiAgICogdGhhdCBzaG91bGQgYmUgdXNlZCB3aGVuIGF1dGhlbnRpY2F0aW5nIHdpdGggV29ya2xvYWRJZGVudGl0eS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5I3NlcnZpY2VBY2NvdW50UmVmXG4gICAqL1xuICByZWFkb25seSBzZXJ2aWNlQWNjb3VudFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5KG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eSB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3NlcnZpY2VBY2NvdW50UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZihvYmouc2VydmljZUFjY291bnRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEF1dGhlbnRpY2F0ZSBhZ2FpbnN0IEFXUyB1c2luZyBzZXJ2aWNlIGFjY291bnQgdG9rZW5zLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhKd3Qge1xuICAvKipcbiAgICogQSByZWZlcmVuY2UgdG8gYSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0I3NlcnZpY2VBY2NvdW50UmVmXG4gICAqL1xuICByZWFkb25seSBzZXJ2aWNlQWNjb3VudFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhKd3RTZXJ2aWNlQWNjb3VudFJlZjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0KG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3NlcnZpY2VBY2NvdW50UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhKd3RTZXJ2aWNlQWNjb3VudFJlZihvYmouc2VydmljZUFjY291bnRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEFXU0F1dGhTZWNyZXRSZWYgaG9sZHMgc2VjcmV0IHJlZmVyZW5jZXMgZm9yIEFXUyBjcmVkZW50aWFsc1xuICogYm90aCBBY2Nlc3NLZXlJRCBhbmQgU2VjcmV0QWNjZXNzS2V5IG11c3QgYmUgZGVmaW5lZCBpbiBvcmRlciB0byBwcm9wZXJseSBhdXRoZW50aWNhdGUuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBUaGUgQWNjZXNzS2V5SUQgaXMgdXNlZCBmb3IgYXV0aGVudGljYXRpb25cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmI2FjY2Vzc0tleUlEU2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBhY2Nlc3NLZXlJZFNlY3JldFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZjtcblxuICAvKipcbiAgICogVGhlIFNlY3JldEFjY2Vzc0tleSBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYjc2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWY/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmO1xuXG4gIC8qKlxuICAgKiBUaGUgU2Vzc2lvblRva2VuIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gICAqIFRoaXMgbXVzdCBiZSBkZWZpbmVkIGlmIEFjY2Vzc0tleUlEIGFuZCBTZWNyZXRBY2Nlc3NLZXkgYXJlIHRlbXBvcmFyeSBjcmVkZW50aWFsc1xuICAgKiBzZWU6IGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9JQU0vbGF0ZXN0L1VzZXJHdWlkZS9pZF9jcmVkZW50aWFsc190ZW1wX3VzZS1yZXNvdXJjZXMuaHRtbFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYjc2Vzc2lvblRva2VuU2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBzZXNzaW9uVG9rZW5TZWNyZXRSZWY/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYWNjZXNzS2V5SURTZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmKG9iai5hY2Nlc3NLZXlJZFNlY3JldFJlZiksXG4gICAgJ3NlY3JldEFjY2Vzc0tleVNlY3JldFJlZic6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmKG9iai5zZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYpLFxuICAgICdzZXNzaW9uVG9rZW5TZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZihvYmouc2Vzc2lvblRva2VuU2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBUaGUgU2VjcmV0QWNjZXNzS2V5IGlzIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmI3NlY3JldEFjY2Vzc0tleVNlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZihvYmouc2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5IHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eSNjbHVzdGVyTG9jYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IGNsdXN0ZXJMb2NhdGlvbjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkjY2x1c3Rlck5hbWVcbiAgICovXG4gIHJlYWRvbmx5IGNsdXN0ZXJOYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eSNjbHVzdGVyUHJvamVjdElEXG4gICAqL1xuICByZWFkb25seSBjbHVzdGVyUHJvamVjdElkPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBBIHJlZmVyZW5jZSB0byBhIFNlcnZpY2VBY2NvdW50IHJlc291cmNlLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkjc2VydmljZUFjY291bnRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlcnZpY2VBY2NvdW50UmVmOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5U2VydmljZUFjY291bnRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eShvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdjbHVzdGVyTG9jYXRpb24nOiBvYmouY2x1c3RlckxvY2F0aW9uLFxuICAgICdjbHVzdGVyTmFtZSc6IG9iai5jbHVzdGVyTmFtZSxcbiAgICAnY2x1c3RlclByb2plY3RJRCc6IG9iai5jbHVzdGVyUHJvamVjdElkLFxuICAgICdzZXJ2aWNlQWNjb3VudFJlZic6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5U2VydmljZUFjY291bnRSZWYob2JqLnNlcnZpY2VBY2NvdW50UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXlcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5IHtcbiAgLyoqXG4gICAqIEEgcmVmZXJlbmNlIHRvIGEgc3BlY2lmaWMgJ2tleScgd2l0aGluIGEgU2VjcmV0IHJlc291cmNlLlxuICAgKiBJbiBzb21lIGluc3RhbmNlcywgYGtleWAgaXMgYSByZXF1aXJlZCBmaWVsZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5I3NlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0UmVmOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5U2VjcmV0UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXknIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXkob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXlTZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQmFzaWMgYXV0aCBjcmVkZW50aWFscyB1c2VkIHRvIGF1dGhlbnRpY2F0ZSBhZ2FpbnN0IHRoZSBHcmFmYW5hIGluc3RhbmNlLlxuICogTm90ZTogeW91IG5lZWQgYSB0b2tlbiB3aGljaCBoYXMgZWxldmF0ZWQgcGVybWlzc2lvbnMgdG8gY3JlYXRlIHNlcnZpY2UgYWNjb3VudHMuXG4gKiBTZWUgaGVyZSBmb3IgdGhlIGRvY3VtZW50YXRpb24gb24gYmFzaWMgcm9sZXMgb2ZmZXJlZCBieSBHcmFmYW5hOlxuICogaHR0cHM6Ly9ncmFmYW5hLmNvbS9kb2NzL2dyYWZhbmEvbGF0ZXN0L2FkbWluaXN0cmF0aW9uL3JvbGVzLWFuZC1wZXJtaXNzaW9ucy9hY2Nlc3MtY29udHJvbC9yYmFjLWZpeGVkLWJhc2ljLXJvbGUtZGVmaW5pdGlvbnMvXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjQXV0aEJhc2ljXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGhCYXNpYyB7XG4gIC8qKlxuICAgKiBBIGJhc2ljIGF1dGggcGFzc3dvcmQgdXNlZCB0byBhdXRoZW50aWNhdGUgYWdhaW5zdCB0aGUgR3JhZmFuYSBpbnN0YW5jZS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjQXV0aEJhc2ljI3Bhc3N3b3JkXG4gICAqL1xuICByZWFkb25seSBwYXNzd29yZDogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGhCYXNpY1Bhc3N3b3JkO1xuXG4gIC8qKlxuICAgKiBBIGJhc2ljIGF1dGggdXNlcm5hbWUgdXNlZCB0byBhdXRoZW50aWNhdGUgYWdhaW5zdCB0aGUgR3JhZmFuYSBpbnN0YW5jZS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjQXV0aEJhc2ljI3VzZXJuYW1lXG4gICAqL1xuICByZWFkb25seSB1c2VybmFtZTogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoQmFzaWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoQmFzaWMob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjQXV0aEJhc2ljIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAncGFzc3dvcmQnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGhCYXNpY1Bhc3N3b3JkKG9iai5wYXNzd29yZCksXG4gICAgJ3VzZXJuYW1lJzogb2JqLnVzZXJuYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEEgc2VydmljZSBhY2NvdW50IHRva2VuIHVzZWQgdG8gYXV0aGVudGljYXRlIGFnYWluc3QgdGhlIEdyYWZhbmEgaW5zdGFuY2UuXG4gKiBOb3RlOiB5b3UgbmVlZCBhIHRva2VuIHdoaWNoIGhhcyBlbGV2YXRlZCBwZXJtaXNzaW9ucyB0byBjcmVhdGUgc2VydmljZSBhY2NvdW50cy5cbiAqIFNlZSBoZXJlIGZvciB0aGUgZG9jdW1lbnRhdGlvbiBvbiBiYXNpYyByb2xlcyBvZmZlcmVkIGJ5IEdyYWZhbmE6XG4gKiBodHRwczovL2dyYWZhbmEuY29tL2RvY3MvZ3JhZmFuYS9sYXRlc3QvYWRtaW5pc3RyYXRpb24vcm9sZXMtYW5kLXBlcm1pc3Npb25zL2FjY2Vzcy1jb250cm9sL3JiYWMtZml4ZWQtYmFzaWMtcm9sZS1kZWZpbml0aW9ucy9cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoVG9rZW5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjQXV0aFRva2VuIHtcbiAgLyoqXG4gICAqIFRoZSBrZXkgd2hlcmUgdGhlIHRva2VuIGlzIGZvdW5kLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoVG9rZW4ja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGhUb2tlbiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoVG9rZW4nIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoVG9rZW4ob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjQXV0aFRva2VuIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEF1dGhlbnRpY2F0ZSBhZ2FpbnN0IEFXUyB1c2luZyBzZXJ2aWNlIGFjY291bnQgdG9rZW5zLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhKd3Qge1xuICAvKipcbiAgICogQSByZWZlcmVuY2UgdG8gYSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0I3NlcnZpY2VBY2NvdW50UmVmXG4gICAqL1xuICByZWFkb25seSBzZXJ2aWNlQWNjb3VudFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhKd3RTZXJ2aWNlQWNjb3VudFJlZjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0KG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3NlcnZpY2VBY2NvdW50UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhKd3RTZXJ2aWNlQWNjb3VudFJlZihvYmouc2VydmljZUFjY291bnRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEFXU0F1dGhTZWNyZXRSZWYgaG9sZHMgc2VjcmV0IHJlZmVyZW5jZXMgZm9yIEFXUyBjcmVkZW50aWFsc1xuICogYm90aCBBY2Nlc3NLZXlJRCBhbmQgU2VjcmV0QWNjZXNzS2V5IG11c3QgYmUgZGVmaW5lZCBpbiBvcmRlciB0byBwcm9wZXJseSBhdXRoZW50aWNhdGUuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBUaGUgQWNjZXNzS2V5SUQgaXMgdXNlZCBmb3IgYXV0aGVudGljYXRpb25cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmI2FjY2Vzc0tleUlEU2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBhY2Nlc3NLZXlJZFNlY3JldFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZjtcblxuICAvKipcbiAgICogVGhlIFNlY3JldEFjY2Vzc0tleSBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYjc2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWY/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmO1xuXG4gIC8qKlxuICAgKiBUaGUgU2Vzc2lvblRva2VuIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gICAqIFRoaXMgbXVzdCBiZSBkZWZpbmVkIGlmIEFjY2Vzc0tleUlEIGFuZCBTZWNyZXRBY2Nlc3NLZXkgYXJlIHRlbXBvcmFyeSBjcmVkZW50aWFsc1xuICAgKiBzZWU6IGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9JQU0vbGF0ZXN0L1VzZXJHdWlkZS9pZF9jcmVkZW50aWFsc190ZW1wX3VzZS1yZXNvdXJjZXMuaHRtbFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYjc2Vzc2lvblRva2VuU2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBzZXNzaW9uVG9rZW5TZWNyZXRSZWY/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYWNjZXNzS2V5SURTZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmKG9iai5hY2Nlc3NLZXlJZFNlY3JldFJlZiksXG4gICAgJ3NlY3JldEFjY2Vzc0tleVNlY3JldFJlZic6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmKG9iai5zZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYpLFxuICAgICdzZXNzaW9uVG9rZW5TZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZihvYmouc2Vzc2lvblRva2VuU2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBdXRoIGNvbmZpZ3VyZXMgaG93IHNlY3JldC1tYW5hZ2VyIGF1dGhlbnRpY2F0ZXMgd2l0aCB0aGUgVmF1bHQgc2VydmVyLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoIHtcbiAgLyoqXG4gICAqIEFwcFJvbGUgYXV0aGVudGljYXRlcyB3aXRoIFZhdWx0IHVzaW5nIHRoZSBBcHAgUm9sZSBhdXRoIG1lY2hhbmlzbSxcbiAgICogd2l0aCB0aGUgcm9sZSBhbmQgc2VjcmV0IHN0b3JlZCBpbiBhIEt1YmVybmV0ZXMgU2VjcmV0IHJlc291cmNlLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aCNhcHBSb2xlXG4gICAqL1xuICByZWFkb25seSBhcHBSb2xlPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZTtcblxuICAvKipcbiAgICogQ2VydCBhdXRoZW50aWNhdGVzIHdpdGggVExTIENlcnRpZmljYXRlcyBieSBwYXNzaW5nIGNsaWVudCBjZXJ0aWZpY2F0ZSwgcHJpdmF0ZSBrZXkgYW5kIGNhIGNlcnRpZmljYXRlXG4gICAqIENlcnQgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoI2NlcnRcbiAgICovXG4gIHJlYWRvbmx5IGNlcnQ/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0O1xuXG4gIC8qKlxuICAgKiBJYW0gYXV0aGVudGljYXRlcyB3aXRoIHZhdWx0IGJ5IHBhc3NpbmcgYSBzcGVjaWFsIEFXUyByZXF1ZXN0IHNpZ25lZCB3aXRoIEFXUyBJQU0gY3JlZGVudGlhbHNcbiAgICogQVdTIElBTSBhdXRoZW50aWNhdGlvbiBtZXRob2RcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGgjaWFtXG4gICAqL1xuICByZWFkb25seSBpYW0/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW07XG5cbiAgLyoqXG4gICAqIEp3dCBhdXRoZW50aWNhdGVzIHdpdGggVmF1bHQgYnkgcGFzc2luZyByb2xlIGFuZCBKV1QgdG9rZW4gdXNpbmcgdGhlXG4gICAqIEpXVC9PSURDIGF1dGhlbnRpY2F0aW9uIG1ldGhvZFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aCNqd3RcbiAgICovXG4gIHJlYWRvbmx5IGp3dD86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dDtcblxuICAvKipcbiAgICogS3ViZXJuZXRlcyBhdXRoZW50aWNhdGVzIHdpdGggVmF1bHQgYnkgcGFzc2luZyB0aGUgU2VydmljZUFjY291bnRcbiAgICogdG9rZW4gc3RvcmVkIGluIHRoZSBuYW1lZCBTZWNyZXQgcmVzb3VyY2UgdG8gdGhlIFZhdWx0IHNlcnZlci5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGgja3ViZXJuZXRlc1xuICAgKi9cbiAgcmVhZG9ubHkga3ViZXJuZXRlcz86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXM7XG5cbiAgLyoqXG4gICAqIExkYXAgYXV0aGVudGljYXRlcyB3aXRoIFZhdWx0IGJ5IHBhc3NpbmcgdXNlcm5hbWUvcGFzc3dvcmQgcGFpciB1c2luZ1xuICAgKiB0aGUgTERBUCBhdXRoZW50aWNhdGlvbiBtZXRob2RcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGgjbGRhcFxuICAgKi9cbiAgcmVhZG9ubHkgbGRhcD86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXA7XG5cbiAgLyoqXG4gICAqIE5hbWUgb2YgdGhlIHZhdWx0IG5hbWVzcGFjZSB0byBhdXRoZW50aWNhdGUgdG8uIFRoaXMgY2FuIGJlIGRpZmZlcmVudCB0aGFuIHRoZSBuYW1lc3BhY2UgeW91ciBzZWNyZXQgaXMgaW4uXG4gICAqIE5hbWVzcGFjZXMgaXMgYSBzZXQgb2YgZmVhdHVyZXMgd2l0aGluIFZhdWx0IEVudGVycHJpc2UgdGhhdCBhbGxvd3NcbiAgICogVmF1bHQgZW52aXJvbm1lbnRzIHRvIHN1cHBvcnQgU2VjdXJlIE11bHRpLXRlbmFuY3kuIGUuZzogXCJuczFcIi5cbiAgICogTW9yZSBhYm91dCBuYW1lc3BhY2VzIGNhbiBiZSBmb3VuZCBoZXJlIGh0dHBzOi8vd3d3LnZhdWx0cHJvamVjdC5pby9kb2NzL2VudGVycHJpc2UvbmFtZXNwYWNlc1xuICAgKiBUaGlzIHdpbGwgZGVmYXVsdCB0byBWYXVsdC5OYW1lc3BhY2UgZmllbGQgaWYgc2V0LCBvciBlbXB0eSBvdGhlcndpc2VcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGgjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRva2VuU2VjcmV0UmVmIGF1dGhlbnRpY2F0ZXMgd2l0aCBWYXVsdCBieSBwcmVzZW50aW5nIGEgdG9rZW4uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoI3Rva2VuU2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSB0b2tlblNlY3JldFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFRva2VuU2VjcmV0UmVmO1xuXG4gIC8qKlxuICAgKiBVc2VyUGFzcyBhdXRoZW50aWNhdGVzIHdpdGggVmF1bHQgYnkgcGFzc2luZyB1c2VybmFtZS9wYXNzd29yZCBwYWlyXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoI3VzZXJQYXNzXG4gICAqL1xuICByZWFkb25seSB1c2VyUGFzcz86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFVzZXJQYXNzO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXBwUm9sZSc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlKG9iai5hcHBSb2xlKSxcbiAgICAnY2VydCc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0KG9iai5jZXJ0KSxcbiAgICAnaWFtJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbShvYmouaWFtKSxcbiAgICAnand0JzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dChvYmouand0KSxcbiAgICAna3ViZXJuZXRlcyc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzKG9iai5rdWJlcm5ldGVzKSxcbiAgICAnbGRhcCc6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwKG9iai5sZGFwKSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgICAndG9rZW5TZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVG9rZW5TZWNyZXRSZWYob2JqLnRva2VuU2VjcmV0UmVmKSxcbiAgICAndXNlclBhc3MnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3Mob2JqLnVzZXJQYXNzKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgcHJvdmlkZXIgZm9yIHRoZSBDQSBidW5kbGUgdG8gdXNlIHRvIHZhbGlkYXRlIFZhdWx0IHNlcnZlciBjZXJ0aWZpY2F0ZS5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQ2FQcm92aWRlclxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQ2FQcm92aWRlciB7XG4gIC8qKlxuICAgKiBUaGUga2V5IHdoZXJlIHRoZSBDQSBjZXJ0aWZpY2F0ZSBjYW4gYmUgZm91bmQgaW4gdGhlIFNlY3JldCBvciBDb25maWdNYXAuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgb2JqZWN0IGxvY2F0ZWQgYXQgdGhlIHByb3ZpZGVyIHR5cGUuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSB0aGUgUHJvdmlkZXIgdHlwZSBpcyBpbi5cbiAgICogQ2FuIG9ubHkgYmUgZGVmaW5lZCB3aGVuIHVzZWQgaW4gYSBDbHVzdGVyU2VjcmV0U3RvcmUuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdHlwZSBvZiBwcm92aWRlciB0byB1c2Ugc3VjaCBhcyBcIlNlY3JldFwiLCBvciBcIkNvbmZpZ01hcFwiLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQ2FQcm92aWRlciN0eXBlXG4gICAqL1xuICByZWFkb25seSB0eXBlOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckNhUHJvdmlkZXJUeXBlO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQ2FQcm92aWRlcicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICAgICd0eXBlJzogb2JqLnR5cGUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIGNvbmZpZ3VyYXRpb24gdXNlZCBmb3IgY2xpZW50IHNpZGUgcmVsYXRlZCBUTFMgY29tbXVuaWNhdGlvbiwgd2hlbiB0aGUgVmF1bHQgc2VydmVyXG4gKiByZXF1aXJlcyBtdXR1YWwgYXV0aGVudGljYXRpb24uIE9ubHkgdXNlZCBpZiB0aGUgU2VydmVyIFVSTCBpcyB1c2luZyBIVFRQUyBwcm90b2NvbC5cbiAqIFRoaXMgcGFyYW1ldGVyIGlzIGlnbm9yZWQgZm9yIHBsYWluIEhUVFAgcHJvdG9jb2wgY29ubmVjdGlvbi5cbiAqIEl0J3Mgd29ydGggbm90aW5nIHRoaXMgY29uZmlndXJhdGlvbiBpcyBkaWZmZXJlbnQgZnJvbSB0aGUgXCJUTFMgY2VydGlmaWNhdGVzIGF1dGggbWV0aG9kXCIsXG4gKiB3aGljaCBpcyBhdmFpbGFibGUgdW5kZXIgdGhlIGBhdXRoLmNlcnRgIHNlY3Rpb24uXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzIHtcbiAgLyoqXG4gICAqIENlcnRTZWNyZXRSZWYgaXMgYSBjZXJ0aWZpY2F0ZSBhZGRlZCB0byB0aGUgdHJhbnNwb3J0IGxheWVyXG4gICAqIHdoZW4gY29tbXVuaWNhdGluZyB3aXRoIHRoZSBWYXVsdCBzZXJ2ZXIuXG4gICAqIElmIG5vIGtleSBmb3IgdGhlIFNlY3JldCBpcyBzcGVjaWZpZWQsIGV4dGVybmFsLXNlY3JldCB3aWxsIGRlZmF1bHQgdG8gJ3Rscy5jcnQnLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzI2NlcnRTZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IGNlcnRTZWNyZXRSZWY/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0NlcnRTZWNyZXRSZWY7XG5cbiAgLyoqXG4gICAqIEtleVNlY3JldFJlZiB0byBhIGtleSBpbiBhIFNlY3JldCByZXNvdXJjZSBjb250YWluaW5nIGNsaWVudCBwcml2YXRlIGtleVxuICAgKiBhZGRlZCB0byB0aGUgdHJhbnNwb3J0IGxheWVyIHdoZW4gY29tbXVuaWNhdGluZyB3aXRoIHRoZSBWYXVsdCBzZXJ2ZXIuXG4gICAqIElmIG5vIGtleSBmb3IgdGhlIFNlY3JldCBpcyBzcGVjaWZpZWQsIGV4dGVybmFsLXNlY3JldCB3aWxsIGRlZmF1bHQgdG8gJ3Rscy5rZXknLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzI2tleVNlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkga2V5U2VjcmV0UmVmPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNLZXlTZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdjZXJ0U2VjcmV0UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzQ2VydFNlY3JldFJlZihvYmouY2VydFNlY3JldFJlZiksXG4gICAgJ2tleVNlY3JldFJlZic6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0tleVNlY3JldFJlZihvYmoua2V5U2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBWZXJzaW9uIGlzIHRoZSBWYXVsdCBLViBzZWNyZXQgZW5naW5lIHZlcnNpb24uIFRoaXMgY2FuIGJlIGVpdGhlciBcInYxXCIgb3JcbiAqIFwidjJcIi4gVmVyc2lvbiBkZWZhdWx0cyB0byBcInYyXCIuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclZlcnNpb25cbiAqL1xuZXhwb3J0IGVudW0gQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJWZXJzaW9uIHtcbiAgLyoqIHYxICovXG4gIFYxID0gXCJ2MVwiLFxuICAvKiogdjIgKi9cbiAgVjIgPSBcInYyXCIsXG59XG5cbi8qKlxuICogVGhlIHR5cGUgb2YgcHJvdmlkZXIgdG8gdXNlIHN1Y2ggYXMgXCJTZWNyZXRcIiwgb3IgXCJDb25maWdNYXBcIi5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNDYVByb3ZpZGVyVHlwZVxuICovXG5leHBvcnQgZW51bSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjQ2FQcm92aWRlclR5cGUge1xuICAvKiogU2VjcmV0ICovXG4gIFNFQ1JFVCA9IFwiU2VjcmV0XCIsXG4gIC8qKiBDb25maWdNYXAgKi9cbiAgQ09ORklHX01BUCA9IFwiQ29uZmlnTWFwXCIsXG59XG5cbi8qKlxuICogU2VjcmV0IHJlZiB0byBmaWxsIGluIGNyZWRlbnRpYWxzXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvcldlYmhvb2tTcGVjU2VjcmV0c1NlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNTZWNyZXRzU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIFRoZSBrZXkgd2hlcmUgdGhlIHRva2VuIGlzIGZvdW5kLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNTZWNyZXRzU2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNTZWNyZXRzU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY1NlY3JldHNTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yV2ViaG9va1NwZWNTZWNyZXRzU2VjcmV0UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JXZWJob29rU3BlY1NlY3JldHNTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiB1c2VkIHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEF6dXJlIHVzaW5nIHN0YXRpY1xuICogY3JlZGVudGlhbHMgc3RvcmVkIGluIGEgS2luZD1TZWNyZXQuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBUaGUgQXp1cmUgY2xpZW50SWQgb2YgdGhlIHNlcnZpY2UgcHJpbmNpcGxlIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWYjY2xpZW50SWRcbiAgICovXG4gIHJlYWRvbmx5IGNsaWVudElkPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudElkO1xuXG4gIC8qKlxuICAgKiBUaGUgQXp1cmUgQ2xpZW50U2VjcmV0IG9mIHRoZSBzZXJ2aWNlIHByaW5jaXBsZSB1c2VkIGZvciBhdXRoZW50aWNhdGlvbi5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmI2NsaWVudFNlY3JldFxuICAgKi9cbiAgcmVhZG9ubHkgY2xpZW50U2VjcmV0PzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudFNlY3JldDtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2NsaWVudElkJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRJZChvYmouY2xpZW50SWQpLFxuICAgICdjbGllbnRTZWNyZXQnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudFNlY3JldChvYmouY2xpZW50U2VjcmV0KSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBTZXJ2aWNlQWNjb3VudFJlZiBzcGVjaWZpZWQgdGhlIHNlcnZpY2UgYWNjb3VudFxuICogdGhhdCBzaG91bGQgYmUgdXNlZCB3aGVuIGF1dGhlbnRpY2F0aW5nIHdpdGggV29ya2xvYWRJZGVudGl0eS5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZiB7XG4gIC8qKlxuICAgKiBBdWRpZW5jZSBzcGVjaWZpZXMgdGhlIGBhdWRgIGNsYWltIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHRva2VuXG4gICAqIElmIHRoZSBzZXJ2aWNlIGFjY291bnQgdXNlcyBhIHdlbGwta25vd24gYW5ub3RhdGlvbiBmb3IgZS5nLiBJUlNBIG9yIEdDUCBXb3JrbG9hZCBJZGVudGl0eVxuICAgKiB0aGVuIHRoaXMgYXVkaWVuY2VzIHdpbGwgYmUgYXBwZW5kZWQgdG8gdGhlIGxpc3RcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5U2VydmljZUFjY291bnRSZWYjYXVkaWVuY2VzXG4gICAqL1xuICByZWFkb25seSBhdWRpZW5jZXM/OiBzdHJpbmdbXTtcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlcnZpY2VBY2NvdW50IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIE5hbWVzcGFjZSBvZiB0aGUgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXVkaWVuY2VzJzogb2JqLmF1ZGllbmNlcz8ubWFwKHkgPT4geSksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBIHJlZmVyZW5jZSB0byBhIFNlcnZpY2VBY2NvdW50IHJlc291cmNlLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmIHtcbiAgLyoqXG4gICAqIEF1ZGllbmNlIHNwZWNpZmllcyB0aGUgYGF1ZGAgY2xhaW0gZm9yIHRoZSBzZXJ2aWNlIGFjY291bnQgdG9rZW5cbiAgICogSWYgdGhlIHNlcnZpY2UgYWNjb3VudCB1c2VzIGEgd2VsbC1rbm93biBhbm5vdGF0aW9uIGZvciBlLmcuIElSU0Egb3IgR0NQIFdvcmtsb2FkIElkZW50aXR5XG4gICAqIHRoZW4gdGhpcyBhdWRpZW5jZXMgd2lsbCBiZSBhcHBlbmRlZCB0byB0aGUgbGlzdFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhKd3RTZXJ2aWNlQWNjb3VudFJlZiNhdWRpZW5jZXNcbiAgICovXG4gIHJlYWRvbmx5IGF1ZGllbmNlcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VydmljZUFjY291bnQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZXNwYWNlIG9mIHRoZSByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0U2VydmljZUFjY291bnRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0U2VydmljZUFjY291bnRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0U2VydmljZUFjY291bnRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhdWRpZW5jZXMnOiBvYmouYXVkaWVuY2VzPy5tYXAoeSA9PiB5KSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBBY2Nlc3NLZXlJRCBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZihvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgU2VjcmV0QWNjZXNzS2V5IGlzIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZihvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIFNlc3Npb25Ub2tlbiB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICogVGhpcyBtdXN0IGJlIGRlZmluZWQgaWYgQWNjZXNzS2V5SUQgYW5kIFNlY3JldEFjY2Vzc0tleSBhcmUgdGVtcG9yYXJ5IGNyZWRlbnRpYWxzXG4gKiBzZWU6IGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9JQU0vbGF0ZXN0L1VzZXJHdWlkZS9pZF9jcmVkZW50aWFsc190ZW1wX3VzZS1yZXNvdXJjZXMuaHRtbFxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBTZWNyZXRBY2Nlc3NLZXkgaXMgdXNlZCBmb3IgYXV0aGVudGljYXRpb25cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQSByZWZlcmVuY2UgdG8gYSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZS5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZiB7XG4gIC8qKlxuICAgKiBBdWRpZW5jZSBzcGVjaWZpZXMgdGhlIGBhdWRgIGNsYWltIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHRva2VuXG4gICAqIElmIHRoZSBzZXJ2aWNlIGFjY291bnQgdXNlcyBhIHdlbGwta25vd24gYW5ub3RhdGlvbiBmb3IgZS5nLiBJUlNBIG9yIEdDUCBXb3JrbG9hZCBJZGVudGl0eVxuICAgKiB0aGVuIHRoaXMgYXVkaWVuY2VzIHdpbGwgYmUgYXBwZW5kZWQgdG8gdGhlIGxpc3RcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5U2VydmljZUFjY291bnRSZWYjYXVkaWVuY2VzXG4gICAqL1xuICByZWFkb25seSBhdWRpZW5jZXM/OiBzdHJpbmdbXTtcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlcnZpY2VBY2NvdW50IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIE5hbWVzcGFjZSBvZiB0aGUgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXVkaWVuY2VzJzogb2JqLmF1ZGllbmNlcz8ubWFwKHkgPT4geSksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBIHJlZmVyZW5jZSB0byBhIHNwZWNpZmljICdrZXknIHdpdGhpbiBhIFNlY3JldCByZXNvdXJjZS5cbiAqIEluIHNvbWUgaW5zdGFuY2VzLCBga2V5YCBpcyBhIHJlcXVpcmVkIGZpZWxkLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoUHJpdmF0ZUtleVNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXlTZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoUHJpdmF0ZUtleVNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5U2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5U2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXlTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXlTZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5U2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEEgYmFzaWMgYXV0aCBwYXNzd29yZCB1c2VkIHRvIGF1dGhlbnRpY2F0ZSBhZ2FpbnN0IHRoZSBHcmFmYW5hIGluc3RhbmNlLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGhCYXNpY1Bhc3N3b3JkXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JHcmFmYW5hU3BlY0F1dGhCYXNpY1Bhc3N3b3JkIHtcbiAgLyoqXG4gICAqIFRoZSBrZXkgd2hlcmUgdGhlIHRva2VuIGlzIGZvdW5kLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoQmFzaWNQYXNzd29yZCNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjQXV0aEJhc2ljUGFzc3dvcmQjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckdyYWZhbmFTcGVjQXV0aEJhc2ljUGFzc3dvcmQnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoQmFzaWNQYXNzd29yZChvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yR3JhZmFuYVNwZWNBdXRoQmFzaWNQYXNzd29yZCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBIHJlZmVyZW5jZSB0byBhIFNlcnZpY2VBY2NvdW50IHJlc291cmNlLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmIHtcbiAgLyoqXG4gICAqIEF1ZGllbmNlIHNwZWNpZmllcyB0aGUgYGF1ZGAgY2xhaW0gZm9yIHRoZSBzZXJ2aWNlIGFjY291bnQgdG9rZW5cbiAgICogSWYgdGhlIHNlcnZpY2UgYWNjb3VudCB1c2VzIGEgd2VsbC1rbm93biBhbm5vdGF0aW9uIGZvciBlLmcuIElSU0Egb3IgR0NQIFdvcmtsb2FkIElkZW50aXR5XG4gICAqIHRoZW4gdGhpcyBhdWRpZW5jZXMgd2lsbCBiZSBhcHBlbmRlZCB0byB0aGUgbGlzdFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhKd3RTZXJ2aWNlQWNjb3VudFJlZiNhdWRpZW5jZXNcbiAgICovXG4gIHJlYWRvbmx5IGF1ZGllbmNlcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VydmljZUFjY291bnQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZXNwYWNlIG9mIHRoZSByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0U2VydmljZUFjY291bnRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0U2VydmljZUFjY291bnRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0U2VydmljZUFjY291bnRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhdWRpZW5jZXMnOiBvYmouYXVkaWVuY2VzPy5tYXAoeSA9PiB5KSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBBY2Nlc3NLZXlJRCBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZihvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgU2VjcmV0QWNjZXNzS2V5IGlzIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZihvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIFNlc3Npb25Ub2tlbiB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICogVGhpcyBtdXN0IGJlIGRlZmluZWQgaWYgQWNjZXNzS2V5SUQgYW5kIFNlY3JldEFjY2Vzc0tleSBhcmUgdGVtcG9yYXJ5IGNyZWRlbnRpYWxzXG4gKiBzZWU6IGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9JQU0vbGF0ZXN0L1VzZXJHdWlkZS9pZF9jcmVkZW50aWFsc190ZW1wX3VzZS1yZXNvdXJjZXMuaHRtbFxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEFwcFJvbGUgYXV0aGVudGljYXRlcyB3aXRoIFZhdWx0IHVzaW5nIHRoZSBBcHAgUm9sZSBhdXRoIG1lY2hhbmlzbSxcbiAqIHdpdGggdGhlIHJvbGUgYW5kIHNlY3JldCBzdG9yZWQgaW4gYSBLdWJlcm5ldGVzIFNlY3JldCByZXNvdXJjZS5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlIHtcbiAgLyoqXG4gICAqIFBhdGggd2hlcmUgdGhlIEFwcCBSb2xlIGF1dGhlbnRpY2F0aW9uIGJhY2tlbmQgaXMgbW91bnRlZFxuICAgKiBpbiBWYXVsdCwgZS5nOiBcImFwcHJvbGVcIlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGUjcGF0aFxuICAgKi9cbiAgcmVhZG9ubHkgcGF0aDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBSb2xlSUQgY29uZmlndXJlZCBpbiB0aGUgQXBwIFJvbGUgYXV0aGVudGljYXRpb24gYmFja2VuZCB3aGVuIHNldHRpbmdcbiAgICogdXAgdGhlIGF1dGhlbnRpY2F0aW9uIGJhY2tlbmQgaW4gVmF1bHQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZSNyb2xlSWRcbiAgICovXG4gIHJlYWRvbmx5IHJvbGVJZD86IHN0cmluZztcblxuICAvKipcbiAgICogUmVmZXJlbmNlIHRvIGEga2V5IGluIGEgU2VjcmV0IHRoYXQgY29udGFpbnMgdGhlIEFwcCBSb2xlIElEIHVzZWRcbiAgICogdG8gYXV0aGVudGljYXRlIHdpdGggVmF1bHQuXG4gICAqIFRoZSBga2V5YCBmaWVsZCBtdXN0IGJlIHNwZWNpZmllZCBhbmQgZGVub3RlcyB3aGljaCBlbnRyeSB3aXRoaW4gdGhlIFNlY3JldFxuICAgKiByZXNvdXJjZSBpcyB1c2VkIGFzIHRoZSBhcHAgcm9sZSBpZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlI3JvbGVSZWZcbiAgICovXG4gIHJlYWRvbmx5IHJvbGVSZWY/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlUm9sZVJlZjtcblxuICAvKipcbiAgICogUmVmZXJlbmNlIHRvIGEga2V5IGluIGEgU2VjcmV0IHRoYXQgY29udGFpbnMgdGhlIEFwcCBSb2xlIHNlY3JldCB1c2VkXG4gICAqIHRvIGF1dGhlbnRpY2F0ZSB3aXRoIFZhdWx0LlxuICAgKiBUaGUgYGtleWAgZmllbGQgbXVzdCBiZSBzcGVjaWZpZWQgYW5kIGRlbm90ZXMgd2hpY2ggZW50cnkgd2l0aGluIHRoZSBTZWNyZXRcbiAgICogcmVzb3VyY2UgaXMgdXNlZCBhcyB0aGUgYXBwIHJvbGUgc2VjcmV0LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGUjc2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRSZWY6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVTZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZShvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGUgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdwYXRoJzogb2JqLnBhdGgsXG4gICAgJ3JvbGVJZCc6IG9iai5yb2xlSWQsXG4gICAgJ3JvbGVSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVJvbGVSZWYob2JqLnJvbGVSZWYpLFxuICAgICdzZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVNlY3JldFJlZihvYmouc2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBDZXJ0IGF1dGhlbnRpY2F0ZXMgd2l0aCBUTFMgQ2VydGlmaWNhdGVzIGJ5IHBhc3NpbmcgY2xpZW50IGNlcnRpZmljYXRlLCBwcml2YXRlIGtleSBhbmQgY2EgY2VydGlmaWNhdGVcbiAqIENlcnQgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydCB7XG4gIC8qKlxuICAgKiBDbGllbnRDZXJ0IGlzIGEgY2VydGlmaWNhdGUgdG8gYXV0aGVudGljYXRlIHVzaW5nIHRoZSBDZXJ0IFZhdWx0XG4gICAqIGF1dGhlbnRpY2F0aW9uIG1ldGhvZFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnQjY2xpZW50Q2VydFxuICAgKi9cbiAgcmVhZG9ubHkgY2xpZW50Q2VydD86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0O1xuXG4gIC8qKlxuICAgKiBTZWNyZXRSZWYgdG8gYSBrZXkgaW4gYSBTZWNyZXQgcmVzb3VyY2UgY29udGFpbmluZyBjbGllbnQgcHJpdmF0ZSBrZXkgdG9cbiAgICogYXV0aGVudGljYXRlIHdpdGggVmF1bHQgdXNpbmcgdGhlIENlcnQgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydCNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRTZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydChvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnQgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdjbGllbnRDZXJ0JzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0KG9iai5jbGllbnRDZXJ0KSxcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRTZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogSWFtIGF1dGhlbnRpY2F0ZXMgd2l0aCB2YXVsdCBieSBwYXNzaW5nIGEgc3BlY2lhbCBBV1MgcmVxdWVzdCBzaWduZWQgd2l0aCBBV1MgSUFNIGNyZWRlbnRpYWxzXG4gKiBBV1MgSUFNIGF1dGhlbnRpY2F0aW9uIG1ldGhvZFxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtIHtcbiAgLyoqXG4gICAqIEFXUyBFeHRlcm5hbCBJRCBzZXQgb24gYXNzdW1lZCBJQU0gcm9sZXNcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW0jZXh0ZXJuYWxJRFxuICAgKi9cbiAgcmVhZG9ubHkgZXh0ZXJuYWxJZD86IHN0cmluZztcblxuICAvKipcbiAgICogU3BlY2lmeSBhIHNlcnZpY2UgYWNjb3VudCB3aXRoIElSU0EgZW5hYmxlZFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbSNqd3RcbiAgICovXG4gIHJlYWRvbmx5IGp3dD86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dDtcblxuICAvKipcbiAgICogUGF0aCB3aGVyZSB0aGUgQVdTIGF1dGggbWV0aG9kIGlzIGVuYWJsZWQgaW4gVmF1bHQsIGUuZzogXCJhd3NcIlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbSNwYXRoXG4gICAqL1xuICByZWFkb25seSBwYXRoPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBBV1MgcmVnaW9uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtI3JlZ2lvblxuICAgKi9cbiAgcmVhZG9ubHkgcmVnaW9uPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGlzIGlzIHRoZSBBV1Mgcm9sZSB0byBiZSBhc3N1bWVkIGJlZm9yZSB0YWxraW5nIHRvIHZhdWx0XG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtI3JvbGVcbiAgICovXG4gIHJlYWRvbmx5IHJvbGU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNwZWNpZnkgY3JlZGVudGlhbHMgaW4gYSBTZWNyZXQgb2JqZWN0XG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtI3NlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0UmVmPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmO1xuXG4gIC8qKlxuICAgKiBYLVZhdWx0LUFXUy1JQU0tU2VydmVyLUlEIGlzIGFuIGFkZGl0aW9uYWwgaGVhZGVyIHVzZWQgYnkgVmF1bHQgSUFNIGF1dGggbWV0aG9kIHRvIG1pdGlnYXRlIGFnYWluc3QgZGlmZmVyZW50IHR5cGVzIG9mIHJlcGxheSBhdHRhY2tzLiBNb3JlIGRldGFpbHMgaGVyZTogaHR0cHM6Ly9kZXZlbG9wZXIuaGFzaGljb3JwLmNvbS92YXVsdC9kb2NzL2F1dGgvYXdzXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtI3ZhdWx0QXdzSWFtU2VydmVySURcbiAgICovXG4gIHJlYWRvbmx5IHZhdWx0QXdzSWFtU2VydmVySWQ/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFZhdWx0IFJvbGUuIEluIHZhdWx0LCBhIHJvbGUgZGVzY3JpYmVzIGFuIGlkZW50aXR5IHdpdGggYSBzZXQgb2YgcGVybWlzc2lvbnMsIGdyb3Vwcywgb3IgcG9saWNpZXMgeW91IHdhbnQgdG8gYXR0YWNoIGEgdXNlciBvZiB0aGUgc2VjcmV0cyBlbmdpbmVcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW0jdmF1bHRSb2xlXG4gICAqL1xuICByZWFkb25seSB2YXVsdFJvbGU6IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW0nIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbShvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbSB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2V4dGVybmFsSUQnOiBvYmouZXh0ZXJuYWxJZCxcbiAgICAnand0JzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dChvYmouand0KSxcbiAgICAncGF0aCc6IG9iai5wYXRoLFxuICAgICdyZWdpb24nOiBvYmoucmVnaW9uLFxuICAgICdyb2xlJzogb2JqLnJvbGUsXG4gICAgJ3NlY3JldFJlZic6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gICAgJ3ZhdWx0QXdzSWFtU2VydmVySUQnOiBvYmoudmF1bHRBd3NJYW1TZXJ2ZXJJZCxcbiAgICAndmF1bHRSb2xlJzogb2JqLnZhdWx0Um9sZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBKd3QgYXV0aGVudGljYXRlcyB3aXRoIFZhdWx0IGJ5IHBhc3Npbmcgcm9sZSBhbmQgSldUIHRva2VuIHVzaW5nIHRoZVxuICogSldUL09JREMgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3Qge1xuICAvKipcbiAgICogT3B0aW9uYWwgU2VydmljZUFjY291bnRUb2tlbiBzcGVjaWZpZXMgdGhlIEt1YmVybmV0ZXMgc2VydmljZSBhY2NvdW50IGZvciB3aGljaCB0byByZXF1ZXN0XG4gICAqIGEgdG9rZW4gZm9yIHdpdGggdGhlIGBUb2tlblJlcXVlc3RgIEFQSS5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3Qja3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5cbiAgICovXG4gIHJlYWRvbmx5IGt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW47XG5cbiAgLyoqXG4gICAqIFBhdGggd2hlcmUgdGhlIEpXVCBhdXRoZW50aWNhdGlvbiBiYWNrZW5kIGlzIG1vdW50ZWRcbiAgICogaW4gVmF1bHQsIGUuZzogXCJqd3RcIlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dCNwYXRoXG4gICAqL1xuICByZWFkb25seSBwYXRoOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFJvbGUgaXMgYSBKV1Qgcm9sZSB0byBhdXRoZW50aWNhdGUgdXNpbmcgdGhlIEpXVC9PSURDIFZhdWx0XG4gICAqIGF1dGhlbnRpY2F0aW9uIG1ldGhvZFxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dCNyb2xlXG4gICAqL1xuICByZWFkb25seSByb2xlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBPcHRpb25hbCBTZWNyZXRSZWYgdGhhdCByZWZlcnMgdG8gYSBrZXkgaW4gYSBTZWNyZXQgcmVzb3VyY2UgY29udGFpbmluZyBKV1QgdG9rZW4gdG9cbiAgICogYXV0aGVudGljYXRlIHdpdGggVmF1bHQgdXNpbmcgdGhlIEpXVC9PSURDIGF1dGhlbnRpY2F0aW9uIG1ldGhvZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3Qjc2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRSZWY/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RTZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3Qob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3QgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlbic6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlbihvYmoua3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW4pLFxuICAgICdwYXRoJzogb2JqLnBhdGgsXG4gICAgJ3JvbGUnOiBvYmoucm9sZSxcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dFNlY3JldFJlZihvYmouc2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBLdWJlcm5ldGVzIGF1dGhlbnRpY2F0ZXMgd2l0aCBWYXVsdCBieSBwYXNzaW5nIHRoZSBTZXJ2aWNlQWNjb3VudFxuICogdG9rZW4gc3RvcmVkIGluIHRoZSBuYW1lZCBTZWNyZXQgcmVzb3VyY2UgdG8gdGhlIFZhdWx0IHNlcnZlci5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzIHtcbiAgLyoqXG4gICAqIFBhdGggd2hlcmUgdGhlIEt1YmVybmV0ZXMgYXV0aGVudGljYXRpb24gYmFja2VuZCBpcyBtb3VudGVkIGluIFZhdWx0LCBlLmc6XG4gICAqIFwia3ViZXJuZXRlc1wiXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlcyNtb3VudFBhdGhcbiAgICovXG4gIHJlYWRvbmx5IG1vdW50UGF0aDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBBIHJlcXVpcmVkIGZpZWxkIGNvbnRhaW5pbmcgdGhlIFZhdWx0IFJvbGUgdG8gYXNzdW1lLiBBIFJvbGUgYmluZHMgYVxuICAgKiBLdWJlcm5ldGVzIFNlcnZpY2VBY2NvdW50IHdpdGggYSBzZXQgb2YgVmF1bHQgcG9saWNpZXMuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlcyNyb2xlXG4gICAqL1xuICByZWFkb25seSByb2xlOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIE9wdGlvbmFsIHNlY3JldCBmaWVsZCBjb250YWluaW5nIGEgS3ViZXJuZXRlcyBTZXJ2aWNlQWNjb3VudCBKV1QgdXNlZFxuICAgKiBmb3IgYXV0aGVudGljYXRpbmcgd2l0aCBWYXVsdC4gSWYgYSBuYW1lIGlzIHNwZWNpZmllZCB3aXRob3V0IGEga2V5LFxuICAgKiBgdG9rZW5gIGlzIHRoZSBkZWZhdWx0LiBJZiBvbmUgaXMgbm90IHNwZWNpZmllZCwgdGhlIG9uZSBib3VuZCB0b1xuICAgKiB0aGUgY29udHJvbGxlciB3aWxsIGJlIHVzZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlcyNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZWNyZXRSZWY7XG5cbiAgLyoqXG4gICAqIE9wdGlvbmFsIHNlcnZpY2UgYWNjb3VudCBmaWVsZCBjb250YWluaW5nIHRoZSBuYW1lIG9mIGEga3ViZXJuZXRlcyBTZXJ2aWNlQWNjb3VudC5cbiAgICogSWYgdGhlIHNlcnZpY2UgYWNjb3VudCBpcyBzcGVjaWZpZWQsIHRoZSBzZXJ2aWNlIGFjY291bnQgc2VjcmV0IHRva2VuIEpXVCB3aWxsIGJlIHVzZWRcbiAgICogZm9yIGF1dGhlbnRpY2F0aW5nIHdpdGggVmF1bHQuIElmIHRoZSBzZXJ2aWNlIGFjY291bnQgc2VsZWN0b3IgaXMgbm90IHN1cHBsaWVkLFxuICAgKiB0aGUgc2VjcmV0UmVmIHdpbGwgYmUgdXNlZCBpbnN0ZWFkLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXMjc2VydmljZUFjY291bnRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlcnZpY2VBY2NvdW50UmVmPzogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXMob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnbW91bnRQYXRoJzogb2JqLm1vdW50UGF0aCxcbiAgICAncm9sZSc6IG9iai5yb2xlLFxuICAgICdzZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlY3JldFJlZihvYmouc2VjcmV0UmVmKSxcbiAgICAnc2VydmljZUFjY291bnRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50UmVmKG9iai5zZXJ2aWNlQWNjb3VudFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogTGRhcCBhdXRoZW50aWNhdGVzIHdpdGggVmF1bHQgYnkgcGFzc2luZyB1c2VybmFtZS9wYXNzd29yZCBwYWlyIHVzaW5nXG4gKiB0aGUgTERBUCBhdXRoZW50aWNhdGlvbiBtZXRob2RcbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwIHtcbiAgLyoqXG4gICAqIFBhdGggd2hlcmUgdGhlIExEQVAgYXV0aGVudGljYXRpb24gYmFja2VuZCBpcyBtb3VudGVkXG4gICAqIGluIFZhdWx0LCBlLmc6IFwibGRhcFwiXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcCNwYXRoXG4gICAqL1xuICByZWFkb25seSBwYXRoOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldFJlZiB0byBhIGtleSBpbiBhIFNlY3JldCByZXNvdXJjZSBjb250YWluaW5nIHBhc3N3b3JkIGZvciB0aGUgTERBUFxuICAgKiB1c2VyIHVzZWQgdG8gYXV0aGVudGljYXRlIHdpdGggVmF1bHQgdXNpbmcgdGhlIExEQVAgYXV0aGVudGljYXRpb25cbiAgICogbWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcCNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBTZWNyZXRSZWY7XG5cbiAgLyoqXG4gICAqIFVzZXJuYW1lIGlzIGFuIExEQVAgdXNlcm5hbWUgdXNlZCB0byBhdXRoZW50aWNhdGUgdXNpbmcgdGhlIExEQVAgVmF1bHRcbiAgICogYXV0aGVudGljYXRpb24gbWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcCN1c2VybmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgdXNlcm5hbWU6IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3BhdGgnOiBvYmoucGF0aCxcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBTZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gICAgJ3VzZXJuYW1lJzogb2JqLnVzZXJuYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRva2VuU2VjcmV0UmVmIGF1dGhlbnRpY2F0ZXMgd2l0aCBWYXVsdCBieSBwcmVzZW50aW5nIGEgdG9rZW4uXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhUb2tlblNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFRva2VuU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFRva2VuU2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFRva2VuU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhUb2tlblNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhUb2tlblNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVG9rZW5TZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhUb2tlblNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBVc2VyUGFzcyBhdXRoZW50aWNhdGVzIHdpdGggVmF1bHQgYnkgcGFzc2luZyB1c2VybmFtZS9wYXNzd29yZCBwYWlyXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFVzZXJQYXNzIHtcbiAgLyoqXG4gICAqIFBhdGggd2hlcmUgdGhlIFVzZXJQYXNzd29yZCBhdXRoZW50aWNhdGlvbiBiYWNrZW5kIGlzIG1vdW50ZWRcbiAgICogaW4gVmF1bHQsIGUuZzogXCJ1c2VycGFzc1wiXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3MjcGF0aFxuICAgKi9cbiAgcmVhZG9ubHkgcGF0aDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTZWNyZXRSZWYgdG8gYSBrZXkgaW4gYSBTZWNyZXQgcmVzb3VyY2UgY29udGFpbmluZyBwYXNzd29yZCBmb3IgdGhlXG4gICAqIHVzZXIgdXNlZCB0byBhdXRoZW50aWNhdGUgd2l0aCBWYXVsdCB1c2luZyB0aGUgVXNlclBhc3MgYXV0aGVudGljYXRpb25cbiAgICogbWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3Mjc2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRSZWY/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1NlY3JldFJlZjtcblxuICAvKipcbiAgICogVXNlcm5hbWUgaXMgYSB1c2VybmFtZSB1c2VkIHRvIGF1dGhlbnRpY2F0ZSB1c2luZyB0aGUgVXNlclBhc3MgVmF1bHRcbiAgICogYXV0aGVudGljYXRpb24gbWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3MjdXNlcm5hbWVcbiAgICovXG4gIHJlYWRvbmx5IHVzZXJuYW1lOiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3MnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFVzZXJQYXNzKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3MgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdwYXRoJzogb2JqLnBhdGgsXG4gICAgJ3NlY3JldFJlZic6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1NlY3JldFJlZihvYmouc2VjcmV0UmVmKSxcbiAgICAndXNlcm5hbWUnOiBvYmoudXNlcm5hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIHR5cGUgb2YgcHJvdmlkZXIgdG8gdXNlIHN1Y2ggYXMgXCJTZWNyZXRcIiwgb3IgXCJDb25maWdNYXBcIi5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQ2FQcm92aWRlclR5cGVcbiAqL1xuZXhwb3J0IGVudW0gQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyVHlwZSB7XG4gIC8qKiBTZWNyZXQgKi9cbiAgU0VDUkVUID0gXCJTZWNyZXRcIixcbiAgLyoqIENvbmZpZ01hcCAqL1xuICBDT05GSUdfTUFQID0gXCJDb25maWdNYXBcIixcbn1cblxuLyoqXG4gKiBDZXJ0U2VjcmV0UmVmIGlzIGEgY2VydGlmaWNhdGUgYWRkZWQgdG8gdGhlIHRyYW5zcG9ydCBsYXllclxuICogd2hlbiBjb21tdW5pY2F0aW5nIHdpdGggdGhlIFZhdWx0IHNlcnZlci5cbiAqIElmIG5vIGtleSBmb3IgdGhlIFNlY3JldCBpcyBzcGVjaWZpZWQsIGV4dGVybmFsLXNlY3JldCB3aWxsIGRlZmF1bHQgdG8gJ3Rscy5jcnQnLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNDZXJ0U2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNDZXJ0U2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzQ2VydFNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0NlcnRTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzQ2VydFNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0NlcnRTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzQ2VydFNlY3JldFJlZihvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzQ2VydFNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBLZXlTZWNyZXRSZWYgdG8gYSBrZXkgaW4gYSBTZWNyZXQgcmVzb3VyY2UgY29udGFpbmluZyBjbGllbnQgcHJpdmF0ZSBrZXlcbiAqIGFkZGVkIHRvIHRoZSB0cmFuc3BvcnQgbGF5ZXIgd2hlbiBjb21tdW5pY2F0aW5nIHdpdGggdGhlIFZhdWx0IHNlcnZlci5cbiAqIElmIG5vIGtleSBmb3IgdGhlIFNlY3JldCBpcyBzcGVjaWZpZWQsIGV4dGVybmFsLXNlY3JldCB3aWxsIGRlZmF1bHQgdG8gJ3Rscy5rZXknLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNLZXlTZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0tleVNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0tleVNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0tleVNlY3JldFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNLZXlTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNLZXlTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzS2V5U2VjcmV0UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNLZXlTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIEF6dXJlIGNsaWVudElkIG9mIHRoZSBzZXJ2aWNlIHByaW5jaXBsZSB1c2VkIGZvciBhdXRoZW50aWNhdGlvbi5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRJZFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRJZCB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50SWQja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudElkI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50SWQjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudElkJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50SWQob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50SWQgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIEF6dXJlIENsaWVudFNlY3JldCBvZiB0aGUgc2VydmljZSBwcmluY2lwbGUgdXNlZCBmb3IgYXV0aGVudGljYXRpb24uXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50U2VjcmV0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudFNlY3JldCB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvckFjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZXJ2aWNlUHJpbmNpcGFsU2VjcmV0UmVmQ2xpZW50U2VjcmV0I2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRTZWNyZXQjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRTZWNyZXQjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudFNlY3JldCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JBY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VydmljZVByaW5jaXBhbFNlY3JldFJlZkNsaWVudFNlY3JldChvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yQWNyQWNjZXNzVG9rZW5TcGVjQXV0aFNlcnZpY2VQcmluY2lwYWxTZWNyZXRSZWZDbGllbnRTZWNyZXQgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogUmVmZXJlbmNlIHRvIGEga2V5IGluIGEgU2VjcmV0IHRoYXQgY29udGFpbnMgdGhlIEFwcCBSb2xlIElEIHVzZWRcbiAqIHRvIGF1dGhlbnRpY2F0ZSB3aXRoIFZhdWx0LlxuICogVGhlIGBrZXlgIGZpZWxkIG11c3QgYmUgc3BlY2lmaWVkIGFuZCBkZW5vdGVzIHdoaWNoIGVudHJ5IHdpdGhpbiB0aGUgU2VjcmV0XG4gKiByZXNvdXJjZSBpcyB1c2VkIGFzIHRoZSBhcHAgcm9sZSBpZC5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVSb2xlUmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVJvbGVSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVJvbGVSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVJvbGVSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVSb2xlUmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVSb2xlUmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlUm9sZVJlZihvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVSb2xlUmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFJlZmVyZW5jZSB0byBhIGtleSBpbiBhIFNlY3JldCB0aGF0IGNvbnRhaW5zIHRoZSBBcHAgUm9sZSBzZWNyZXQgdXNlZFxuICogdG8gYXV0aGVudGljYXRlIHdpdGggVmF1bHQuXG4gKiBUaGUgYGtleWAgZmllbGQgbXVzdCBiZSBzcGVjaWZpZWQgYW5kIGRlbm90ZXMgd2hpY2ggZW50cnkgd2l0aGluIHRoZSBTZWNyZXRcbiAqIHJlc291cmNlIGlzIHVzZWQgYXMgdGhlIGFwcCByb2xlIHNlY3JldC5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVTZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVTZWNyZXRSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVNlY3JldFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlU2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlU2VjcmV0UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBDbGllbnRDZXJ0IGlzIGEgY2VydGlmaWNhdGUgdG8gYXV0aGVudGljYXRlIHVzaW5nIHRoZSBDZXJ0IFZhdWx0XG4gKiBhdXRoZW50aWNhdGlvbiBtZXRob2RcbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydENsaWVudENlcnQge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydENsaWVudENlcnQja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydENsaWVudENlcnQjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0I25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0Q2xpZW50Q2VydChvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlY3JldFJlZiB0byBhIGtleSBpbiBhIFNlY3JldCByZXNvdXJjZSBjb250YWluaW5nIGNsaWVudCBwcml2YXRlIGtleSB0b1xuICogYXV0aGVudGljYXRlIHdpdGggVmF1bHQgdXNpbmcgdGhlIENlcnQgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0U2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydFNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0U2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydFNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydFNlY3JldFJlZihvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogU3BlY2lmeSBhIHNlcnZpY2UgYWNjb3VudCB3aXRoIElSU0EgZW5hYmxlZFxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0IHtcbiAgLyoqXG4gICAqIEEgcmVmZXJlbmNlIHRvIGEgU2VydmljZUFjY291bnQgcmVzb3VyY2UuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0I3NlcnZpY2VBY2NvdW50UmVmXG4gICAqL1xuICByZWFkb25seSBzZXJ2aWNlQWNjb3VudFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dFNlcnZpY2VBY2NvdW50UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0KG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VydmljZUFjY291bnRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0U2VydmljZUFjY291bnRSZWYob2JqLnNlcnZpY2VBY2NvdW50UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBTcGVjaWZ5IGNyZWRlbnRpYWxzIGluIGEgU2VjcmV0IG9iamVjdFxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIFRoZSBBY2Nlc3NLZXlJRCBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZiNhY2Nlc3NLZXlJRFNlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgYWNjZXNzS2V5SWRTZWNyZXRSZWY/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZjtcblxuICAvKipcbiAgICogVGhlIFNlY3JldEFjY2Vzc0tleSBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZiNzZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldEFjY2Vzc0tleVNlY3JldFJlZj86IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZjtcblxuICAvKipcbiAgICogVGhlIFNlc3Npb25Ub2tlbiB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICAgKiBUaGlzIG11c3QgYmUgZGVmaW5lZCBpZiBBY2Nlc3NLZXlJRCBhbmQgU2VjcmV0QWNjZXNzS2V5IGFyZSB0ZW1wb3JhcnkgY3JlZGVudGlhbHNcbiAgICogc2VlOiBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vSUFNL2xhdGVzdC9Vc2VyR3VpZGUvaWRfY3JlZGVudGlhbHNfdGVtcF91c2UtcmVzb3VyY2VzLmh0bWxcbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWYjc2Vzc2lvblRva2VuU2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBzZXNzaW9uVG9rZW5TZWNyZXRSZWY/OiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhY2Nlc3NLZXlJRFNlY3JldFJlZic6IHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZihvYmouYWNjZXNzS2V5SWRTZWNyZXRSZWYpLFxuICAgICdzZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmKG9iai5zZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYpLFxuICAgICdzZXNzaW9uVG9rZW5TZWNyZXRSZWYnOiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmKG9iai5zZXNzaW9uVG9rZW5TZWNyZXRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE9wdGlvbmFsIFNlcnZpY2VBY2NvdW50VG9rZW4gc3BlY2lmaWVzIHRoZSBLdWJlcm5ldGVzIHNlcnZpY2UgYWNjb3VudCBmb3Igd2hpY2ggdG8gcmVxdWVzdFxuICogYSB0b2tlbiBmb3Igd2l0aCB0aGUgYFRva2VuUmVxdWVzdGAgQVBJLlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlbiB7XG4gIC8qKlxuICAgKiBPcHRpb25hbCBhdWRpZW5jZXMgZmllbGQgdGhhdCB3aWxsIGJlIHVzZWQgdG8gcmVxdWVzdCBhIHRlbXBvcmFyeSBLdWJlcm5ldGVzIHNlcnZpY2VcbiAgICogYWNjb3VudCB0b2tlbiBmb3IgdGhlIHNlcnZpY2UgYWNjb3VudCByZWZlcmVuY2VkIGJ5IGBzZXJ2aWNlQWNjb3VudFJlZmAuXG4gICAqIERlZmF1bHRzIHRvIGEgc2luZ2xlIGF1ZGllbmNlIGB2YXVsdGAgaXQgbm90IHNwZWNpZmllZC5cbiAgICogRGVwcmVjYXRlZDogdXNlIHNlcnZpY2VBY2NvdW50UmVmLkF1ZGllbmNlcyBpbnN0ZWFkXG4gICAqXG4gICAqIEBkZWZhdWx0IGEgc2luZ2xlIGF1ZGllbmNlIGB2YXVsdGAgaXQgbm90IHNwZWNpZmllZC5cbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlbiNhdWRpZW5jZXNcbiAgICovXG4gIHJlYWRvbmx5IGF1ZGllbmNlcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBPcHRpb25hbCBleHBpcmF0aW9uIHRpbWUgaW4gc2Vjb25kcyB0aGF0IHdpbGwgYmUgdXNlZCB0byByZXF1ZXN0IGEgdGVtcG9yYXJ5XG4gICAqIEt1YmVybmV0ZXMgc2VydmljZSBhY2NvdW50IHRva2VuIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHJlZmVyZW5jZWQgYnlcbiAgICogYHNlcnZpY2VBY2NvdW50UmVmYC5cbiAgICogRGVwcmVjYXRlZDogdGhpcyB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIGZ1dHVyZS5cbiAgICogRGVmYXVsdHMgdG8gMTAgbWludXRlcy5cbiAgICpcbiAgICogQGRlZmF1bHQgMTAgbWludXRlcy5cbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlbiNleHBpcmF0aW9uU2Vjb25kc1xuICAgKi9cbiAgcmVhZG9ubHkgZXhwaXJhdGlvblNlY29uZHM/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIFNlcnZpY2UgYWNjb3VudCBmaWVsZCBjb250YWluaW5nIHRoZSBuYW1lIG9mIGEga3ViZXJuZXRlcyBTZXJ2aWNlQWNjb3VudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlbiNzZXJ2aWNlQWNjb3VudFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VydmljZUFjY291bnRSZWY6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuU2VydmljZUFjY291bnRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW4nIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW4gfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhdWRpZW5jZXMnOiBvYmouYXVkaWVuY2VzPy5tYXAoeSA9PiB5KSxcbiAgICAnZXhwaXJhdGlvblNlY29uZHMnOiBvYmouZXhwaXJhdGlvblNlY29uZHMsXG4gICAgJ3NlcnZpY2VBY2NvdW50UmVmJzogdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuU2VydmljZUFjY291bnRSZWYob2JqLnNlcnZpY2VBY2NvdW50UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBPcHRpb25hbCBTZWNyZXRSZWYgdGhhdCByZWZlcnMgdG8gYSBrZXkgaW4gYSBTZWNyZXQgcmVzb3VyY2UgY29udGFpbmluZyBKV1QgdG9rZW4gdG9cbiAqIGF1dGhlbnRpY2F0ZSB3aXRoIFZhdWx0IHVzaW5nIHRoZSBKV1QvT0lEQyBhdXRoZW50aWNhdGlvbiBtZXRob2QuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RTZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RTZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0U2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dFNlY3JldFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0U2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dFNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0U2VjcmV0UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0U2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE9wdGlvbmFsIHNlY3JldCBmaWVsZCBjb250YWluaW5nIGEgS3ViZXJuZXRlcyBTZXJ2aWNlQWNjb3VudCBKV1QgdXNlZFxuICogZm9yIGF1dGhlbnRpY2F0aW5nIHdpdGggVmF1bHQuIElmIGEgbmFtZSBpcyBzcGVjaWZpZWQgd2l0aG91dCBhIGtleSxcbiAqIGB0b2tlbmAgaXMgdGhlIGRlZmF1bHQuIElmIG9uZSBpcyBub3Qgc3BlY2lmaWVkLCB0aGUgb25lIGJvdW5kIHRvXG4gKiB0aGUgY29udHJvbGxlciB3aWxsIGJlIHVzZWQuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlY3JldFJlZihvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogT3B0aW9uYWwgc2VydmljZSBhY2NvdW50IGZpZWxkIGNvbnRhaW5pbmcgdGhlIG5hbWUgb2YgYSBrdWJlcm5ldGVzIFNlcnZpY2VBY2NvdW50LlxuICogSWYgdGhlIHNlcnZpY2UgYWNjb3VudCBpcyBzcGVjaWZpZWQsIHRoZSBzZXJ2aWNlIGFjY291bnQgc2VjcmV0IHRva2VuIEpXVCB3aWxsIGJlIHVzZWRcbiAqIGZvciBhdXRoZW50aWNhdGluZyB3aXRoIFZhdWx0LiBJZiB0aGUgc2VydmljZSBhY2NvdW50IHNlbGVjdG9yIGlzIG5vdCBzdXBwbGllZCxcbiAqIHRoZSBzZWNyZXRSZWYgd2lsbCBiZSB1c2VkIGluc3RlYWQuXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VydmljZUFjY291bnRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VydmljZUFjY291bnRSZWYge1xuICAvKipcbiAgICogQXVkaWVuY2Ugc3BlY2lmaWVzIHRoZSBgYXVkYCBjbGFpbSBmb3IgdGhlIHNlcnZpY2UgYWNjb3VudCB0b2tlblxuICAgKiBJZiB0aGUgc2VydmljZSBhY2NvdW50IHVzZXMgYSB3ZWxsLWtub3duIGFubm90YXRpb24gZm9yIGUuZy4gSVJTQSBvciBHQ1AgV29ya2xvYWQgSWRlbnRpdHlcbiAgICogdGhlbiB0aGlzIGF1ZGllbmNlcyB3aWxsIGJlIGFwcGVuZGVkIHRvIHRoZSBsaXN0XG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50UmVmI2F1ZGllbmNlc1xuICAgKi9cbiAgcmVhZG9ubHkgYXVkaWVuY2VzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VydmljZUFjY291bnRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBOYW1lc3BhY2Ugb2YgdGhlIHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VydmljZUFjY291bnRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFJlZihvYmo6IENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1ZGllbmNlcyc6IG9iai5hdWRpZW5jZXM/Lm1hcCh5ID0+IHkpLFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VjcmV0UmVmIHRvIGEga2V5IGluIGEgU2VjcmV0IHJlc291cmNlIGNvbnRhaW5pbmcgcGFzc3dvcmQgZm9yIHRoZSBMREFQXG4gKiB1c2VyIHVzZWQgdG8gYXV0aGVudGljYXRlIHdpdGggVmF1bHQgdXNpbmcgdGhlIExEQVAgYXV0aGVudGljYXRpb25cbiAqIG1ldGhvZFxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcFNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBTZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcFNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwU2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBTZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwU2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlY3JldFJlZiB0byBhIGtleSBpbiBhIFNlY3JldCByZXNvdXJjZSBjb250YWluaW5nIHBhc3N3b3JkIGZvciB0aGVcbiAqIHVzZXIgdXNlZCB0byBhdXRoZW50aWNhdGUgd2l0aCBWYXVsdCB1c2luZyB0aGUgVXNlclBhc3MgYXV0aGVudGljYXRpb25cbiAqIG1ldGhvZFxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3NTZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1NlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1NlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1NlY3JldFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3NTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3NTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFVzZXJQYXNzU2VjcmV0UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3NTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQSByZWZlcmVuY2UgdG8gYSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZS5cbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dFNlcnZpY2VBY2NvdW50UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0U2VydmljZUFjY291bnRSZWYge1xuICAvKipcbiAgICogQXVkaWVuY2Ugc3BlY2lmaWVzIHRoZSBgYXVkYCBjbGFpbSBmb3IgdGhlIHNlcnZpY2UgYWNjb3VudCB0b2tlblxuICAgKiBJZiB0aGUgc2VydmljZSBhY2NvdW50IHVzZXMgYSB3ZWxsLWtub3duIGFubm90YXRpb24gZm9yIGUuZy4gSVJTQSBvciBHQ1AgV29ya2xvYWQgSWRlbnRpdHlcbiAgICogdGhlbiB0aGlzIGF1ZGllbmNlcyB3aWxsIGJlIGFwcGVuZGVkIHRvIHRoZSBsaXN0XG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0U2VydmljZUFjY291bnRSZWYjYXVkaWVuY2VzXG4gICAqL1xuICByZWFkb25seSBhdWRpZW5jZXM/OiBzdHJpbmdbXTtcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlcnZpY2VBY2NvdW50IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dFNlcnZpY2VBY2NvdW50UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZXNwYWNlIG9mIHRoZSByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1Kd3RTZXJ2aWNlQWNjb3VudFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1Kd3RTZXJ2aWNlQWNjb3VudFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0U2VydmljZUFjY291bnRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1Kd3RTZXJ2aWNlQWNjb3VudFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1ZGllbmNlcyc6IG9iai5hdWRpZW5jZXM/Lm1hcCh5ID0+IHkpLFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIEFjY2Vzc0tleUlEIGlzIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgU2VjcmV0QWNjZXNzS2V5IGlzIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gKlxuICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBTZXNzaW9uVG9rZW4gdXNlZCBmb3IgYXV0aGVudGljYXRpb25cbiAqIFRoaXMgbXVzdCBiZSBkZWZpbmVkIGlmIEFjY2Vzc0tleUlEIGFuZCBTZWNyZXRBY2Nlc3NLZXkgYXJlIHRlbXBvcmFyeSBjcmVkZW50aWFsc1xuICogc2VlOiBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vSUFNL2xhdGVzdC9Vc2VyR3VpZGUvaWRfY3JlZGVudGlhbHNfdGVtcF91c2UtcmVzb3VyY2VzLmh0bWxcbiAqXG4gKiBAc2NoZW1hIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYob2JqOiBDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VydmljZSBhY2NvdW50IGZpZWxkIGNvbnRhaW5pbmcgdGhlIG5hbWUgb2YgYSBrdWJlcm5ldGVzIFNlcnZpY2VBY2NvdW50LlxuICpcbiAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5TZXJ2aWNlQWNjb3VudFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENsdXN0ZXJHZW5lcmF0b3JTcGVjR2VuZXJhdG9yVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuU2VydmljZUFjY291bnRSZWYge1xuICAvKipcbiAgICogQXVkaWVuY2Ugc3BlY2lmaWVzIHRoZSBgYXVkYCBjbGFpbSBmb3IgdGhlIHNlcnZpY2UgYWNjb3VudCB0b2tlblxuICAgKiBJZiB0aGUgc2VydmljZSBhY2NvdW50IHVzZXMgYSB3ZWxsLWtub3duIGFubm90YXRpb24gZm9yIGUuZy4gSVJTQSBvciBHQ1AgV29ya2xvYWQgSWRlbnRpdHlcbiAgICogdGhlbiB0aGlzIGF1ZGllbmNlcyB3aWxsIGJlIGFwcGVuZGVkIHRvIHRoZSBsaXN0XG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5TZXJ2aWNlQWNjb3VudFJlZiNhdWRpZW5jZXNcbiAgICovXG4gIHJlYWRvbmx5IGF1ZGllbmNlcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VydmljZUFjY291bnQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5TZXJ2aWNlQWNjb3VudFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIE5hbWVzcGFjZSBvZiB0aGUgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5TZXJ2aWNlQWNjb3VudFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlblNlcnZpY2VBY2NvdW50UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9DbHVzdGVyR2VuZXJhdG9yU3BlY0dlbmVyYXRvclZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlblNlcnZpY2VBY2NvdW50UmVmKG9iajogQ2x1c3RlckdlbmVyYXRvclNwZWNHZW5lcmF0b3JWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5TZXJ2aWNlQWNjb3VudFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1ZGllbmNlcyc6IG9iai5hdWRpZW5jZXM/Lm1hcCh5ID0+IHkpLFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cblxuLyoqXG4gKiBFQ1JBdXRob3JpemF0aW9uVG9rZW5TcGVjIHVzZXMgdGhlIEdldEF1dGhvcml6YXRpb25Ub2tlbiBBUEkgdG8gcmV0cmlldmUgYW5cbmF1dGhvcml6YXRpb24gdG9rZW4uXG5UaGUgYXV0aG9yaXphdGlvbiB0b2tlbiBpcyB2YWxpZCBmb3IgMTIgaG91cnMuXG5UaGUgYXV0aG9yaXphdGlvblRva2VuIHJldHVybmVkIGlzIGEgYmFzZTY0IGVuY29kZWQgc3RyaW5nIHRoYXQgY2FuIGJlIGRlY29kZWRcbmFuZCB1c2VkIGluIGEgZG9ja2VyIGxvZ2luIGNvbW1hbmQgdG8gYXV0aGVudGljYXRlIHRvIGEgcmVnaXN0cnkuXG5Gb3IgbW9yZSBpbmZvcm1hdGlvbiwgc2VlIFJlZ2lzdHJ5IGF1dGhlbnRpY2F0aW9uIChodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vQW1hem9uRUNSL2xhdGVzdC91c2VyZ3VpZGUvUmVnaXN0cmllcy5odG1sI3JlZ2lzdHJ5X2F1dGgpIGluIHRoZSBBbWF6b24gRWxhc3RpYyBDb250YWluZXIgUmVnaXN0cnkgVXNlciBHdWlkZS5cbiAqXG4gKiBAc2NoZW1hIEVDUkF1dGhvcml6YXRpb25Ub2tlblxuICovXG5leHBvcnQgY2xhc3MgRWNyQXV0aG9yaXphdGlvblRva2VuIGV4dGVuZHMgQXBpT2JqZWN0IHtcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGFwaVZlcnNpb24gYW5kIGtpbmQgZm9yIFwiRUNSQXV0aG9yaXphdGlvblRva2VuXCJcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgR1ZLOiBHcm91cFZlcnNpb25LaW5kID0ge1xuICAgIGFwaVZlcnNpb246ICdnZW5lcmF0b3JzLmV4dGVybmFsLXNlY3JldHMuaW8vdjFhbHBoYTEnLFxuICAgIGtpbmQ6ICdFQ1JBdXRob3JpemF0aW9uVG9rZW4nLFxuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgYSBLdWJlcm5ldGVzIG1hbmlmZXN0IGZvciBcIkVDUkF1dGhvcml6YXRpb25Ub2tlblwiLlxuICAgKlxuICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGlubGluZSByZXNvdXJjZSBtYW5pZmVzdHMgaW5zaWRlIG90aGVyIG9iamVjdHMgKGUuZy4gYXMgdGVtcGxhdGVzKS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1hbmlmZXN0KHByb3BzOiBFY3JBdXRob3JpemF0aW9uVG9rZW5Qcm9wcyA9IHt9KTogYW55IHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uRWNyQXV0aG9yaXphdGlvblRva2VuLkdWSyxcbiAgICAgIC4uLnRvSnNvbl9FY3JBdXRob3JpemF0aW9uVG9rZW5Qcm9wcyhwcm9wcyksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgXCJFQ1JBdXRob3JpemF0aW9uVG9rZW5cIiBBUEkgb2JqZWN0XG4gICAqIEBwYXJhbSBzY29wZSB0aGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgb2JqZWN0XG4gICAqIEBwYXJhbSBpZCBhIHNjb3BlLWxvY2FsIG5hbWUgZm9yIHRoZSBvYmplY3RcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IEVjckF1dGhvcml6YXRpb25Ub2tlblByb3BzID0ge30pIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIC4uLkVjckF1dGhvcml6YXRpb25Ub2tlbi5HVkssXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBvYmplY3QgdG8gS3ViZXJuZXRlcyBKU09OLlxuICAgKi9cbiAgcHVibGljIHRvSnNvbigpOiBhbnkge1xuICAgIGNvbnN0IHJlc29sdmVkID0gc3VwZXIudG9Kc29uKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uRWNyQXV0aG9yaXphdGlvblRva2VuLkdWSyxcbiAgICAgIC4uLnRvSnNvbl9FY3JBdXRob3JpemF0aW9uVG9rZW5Qcm9wcyhyZXNvbHZlZCksXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIEVDUkF1dGhvcml6YXRpb25Ub2tlblNwZWMgdXNlcyB0aGUgR2V0QXV0aG9yaXphdGlvblRva2VuIEFQSSB0byByZXRyaWV2ZSBhblxuICogYXV0aG9yaXphdGlvbiB0b2tlbi5cbiAqIFRoZSBhdXRob3JpemF0aW9uIHRva2VuIGlzIHZhbGlkIGZvciAxMiBob3Vycy5cbiAqIFRoZSBhdXRob3JpemF0aW9uVG9rZW4gcmV0dXJuZWQgaXMgYSBiYXNlNjQgZW5jb2RlZCBzdHJpbmcgdGhhdCBjYW4gYmUgZGVjb2RlZFxuICogYW5kIHVzZWQgaW4gYSBkb2NrZXIgbG9naW4gY29tbWFuZCB0byBhdXRoZW50aWNhdGUgdG8gYSByZWdpc3RyeS5cbiAqIEZvciBtb3JlIGluZm9ybWF0aW9uLCBzZWUgUmVnaXN0cnkgYXV0aGVudGljYXRpb24gKGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9BbWF6b25FQ1IvbGF0ZXN0L3VzZXJndWlkZS9SZWdpc3RyaWVzLmh0bWwjcmVnaXN0cnlfYXV0aCkgaW4gdGhlIEFtYXpvbiBFbGFzdGljIENvbnRhaW5lciBSZWdpc3RyeSBVc2VyIEd1aWRlLlxuICpcbiAqIEBzY2hlbWEgRUNSQXV0aG9yaXphdGlvblRva2VuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRWNyQXV0aG9yaXphdGlvblRva2VuUHJvcHMge1xuICAvKipcbiAgICogQHNjaGVtYSBFQ1JBdXRob3JpemF0aW9uVG9rZW4jbWV0YWRhdGFcbiAgICovXG4gIHJlYWRvbmx5IG1ldGFkYXRhPzogQXBpT2JqZWN0TWV0YWRhdGE7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgRUNSQXV0aG9yaXphdGlvblRva2VuI3NwZWNcbiAgICovXG4gIHJlYWRvbmx5IHNwZWM/OiBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0VjckF1dGhvcml6YXRpb25Ub2tlblByb3BzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9FY3JBdXRob3JpemF0aW9uVG9rZW5Qcm9wcyhvYmo6IEVjckF1dGhvcml6YXRpb25Ub2tlblByb3BzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnbWV0YWRhdGEnOiBvYmoubWV0YWRhdGEsXG4gICAgJ3NwZWMnOiB0b0pzb25fRWNyQXV0aG9yaXphdGlvblRva2VuU3BlYyhvYmouc3BlYyksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRWNyQXV0aG9yaXphdGlvblRva2VuU3BlYyB7XG4gIC8qKlxuICAgKiBBdXRoIGRlZmluZXMgaG93IHRvIGF1dGhlbnRpY2F0ZSB3aXRoIEFXU1xuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWMjYXV0aFxuICAgKi9cbiAgcmVhZG9ubHkgYXV0aD86IEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoO1xuXG4gIC8qKlxuICAgKiBSZWdpb24gc3BlY2lmaWVzIHRoZSByZWdpb24gdG8gb3BlcmF0ZSBpbi5cbiAgICpcbiAgICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjI3JlZ2lvblxuICAgKi9cbiAgcmVhZG9ubHkgcmVnaW9uOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFlvdSBjYW4gYXNzdW1lIGEgcm9sZSBiZWZvcmUgbWFraW5nIGNhbGxzIHRvIHRoZVxuICAgKiBkZXNpcmVkIEFXUyBzZXJ2aWNlLlxuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWMjcm9sZVxuICAgKi9cbiAgcmVhZG9ubHkgcm9sZT86IHN0cmluZztcblxuICAvKipcbiAgICogU2NvcGUgc3BlY2lmaWVzIHRoZSBFQ1Igc2VydmljZSBzY29wZS5cbiAgICogVmFsaWQgb3B0aW9ucyBhcmUgcHJpdmF0ZSBhbmQgcHVibGljLlxuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWMjc2NvcGVcbiAgICovXG4gIHJlYWRvbmx5IHNjb3BlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0VjckF1dGhvcml6YXRpb25Ub2tlblNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0VjckF1dGhvcml6YXRpb25Ub2tlblNwZWMob2JqOiBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXV0aCc6IHRvSnNvbl9FY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aChvYmouYXV0aCksXG4gICAgJ3JlZ2lvbic6IG9iai5yZWdpb24sXG4gICAgJ3JvbGUnOiBvYmoucm9sZSxcbiAgICAnc2NvcGUnOiBvYmouc2NvcGUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQXV0aCBkZWZpbmVzIGhvdyB0byBhdXRoZW50aWNhdGUgd2l0aCBBV1NcbiAqXG4gKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGgge1xuICAvKipcbiAgICogQXV0aGVudGljYXRlIGFnYWluc3QgQVdTIHVzaW5nIHNlcnZpY2UgYWNjb3VudCB0b2tlbnMuXG4gICAqXG4gICAqIEBzY2hlbWEgRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGgjand0XG4gICAqL1xuICByZWFkb25seSBqd3Q/OiBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dDtcblxuICAvKipcbiAgICogQVdTQXV0aFNlY3JldFJlZiBob2xkcyBzZWNyZXQgcmVmZXJlbmNlcyBmb3IgQVdTIGNyZWRlbnRpYWxzXG4gICAqIGJvdGggQWNjZXNzS2V5SUQgYW5kIFNlY3JldEFjY2Vzc0tleSBtdXN0IGJlIGRlZmluZWQgaW4gb3JkZXIgdG8gcHJvcGVybHkgYXV0aGVudGljYXRlLlxuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoI3NlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0UmVmPzogRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGgnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0VjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoKG9iajogRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGggfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdqd3QnOiB0b0pzb25fRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhKd3Qob2JqLmp3dCksXG4gICAgJ3NlY3JldFJlZic6IHRvSnNvbl9FY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZihvYmouc2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBdXRoZW50aWNhdGUgYWdhaW5zdCBBV1MgdXNpbmcgc2VydmljZSBhY2NvdW50IHRva2Vucy5cbiAqXG4gKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhKd3Qge1xuICAvKipcbiAgICogQSByZWZlcmVuY2UgdG8gYSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZS5cbiAgICpcbiAgICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dCNzZXJ2aWNlQWNjb3VudFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VydmljZUFjY291bnRSZWY/OiBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0VjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9FY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dChvYmo6IEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VydmljZUFjY291bnRSZWYnOiB0b0pzb25fRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhKd3RTZXJ2aWNlQWNjb3VudFJlZihvYmouc2VydmljZUFjY291bnRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEFXU0F1dGhTZWNyZXRSZWYgaG9sZHMgc2VjcmV0IHJlZmVyZW5jZXMgZm9yIEFXUyBjcmVkZW50aWFsc1xuICogYm90aCBBY2Nlc3NLZXlJRCBhbmQgU2VjcmV0QWNjZXNzS2V5IG11c3QgYmUgZGVmaW5lZCBpbiBvcmRlciB0byBwcm9wZXJseSBhdXRoZW50aWNhdGUuXG4gKlxuICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIFRoZSBBY2Nlc3NLZXlJRCBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmI2FjY2Vzc0tleUlEU2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBhY2Nlc3NLZXlJZFNlY3JldFJlZj86IEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWY7XG5cbiAgLyoqXG4gICAqIFRoZSBTZWNyZXRBY2Nlc3NLZXkgaXMgdXNlZCBmb3IgYXV0aGVudGljYXRpb25cbiAgICpcbiAgICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZiNzZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldEFjY2Vzc0tleVNlY3JldFJlZj86IEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmO1xuXG4gIC8qKlxuICAgKiBUaGUgU2Vzc2lvblRva2VuIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gICAqIFRoaXMgbXVzdCBiZSBkZWZpbmVkIGlmIEFjY2Vzc0tleUlEIGFuZCBTZWNyZXRBY2Nlc3NLZXkgYXJlIHRlbXBvcmFyeSBjcmVkZW50aWFsc1xuICAgKiBzZWU6IGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9JQU0vbGF0ZXN0L1VzZXJHdWlkZS9pZF9jcmVkZW50aWFsc190ZW1wX3VzZS1yZXNvdXJjZXMuaHRtbFxuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmI3Nlc3Npb25Ub2tlblNlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2Vzc2lvblRva2VuU2VjcmV0UmVmPzogRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0VjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmKG9iajogRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhY2Nlc3NLZXlJRFNlY3JldFJlZic6IHRvSnNvbl9FY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmKG9iai5hY2Nlc3NLZXlJZFNlY3JldFJlZiksXG4gICAgJ3NlY3JldEFjY2Vzc0tleVNlY3JldFJlZic6IHRvSnNvbl9FY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZihvYmouc2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmKSxcbiAgICAnc2Vzc2lvblRva2VuU2VjcmV0UmVmJzogdG9Kc29uX0VjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmKG9iai5zZXNzaW9uVG9rZW5TZWNyZXRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEEgcmVmZXJlbmNlIHRvIGEgU2VydmljZUFjY291bnQgcmVzb3VyY2UuXG4gKlxuICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhKd3RTZXJ2aWNlQWNjb3VudFJlZiB7XG4gIC8qKlxuICAgKiBBdWRpZW5jZSBzcGVjaWZpZXMgdGhlIGBhdWRgIGNsYWltIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHRva2VuXG4gICAqIElmIHRoZSBzZXJ2aWNlIGFjY291bnQgdXNlcyBhIHdlbGwta25vd24gYW5ub3RhdGlvbiBmb3IgZS5nLiBJUlNBIG9yIEdDUCBXb3JrbG9hZCBJZGVudGl0eVxuICAgKiB0aGVuIHRoaXMgYXVkaWVuY2VzIHdpbGwgYmUgYXBwZW5kZWQgdG8gdGhlIGxpc3RcbiAgICpcbiAgICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmI2F1ZGllbmNlc1xuICAgKi9cbiAgcmVhZG9ubHkgYXVkaWVuY2VzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZXNwYWNlIG9mIHRoZSByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0VjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0U2VydmljZUFjY291bnRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0VjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoSnd0U2VydmljZUFjY291bnRSZWYob2JqOiBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXVkaWVuY2VzJzogb2JqLmF1ZGllbmNlcz8ubWFwKHkgPT4geSksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgQWNjZXNzS2V5SUQgaXMgdXNlZCBmb3IgYXV0aGVudGljYXRpb25cbiAqXG4gKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9FY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmKG9iajogRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgU2VjcmV0QWNjZXNzS2V5IGlzIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gKlxuICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYob2JqOiBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgU2Vzc2lvblRva2VuIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gKiBUaGlzIG11c3QgYmUgZGVmaW5lZCBpZiBBY2Nlc3NLZXlJRCBhbmQgU2VjcmV0QWNjZXNzS2V5IGFyZSB0ZW1wb3JhcnkgY3JlZGVudGlhbHNcbiAqIHNlZTogaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL0lBTS9sYXRlc3QvVXNlckd1aWRlL2lkX2NyZWRlbnRpYWxzX3RlbXBfdXNlLXJlc291cmNlcy5odG1sXG4gKlxuICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIEVjckF1dGhvcml6YXRpb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fRWNyQXV0aG9yaXphdGlvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYob2JqOiBFY3JBdXRob3JpemF0aW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuXG4vKipcbiAqIEZha2UgZ2VuZXJhdG9yIGlzIHVzZWQgZm9yIHRlc3RpbmcuIEl0IGxldHMgeW91IGRlZmluZVxuYSBzdGF0aWMgc2V0IG9mIGNyZWRlbnRpYWxzIHRoYXQgaXMgYWx3YXlzIHJldHVybmVkLlxuICpcbiAqIEBzY2hlbWEgRmFrZVxuICovXG5leHBvcnQgY2xhc3MgRmFrZSBleHRlbmRzIEFwaU9iamVjdCB7XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBhcGlWZXJzaW9uIGFuZCBraW5kIGZvciBcIkZha2VcIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2dlbmVyYXRvcnMuZXh0ZXJuYWwtc2VjcmV0cy5pby92MWFscGhhMScsXG4gICAga2luZDogJ0Zha2UnLFxuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgYSBLdWJlcm5ldGVzIG1hbmlmZXN0IGZvciBcIkZha2VcIi5cbiAgICpcbiAgICogVGhpcyBjYW4gYmUgdXNlZCB0byBpbmxpbmUgcmVzb3VyY2UgbWFuaWZlc3RzIGluc2lkZSBvdGhlciBvYmplY3RzIChlLmcuIGFzIHRlbXBsYXRlcykuXG4gICAqXG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtYW5pZmVzdChwcm9wczogRmFrZVByb3BzID0ge30pOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5GYWtlLkdWSyxcbiAgICAgIC4uLnRvSnNvbl9GYWtlUHJvcHMocHJvcHMpLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyBhIFwiRmFrZVwiIEFQSSBvYmplY3RcbiAgICogQHBhcmFtIHNjb3BlIHRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBvYmplY3RcbiAgICogQHBhcmFtIGlkIGEgc2NvcGUtbG9jYWwgbmFtZSBmb3IgdGhlIG9iamVjdFxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogRmFrZVByb3BzID0ge30pIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIC4uLkZha2UuR1ZLLFxuICAgICAgLi4ucHJvcHMsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyB0aGUgb2JqZWN0IHRvIEt1YmVybmV0ZXMgSlNPTi5cbiAgICovXG4gIHB1YmxpYyB0b0pzb24oKTogYW55IHtcbiAgICBjb25zdCByZXNvbHZlZCA9IHN1cGVyLnRvSnNvbigpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLkZha2UuR1ZLLFxuICAgICAgLi4udG9Kc29uX0Zha2VQcm9wcyhyZXNvbHZlZCksXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIEZha2UgZ2VuZXJhdG9yIGlzIHVzZWQgZm9yIHRlc3RpbmcuIEl0IGxldHMgeW91IGRlZmluZVxuICogYSBzdGF0aWMgc2V0IG9mIGNyZWRlbnRpYWxzIHRoYXQgaXMgYWx3YXlzIHJldHVybmVkLlxuICpcbiAqIEBzY2hlbWEgRmFrZVxuICovXG5leHBvcnQgaW50ZXJmYWNlIEZha2VQcm9wcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIEZha2UjbWV0YWRhdGFcbiAgICovXG4gIHJlYWRvbmx5IG1ldGFkYXRhPzogQXBpT2JqZWN0TWV0YWRhdGE7XG5cbiAgLyoqXG4gICAqIEZha2VTcGVjIGNvbnRhaW5zIHRoZSBzdGF0aWMgZGF0YS5cbiAgICpcbiAgICogQHNjaGVtYSBGYWtlI3NwZWNcbiAgICovXG4gIHJlYWRvbmx5IHNwZWM/OiBGYWtlU3BlYztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdGYWtlUHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0Zha2VQcm9wcyhvYmo6IEZha2VQcm9wcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ21ldGFkYXRhJzogb2JqLm1ldGFkYXRhLFxuICAgICdzcGVjJzogdG9Kc29uX0Zha2VTcGVjKG9iai5zcGVjKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBGYWtlU3BlYyBjb250YWlucyB0aGUgc3RhdGljIGRhdGEuXG4gKlxuICogQHNjaGVtYSBGYWtlU3BlY1xuICovXG5leHBvcnQgaW50ZXJmYWNlIEZha2VTcGVjIHtcbiAgLyoqXG4gICAqIFVzZWQgdG8gc2VsZWN0IHRoZSBjb3JyZWN0IEVTTyBjb250cm9sbGVyICh0aGluazogaW5ncmVzcy5pbmdyZXNzQ2xhc3NOYW1lKVxuICAgKiBUaGUgRVNPIGNvbnRyb2xsZXIgaXMgaW5zdGFudGlhdGVkIHdpdGggYSBzcGVjaWZpYyBjb250cm9sbGVyIG5hbWUgYW5kIGZpbHRlcnMgVkRTIGJhc2VkIG9uIHRoaXMgcHJvcGVydHlcbiAgICpcbiAgICogQHNjaGVtYSBGYWtlU3BlYyNjb250cm9sbGVyXG4gICAqL1xuICByZWFkb25seSBjb250cm9sbGVyPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBEYXRhIGRlZmluZXMgdGhlIHN0YXRpYyBkYXRhIHJldHVybmVkXG4gICAqIGJ5IHRoaXMgZ2VuZXJhdG9yLlxuICAgKlxuICAgKiBAc2NoZW1hIEZha2VTcGVjI2RhdGFcbiAgICovXG4gIHJlYWRvbmx5IGRhdGE/OiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9O1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0Zha2VTcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9GYWtlU3BlYyhvYmo6IEZha2VTcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnY29udHJvbGxlcic6IG9iai5jb250cm9sbGVyLFxuICAgICdkYXRhJzogKChvYmouZGF0YSkgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLmRhdGEpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG5cbi8qKlxuICogR0NSQWNjZXNzVG9rZW4gZ2VuZXJhdGVzIGFuIEdDUCBhY2Nlc3MgdG9rZW5cbnRoYXQgY2FuIGJlIHVzZWQgdG8gYXV0aGVudGljYXRlIHdpdGggR0NSLlxuICpcbiAqIEBzY2hlbWEgR0NSQWNjZXNzVG9rZW5cbiAqL1xuZXhwb3J0IGNsYXNzIEdjckFjY2Vzc1Rva2VuIGV4dGVuZHMgQXBpT2JqZWN0IHtcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGFwaVZlcnNpb24gYW5kIGtpbmQgZm9yIFwiR0NSQWNjZXNzVG9rZW5cIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2dlbmVyYXRvcnMuZXh0ZXJuYWwtc2VjcmV0cy5pby92MWFscGhhMScsXG4gICAga2luZDogJ0dDUkFjY2Vzc1Rva2VuJyxcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIGEgS3ViZXJuZXRlcyBtYW5pZmVzdCBmb3IgXCJHQ1JBY2Nlc3NUb2tlblwiLlxuICAgKlxuICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGlubGluZSByZXNvdXJjZSBtYW5pZmVzdHMgaW5zaWRlIG90aGVyIG9iamVjdHMgKGUuZy4gYXMgdGVtcGxhdGVzKS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1hbmlmZXN0KHByb3BzOiBHY3JBY2Nlc3NUb2tlblByb3BzID0ge30pOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5HY3JBY2Nlc3NUb2tlbi5HVkssXG4gICAgICAuLi50b0pzb25fR2NyQWNjZXNzVG9rZW5Qcm9wcyhwcm9wcyksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgXCJHQ1JBY2Nlc3NUb2tlblwiIEFQSSBvYmplY3RcbiAgICogQHBhcmFtIHNjb3BlIHRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBvYmplY3RcbiAgICogQHBhcmFtIGlkIGEgc2NvcGUtbG9jYWwgbmFtZSBmb3IgdGhlIG9iamVjdFxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogR2NyQWNjZXNzVG9rZW5Qcm9wcyA9IHt9KSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICAuLi5HY3JBY2Nlc3NUb2tlbi5HVkssXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBvYmplY3QgdG8gS3ViZXJuZXRlcyBKU09OLlxuICAgKi9cbiAgcHVibGljIHRvSnNvbigpOiBhbnkge1xuICAgIGNvbnN0IHJlc29sdmVkID0gc3VwZXIudG9Kc29uKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uR2NyQWNjZXNzVG9rZW4uR1ZLLFxuICAgICAgLi4udG9Kc29uX0djckFjY2Vzc1Rva2VuUHJvcHMocmVzb2x2ZWQpLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBHQ1JBY2Nlc3NUb2tlbiBnZW5lcmF0ZXMgYW4gR0NQIGFjY2VzcyB0b2tlblxuICogdGhhdCBjYW4gYmUgdXNlZCB0byBhdXRoZW50aWNhdGUgd2l0aCBHQ1IuXG4gKlxuICogQHNjaGVtYSBHQ1JBY2Nlc3NUb2tlblxuICovXG5leHBvcnQgaW50ZXJmYWNlIEdjckFjY2Vzc1Rva2VuUHJvcHMge1xuICAvKipcbiAgICogQHNjaGVtYSBHQ1JBY2Nlc3NUb2tlbiNtZXRhZGF0YVxuICAgKi9cbiAgcmVhZG9ubHkgbWV0YWRhdGE/OiBBcGlPYmplY3RNZXRhZGF0YTtcblxuICAvKipcbiAgICogQHNjaGVtYSBHQ1JBY2Nlc3NUb2tlbiNzcGVjXG4gICAqL1xuICByZWFkb25seSBzcGVjPzogR2NyQWNjZXNzVG9rZW5TcGVjO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0djckFjY2Vzc1Rva2VuUHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0djckFjY2Vzc1Rva2VuUHJvcHMob2JqOiBHY3JBY2Nlc3NUb2tlblByb3BzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnbWV0YWRhdGEnOiBvYmoubWV0YWRhdGEsXG4gICAgJ3NwZWMnOiB0b0pzb25fR2NyQWNjZXNzVG9rZW5TcGVjKG9iai5zcGVjKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIEdjckFjY2Vzc1Rva2VuU3BlY1xuICovXG5leHBvcnQgaW50ZXJmYWNlIEdjckFjY2Vzc1Rva2VuU3BlYyB7XG4gIC8qKlxuICAgKiBBdXRoIGRlZmluZXMgdGhlIG1lYW5zIGZvciBhdXRoZW50aWNhdGluZyB3aXRoIEdDUFxuICAgKlxuICAgKiBAc2NoZW1hIEdjckFjY2Vzc1Rva2VuU3BlYyNhdXRoXG4gICAqL1xuICByZWFkb25seSBhdXRoOiBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoO1xuXG4gIC8qKlxuICAgKiBQcm9qZWN0SUQgZGVmaW5lcyB3aGljaCBwcm9qZWN0IHRvIHVzZSB0byBhdXRoZW50aWNhdGUgd2l0aFxuICAgKlxuICAgKiBAc2NoZW1hIEdjckFjY2Vzc1Rva2VuU3BlYyNwcm9qZWN0SURcbiAgICovXG4gIHJlYWRvbmx5IHByb2plY3RJZDogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0djckFjY2Vzc1Rva2VuU3BlYycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fR2NyQWNjZXNzVG9rZW5TcGVjKG9iajogR2NyQWNjZXNzVG9rZW5TcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXV0aCc6IHRvSnNvbl9HY3JBY2Nlc3NUb2tlblNwZWNBdXRoKG9iai5hdXRoKSxcbiAgICAncHJvamVjdElEJzogb2JqLnByb2plY3RJZCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBdXRoIGRlZmluZXMgdGhlIG1lYW5zIGZvciBhdXRoZW50aWNhdGluZyB3aXRoIEdDUFxuICpcbiAqIEBzY2hlbWEgR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFxuICovXG5leHBvcnQgaW50ZXJmYWNlIEdjckFjY2Vzc1Rva2VuU3BlY0F1dGgge1xuICAvKipcbiAgICogQHNjaGVtYSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoI3NlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0UmVmPzogR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZjtcblxuICAvKipcbiAgICogQHNjaGVtYSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoI3dvcmtsb2FkSWRlbnRpdHlcbiAgICovXG4gIHJlYWRvbmx5IHdvcmtsb2FkSWRlbnRpdHk/OiBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eTtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdHY3JBY2Nlc3NUb2tlblNwZWNBdXRoJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9HY3JBY2Nlc3NUb2tlblNwZWNBdXRoKG9iajogR2NyQWNjZXNzVG9rZW5TcGVjQXV0aCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3NlY3JldFJlZic6IHRvSnNvbl9HY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmKG9iai5zZWNyZXRSZWYpLFxuICAgICd3b3JrbG9hZElkZW50aXR5JzogdG9Kc29uX0djckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5KG9iai53b3JrbG9hZElkZW50aXR5KSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIEdjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIFRoZSBTZWNyZXRBY2Nlc3NLZXkgaXMgdXNlZCBmb3IgYXV0aGVudGljYXRpb25cbiAgICpcbiAgICogQHNjaGVtYSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmI3NlY3JldEFjY2Vzc0tleVNlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmPzogR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9HY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmKG9iajogR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3NlY3JldEFjY2Vzc0tleVNlY3JldFJlZic6IHRvSnNvbl9HY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmKG9iai5zZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eSB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIEdjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5I2NsdXN0ZXJMb2NhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgY2x1c3RlckxvY2F0aW9uOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkjY2x1c3Rlck5hbWVcbiAgICovXG4gIHJlYWRvbmx5IGNsdXN0ZXJOYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkjY2x1c3RlclByb2plY3RJRFxuICAgKi9cbiAgcmVhZG9ubHkgY2x1c3RlclByb2plY3RJZD86IHN0cmluZztcblxuICAvKipcbiAgICogQSByZWZlcmVuY2UgdG8gYSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZS5cbiAgICpcbiAgICogQHNjaGVtYSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eSNzZXJ2aWNlQWNjb3VudFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VydmljZUFjY291bnRSZWY6IEdjckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5U2VydmljZUFjY291bnRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHknIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0djckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5KG9iajogR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHkgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdjbHVzdGVyTG9jYXRpb24nOiBvYmouY2x1c3RlckxvY2F0aW9uLFxuICAgICdjbHVzdGVyTmFtZSc6IG9iai5jbHVzdGVyTmFtZSxcbiAgICAnY2x1c3RlclByb2plY3RJRCc6IG9iai5jbHVzdGVyUHJvamVjdElkLFxuICAgICdzZXJ2aWNlQWNjb3VudFJlZic6IHRvSnNvbl9HY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmKG9iai5zZXJ2aWNlQWNjb3VudFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIFNlY3JldEFjY2Vzc0tleSBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICpcbiAqIEBzY2hlbWEgR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEdjckFjY2Vzc1Rva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0djckFjY2Vzc1Rva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0djckFjY2Vzc1Rva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYob2JqOiBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEEgcmVmZXJlbmNlIHRvIGEgU2VydmljZUFjY291bnQgcmVzb3VyY2UuXG4gKlxuICogQHNjaGVtYSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgR2NyQWNjZXNzVG9rZW5TcGVjQXV0aFdvcmtsb2FkSWRlbnRpdHlTZXJ2aWNlQWNjb3VudFJlZiB7XG4gIC8qKlxuICAgKiBBdWRpZW5jZSBzcGVjaWZpZXMgdGhlIGBhdWRgIGNsYWltIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHRva2VuXG4gICAqIElmIHRoZSBzZXJ2aWNlIGFjY291bnQgdXNlcyBhIHdlbGwta25vd24gYW5ub3RhdGlvbiBmb3IgZS5nLiBJUlNBIG9yIEdDUCBXb3JrbG9hZCBJZGVudGl0eVxuICAgKiB0aGVuIHRoaXMgYXVkaWVuY2VzIHdpbGwgYmUgYXBwZW5kZWQgdG8gdGhlIGxpc3RcbiAgICpcbiAgICogQHNjaGVtYSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmI2F1ZGllbmNlc1xuICAgKi9cbiAgcmVhZG9ubHkgYXVkaWVuY2VzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZXNwYWNlIG9mIHRoZSByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0djckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5U2VydmljZUFjY291bnRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0djckFjY2Vzc1Rva2VuU3BlY0F1dGhXb3JrbG9hZElkZW50aXR5U2VydmljZUFjY291bnRSZWYob2JqOiBHY3JBY2Nlc3NUb2tlblNwZWNBdXRoV29ya2xvYWRJZGVudGl0eVNlcnZpY2VBY2NvdW50UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXVkaWVuY2VzJzogb2JqLmF1ZGllbmNlcz8ubWFwKHkgPT4geSksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuXG4vKipcbiAqXG4gKlxuICogQHNjaGVtYSBHZW5lcmF0b3JTdGF0ZVxuICovXG5leHBvcnQgY2xhc3MgR2VuZXJhdG9yU3RhdGUgZXh0ZW5kcyBBcGlPYmplY3Qge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYXBpVmVyc2lvbiBhbmQga2luZCBmb3IgXCJHZW5lcmF0b3JTdGF0ZVwiXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEdWSzogR3JvdXBWZXJzaW9uS2luZCA9IHtcbiAgICBhcGlWZXJzaW9uOiAnZ2VuZXJhdG9ycy5leHRlcm5hbC1zZWNyZXRzLmlvL3YxYWxwaGExJyxcbiAgICBraW5kOiAnR2VuZXJhdG9yU3RhdGUnLFxuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgYSBLdWJlcm5ldGVzIG1hbmlmZXN0IGZvciBcIkdlbmVyYXRvclN0YXRlXCIuXG4gICAqXG4gICAqIFRoaXMgY2FuIGJlIHVzZWQgdG8gaW5saW5lIHJlc291cmNlIG1hbmlmZXN0cyBpbnNpZGUgb3RoZXIgb2JqZWN0cyAoZS5nLiBhcyB0ZW1wbGF0ZXMpLlxuICAgKlxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWFuaWZlc3QocHJvcHM6IEdlbmVyYXRvclN0YXRlUHJvcHMgPSB7fSk6IGFueSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLkdlbmVyYXRvclN0YXRlLkdWSyxcbiAgICAgIC4uLnRvSnNvbl9HZW5lcmF0b3JTdGF0ZVByb3BzKHByb3BzKSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBcIkdlbmVyYXRvclN0YXRlXCIgQVBJIG9iamVjdFxuICAgKiBAcGFyYW0gc2NvcGUgdGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIG9iamVjdFxuICAgKiBAcGFyYW0gaWQgYSBzY29wZS1sb2NhbCBuYW1lIGZvciB0aGUgb2JqZWN0XG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBHZW5lcmF0b3JTdGF0ZVByb3BzID0ge30pIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIC4uLkdlbmVyYXRvclN0YXRlLkdWSyxcbiAgICAgIC4uLnByb3BzLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgdGhlIG9iamVjdCB0byBLdWJlcm5ldGVzIEpTT04uXG4gICAqL1xuICBwdWJsaWMgdG9Kc29uKCk6IGFueSB7XG4gICAgY29uc3QgcmVzb2x2ZWQgPSBzdXBlci50b0pzb24oKTtcblxuICAgIHJldHVybiB7XG4gICAgICAuLi5HZW5lcmF0b3JTdGF0ZS5HVkssXG4gICAgICAuLi50b0pzb25fR2VuZXJhdG9yU3RhdGVQcm9wcyhyZXNvbHZlZCksXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIEBzY2hlbWEgR2VuZXJhdG9yU3RhdGVcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHZW5lcmF0b3JTdGF0ZVByb3BzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgR2VuZXJhdG9yU3RhdGUjbWV0YWRhdGFcbiAgICovXG4gIHJlYWRvbmx5IG1ldGFkYXRhPzogQXBpT2JqZWN0TWV0YWRhdGE7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgR2VuZXJhdG9yU3RhdGUjc3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgc3BlYz86IEdlbmVyYXRvclN0YXRlU3BlYztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdHZW5lcmF0b3JTdGF0ZVByb3BzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9HZW5lcmF0b3JTdGF0ZVByb3BzKG9iajogR2VuZXJhdG9yU3RhdGVQcm9wcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ21ldGFkYXRhJzogb2JqLm1ldGFkYXRhLFxuICAgICdzcGVjJzogdG9Kc29uX0dlbmVyYXRvclN0YXRlU3BlYyhvYmouc3BlYyksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQHNjaGVtYSBHZW5lcmF0b3JTdGF0ZVNwZWNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHZW5lcmF0b3JTdGF0ZVNwZWMge1xuICAvKipcbiAgICogR2FyYmFnZUNvbGxlY3Rpb25EZWFkbGluZSBpcyB0aGUgdGltZSBhZnRlciB3aGljaCB0aGUgZ2VuZXJhdG9yIHN0YXRlXG4gICAqIHdpbGwgYmUgZGVsZXRlZC5cbiAgICogSXQgaXMgc2V0IGJ5IHRoZSBjb250cm9sbGVyIHdoaWNoIGNyZWF0ZXMgdGhlIGdlbmVyYXRvciBzdGF0ZSBhbmRcbiAgICogY2FuIGJlIHNldCBjb25maWd1cmVkIGJ5IHRoZSB1c2VyLlxuICAgKiBJZiB0aGUgZ2FyYmFnZSBjb2xsZWN0aW9uIGRlYWRsaW5lIGlzIG5vdCBzZXQgdGhlIGdlbmVyYXRvciBzdGF0ZSB3aWxsIG5vdCBiZSBkZWxldGVkLlxuICAgKlxuICAgKiBAc2NoZW1hIEdlbmVyYXRvclN0YXRlU3BlYyNnYXJiYWdlQ29sbGVjdGlvbkRlYWRsaW5lXG4gICAqL1xuICByZWFkb25seSBnYXJiYWdlQ29sbGVjdGlvbkRlYWRsaW5lPzogRGF0ZTtcblxuICAvKipcbiAgICogUmVzb3VyY2UgaXMgdGhlIGdlbmVyYXRvciBtYW5pZmVzdCB0aGF0IHByb2R1Y2VkIHRoZSBzdGF0ZS5cbiAgICogSXQgaXMgYSBzbmFwc2hvdCBvZiB0aGUgZ2VuZXJhdG9yIG1hbmlmZXN0IGF0IHRoZSB0aW1lIHRoZSBzdGF0ZSB3YXMgcHJvZHVjZWQuXG4gICAqIFRoaXMgbWFuaWZlc3Qgd2lsbCBiZSB1c2VkIHRvIGRlbGV0ZSB0aGUgcmVzb3VyY2UuIEFueSBjb25maWd1cmF0aW9uIHRoYXQgaXMgcmVmZXJlbmNlZFxuICAgKiBpbiB0aGUgbWFuaWZlc3Qgc2hvdWxkIGJlIGF2YWlsYWJsZSBhdCB0aGUgdGltZSBvZiBnYXJiYWdlIGNvbGxlY3Rpb24uIElmIHRoYXQgaXMgbm90IHRoZSBjYXNlIGRlbGV0aW9uIHdpbGxcbiAgICogYmUgYmxvY2tlZCBieSBhIGZpbmFsaXplci5cbiAgICpcbiAgICogQHNjaGVtYSBHZW5lcmF0b3JTdGF0ZVNwZWMjcmVzb3VyY2VcbiAgICovXG4gIHJlYWRvbmx5IHJlc291cmNlOiBhbnk7XG5cbiAgLyoqXG4gICAqIFN0YXRlIGlzIHRoZSBzdGF0ZSB0aGF0IHdhcyBwcm9kdWNlZCBieSB0aGUgZ2VuZXJhdG9yIGltcGxlbWVudGF0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIEdlbmVyYXRvclN0YXRlU3BlYyNzdGF0ZVxuICAgKi9cbiAgcmVhZG9ubHkgc3RhdGU6IGFueTtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdHZW5lcmF0b3JTdGF0ZVNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0dlbmVyYXRvclN0YXRlU3BlYyhvYmo6IEdlbmVyYXRvclN0YXRlU3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2dhcmJhZ2VDb2xsZWN0aW9uRGVhZGxpbmUnOiBvYmouZ2FyYmFnZUNvbGxlY3Rpb25EZWFkbGluZT8udG9JU09TdHJpbmcoKSxcbiAgICAncmVzb3VyY2UnOiBvYmoucmVzb3VyY2UsXG4gICAgJ3N0YXRlJzogb2JqLnN0YXRlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG5cbi8qKlxuICogR2l0aHViQWNjZXNzVG9rZW4gZ2VuZXJhdGVzIGdoc18gYWNjZXNzVG9rZW5cbiAqXG4gKiBAc2NoZW1hIEdpdGh1YkFjY2Vzc1Rva2VuXG4gKi9cbmV4cG9ydCBjbGFzcyBHaXRodWJBY2Nlc3NUb2tlbiBleHRlbmRzIEFwaU9iamVjdCB7XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBhcGlWZXJzaW9uIGFuZCBraW5kIGZvciBcIkdpdGh1YkFjY2Vzc1Rva2VuXCJcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgR1ZLOiBHcm91cFZlcnNpb25LaW5kID0ge1xuICAgIGFwaVZlcnNpb246ICdnZW5lcmF0b3JzLmV4dGVybmFsLXNlY3JldHMuaW8vdjFhbHBoYTEnLFxuICAgIGtpbmQ6ICdHaXRodWJBY2Nlc3NUb2tlbicsXG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyBhIEt1YmVybmV0ZXMgbWFuaWZlc3QgZm9yIFwiR2l0aHViQWNjZXNzVG9rZW5cIi5cbiAgICpcbiAgICogVGhpcyBjYW4gYmUgdXNlZCB0byBpbmxpbmUgcmVzb3VyY2UgbWFuaWZlc3RzIGluc2lkZSBvdGhlciBvYmplY3RzIChlLmcuIGFzIHRlbXBsYXRlcykuXG4gICAqXG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtYW5pZmVzdChwcm9wczogR2l0aHViQWNjZXNzVG9rZW5Qcm9wcyA9IHt9KTogYW55IHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uR2l0aHViQWNjZXNzVG9rZW4uR1ZLLFxuICAgICAgLi4udG9Kc29uX0dpdGh1YkFjY2Vzc1Rva2VuUHJvcHMocHJvcHMpLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyBhIFwiR2l0aHViQWNjZXNzVG9rZW5cIiBBUEkgb2JqZWN0XG4gICAqIEBwYXJhbSBzY29wZSB0aGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgb2JqZWN0XG4gICAqIEBwYXJhbSBpZCBhIHNjb3BlLWxvY2FsIG5hbWUgZm9yIHRoZSBvYmplY3RcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IEdpdGh1YkFjY2Vzc1Rva2VuUHJvcHMgPSB7fSkge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgLi4uR2l0aHViQWNjZXNzVG9rZW4uR1ZLLFxuICAgICAgLi4ucHJvcHMsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyB0aGUgb2JqZWN0IHRvIEt1YmVybmV0ZXMgSlNPTi5cbiAgICovXG4gIHB1YmxpYyB0b0pzb24oKTogYW55IHtcbiAgICBjb25zdCByZXNvbHZlZCA9IHN1cGVyLnRvSnNvbigpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLkdpdGh1YkFjY2Vzc1Rva2VuLkdWSyxcbiAgICAgIC4uLnRvSnNvbl9HaXRodWJBY2Nlc3NUb2tlblByb3BzKHJlc29sdmVkKSxcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogR2l0aHViQWNjZXNzVG9rZW4gZ2VuZXJhdGVzIGdoc18gYWNjZXNzVG9rZW5cbiAqXG4gKiBAc2NoZW1hIEdpdGh1YkFjY2Vzc1Rva2VuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgR2l0aHViQWNjZXNzVG9rZW5Qcm9wcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIEdpdGh1YkFjY2Vzc1Rva2VuI21ldGFkYXRhXG4gICAqL1xuICByZWFkb25seSBtZXRhZGF0YT86IEFwaU9iamVjdE1ldGFkYXRhO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIEdpdGh1YkFjY2Vzc1Rva2VuI3NwZWNcbiAgICovXG4gIHJlYWRvbmx5IHNwZWM/OiBHaXRodWJBY2Nlc3NUb2tlblNwZWM7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnR2l0aHViQWNjZXNzVG9rZW5Qcm9wcycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fR2l0aHViQWNjZXNzVG9rZW5Qcm9wcyhvYmo6IEdpdGh1YkFjY2Vzc1Rva2VuUHJvcHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtZXRhZGF0YSc6IG9iai5tZXRhZGF0YSxcbiAgICAnc3BlYyc6IHRvSnNvbl9HaXRodWJBY2Nlc3NUb2tlblNwZWMob2JqLnNwZWMpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgR2l0aHViQWNjZXNzVG9rZW5TcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgR2l0aHViQWNjZXNzVG9rZW5TcGVjIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgR2l0aHViQWNjZXNzVG9rZW5TcGVjI2FwcElEXG4gICAqL1xuICByZWFkb25seSBhcHBJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBBdXRoIGNvbmZpZ3VyZXMgaG93IEVTTyBhdXRoZW50aWNhdGVzIHdpdGggYSBHaXRodWIgaW5zdGFuY2UuXG4gICAqXG4gICAqIEBzY2hlbWEgR2l0aHViQWNjZXNzVG9rZW5TcGVjI2F1dGhcbiAgICovXG4gIHJlYWRvbmx5IGF1dGg6IEdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGg7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgR2l0aHViQWNjZXNzVG9rZW5TcGVjI2luc3RhbGxJRFxuICAgKi9cbiAgcmVhZG9ubHkgaW5zdGFsbElkOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIE1hcCBvZiBwZXJtaXNzaW9ucyB0aGUgdG9rZW4gd2lsbCBoYXZlLiBJZiBvbWl0dGVkLCBkZWZhdWx0cyB0byBhbGwgcGVybWlzc2lvbnMgdGhlIEdpdEh1YiBBcHAgaGFzLlxuICAgKlxuICAgKiBAc2NoZW1hIEdpdGh1YkFjY2Vzc1Rva2VuU3BlYyNwZXJtaXNzaW9uc1xuICAgKi9cbiAgcmVhZG9ubHkgcGVybWlzc2lvbnM/OiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9O1xuXG4gIC8qKlxuICAgKiBMaXN0IG9mIHJlcG9zaXRvcmllcyB0aGUgdG9rZW4gd2lsbCBoYXZlIGFjY2VzcyB0by4gSWYgb21pdHRlZCwgZGVmYXVsdHMgdG8gYWxsIHJlcG9zaXRvcmllcyB0aGUgR2l0SHViIEFwcFxuICAgKiBpcyBpbnN0YWxsZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgR2l0aHViQWNjZXNzVG9rZW5TcGVjI3JlcG9zaXRvcmllc1xuICAgKi9cbiAgcmVhZG9ubHkgcmVwb3NpdG9yaWVzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIFVSTCBjb25maWd1cmVzIHRoZSBHaXRodWIgaW5zdGFuY2UgVVJMLiBEZWZhdWx0cyB0byBodHRwczovL2dpdGh1Yi5jb20vLlxuICAgKlxuICAgKiBAZGVmYXVsdCBodHRwczovL2dpdGh1Yi5jb20vLlxuICAgKiBAc2NoZW1hIEdpdGh1YkFjY2Vzc1Rva2VuU3BlYyN1cmxcbiAgICovXG4gIHJlYWRvbmx5IHVybD86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdHaXRodWJBY2Nlc3NUb2tlblNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0dpdGh1YkFjY2Vzc1Rva2VuU3BlYyhvYmo6IEdpdGh1YkFjY2Vzc1Rva2VuU3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2FwcElEJzogb2JqLmFwcElkLFxuICAgICdhdXRoJzogdG9Kc29uX0dpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGgob2JqLmF1dGgpLFxuICAgICdpbnN0YWxsSUQnOiBvYmouaW5zdGFsbElkLFxuICAgICdwZXJtaXNzaW9ucyc6ICgob2JqLnBlcm1pc3Npb25zKSA9PT0gdW5kZWZpbmVkKSA/IHVuZGVmaW5lZCA6IChPYmplY3QuZW50cmllcyhvYmoucGVybWlzc2lvbnMpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSkpLFxuICAgICdyZXBvc2l0b3JpZXMnOiBvYmoucmVwb3NpdG9yaWVzPy5tYXAoeSA9PiB5KSxcbiAgICAndXJsJzogb2JqLnVybCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBdXRoIGNvbmZpZ3VyZXMgaG93IEVTTyBhdXRoZW50aWNhdGVzIHdpdGggYSBHaXRodWIgaW5zdGFuY2UuXG4gKlxuICogQHNjaGVtYSBHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aCB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIEdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGgjcHJpdmF0ZUtleVxuICAgKi9cbiAgcmVhZG9ubHkgcHJpdmF0ZUtleTogR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXk7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aChvYmo6IEdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGggfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdwcml2YXRlS2V5JzogdG9Kc29uX0dpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5KG9iai5wcml2YXRlS2V5KSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIEdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXkge1xuICAvKipcbiAgICogQSByZWZlcmVuY2UgdG8gYSBzcGVjaWZpYyAna2V5JyB3aXRoaW4gYSBTZWNyZXQgcmVzb3VyY2UuXG4gICAqIEluIHNvbWUgaW5zdGFuY2VzLCBga2V5YCBpcyBhIHJlcXVpcmVkIGZpZWxkLlxuICAgKlxuICAgKiBAc2NoZW1hIEdpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5I3NlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0UmVmOiBHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoUHJpdmF0ZUtleVNlY3JldFJlZjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoUHJpdmF0ZUtleScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXkob2JqOiBHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoUHJpdmF0ZUtleSB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3NlY3JldFJlZic6IHRvSnNvbl9HaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoUHJpdmF0ZUtleVNlY3JldFJlZihvYmouc2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBIHJlZmVyZW5jZSB0byBhIHNwZWNpZmljICdrZXknIHdpdGhpbiBhIFNlY3JldCByZXNvdXJjZS5cbiAqIEluIHNvbWUgaW5zdGFuY2VzLCBga2V5YCBpcyBhIHJlcXVpcmVkIGZpZWxkLlxuICpcbiAqIEBzY2hlbWEgR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXlTZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoUHJpdmF0ZUtleVNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoUHJpdmF0ZUtleVNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBHaXRodWJBY2Nlc3NUb2tlblNwZWNBdXRoUHJpdmF0ZUtleVNlY3JldFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXlTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXlTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0dpdGh1YkFjY2Vzc1Rva2VuU3BlY0F1dGhQcml2YXRlS2V5U2VjcmV0UmVmKG9iajogR2l0aHViQWNjZXNzVG9rZW5TcGVjQXV0aFByaXZhdGVLZXlTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cblxuLyoqXG4gKlxuICpcbiAqIEBzY2hlbWEgR3JhZmFuYVxuICovXG5leHBvcnQgY2xhc3MgR3JhZmFuYSBleHRlbmRzIEFwaU9iamVjdCB7XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBhcGlWZXJzaW9uIGFuZCBraW5kIGZvciBcIkdyYWZhbmFcIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2dlbmVyYXRvcnMuZXh0ZXJuYWwtc2VjcmV0cy5pby92MWFscGhhMScsXG4gICAga2luZDogJ0dyYWZhbmEnLFxuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgYSBLdWJlcm5ldGVzIG1hbmlmZXN0IGZvciBcIkdyYWZhbmFcIi5cbiAgICpcbiAgICogVGhpcyBjYW4gYmUgdXNlZCB0byBpbmxpbmUgcmVzb3VyY2UgbWFuaWZlc3RzIGluc2lkZSBvdGhlciBvYmplY3RzIChlLmcuIGFzIHRlbXBsYXRlcykuXG4gICAqXG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtYW5pZmVzdChwcm9wczogR3JhZmFuYVByb3BzID0ge30pOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5HcmFmYW5hLkdWSyxcbiAgICAgIC4uLnRvSnNvbl9HcmFmYW5hUHJvcHMocHJvcHMpLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyBhIFwiR3JhZmFuYVwiIEFQSSBvYmplY3RcbiAgICogQHBhcmFtIHNjb3BlIHRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBvYmplY3RcbiAgICogQHBhcmFtIGlkIGEgc2NvcGUtbG9jYWwgbmFtZSBmb3IgdGhlIG9iamVjdFxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogR3JhZmFuYVByb3BzID0ge30pIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIC4uLkdyYWZhbmEuR1ZLLFxuICAgICAgLi4ucHJvcHMsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyB0aGUgb2JqZWN0IHRvIEt1YmVybmV0ZXMgSlNPTi5cbiAgICovXG4gIHB1YmxpYyB0b0pzb24oKTogYW55IHtcbiAgICBjb25zdCByZXNvbHZlZCA9IHN1cGVyLnRvSnNvbigpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLkdyYWZhbmEuR1ZLLFxuICAgICAgLi4udG9Kc29uX0dyYWZhbmFQcm9wcyhyZXNvbHZlZCksXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIEBzY2hlbWEgR3JhZmFuYVxuICovXG5leHBvcnQgaW50ZXJmYWNlIEdyYWZhbmFQcm9wcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIEdyYWZhbmEjbWV0YWRhdGFcbiAgICovXG4gIHJlYWRvbmx5IG1ldGFkYXRhPzogQXBpT2JqZWN0TWV0YWRhdGE7XG5cbiAgLyoqXG4gICAqIEdyYWZhbmFTcGVjIGNvbnRyb2xzIHRoZSBiZWhhdmlvciBvZiB0aGUgZ3JhZmFuYSBnZW5lcmF0b3IuXG4gICAqXG4gICAqIEBzY2hlbWEgR3JhZmFuYSNzcGVjXG4gICAqL1xuICByZWFkb25seSBzcGVjPzogR3JhZmFuYVNwZWM7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnR3JhZmFuYVByb3BzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9HcmFmYW5hUHJvcHMob2JqOiBHcmFmYW5hUHJvcHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtZXRhZGF0YSc6IG9iai5tZXRhZGF0YSxcbiAgICAnc3BlYyc6IHRvSnNvbl9HcmFmYW5hU3BlYyhvYmouc3BlYyksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogR3JhZmFuYVNwZWMgY29udHJvbHMgdGhlIGJlaGF2aW9yIG9mIHRoZSBncmFmYW5hIGdlbmVyYXRvci5cbiAqXG4gKiBAc2NoZW1hIEdyYWZhbmFTcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgR3JhZmFuYVNwZWMge1xuICAvKipcbiAgICogQXV0aCBpcyB0aGUgYXV0aGVudGljYXRpb24gY29uZmlndXJhdGlvbiB0byBhdXRoZW50aWNhdGVcbiAgICogYWdhaW5zdCB0aGUgR3JhZmFuYSBpbnN0YW5jZS5cbiAgICpcbiAgICogQHNjaGVtYSBHcmFmYW5hU3BlYyNhdXRoXG4gICAqL1xuICByZWFkb25seSBhdXRoOiBHcmFmYW5hU3BlY0F1dGg7XG5cbiAgLyoqXG4gICAqIFNlcnZpY2VBY2NvdW50IGlzIHRoZSBjb25maWd1cmF0aW9uIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHRoYXRcbiAgICogaXMgc3VwcG9zZWQgdG8gYmUgZ2VuZXJhdGVkIGJ5IHRoZSBnZW5lcmF0b3IuXG4gICAqXG4gICAqIEBzY2hlbWEgR3JhZmFuYVNwZWMjc2VydmljZUFjY291bnRcbiAgICovXG4gIHJlYWRvbmx5IHNlcnZpY2VBY2NvdW50OiBHcmFmYW5hU3BlY1NlcnZpY2VBY2NvdW50O1xuXG4gIC8qKlxuICAgKiBVUkwgaXMgdGhlIFVSTCBvZiB0aGUgR3JhZmFuYSBpbnN0YW5jZS5cbiAgICpcbiAgICogQHNjaGVtYSBHcmFmYW5hU3BlYyN1cmxcbiAgICovXG4gIHJlYWRvbmx5IHVybDogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0dyYWZhbmFTcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9HcmFmYW5hU3BlYyhvYmo6IEdyYWZhbmFTcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXV0aCc6IHRvSnNvbl9HcmFmYW5hU3BlY0F1dGgob2JqLmF1dGgpLFxuICAgICdzZXJ2aWNlQWNjb3VudCc6IHRvSnNvbl9HcmFmYW5hU3BlY1NlcnZpY2VBY2NvdW50KG9iai5zZXJ2aWNlQWNjb3VudCksXG4gICAgJ3VybCc6IG9iai51cmwsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQXV0aCBpcyB0aGUgYXV0aGVudGljYXRpb24gY29uZmlndXJhdGlvbiB0byBhdXRoZW50aWNhdGVcbiAqIGFnYWluc3QgdGhlIEdyYWZhbmEgaW5zdGFuY2UuXG4gKlxuICogQHNjaGVtYSBHcmFmYW5hU3BlY0F1dGhcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHcmFmYW5hU3BlY0F1dGgge1xuICAvKipcbiAgICogQmFzaWMgYXV0aCBjcmVkZW50aWFscyB1c2VkIHRvIGF1dGhlbnRpY2F0ZSBhZ2FpbnN0IHRoZSBHcmFmYW5hIGluc3RhbmNlLlxuICAgKiBOb3RlOiB5b3UgbmVlZCBhIHRva2VuIHdoaWNoIGhhcyBlbGV2YXRlZCBwZXJtaXNzaW9ucyB0byBjcmVhdGUgc2VydmljZSBhY2NvdW50cy5cbiAgICogU2VlIGhlcmUgZm9yIHRoZSBkb2N1bWVudGF0aW9uIG9uIGJhc2ljIHJvbGVzIG9mZmVyZWQgYnkgR3JhZmFuYTpcbiAgICogaHR0cHM6Ly9ncmFmYW5hLmNvbS9kb2NzL2dyYWZhbmEvbGF0ZXN0L2FkbWluaXN0cmF0aW9uL3JvbGVzLWFuZC1wZXJtaXNzaW9ucy9hY2Nlc3MtY29udHJvbC9yYmFjLWZpeGVkLWJhc2ljLXJvbGUtZGVmaW5pdGlvbnMvXG4gICAqXG4gICAqIEBzY2hlbWEgR3JhZmFuYVNwZWNBdXRoI2Jhc2ljXG4gICAqL1xuICByZWFkb25seSBiYXNpYz86IEdyYWZhbmFTcGVjQXV0aEJhc2ljO1xuXG4gIC8qKlxuICAgKiBBIHNlcnZpY2UgYWNjb3VudCB0b2tlbiB1c2VkIHRvIGF1dGhlbnRpY2F0ZSBhZ2FpbnN0IHRoZSBHcmFmYW5hIGluc3RhbmNlLlxuICAgKiBOb3RlOiB5b3UgbmVlZCBhIHRva2VuIHdoaWNoIGhhcyBlbGV2YXRlZCBwZXJtaXNzaW9ucyB0byBjcmVhdGUgc2VydmljZSBhY2NvdW50cy5cbiAgICogU2VlIGhlcmUgZm9yIHRoZSBkb2N1bWVudGF0aW9uIG9uIGJhc2ljIHJvbGVzIG9mZmVyZWQgYnkgR3JhZmFuYTpcbiAgICogaHR0cHM6Ly9ncmFmYW5hLmNvbS9kb2NzL2dyYWZhbmEvbGF0ZXN0L2FkbWluaXN0cmF0aW9uL3JvbGVzLWFuZC1wZXJtaXNzaW9ucy9hY2Nlc3MtY29udHJvbC9yYmFjLWZpeGVkLWJhc2ljLXJvbGUtZGVmaW5pdGlvbnMvXG4gICAqXG4gICAqIEBzY2hlbWEgR3JhZmFuYVNwZWNBdXRoI3Rva2VuXG4gICAqL1xuICByZWFkb25seSB0b2tlbj86IEdyYWZhbmFTcGVjQXV0aFRva2VuO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0dyYWZhbmFTcGVjQXV0aCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fR3JhZmFuYVNwZWNBdXRoKG9iajogR3JhZmFuYVNwZWNBdXRoIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYmFzaWMnOiB0b0pzb25fR3JhZmFuYVNwZWNBdXRoQmFzaWMob2JqLmJhc2ljKSxcbiAgICAndG9rZW4nOiB0b0pzb25fR3JhZmFuYVNwZWNBdXRoVG9rZW4ob2JqLnRva2VuKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBTZXJ2aWNlQWNjb3VudCBpcyB0aGUgY29uZmlndXJhdGlvbiBmb3IgdGhlIHNlcnZpY2UgYWNjb3VudCB0aGF0XG4gKiBpcyBzdXBwb3NlZCB0byBiZSBnZW5lcmF0ZWQgYnkgdGhlIGdlbmVyYXRvci5cbiAqXG4gKiBAc2NoZW1hIEdyYWZhbmFTcGVjU2VydmljZUFjY291bnRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHcmFmYW5hU3BlY1NlcnZpY2VBY2NvdW50IHtcbiAgLyoqXG4gICAqIE5hbWUgaXMgdGhlIG5hbWUgb2YgdGhlIHNlcnZpY2UgYWNjb3VudCB0aGF0IHdpbGwgYmUgY3JlYXRlZCBieSBFU08uXG4gICAqXG4gICAqIEBzY2hlbWEgR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudCNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFJvbGUgaXMgdGhlIHJvbGUgb2YgdGhlIHNlcnZpY2UgYWNjb3VudC5cbiAgICogU2VlIGhlcmUgZm9yIHRoZSBkb2N1bWVudGF0aW9uIG9uIGJhc2ljIHJvbGVzIG9mZmVyZWQgYnkgR3JhZmFuYTpcbiAgICogaHR0cHM6Ly9ncmFmYW5hLmNvbS9kb2NzL2dyYWZhbmEvbGF0ZXN0L2FkbWluaXN0cmF0aW9uL3JvbGVzLWFuZC1wZXJtaXNzaW9ucy9hY2Nlc3MtY29udHJvbC9yYmFjLWZpeGVkLWJhc2ljLXJvbGUtZGVmaW5pdGlvbnMvXG4gICAqXG4gICAqIEBzY2hlbWEgR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudCNyb2xlXG4gICAqL1xuICByZWFkb25seSByb2xlOiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fR3JhZmFuYVNwZWNTZXJ2aWNlQWNjb3VudChvYmo6IEdyYWZhbmFTcGVjU2VydmljZUFjY291bnQgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ3JvbGUnOiBvYmoucm9sZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBCYXNpYyBhdXRoIGNyZWRlbnRpYWxzIHVzZWQgdG8gYXV0aGVudGljYXRlIGFnYWluc3QgdGhlIEdyYWZhbmEgaW5zdGFuY2UuXG4gKiBOb3RlOiB5b3UgbmVlZCBhIHRva2VuIHdoaWNoIGhhcyBlbGV2YXRlZCBwZXJtaXNzaW9ucyB0byBjcmVhdGUgc2VydmljZSBhY2NvdW50cy5cbiAqIFNlZSBoZXJlIGZvciB0aGUgZG9jdW1lbnRhdGlvbiBvbiBiYXNpYyByb2xlcyBvZmZlcmVkIGJ5IEdyYWZhbmE6XG4gKiBodHRwczovL2dyYWZhbmEuY29tL2RvY3MvZ3JhZmFuYS9sYXRlc3QvYWRtaW5pc3RyYXRpb24vcm9sZXMtYW5kLXBlcm1pc3Npb25zL2FjY2Vzcy1jb250cm9sL3JiYWMtZml4ZWQtYmFzaWMtcm9sZS1kZWZpbml0aW9ucy9cbiAqXG4gKiBAc2NoZW1hIEdyYWZhbmFTcGVjQXV0aEJhc2ljXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgR3JhZmFuYVNwZWNBdXRoQmFzaWMge1xuICAvKipcbiAgICogQSBiYXNpYyBhdXRoIHBhc3N3b3JkIHVzZWQgdG8gYXV0aGVudGljYXRlIGFnYWluc3QgdGhlIEdyYWZhbmEgaW5zdGFuY2UuXG4gICAqXG4gICAqIEBzY2hlbWEgR3JhZmFuYVNwZWNBdXRoQmFzaWMjcGFzc3dvcmRcbiAgICovXG4gIHJlYWRvbmx5IHBhc3N3b3JkOiBHcmFmYW5hU3BlY0F1dGhCYXNpY1Bhc3N3b3JkO1xuXG4gIC8qKlxuICAgKiBBIGJhc2ljIGF1dGggdXNlcm5hbWUgdXNlZCB0byBhdXRoZW50aWNhdGUgYWdhaW5zdCB0aGUgR3JhZmFuYSBpbnN0YW5jZS5cbiAgICpcbiAgICogQHNjaGVtYSBHcmFmYW5hU3BlY0F1dGhCYXNpYyN1c2VybmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgdXNlcm5hbWU6IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdHcmFmYW5hU3BlY0F1dGhCYXNpYycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fR3JhZmFuYVNwZWNBdXRoQmFzaWMob2JqOiBHcmFmYW5hU3BlY0F1dGhCYXNpYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3Bhc3N3b3JkJzogdG9Kc29uX0dyYWZhbmFTcGVjQXV0aEJhc2ljUGFzc3dvcmQob2JqLnBhc3N3b3JkKSxcbiAgICAndXNlcm5hbWUnOiBvYmoudXNlcm5hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQSBzZXJ2aWNlIGFjY291bnQgdG9rZW4gdXNlZCB0byBhdXRoZW50aWNhdGUgYWdhaW5zdCB0aGUgR3JhZmFuYSBpbnN0YW5jZS5cbiAqIE5vdGU6IHlvdSBuZWVkIGEgdG9rZW4gd2hpY2ggaGFzIGVsZXZhdGVkIHBlcm1pc3Npb25zIHRvIGNyZWF0ZSBzZXJ2aWNlIGFjY291bnRzLlxuICogU2VlIGhlcmUgZm9yIHRoZSBkb2N1bWVudGF0aW9uIG9uIGJhc2ljIHJvbGVzIG9mZmVyZWQgYnkgR3JhZmFuYTpcbiAqIGh0dHBzOi8vZ3JhZmFuYS5jb20vZG9jcy9ncmFmYW5hL2xhdGVzdC9hZG1pbmlzdHJhdGlvbi9yb2xlcy1hbmQtcGVybWlzc2lvbnMvYWNjZXNzLWNvbnRyb2wvcmJhYy1maXhlZC1iYXNpYy1yb2xlLWRlZmluaXRpb25zL1xuICpcbiAqIEBzY2hlbWEgR3JhZmFuYVNwZWNBdXRoVG9rZW5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHcmFmYW5hU3BlY0F1dGhUb2tlbiB7XG4gIC8qKlxuICAgKiBUaGUga2V5IHdoZXJlIHRoZSB0b2tlbiBpcyBmb3VuZC5cbiAgICpcbiAgICogQHNjaGVtYSBHcmFmYW5hU3BlY0F1dGhUb2tlbiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBHcmFmYW5hU3BlY0F1dGhUb2tlbiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0dyYWZhbmFTcGVjQXV0aFRva2VuJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9HcmFmYW5hU3BlY0F1dGhUb2tlbihvYmo6IEdyYWZhbmFTcGVjQXV0aFRva2VuIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEEgYmFzaWMgYXV0aCBwYXNzd29yZCB1c2VkIHRvIGF1dGhlbnRpY2F0ZSBhZ2FpbnN0IHRoZSBHcmFmYW5hIGluc3RhbmNlLlxuICpcbiAqIEBzY2hlbWEgR3JhZmFuYVNwZWNBdXRoQmFzaWNQYXNzd29yZFxuICovXG5leHBvcnQgaW50ZXJmYWNlIEdyYWZhbmFTcGVjQXV0aEJhc2ljUGFzc3dvcmQge1xuICAvKipcbiAgICogVGhlIGtleSB3aGVyZSB0aGUgdG9rZW4gaXMgZm91bmQuXG4gICAqXG4gICAqIEBzY2hlbWEgR3JhZmFuYVNwZWNBdXRoQmFzaWNQYXNzd29yZCNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBHcmFmYW5hU3BlY0F1dGhCYXNpY1Bhc3N3b3JkI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnR3JhZmFuYVNwZWNBdXRoQmFzaWNQYXNzd29yZCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fR3JhZmFuYVNwZWNBdXRoQmFzaWNQYXNzd29yZChvYmo6IEdyYWZhbmFTcGVjQXV0aEJhc2ljUGFzc3dvcmQgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cblxuLyoqXG4gKiBQYXNzd29yZCBnZW5lcmF0ZXMgYSByYW5kb20gcGFzc3dvcmQgYmFzZWQgb24gdGhlXG5jb25maWd1cmF0aW9uIHBhcmFtZXRlcnMgaW4gc3BlYy5cbllvdSBjYW4gc3BlY2lmeSB0aGUgbGVuZ3RoLCBjaGFyYWN0ZXJzZXQgYW5kIG90aGVyIGF0dHJpYnV0ZXMuXG4gKlxuICogQHNjaGVtYSBQYXNzd29yZFxuICovXG5leHBvcnQgY2xhc3MgUGFzc3dvcmQgZXh0ZW5kcyBBcGlPYmplY3Qge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYXBpVmVyc2lvbiBhbmQga2luZCBmb3IgXCJQYXNzd29yZFwiXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEdWSzogR3JvdXBWZXJzaW9uS2luZCA9IHtcbiAgICBhcGlWZXJzaW9uOiAnZ2VuZXJhdG9ycy5leHRlcm5hbC1zZWNyZXRzLmlvL3YxYWxwaGExJyxcbiAgICBraW5kOiAnUGFzc3dvcmQnLFxuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgYSBLdWJlcm5ldGVzIG1hbmlmZXN0IGZvciBcIlBhc3N3b3JkXCIuXG4gICAqXG4gICAqIFRoaXMgY2FuIGJlIHVzZWQgdG8gaW5saW5lIHJlc291cmNlIG1hbmlmZXN0cyBpbnNpZGUgb3RoZXIgb2JqZWN0cyAoZS5nLiBhcyB0ZW1wbGF0ZXMpLlxuICAgKlxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWFuaWZlc3QocHJvcHM6IFBhc3N3b3JkUHJvcHMgPSB7fSk6IGFueSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLlBhc3N3b3JkLkdWSyxcbiAgICAgIC4uLnRvSnNvbl9QYXNzd29yZFByb3BzKHByb3BzKSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBcIlBhc3N3b3JkXCIgQVBJIG9iamVjdFxuICAgKiBAcGFyYW0gc2NvcGUgdGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIG9iamVjdFxuICAgKiBAcGFyYW0gaWQgYSBzY29wZS1sb2NhbCBuYW1lIGZvciB0aGUgb2JqZWN0XG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBQYXNzd29yZFByb3BzID0ge30pIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIC4uLlBhc3N3b3JkLkdWSyxcbiAgICAgIC4uLnByb3BzLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgdGhlIG9iamVjdCB0byBLdWJlcm5ldGVzIEpTT04uXG4gICAqL1xuICBwdWJsaWMgdG9Kc29uKCk6IGFueSB7XG4gICAgY29uc3QgcmVzb2x2ZWQgPSBzdXBlci50b0pzb24oKTtcblxuICAgIHJldHVybiB7XG4gICAgICAuLi5QYXNzd29yZC5HVkssXG4gICAgICAuLi50b0pzb25fUGFzc3dvcmRQcm9wcyhyZXNvbHZlZCksXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIFBhc3N3b3JkIGdlbmVyYXRlcyBhIHJhbmRvbSBwYXNzd29yZCBiYXNlZCBvbiB0aGVcbiAqIGNvbmZpZ3VyYXRpb24gcGFyYW1ldGVycyBpbiBzcGVjLlxuICogWW91IGNhbiBzcGVjaWZ5IHRoZSBsZW5ndGgsIGNoYXJhY3RlcnNldCBhbmQgb3RoZXIgYXR0cmlidXRlcy5cbiAqXG4gKiBAc2NoZW1hIFBhc3N3b3JkXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUGFzc3dvcmRQcm9wcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIFBhc3N3b3JkI21ldGFkYXRhXG4gICAqL1xuICByZWFkb25seSBtZXRhZGF0YT86IEFwaU9iamVjdE1ldGFkYXRhO1xuXG4gIC8qKlxuICAgKiBQYXNzd29yZFNwZWMgY29udHJvbHMgdGhlIGJlaGF2aW9yIG9mIHRoZSBwYXNzd29yZCBnZW5lcmF0b3IuXG4gICAqXG4gICAqIEBzY2hlbWEgUGFzc3dvcmQjc3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgc3BlYz86IFBhc3N3b3JkU3BlYztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdQYXNzd29yZFByb3BzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9QYXNzd29yZFByb3BzKG9iajogUGFzc3dvcmRQcm9wcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ21ldGFkYXRhJzogb2JqLm1ldGFkYXRhLFxuICAgICdzcGVjJzogdG9Kc29uX1Bhc3N3b3JkU3BlYyhvYmouc3BlYyksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogUGFzc3dvcmRTcGVjIGNvbnRyb2xzIHRoZSBiZWhhdmlvciBvZiB0aGUgcGFzc3dvcmQgZ2VuZXJhdG9yLlxuICpcbiAqIEBzY2hlbWEgUGFzc3dvcmRTcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUGFzc3dvcmRTcGVjIHtcbiAgLyoqXG4gICAqIHNldCBBbGxvd1JlcGVhdCB0byB0cnVlIHRvIGFsbG93IHJlcGVhdGluZyBjaGFyYWN0ZXJzLlxuICAgKlxuICAgKiBAc2NoZW1hIFBhc3N3b3JkU3BlYyNhbGxvd1JlcGVhdFxuICAgKi9cbiAgcmVhZG9ubHkgYWxsb3dSZXBlYXQ6IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIERpZ2l0cyBzcGVjaWZpZXMgdGhlIG51bWJlciBvZiBkaWdpdHMgaW4gdGhlIGdlbmVyYXRlZFxuICAgKiBwYXNzd29yZC4gSWYgb21pdHRlZCBpdCBkZWZhdWx0cyB0byAyNSUgb2YgdGhlIGxlbmd0aCBvZiB0aGUgcGFzc3dvcmRcbiAgICpcbiAgICogQHNjaGVtYSBQYXNzd29yZFNwZWMjZGlnaXRzXG4gICAqL1xuICByZWFkb25seSBkaWdpdHM/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIExlbmd0aCBvZiB0aGUgcGFzc3dvcmQgdG8gYmUgZ2VuZXJhdGVkLlxuICAgKiBEZWZhdWx0cyB0byAyNFxuICAgKlxuICAgKiBAZGVmYXVsdCAyNFxuICAgKiBAc2NoZW1hIFBhc3N3b3JkU3BlYyNsZW5ndGhcbiAgICovXG4gIHJlYWRvbmx5IGxlbmd0aDogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBTZXQgTm9VcHBlciB0byBkaXNhYmxlIHVwcGVyY2FzZSBjaGFyYWN0ZXJzXG4gICAqXG4gICAqIEBzY2hlbWEgUGFzc3dvcmRTcGVjI25vVXBwZXJcbiAgICovXG4gIHJlYWRvbmx5IG5vVXBwZXI6IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFN5bWJvbENoYXJhY3RlcnMgc3BlY2lmaWVzIHRoZSBzcGVjaWFsIGNoYXJhY3RlcnMgdGhhdCBzaG91bGQgYmUgdXNlZFxuICAgKiBpbiB0aGUgZ2VuZXJhdGVkIHBhc3N3b3JkLlxuICAgKlxuICAgKiBAc2NoZW1hIFBhc3N3b3JkU3BlYyNzeW1ib2xDaGFyYWN0ZXJzXG4gICAqL1xuICByZWFkb25seSBzeW1ib2xDaGFyYWN0ZXJzPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTeW1ib2xzIHNwZWNpZmllcyB0aGUgbnVtYmVyIG9mIHN5bWJvbCBjaGFyYWN0ZXJzIGluIHRoZSBnZW5lcmF0ZWRcbiAgICogcGFzc3dvcmQuIElmIG9taXR0ZWQgaXQgZGVmYXVsdHMgdG8gMjUlIG9mIHRoZSBsZW5ndGggb2YgdGhlIHBhc3N3b3JkXG4gICAqXG4gICAqIEBzY2hlbWEgUGFzc3dvcmRTcGVjI3N5bWJvbHNcbiAgICovXG4gIHJlYWRvbmx5IHN5bWJvbHM/OiBudW1iZXI7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnUGFzc3dvcmRTcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9QYXNzd29yZFNwZWMob2JqOiBQYXNzd29yZFNwZWMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhbGxvd1JlcGVhdCc6IG9iai5hbGxvd1JlcGVhdCxcbiAgICAnZGlnaXRzJzogb2JqLmRpZ2l0cyxcbiAgICAnbGVuZ3RoJzogb2JqLmxlbmd0aCxcbiAgICAnbm9VcHBlcic6IG9iai5ub1VwcGVyLFxuICAgICdzeW1ib2xDaGFyYWN0ZXJzJzogb2JqLnN5bWJvbENoYXJhY3RlcnMsXG4gICAgJ3N5bWJvbHMnOiBvYmouc3ltYm9scyxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuXG4vKipcbiAqIFF1YXlBY2Nlc3NUb2tlbiBnZW5lcmF0ZXMgUXVheSBvYXV0aCB0b2tlbiBmb3IgcHVsbGluZy9wdXNoaW5nIGltYWdlc1xuICpcbiAqIEBzY2hlbWEgUXVheUFjY2Vzc1Rva2VuXG4gKi9cbmV4cG9ydCBjbGFzcyBRdWF5QWNjZXNzVG9rZW4gZXh0ZW5kcyBBcGlPYmplY3Qge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYXBpVmVyc2lvbiBhbmQga2luZCBmb3IgXCJRdWF5QWNjZXNzVG9rZW5cIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2dlbmVyYXRvcnMuZXh0ZXJuYWwtc2VjcmV0cy5pby92MWFscGhhMScsXG4gICAga2luZDogJ1F1YXlBY2Nlc3NUb2tlbicsXG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyBhIEt1YmVybmV0ZXMgbWFuaWZlc3QgZm9yIFwiUXVheUFjY2Vzc1Rva2VuXCIuXG4gICAqXG4gICAqIFRoaXMgY2FuIGJlIHVzZWQgdG8gaW5saW5lIHJlc291cmNlIG1hbmlmZXN0cyBpbnNpZGUgb3RoZXIgb2JqZWN0cyAoZS5nLiBhcyB0ZW1wbGF0ZXMpLlxuICAgKlxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWFuaWZlc3QocHJvcHM6IFF1YXlBY2Nlc3NUb2tlblByb3BzID0ge30pOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5RdWF5QWNjZXNzVG9rZW4uR1ZLLFxuICAgICAgLi4udG9Kc29uX1F1YXlBY2Nlc3NUb2tlblByb3BzKHByb3BzKSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBcIlF1YXlBY2Nlc3NUb2tlblwiIEFQSSBvYmplY3RcbiAgICogQHBhcmFtIHNjb3BlIHRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBvYmplY3RcbiAgICogQHBhcmFtIGlkIGEgc2NvcGUtbG9jYWwgbmFtZSBmb3IgdGhlIG9iamVjdFxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogUXVheUFjY2Vzc1Rva2VuUHJvcHMgPSB7fSkge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgLi4uUXVheUFjY2Vzc1Rva2VuLkdWSyxcbiAgICAgIC4uLnByb3BzLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgdGhlIG9iamVjdCB0byBLdWJlcm5ldGVzIEpTT04uXG4gICAqL1xuICBwdWJsaWMgdG9Kc29uKCk6IGFueSB7XG4gICAgY29uc3QgcmVzb2x2ZWQgPSBzdXBlci50b0pzb24oKTtcblxuICAgIHJldHVybiB7XG4gICAgICAuLi5RdWF5QWNjZXNzVG9rZW4uR1ZLLFxuICAgICAgLi4udG9Kc29uX1F1YXlBY2Nlc3NUb2tlblByb3BzKHJlc29sdmVkKSxcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogUXVheUFjY2Vzc1Rva2VuIGdlbmVyYXRlcyBRdWF5IG9hdXRoIHRva2VuIGZvciBwdWxsaW5nL3B1c2hpbmcgaW1hZ2VzXG4gKlxuICogQHNjaGVtYSBRdWF5QWNjZXNzVG9rZW5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBRdWF5QWNjZXNzVG9rZW5Qcm9wcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIFF1YXlBY2Nlc3NUb2tlbiNtZXRhZGF0YVxuICAgKi9cbiAgcmVhZG9ubHkgbWV0YWRhdGE/OiBBcGlPYmplY3RNZXRhZGF0YTtcblxuICAvKipcbiAgICogQHNjaGVtYSBRdWF5QWNjZXNzVG9rZW4jc3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgc3BlYz86IFF1YXlBY2Nlc3NUb2tlblNwZWM7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnUXVheUFjY2Vzc1Rva2VuUHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1F1YXlBY2Nlc3NUb2tlblByb3BzKG9iajogUXVheUFjY2Vzc1Rva2VuUHJvcHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtZXRhZGF0YSc6IG9iai5tZXRhZGF0YSxcbiAgICAnc3BlYyc6IHRvSnNvbl9RdWF5QWNjZXNzVG9rZW5TcGVjKG9iai5zcGVjKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIFF1YXlBY2Nlc3NUb2tlblNwZWNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBRdWF5QWNjZXNzVG9rZW5TcGVjIHtcbiAgLyoqXG4gICAqIE5hbWUgb2YgdGhlIHJvYm90IGFjY291bnQgeW91IGFyZSBmZWRlcmF0aW5nIHdpdGhcbiAgICpcbiAgICogQHNjaGVtYSBRdWF5QWNjZXNzVG9rZW5TcGVjI3JvYm90QWNjb3VudFxuICAgKi9cbiAgcmVhZG9ubHkgcm9ib3RBY2NvdW50OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIE5hbWUgb2YgdGhlIHNlcnZpY2UgYWNjb3VudCB5b3UgYXJlIGZlZGVyYXRpbmcgd2l0aFxuICAgKlxuICAgKiBAc2NoZW1hIFF1YXlBY2Nlc3NUb2tlblNwZWMjc2VydmljZUFjY291bnRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlcnZpY2VBY2NvdW50UmVmOiBRdWF5QWNjZXNzVG9rZW5TcGVjU2VydmljZUFjY291bnRSZWY7XG5cbiAgLyoqXG4gICAqIFVSTCBjb25maWd1cmVzIHRoZSBRdWF5IGluc3RhbmNlIFVSTC4gRGVmYXVsdHMgdG8gcXVheS5pby5cbiAgICpcbiAgICogQGRlZmF1bHQgcXVheS5pby5cbiAgICogQHNjaGVtYSBRdWF5QWNjZXNzVG9rZW5TcGVjI3VybFxuICAgKi9cbiAgcmVhZG9ubHkgdXJsPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1F1YXlBY2Nlc3NUb2tlblNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1F1YXlBY2Nlc3NUb2tlblNwZWMob2JqOiBRdWF5QWNjZXNzVG9rZW5TcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAncm9ib3RBY2NvdW50Jzogb2JqLnJvYm90QWNjb3VudCxcbiAgICAnc2VydmljZUFjY291bnRSZWYnOiB0b0pzb25fUXVheUFjY2Vzc1Rva2VuU3BlY1NlcnZpY2VBY2NvdW50UmVmKG9iai5zZXJ2aWNlQWNjb3VudFJlZiksXG4gICAgJ3VybCc6IG9iai51cmwsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogTmFtZSBvZiB0aGUgc2VydmljZSBhY2NvdW50IHlvdSBhcmUgZmVkZXJhdGluZyB3aXRoXG4gKlxuICogQHNjaGVtYSBRdWF5QWNjZXNzVG9rZW5TcGVjU2VydmljZUFjY291bnRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBRdWF5QWNjZXNzVG9rZW5TcGVjU2VydmljZUFjY291bnRSZWYge1xuICAvKipcbiAgICogQXVkaWVuY2Ugc3BlY2lmaWVzIHRoZSBgYXVkYCBjbGFpbSBmb3IgdGhlIHNlcnZpY2UgYWNjb3VudCB0b2tlblxuICAgKiBJZiB0aGUgc2VydmljZSBhY2NvdW50IHVzZXMgYSB3ZWxsLWtub3duIGFubm90YXRpb24gZm9yIGUuZy4gSVJTQSBvciBHQ1AgV29ya2xvYWQgSWRlbnRpdHlcbiAgICogdGhlbiB0aGlzIGF1ZGllbmNlcyB3aWxsIGJlIGFwcGVuZGVkIHRvIHRoZSBsaXN0XG4gICAqXG4gICAqIEBzY2hlbWEgUXVheUFjY2Vzc1Rva2VuU3BlY1NlcnZpY2VBY2NvdW50UmVmI2F1ZGllbmNlc1xuICAgKi9cbiAgcmVhZG9ubHkgYXVkaWVuY2VzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBRdWF5QWNjZXNzVG9rZW5TcGVjU2VydmljZUFjY291bnRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBOYW1lc3BhY2Ugb2YgdGhlIHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIFF1YXlBY2Nlc3NUb2tlblNwZWNTZXJ2aWNlQWNjb3VudFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdRdWF5QWNjZXNzVG9rZW5TcGVjU2VydmljZUFjY291bnRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1F1YXlBY2Nlc3NUb2tlblNwZWNTZXJ2aWNlQWNjb3VudFJlZihvYmo6IFF1YXlBY2Nlc3NUb2tlblNwZWNTZXJ2aWNlQWNjb3VudFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1ZGllbmNlcyc6IG9iai5hdWRpZW5jZXM/Lm1hcCh5ID0+IHkpLFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cblxuLyoqXG4gKiBTVFNTZXNzaW9uVG9rZW4gdXNlcyB0aGUgR2V0U2Vzc2lvblRva2VuIEFQSSB0byByZXRyaWV2ZSBhbiBhdXRob3JpemF0aW9uIHRva2VuLlxuVGhlIGF1dGhvcml6YXRpb24gdG9rZW4gaXMgdmFsaWQgZm9yIDEyIGhvdXJzLlxuVGhlIGF1dGhvcml6YXRpb25Ub2tlbiByZXR1cm5lZCBpcyBhIGJhc2U2NCBlbmNvZGVkIHN0cmluZyB0aGF0IGNhbiBiZSBkZWNvZGVkLlxuRm9yIG1vcmUgaW5mb3JtYXRpb24sIHNlZSBHZXRTZXNzaW9uVG9rZW4gKGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9TVFMvbGF0ZXN0L0FQSVJlZmVyZW5jZS9BUElfR2V0U2Vzc2lvblRva2VuLmh0bWwpLlxuICpcbiAqIEBzY2hlbWEgU1RTU2Vzc2lvblRva2VuXG4gKi9cbmV4cG9ydCBjbGFzcyBTdHNTZXNzaW9uVG9rZW4gZXh0ZW5kcyBBcGlPYmplY3Qge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYXBpVmVyc2lvbiBhbmQga2luZCBmb3IgXCJTVFNTZXNzaW9uVG9rZW5cIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2dlbmVyYXRvcnMuZXh0ZXJuYWwtc2VjcmV0cy5pby92MWFscGhhMScsXG4gICAga2luZDogJ1NUU1Nlc3Npb25Ub2tlbicsXG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyBhIEt1YmVybmV0ZXMgbWFuaWZlc3QgZm9yIFwiU1RTU2Vzc2lvblRva2VuXCIuXG4gICAqXG4gICAqIFRoaXMgY2FuIGJlIHVzZWQgdG8gaW5saW5lIHJlc291cmNlIG1hbmlmZXN0cyBpbnNpZGUgb3RoZXIgb2JqZWN0cyAoZS5nLiBhcyB0ZW1wbGF0ZXMpLlxuICAgKlxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWFuaWZlc3QocHJvcHM6IFN0c1Nlc3Npb25Ub2tlblByb3BzID0ge30pOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5TdHNTZXNzaW9uVG9rZW4uR1ZLLFxuICAgICAgLi4udG9Kc29uX1N0c1Nlc3Npb25Ub2tlblByb3BzKHByb3BzKSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBcIlNUU1Nlc3Npb25Ub2tlblwiIEFQSSBvYmplY3RcbiAgICogQHBhcmFtIHNjb3BlIHRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBvYmplY3RcbiAgICogQHBhcmFtIGlkIGEgc2NvcGUtbG9jYWwgbmFtZSBmb3IgdGhlIG9iamVjdFxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogU3RzU2Vzc2lvblRva2VuUHJvcHMgPSB7fSkge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgLi4uU3RzU2Vzc2lvblRva2VuLkdWSyxcbiAgICAgIC4uLnByb3BzLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgdGhlIG9iamVjdCB0byBLdWJlcm5ldGVzIEpTT04uXG4gICAqL1xuICBwdWJsaWMgdG9Kc29uKCk6IGFueSB7XG4gICAgY29uc3QgcmVzb2x2ZWQgPSBzdXBlci50b0pzb24oKTtcblxuICAgIHJldHVybiB7XG4gICAgICAuLi5TdHNTZXNzaW9uVG9rZW4uR1ZLLFxuICAgICAgLi4udG9Kc29uX1N0c1Nlc3Npb25Ub2tlblByb3BzKHJlc29sdmVkKSxcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogU1RTU2Vzc2lvblRva2VuIHVzZXMgdGhlIEdldFNlc3Npb25Ub2tlbiBBUEkgdG8gcmV0cmlldmUgYW4gYXV0aG9yaXphdGlvbiB0b2tlbi5cbiAqIFRoZSBhdXRob3JpemF0aW9uIHRva2VuIGlzIHZhbGlkIGZvciAxMiBob3Vycy5cbiAqIFRoZSBhdXRob3JpemF0aW9uVG9rZW4gcmV0dXJuZWQgaXMgYSBiYXNlNjQgZW5jb2RlZCBzdHJpbmcgdGhhdCBjYW4gYmUgZGVjb2RlZC5cbiAqIEZvciBtb3JlIGluZm9ybWF0aW9uLCBzZWUgR2V0U2Vzc2lvblRva2VuIChodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vU1RTL2xhdGVzdC9BUElSZWZlcmVuY2UvQVBJX0dldFNlc3Npb25Ub2tlbi5odG1sKS5cbiAqXG4gKiBAc2NoZW1hIFNUU1Nlc3Npb25Ub2tlblxuICovXG5leHBvcnQgaW50ZXJmYWNlIFN0c1Nlc3Npb25Ub2tlblByb3BzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgU1RTU2Vzc2lvblRva2VuI21ldGFkYXRhXG4gICAqL1xuICByZWFkb25seSBtZXRhZGF0YT86IEFwaU9iamVjdE1ldGFkYXRhO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFNUU1Nlc3Npb25Ub2tlbiNzcGVjXG4gICAqL1xuICByZWFkb25seSBzcGVjPzogU3RzU2Vzc2lvblRva2VuU3BlYztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdTdHNTZXNzaW9uVG9rZW5Qcm9wcycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fU3RzU2Vzc2lvblRva2VuUHJvcHMob2JqOiBTdHNTZXNzaW9uVG9rZW5Qcm9wcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ21ldGFkYXRhJzogb2JqLm1ldGFkYXRhLFxuICAgICdzcGVjJzogdG9Kc29uX1N0c1Nlc3Npb25Ub2tlblNwZWMob2JqLnNwZWMpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgU3RzU2Vzc2lvblRva2VuU3BlY1xuICovXG5leHBvcnQgaW50ZXJmYWNlIFN0c1Nlc3Npb25Ub2tlblNwZWMge1xuICAvKipcbiAgICogQXV0aCBkZWZpbmVzIGhvdyB0byBhdXRoZW50aWNhdGUgd2l0aCBBV1NcbiAgICpcbiAgICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjI2F1dGhcbiAgICovXG4gIHJlYWRvbmx5IGF1dGg/OiBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aDtcblxuICAvKipcbiAgICogUmVnaW9uIHNwZWNpZmllcyB0aGUgcmVnaW9uIHRvIG9wZXJhdGUgaW4uXG4gICAqXG4gICAqIEBzY2hlbWEgU3RzU2Vzc2lvblRva2VuU3BlYyNyZWdpb25cbiAgICovXG4gIHJlYWRvbmx5IHJlZ2lvbjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBSZXF1ZXN0UGFyYW1ldGVycyBjb250YWlucyBwYXJhbWV0ZXJzIHRoYXQgY2FuIGJlIHBhc3NlZCB0byB0aGUgU1RTIHNlcnZpY2UuXG4gICAqXG4gICAqIEBzY2hlbWEgU3RzU2Vzc2lvblRva2VuU3BlYyNyZXF1ZXN0UGFyYW1ldGVyc1xuICAgKi9cbiAgcmVhZG9ubHkgcmVxdWVzdFBhcmFtZXRlcnM/OiBTdHNTZXNzaW9uVG9rZW5TcGVjUmVxdWVzdFBhcmFtZXRlcnM7XG5cbiAgLyoqXG4gICAqIFlvdSBjYW4gYXNzdW1lIGEgcm9sZSBiZWZvcmUgbWFraW5nIGNhbGxzIHRvIHRoZVxuICAgKiBkZXNpcmVkIEFXUyBzZXJ2aWNlLlxuICAgKlxuICAgKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWMjcm9sZVxuICAgKi9cbiAgcmVhZG9ubHkgcm9sZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdTdHNTZXNzaW9uVG9rZW5TcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9TdHNTZXNzaW9uVG9rZW5TcGVjKG9iajogU3RzU2Vzc2lvblRva2VuU3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1dGgnOiB0b0pzb25fU3RzU2Vzc2lvblRva2VuU3BlY0F1dGgob2JqLmF1dGgpLFxuICAgICdyZWdpb24nOiBvYmoucmVnaW9uLFxuICAgICdyZXF1ZXN0UGFyYW1ldGVycyc6IHRvSnNvbl9TdHNTZXNzaW9uVG9rZW5TcGVjUmVxdWVzdFBhcmFtZXRlcnMob2JqLnJlcXVlc3RQYXJhbWV0ZXJzKSxcbiAgICAncm9sZSc6IG9iai5yb2xlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEF1dGggZGVmaW5lcyBob3cgdG8gYXV0aGVudGljYXRlIHdpdGggQVdTXG4gKlxuICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFxuICovXG5leHBvcnQgaW50ZXJmYWNlIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoIHtcbiAgLyoqXG4gICAqIEF1dGhlbnRpY2F0ZSBhZ2FpbnN0IEFXUyB1c2luZyBzZXJ2aWNlIGFjY291bnQgdG9rZW5zLlxuICAgKlxuICAgKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoI2p3dFxuICAgKi9cbiAgcmVhZG9ubHkgand0PzogU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhKd3Q7XG5cbiAgLyoqXG4gICAqIEFXU0F1dGhTZWNyZXRSZWYgaG9sZHMgc2VjcmV0IHJlZmVyZW5jZXMgZm9yIEFXUyBjcmVkZW50aWFsc1xuICAgKiBib3RoIEFjY2Vzc0tleUlEIGFuZCBTZWNyZXRBY2Nlc3NLZXkgbXVzdCBiZSBkZWZpbmVkIGluIG9yZGVyIHRvIHByb3Blcmx5IGF1dGhlbnRpY2F0ZS5cbiAgICpcbiAgICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aCNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZj86IFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1N0c1Nlc3Npb25Ub2tlblNwZWNBdXRoJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9TdHNTZXNzaW9uVG9rZW5TcGVjQXV0aChvYmo6IFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnand0JzogdG9Kc29uX1N0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0KG9iai5qd3QpLFxuICAgICdzZWNyZXRSZWYnOiB0b0pzb25fU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogUmVxdWVzdFBhcmFtZXRlcnMgY29udGFpbnMgcGFyYW1ldGVycyB0aGF0IGNhbiBiZSBwYXNzZWQgdG8gdGhlIFNUUyBzZXJ2aWNlLlxuICpcbiAqIEBzY2hlbWEgU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzIHtcbiAgLyoqXG4gICAqIFNlcmlhbE51bWJlciBpcyB0aGUgaWRlbnRpZmljYXRpb24gbnVtYmVyIG9mIHRoZSBNRkEgZGV2aWNlIHRoYXQgaXMgYXNzb2NpYXRlZCB3aXRoIHRoZSBJQU0gdXNlciB3aG8gaXMgbWFraW5nXG4gICAqIHRoZSBHZXRTZXNzaW9uVG9rZW4gY2FsbC5cbiAgICogUG9zc2libGUgdmFsdWVzOiBoYXJkd2FyZSBkZXZpY2UgKHN1Y2ggYXMgR0FIVDEyMzQ1Njc4KSBvciBhbiBBbWF6b24gUmVzb3VyY2UgTmFtZSAoQVJOKSBmb3IgYSB2aXJ0dWFsIGRldmljZVxuICAgKiAoc3VjaCBhcyBhcm46YXdzOmlhbTo6MTIzNDU2Nzg5MDEyOm1mYS91c2VyKVxuICAgKlxuICAgKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNSZXF1ZXN0UGFyYW1ldGVycyNzZXJpYWxOdW1iZXJcbiAgICovXG4gIHJlYWRvbmx5IHNlcmlhbE51bWJlcj86IHN0cmluZztcblxuICAvKipcbiAgICogU2Vzc2lvbkR1cmF0aW9uIFRoZSBkdXJhdGlvbiwgaW4gc2Vjb25kcywgdGhhdCB0aGUgY3JlZGVudGlhbHMgc2hvdWxkIHJlbWFpbiB2YWxpZC4gQWNjZXB0YWJsZSBkdXJhdGlvbnMgZm9yXG4gICAqIElBTSB1c2VyIHNlc3Npb25zIHJhbmdlIGZyb20gOTAwIHNlY29uZHMgKDE1IG1pbnV0ZXMpIHRvIDEyOSw2MDAgc2Vjb25kcyAoMzYgaG91cnMpLCB3aXRoIDQzLDIwMCBzZWNvbmRzXG4gICAqICgxMiBob3VycykgYXMgdGhlIGRlZmF1bHQuXG4gICAqXG4gICAqIEBzY2hlbWEgU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzI3Nlc3Npb25EdXJhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgc2Vzc2lvbkR1cmF0aW9uPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBUb2tlbkNvZGUgaXMgdGhlIHZhbHVlIHByb3ZpZGVkIGJ5IHRoZSBNRkEgZGV2aWNlLCBpZiBNRkEgaXMgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzI3Rva2VuQ29kZVxuICAgKi9cbiAgcmVhZG9ubHkgdG9rZW5Db2RlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1N0c1Nlc3Npb25Ub2tlblNwZWNSZXF1ZXN0UGFyYW1ldGVycycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzKG9iajogU3RzU2Vzc2lvblRva2VuU3BlY1JlcXVlc3RQYXJhbWV0ZXJzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VyaWFsTnVtYmVyJzogb2JqLnNlcmlhbE51bWJlcixcbiAgICAnc2Vzc2lvbkR1cmF0aW9uJzogb2JqLnNlc3Npb25EdXJhdGlvbixcbiAgICAndG9rZW5Db2RlJzogb2JqLnRva2VuQ29kZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBdXRoZW50aWNhdGUgYWdhaW5zdCBBV1MgdXNpbmcgc2VydmljZSBhY2NvdW50IHRva2Vucy5cbiAqXG4gKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhKd3Qge1xuICAvKipcbiAgICogQSByZWZlcmVuY2UgdG8gYSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZS5cbiAgICpcbiAgICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dCNzZXJ2aWNlQWNjb3VudFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VydmljZUFjY291bnRSZWY/OiBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1N0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9TdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dChvYmo6IFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VydmljZUFjY291bnRSZWYnOiB0b0pzb25fU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhKd3RTZXJ2aWNlQWNjb3VudFJlZihvYmouc2VydmljZUFjY291bnRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEFXU0F1dGhTZWNyZXRSZWYgaG9sZHMgc2VjcmV0IHJlZmVyZW5jZXMgZm9yIEFXUyBjcmVkZW50aWFsc1xuICogYm90aCBBY2Nlc3NLZXlJRCBhbmQgU2VjcmV0QWNjZXNzS2V5IG11c3QgYmUgZGVmaW5lZCBpbiBvcmRlciB0byBwcm9wZXJseSBhdXRoZW50aWNhdGUuXG4gKlxuICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIFRoZSBBY2Nlc3NLZXlJRCBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICAgKlxuICAgKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmI2FjY2Vzc0tleUlEU2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBhY2Nlc3NLZXlJZFNlY3JldFJlZj86IFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWY7XG5cbiAgLyoqXG4gICAqIFRoZSBTZWNyZXRBY2Nlc3NLZXkgaXMgdXNlZCBmb3IgYXV0aGVudGljYXRpb25cbiAgICpcbiAgICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZiNzZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldEFjY2Vzc0tleVNlY3JldFJlZj86IFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmO1xuXG4gIC8qKlxuICAgKiBUaGUgU2Vzc2lvblRva2VuIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gICAqIFRoaXMgbXVzdCBiZSBkZWZpbmVkIGlmIEFjY2Vzc0tleUlEIGFuZCBTZWNyZXRBY2Nlc3NLZXkgYXJlIHRlbXBvcmFyeSBjcmVkZW50aWFsc1xuICAgKiBzZWU6IGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9JQU0vbGF0ZXN0L1VzZXJHdWlkZS9pZF9jcmVkZW50aWFsc190ZW1wX3VzZS1yZXNvdXJjZXMuaHRtbFxuICAgKlxuICAgKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmI3Nlc3Npb25Ub2tlblNlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2Vzc2lvblRva2VuU2VjcmV0UmVmPzogU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1N0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmKG9iajogU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhY2Nlc3NLZXlJRFNlY3JldFJlZic6IHRvSnNvbl9TdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmKG9iai5hY2Nlc3NLZXlJZFNlY3JldFJlZiksXG4gICAgJ3NlY3JldEFjY2Vzc0tleVNlY3JldFJlZic6IHRvSnNvbl9TdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZihvYmouc2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmKSxcbiAgICAnc2Vzc2lvblRva2VuU2VjcmV0UmVmJzogdG9Kc29uX1N0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmKG9iai5zZXNzaW9uVG9rZW5TZWNyZXRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEEgcmVmZXJlbmNlIHRvIGEgU2VydmljZUFjY291bnQgcmVzb3VyY2UuXG4gKlxuICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhKd3RTZXJ2aWNlQWNjb3VudFJlZiB7XG4gIC8qKlxuICAgKiBBdWRpZW5jZSBzcGVjaWZpZXMgdGhlIGBhdWRgIGNsYWltIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHRva2VuXG4gICAqIElmIHRoZSBzZXJ2aWNlIGFjY291bnQgdXNlcyBhIHdlbGwta25vd24gYW5ub3RhdGlvbiBmb3IgZS5nLiBJUlNBIG9yIEdDUCBXb3JrbG9hZCBJZGVudGl0eVxuICAgKiB0aGVuIHRoaXMgYXVkaWVuY2VzIHdpbGwgYmUgYXBwZW5kZWQgdG8gdGhlIGxpc3RcbiAgICpcbiAgICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmI2F1ZGllbmNlc1xuICAgKi9cbiAgcmVhZG9ubHkgYXVkaWVuY2VzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZXJ2aWNlQWNjb3VudCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZXNwYWNlIG9mIHRoZSByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1N0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0U2VydmljZUFjY291bnRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1N0c1Nlc3Npb25Ub2tlblNwZWNBdXRoSnd0U2VydmljZUFjY291bnRSZWYob2JqOiBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aEp3dFNlcnZpY2VBY2NvdW50UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXVkaWVuY2VzJzogb2JqLmF1ZGllbmNlcz8ubWFwKHkgPT4geSksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgQWNjZXNzS2V5SUQgaXMgdXNlZCBmb3IgYXV0aGVudGljYXRpb25cbiAqXG4gKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9TdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmKG9iajogU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgU2VjcmV0QWNjZXNzS2V5IGlzIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gKlxuICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYob2JqOiBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgU2Vzc2lvblRva2VuIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gKiBUaGlzIG11c3QgYmUgZGVmaW5lZCBpZiBBY2Nlc3NLZXlJRCBhbmQgU2VjcmV0QWNjZXNzS2V5IGFyZSB0ZW1wb3JhcnkgY3JlZGVudGlhbHNcbiAqIHNlZTogaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL0lBTS9sYXRlc3QvVXNlckd1aWRlL2lkX2NyZWRlbnRpYWxzX3RlbXBfdXNlLXJlc291cmNlcy5odG1sXG4gKlxuICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFN0c1Nlc3Npb25Ub2tlblNwZWNBdXRoU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fU3RzU2Vzc2lvblRva2VuU3BlY0F1dGhTZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYob2JqOiBTdHNTZXNzaW9uVG9rZW5TcGVjQXV0aFNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuXG4vKipcbiAqIFVVSUQgZ2VuZXJhdGVzIGEgdmVyc2lvbiAxIFVVSUQgKGU1NjY1N2UzLTc2NGYtMTFlZi1hMzk3LTY1MjMxYTg4YzIxNikuXG4gKlxuICogQHNjaGVtYSBVVUlEXG4gKi9cbmV4cG9ydCBjbGFzcyBVdWlkIGV4dGVuZHMgQXBpT2JqZWN0IHtcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGFwaVZlcnNpb24gYW5kIGtpbmQgZm9yIFwiVVVJRFwiXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEdWSzogR3JvdXBWZXJzaW9uS2luZCA9IHtcbiAgICBhcGlWZXJzaW9uOiAnZ2VuZXJhdG9ycy5leHRlcm5hbC1zZWNyZXRzLmlvL3YxYWxwaGExJyxcbiAgICBraW5kOiAnVVVJRCcsXG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyBhIEt1YmVybmV0ZXMgbWFuaWZlc3QgZm9yIFwiVVVJRFwiLlxuICAgKlxuICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGlubGluZSByZXNvdXJjZSBtYW5pZmVzdHMgaW5zaWRlIG90aGVyIG9iamVjdHMgKGUuZy4gYXMgdGVtcGxhdGVzKS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1hbmlmZXN0KHByb3BzOiBVdWlkUHJvcHMgPSB7fSk6IGFueSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLlV1aWQuR1ZLLFxuICAgICAgLi4udG9Kc29uX1V1aWRQcm9wcyhwcm9wcyksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgXCJVVUlEXCIgQVBJIG9iamVjdFxuICAgKiBAcGFyYW0gc2NvcGUgdGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIG9iamVjdFxuICAgKiBAcGFyYW0gaWQgYSBzY29wZS1sb2NhbCBuYW1lIGZvciB0aGUgb2JqZWN0XG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBVdWlkUHJvcHMgPSB7fSkge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgLi4uVXVpZC5HVkssXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBvYmplY3QgdG8gS3ViZXJuZXRlcyBKU09OLlxuICAgKi9cbiAgcHVibGljIHRvSnNvbigpOiBhbnkge1xuICAgIGNvbnN0IHJlc29sdmVkID0gc3VwZXIudG9Kc29uKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uVXVpZC5HVkssXG4gICAgICAuLi50b0pzb25fVXVpZFByb3BzKHJlc29sdmVkKSxcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogVVVJRCBnZW5lcmF0ZXMgYSB2ZXJzaW9uIDEgVVVJRCAoZTU2NjU3ZTMtNzY0Zi0xMWVmLWEzOTctNjUyMzFhODhjMjE2KS5cbiAqXG4gKiBAc2NoZW1hIFVVSURcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBVdWlkUHJvcHMge1xuICAvKipcbiAgICogQHNjaGVtYSBVVUlEI21ldGFkYXRhXG4gICAqL1xuICByZWFkb25seSBtZXRhZGF0YT86IEFwaU9iamVjdE1ldGFkYXRhO1xuXG4gIC8qKlxuICAgKiBVVUlEU3BlYyBjb250cm9scyB0aGUgYmVoYXZpb3Igb2YgdGhlIHV1aWQgZ2VuZXJhdG9yLlxuICAgKlxuICAgKiBAc2NoZW1hIFVVSUQjc3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgc3BlYz86IGFueTtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdVdWlkUHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1V1aWRQcm9wcyhvYmo6IFV1aWRQcm9wcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ21ldGFkYXRhJzogb2JqLm1ldGFkYXRhLFxuICAgICdzcGVjJzogb2JqLnNwZWMsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cblxuLyoqXG4gKlxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0XG4gKi9cbmV4cG9ydCBjbGFzcyBWYXVsdER5bmFtaWNTZWNyZXQgZXh0ZW5kcyBBcGlPYmplY3Qge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYXBpVmVyc2lvbiBhbmQga2luZCBmb3IgXCJWYXVsdER5bmFtaWNTZWNyZXRcIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2dlbmVyYXRvcnMuZXh0ZXJuYWwtc2VjcmV0cy5pby92MWFscGhhMScsXG4gICAga2luZDogJ1ZhdWx0RHluYW1pY1NlY3JldCcsXG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyBhIEt1YmVybmV0ZXMgbWFuaWZlc3QgZm9yIFwiVmF1bHREeW5hbWljU2VjcmV0XCIuXG4gICAqXG4gICAqIFRoaXMgY2FuIGJlIHVzZWQgdG8gaW5saW5lIHJlc291cmNlIG1hbmlmZXN0cyBpbnNpZGUgb3RoZXIgb2JqZWN0cyAoZS5nLiBhcyB0ZW1wbGF0ZXMpLlxuICAgKlxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWFuaWZlc3QocHJvcHM6IFZhdWx0RHluYW1pY1NlY3JldFByb3BzID0ge30pOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5WYXVsdER5bmFtaWNTZWNyZXQuR1ZLLFxuICAgICAgLi4udG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFByb3BzKHByb3BzKSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBcIlZhdWx0RHluYW1pY1NlY3JldFwiIEFQSSBvYmplY3RcbiAgICogQHBhcmFtIHNjb3BlIHRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBvYmplY3RcbiAgICogQHBhcmFtIGlkIGEgc2NvcGUtbG9jYWwgbmFtZSBmb3IgdGhlIG9iamVjdFxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogVmF1bHREeW5hbWljU2VjcmV0UHJvcHMgPSB7fSkge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgLi4uVmF1bHREeW5hbWljU2VjcmV0LkdWSyxcbiAgICAgIC4uLnByb3BzLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgdGhlIG9iamVjdCB0byBLdWJlcm5ldGVzIEpTT04uXG4gICAqL1xuICBwdWJsaWMgdG9Kc29uKCk6IGFueSB7XG4gICAgY29uc3QgcmVzb2x2ZWQgPSBzdXBlci50b0pzb24oKTtcblxuICAgIHJldHVybiB7XG4gICAgICAuLi5WYXVsdER5bmFtaWNTZWNyZXQuR1ZLLFxuICAgICAgLi4udG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFByb3BzKHJlc29sdmVkKSxcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRQcm9wcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldCNtZXRhZGF0YVxuICAgKi9cbiAgcmVhZG9ubHkgbWV0YWRhdGE/OiBBcGlPYmplY3RNZXRhZGF0YTtcblxuICAvKipcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXQjc3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgc3BlYz86IFZhdWx0RHluYW1pY1NlY3JldFNwZWM7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0UHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFByb3BzKG9iajogVmF1bHREeW5hbWljU2VjcmV0UHJvcHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtZXRhZGF0YSc6IG9iai5tZXRhZGF0YSxcbiAgICAnc3BlYyc6IHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjKG9iai5zcGVjKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjIHtcbiAgLyoqXG4gICAqIERvIG5vdCBmYWlsIGlmIG5vIHNlY3JldHMgYXJlIGZvdW5kLiBVc2VmdWwgZm9yIHJlcXVlc3RzIHdoZXJlIG5vIGRhdGEgaXMgZXhwZWN0ZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlYyNhbGxvd0VtcHR5UmVzcG9uc2VcbiAgICovXG4gIHJlYWRvbmx5IGFsbG93RW1wdHlSZXNwb25zZT86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFVzZWQgdG8gc2VsZWN0IHRoZSBjb3JyZWN0IEVTTyBjb250cm9sbGVyICh0aGluazogaW5ncmVzcy5pbmdyZXNzQ2xhc3NOYW1lKVxuICAgKiBUaGUgRVNPIGNvbnRyb2xsZXIgaXMgaW5zdGFudGlhdGVkIHdpdGggYSBzcGVjaWZpYyBjb250cm9sbGVyIG5hbWUgYW5kIGZpbHRlcnMgVkRTIGJhc2VkIG9uIHRoaXMgcHJvcGVydHlcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjI2NvbnRyb2xsZXJcbiAgICovXG4gIHJlYWRvbmx5IGNvbnRyb2xsZXI/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFZhdWx0IEFQSSBtZXRob2QgdG8gdXNlIChHRVQvUE9TVC9vdGhlcilcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjI21ldGhvZFxuICAgKi9cbiAgcmVhZG9ubHkgbWV0aG9kPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBQYXJhbWV0ZXJzIHRvIHBhc3MgdG8gVmF1bHQgd3JpdGUgKGZvciBub24tR0VUIG1ldGhvZHMpXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlYyNwYXJhbWV0ZXJzXG4gICAqL1xuICByZWFkb25seSBwYXJhbWV0ZXJzPzogYW55O1xuXG4gIC8qKlxuICAgKiBWYXVsdCBwYXRoIHRvIG9idGFpbiB0aGUgZHluYW1pYyBzZWNyZXQgZnJvbVxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWMjcGF0aFxuICAgKi9cbiAgcmVhZG9ubHkgcGF0aDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBWYXVsdCBwcm92aWRlciBjb21tb24gc3BlY1xuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWMjcHJvdmlkZXJcbiAgICovXG4gIHJlYWRvbmx5IHByb3ZpZGVyOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXI7XG5cbiAgLyoqXG4gICAqIFJlc3VsdCB0eXBlIGRlZmluZXMgd2hpY2ggZGF0YSBpcyByZXR1cm5lZCBmcm9tIHRoZSBnZW5lcmF0b3IuXG4gICAqIEJ5IGRlZmF1bHQgaXQgaXMgdGhlIFwiZGF0YVwiIHNlY3Rpb24gb2YgdGhlIFZhdWx0IEFQSSByZXNwb25zZS5cbiAgICogV2hlbiB1c2luZyBlLmcuIC9hdXRoL3Rva2VuL2NyZWF0ZSB0aGUgXCJkYXRhXCIgc2VjdGlvbiBpcyBlbXB0eSBidXRcbiAgICogdGhlIFwiYXV0aFwiIHNlY3Rpb24gY29udGFpbnMgdGhlIGdlbmVyYXRlZCB0b2tlbi5cbiAgICogUGxlYXNlIHJlZmVyIHRvIHRoZSB2YXVsdCBkb2NzIHJlZ2FyZGluZyB0aGUgcmVzdWx0IGRhdGEgc3RydWN0dXJlLlxuICAgKiBBZGRpdGlvbmFsbHksIGFjY2Vzc2luZyB0aGUgcmF3IHJlc3BvbnNlIGlzIHBvc3NpYmx5IGJ5IHVzaW5nIFwiUmF3XCIgcmVzdWx0IHR5cGUuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlYyNyZXN1bHRUeXBlXG4gICAqL1xuICByZWFkb25seSByZXN1bHRUeXBlPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Jlc3VsdFR5cGU7XG5cbiAgLyoqXG4gICAqIFVzZWQgdG8gY29uZmlndXJlIGh0dHAgcmV0cmllcyBpZiBmYWlsZWRcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjI3JldHJ5U2V0dGluZ3NcbiAgICovXG4gIHJlYWRvbmx5IHJldHJ5U2V0dGluZ3M/OiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUmV0cnlTZXR0aW5ncztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjKG9iajogVmF1bHREeW5hbWljU2VjcmV0U3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2FsbG93RW1wdHlSZXNwb25zZSc6IG9iai5hbGxvd0VtcHR5UmVzcG9uc2UsXG4gICAgJ2NvbnRyb2xsZXInOiBvYmouY29udHJvbGxlcixcbiAgICAnbWV0aG9kJzogb2JqLm1ldGhvZCxcbiAgICAncGFyYW1ldGVycyc6IG9iai5wYXJhbWV0ZXJzLFxuICAgICdwYXRoJzogb2JqLnBhdGgsXG4gICAgJ3Byb3ZpZGVyJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlcihvYmoucHJvdmlkZXIpLFxuICAgICdyZXN1bHRUeXBlJzogb2JqLnJlc3VsdFR5cGUsXG4gICAgJ3JldHJ5U2V0dGluZ3MnOiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1JldHJ5U2V0dGluZ3Mob2JqLnJldHJ5U2V0dGluZ3MpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFZhdWx0IHByb3ZpZGVyIGNvbW1vbiBzcGVjXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXIge1xuICAvKipcbiAgICogQXV0aCBjb25maWd1cmVzIGhvdyBzZWNyZXQtbWFuYWdlciBhdXRoZW50aWNhdGVzIHdpdGggdGhlIFZhdWx0IHNlcnZlci5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXIjYXV0aFxuICAgKi9cbiAgcmVhZG9ubHkgYXV0aD86IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGg7XG5cbiAgLyoqXG4gICAqIFBFTSBlbmNvZGVkIENBIGJ1bmRsZSB1c2VkIHRvIHZhbGlkYXRlIFZhdWx0IHNlcnZlciBjZXJ0aWZpY2F0ZS4gT25seSB1c2VkXG4gICAqIGlmIHRoZSBTZXJ2ZXIgVVJMIGlzIHVzaW5nIEhUVFBTIHByb3RvY29sLiBUaGlzIHBhcmFtZXRlciBpcyBpZ25vcmVkIGZvclxuICAgKiBwbGFpbiBIVFRQIHByb3RvY29sIGNvbm5lY3Rpb24uIElmIG5vdCBzZXQgdGhlIHN5c3RlbSByb290IGNlcnRpZmljYXRlc1xuICAgKiBhcmUgdXNlZCB0byB2YWxpZGF0ZSB0aGUgVExTIGNvbm5lY3Rpb24uXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyI2NhQnVuZGxlXG4gICAqL1xuICByZWFkb25seSBjYUJ1bmRsZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHByb3ZpZGVyIGZvciB0aGUgQ0EgYnVuZGxlIHRvIHVzZSB0byB2YWxpZGF0ZSBWYXVsdCBzZXJ2ZXIgY2VydGlmaWNhdGUuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyI2NhUHJvdmlkZXJcbiAgICovXG4gIHJlYWRvbmx5IGNhUHJvdmlkZXI/OiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyO1xuXG4gIC8qKlxuICAgKiBGb3J3YXJkSW5jb25zaXN0ZW50IHRlbGxzIFZhdWx0IHRvIGZvcndhcmQgcmVhZC1hZnRlci13cml0ZSByZXF1ZXN0cyB0byB0aGUgVmF1bHRcbiAgICogbGVhZGVyIGluc3RlYWQgb2Ygc2ltcGx5IHJldHJ5aW5nIHdpdGhpbiBhIGxvb3AuIFRoaXMgY2FuIGluY3JlYXNlIHBlcmZvcm1hbmNlIGlmXG4gICAqIHRoZSBvcHRpb24gaXMgZW5hYmxlZCBzZXJ2ZXJzaWRlLlxuICAgKiBodHRwczovL3d3dy52YXVsdHByb2plY3QuaW8vZG9jcy9jb25maWd1cmF0aW9uL3JlcGxpY2F0aW9uI2FsbG93X2ZvcndhcmRpbmdfdmlhX2hlYWRlclxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlciNmb3J3YXJkSW5jb25zaXN0ZW50XG4gICAqL1xuICByZWFkb25seSBmb3J3YXJkSW5jb25zaXN0ZW50PzogYm9vbGVhbjtcblxuICAvKipcbiAgICogSGVhZGVycyB0byBiZSBhZGRlZCBpbiBWYXVsdCByZXF1ZXN0XG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyI2hlYWRlcnNcbiAgICovXG4gIHJlYWRvbmx5IGhlYWRlcnM/OiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9O1xuXG4gIC8qKlxuICAgKiBOYW1lIG9mIHRoZSB2YXVsdCBuYW1lc3BhY2UuIE5hbWVzcGFjZXMgaXMgYSBzZXQgb2YgZmVhdHVyZXMgd2l0aGluIFZhdWx0IEVudGVycHJpc2UgdGhhdCBhbGxvd3NcbiAgICogVmF1bHQgZW52aXJvbm1lbnRzIHRvIHN1cHBvcnQgU2VjdXJlIE11bHRpLXRlbmFuY3kuIGUuZzogXCJuczFcIi5cbiAgICogTW9yZSBhYm91dCBuYW1lc3BhY2VzIGNhbiBiZSBmb3VuZCBoZXJlIGh0dHBzOi8vd3d3LnZhdWx0cHJvamVjdC5pby9kb2NzL2VudGVycHJpc2UvbmFtZXNwYWNlc1xuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlciNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxuICAvKipcbiAgICogUGF0aCBpcyB0aGUgbW91bnQgcGF0aCBvZiB0aGUgVmF1bHQgS1YgYmFja2VuZCBlbmRwb2ludCwgZS5nOlxuICAgKiBcInNlY3JldFwiLiBUaGUgdjIgS1Ygc2VjcmV0IGVuZ2luZSB2ZXJzaW9uIHNwZWNpZmljIFwiL2RhdGFcIiBwYXRoIHN1ZmZpeFxuICAgKiBmb3IgZmV0Y2hpbmcgc2VjcmV0cyBmcm9tIFZhdWx0IGlzIG9wdGlvbmFsIGFuZCB3aWxsIGJlIGFwcGVuZGVkXG4gICAqIGlmIG5vdCBwcmVzZW50IGluIHNwZWNpZmllZCBwYXRoLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlciNwYXRoXG4gICAqL1xuICByZWFkb25seSBwYXRoPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBSZWFkWW91cldyaXRlcyBlbnN1cmVzIGlzb2xhdGVkIHJlYWQtYWZ0ZXItd3JpdGUgc2VtYW50aWNzIGJ5XG4gICAqIHByb3ZpZGluZyBkaXNjb3ZlcmVkIGNsdXN0ZXIgcmVwbGljYXRpb24gc3RhdGVzIGluIGVhY2ggcmVxdWVzdC5cbiAgICogTW9yZSBpbmZvcm1hdGlvbiBhYm91dCBldmVudHVhbCBjb25zaXN0ZW5jeSBpbiBWYXVsdCBjYW4gYmUgZm91bmQgaGVyZVxuICAgKiBodHRwczovL3d3dy52YXVsdHByb2plY3QuaW8vZG9jcy9lbnRlcnByaXNlL2NvbnNpc3RlbmN5XG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyI3JlYWRZb3VyV3JpdGVzXG4gICAqL1xuICByZWFkb25seSByZWFkWW91cldyaXRlcz86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFNlcnZlciBpcyB0aGUgY29ubmVjdGlvbiBhZGRyZXNzIGZvciB0aGUgVmF1bHQgc2VydmVyLCBlLmc6IFwiaHR0cHM6Ly92YXVsdC5leGFtcGxlLmNvbTo4MjAwXCIuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyI3NlcnZlclxuICAgKi9cbiAgcmVhZG9ubHkgc2VydmVyOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBjb25maWd1cmF0aW9uIHVzZWQgZm9yIGNsaWVudCBzaWRlIHJlbGF0ZWQgVExTIGNvbW11bmljYXRpb24sIHdoZW4gdGhlIFZhdWx0IHNlcnZlclxuICAgKiByZXF1aXJlcyBtdXR1YWwgYXV0aGVudGljYXRpb24uIE9ubHkgdXNlZCBpZiB0aGUgU2VydmVyIFVSTCBpcyB1c2luZyBIVFRQUyBwcm90b2NvbC5cbiAgICogVGhpcyBwYXJhbWV0ZXIgaXMgaWdub3JlZCBmb3IgcGxhaW4gSFRUUCBwcm90b2NvbCBjb25uZWN0aW9uLlxuICAgKiBJdCdzIHdvcnRoIG5vdGluZyB0aGlzIGNvbmZpZ3VyYXRpb24gaXMgZGlmZmVyZW50IGZyb20gdGhlIFwiVExTIGNlcnRpZmljYXRlcyBhdXRoIG1ldGhvZFwiLFxuICAgKiB3aGljaCBpcyBhdmFpbGFibGUgdW5kZXIgdGhlIGBhdXRoLmNlcnRgIHNlY3Rpb24uXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyI3Rsc1xuICAgKi9cbiAgcmVhZG9ubHkgdGxzPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzO1xuXG4gIC8qKlxuICAgKiBWZXJzaW9uIGlzIHRoZSBWYXVsdCBLViBzZWNyZXQgZW5naW5lIHZlcnNpb24uIFRoaXMgY2FuIGJlIGVpdGhlciBcInYxXCIgb3JcbiAgICogXCJ2MlwiLiBWZXJzaW9uIGRlZmF1bHRzIHRvIFwidjJcIi5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXIjdmVyc2lvblxuICAgKi9cbiAgcmVhZG9ubHkgdmVyc2lvbj86IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclZlcnNpb247XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXIob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXIgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhdXRoJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGgob2JqLmF1dGgpLFxuICAgICdjYUJ1bmRsZSc6IG9iai5jYUJ1bmRsZSxcbiAgICAnY2FQcm92aWRlcic6IHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyKG9iai5jYVByb3ZpZGVyKSxcbiAgICAnZm9yd2FyZEluY29uc2lzdGVudCc6IG9iai5mb3J3YXJkSW5jb25zaXN0ZW50LFxuICAgICdoZWFkZXJzJzogKChvYmouaGVhZGVycykgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLmhlYWRlcnMpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSkpLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICAgICdwYXRoJzogb2JqLnBhdGgsXG4gICAgJ3JlYWRZb3VyV3JpdGVzJzogb2JqLnJlYWRZb3VyV3JpdGVzLFxuICAgICdzZXJ2ZXInOiBvYmouc2VydmVyLFxuICAgICd0bHMnOiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzKG9iai50bHMpLFxuICAgICd2ZXJzaW9uJzogb2JqLnZlcnNpb24sXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogUmVzdWx0IHR5cGUgZGVmaW5lcyB3aGljaCBkYXRhIGlzIHJldHVybmVkIGZyb20gdGhlIGdlbmVyYXRvci5cbiAqIEJ5IGRlZmF1bHQgaXQgaXMgdGhlIFwiZGF0YVwiIHNlY3Rpb24gb2YgdGhlIFZhdWx0IEFQSSByZXNwb25zZS5cbiAqIFdoZW4gdXNpbmcgZS5nLiAvYXV0aC90b2tlbi9jcmVhdGUgdGhlIFwiZGF0YVwiIHNlY3Rpb24gaXMgZW1wdHkgYnV0XG4gKiB0aGUgXCJhdXRoXCIgc2VjdGlvbiBjb250YWlucyB0aGUgZ2VuZXJhdGVkIHRva2VuLlxuICogUGxlYXNlIHJlZmVyIHRvIHRoZSB2YXVsdCBkb2NzIHJlZ2FyZGluZyB0aGUgcmVzdWx0IGRhdGEgc3RydWN0dXJlLlxuICogQWRkaXRpb25hbGx5LCBhY2Nlc3NpbmcgdGhlIHJhdyByZXNwb25zZSBpcyBwb3NzaWJseSBieSB1c2luZyBcIlJhd1wiIHJlc3VsdCB0eXBlLlxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Jlc3VsdFR5cGVcbiAqL1xuZXhwb3J0IGVudW0gVmF1bHREeW5hbWljU2VjcmV0U3BlY1Jlc3VsdFR5cGUge1xuICAvKiogRGF0YSAqL1xuICBEQVRBID0gXCJEYXRhXCIsXG4gIC8qKiBBdXRoICovXG4gIEFVVEggPSBcIkF1dGhcIixcbiAgLyoqIFJhdyAqL1xuICBSQVcgPSBcIlJhd1wiLFxufVxuXG4vKipcbiAqIFVzZWQgdG8gY29uZmlndXJlIGh0dHAgcmV0cmllcyBpZiBmYWlsZWRcbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNSZXRyeVNldHRpbmdzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1JldHJ5U2V0dGluZ3Mge1xuICAvKipcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUmV0cnlTZXR0aW5ncyNtYXhSZXRyaWVzXG4gICAqL1xuICByZWFkb25seSBtYXhSZXRyaWVzPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNSZXRyeVNldHRpbmdzI3JldHJ5SW50ZXJ2YWxcbiAgICovXG4gIHJlYWRvbmx5IHJldHJ5SW50ZXJ2YWw/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1JldHJ5U2V0dGluZ3MnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNSZXRyeVNldHRpbmdzKG9iajogVmF1bHREeW5hbWljU2VjcmV0U3BlY1JldHJ5U2V0dGluZ3MgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtYXhSZXRyaWVzJzogb2JqLm1heFJldHJpZXMsXG4gICAgJ3JldHJ5SW50ZXJ2YWwnOiBvYmoucmV0cnlJbnRlcnZhbCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBdXRoIGNvbmZpZ3VyZXMgaG93IHNlY3JldC1tYW5hZ2VyIGF1dGhlbnRpY2F0ZXMgd2l0aCB0aGUgVmF1bHQgc2VydmVyLlxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFxuICovXG5leHBvcnQgaW50ZXJmYWNlIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGgge1xuICAvKipcbiAgICogQXBwUm9sZSBhdXRoZW50aWNhdGVzIHdpdGggVmF1bHQgdXNpbmcgdGhlIEFwcCBSb2xlIGF1dGggbWVjaGFuaXNtLFxuICAgKiB3aXRoIHRoZSByb2xlIGFuZCBzZWNyZXQgc3RvcmVkIGluIGEgS3ViZXJuZXRlcyBTZWNyZXQgcmVzb3VyY2UuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aCNhcHBSb2xlXG4gICAqL1xuICByZWFkb25seSBhcHBSb2xlPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGU7XG5cbiAgLyoqXG4gICAqIENlcnQgYXV0aGVudGljYXRlcyB3aXRoIFRMUyBDZXJ0aWZpY2F0ZXMgYnkgcGFzc2luZyBjbGllbnQgY2VydGlmaWNhdGUsIHByaXZhdGUga2V5IGFuZCBjYSBjZXJ0aWZpY2F0ZVxuICAgKiBDZXJ0IGF1dGhlbnRpY2F0aW9uIG1ldGhvZFxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGgjY2VydFxuICAgKi9cbiAgcmVhZG9ubHkgY2VydD86IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0O1xuXG4gIC8qKlxuICAgKiBJYW0gYXV0aGVudGljYXRlcyB3aXRoIHZhdWx0IGJ5IHBhc3NpbmcgYSBzcGVjaWFsIEFXUyByZXF1ZXN0IHNpZ25lZCB3aXRoIEFXUyBJQU0gY3JlZGVudGlhbHNcbiAgICogQVdTIElBTSBhdXRoZW50aWNhdGlvbiBtZXRob2RcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoI2lhbVxuICAgKi9cbiAgcmVhZG9ubHkgaWFtPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbTtcblxuICAvKipcbiAgICogSnd0IGF1dGhlbnRpY2F0ZXMgd2l0aCBWYXVsdCBieSBwYXNzaW5nIHJvbGUgYW5kIEpXVCB0b2tlbiB1c2luZyB0aGVcbiAgICogSldUL09JREMgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aCNqd3RcbiAgICovXG4gIHJlYWRvbmx5IGp3dD86IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3Q7XG5cbiAgLyoqXG4gICAqIEt1YmVybmV0ZXMgYXV0aGVudGljYXRlcyB3aXRoIFZhdWx0IGJ5IHBhc3NpbmcgdGhlIFNlcnZpY2VBY2NvdW50XG4gICAqIHRva2VuIHN0b3JlZCBpbiB0aGUgbmFtZWQgU2VjcmV0IHJlc291cmNlIHRvIHRoZSBWYXVsdCBzZXJ2ZXIuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aCNrdWJlcm5ldGVzXG4gICAqL1xuICByZWFkb25seSBrdWJlcm5ldGVzPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXM7XG5cbiAgLyoqXG4gICAqIExkYXAgYXV0aGVudGljYXRlcyB3aXRoIFZhdWx0IGJ5IHBhc3NpbmcgdXNlcm5hbWUvcGFzc3dvcmQgcGFpciB1c2luZ1xuICAgKiB0aGUgTERBUCBhdXRoZW50aWNhdGlvbiBtZXRob2RcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoI2xkYXBcbiAgICovXG4gIHJlYWRvbmx5IGxkYXA/OiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcDtcblxuICAvKipcbiAgICogTmFtZSBvZiB0aGUgdmF1bHQgbmFtZXNwYWNlIHRvIGF1dGhlbnRpY2F0ZSB0by4gVGhpcyBjYW4gYmUgZGlmZmVyZW50IHRoYW4gdGhlIG5hbWVzcGFjZSB5b3VyIHNlY3JldCBpcyBpbi5cbiAgICogTmFtZXNwYWNlcyBpcyBhIHNldCBvZiBmZWF0dXJlcyB3aXRoaW4gVmF1bHQgRW50ZXJwcmlzZSB0aGF0IGFsbG93c1xuICAgKiBWYXVsdCBlbnZpcm9ubWVudHMgdG8gc3VwcG9ydCBTZWN1cmUgTXVsdGktdGVuYW5jeS4gZS5nOiBcIm5zMVwiLlxuICAgKiBNb3JlIGFib3V0IG5hbWVzcGFjZXMgY2FuIGJlIGZvdW5kIGhlcmUgaHR0cHM6Ly93d3cudmF1bHRwcm9qZWN0LmlvL2RvY3MvZW50ZXJwcmlzZS9uYW1lc3BhY2VzXG4gICAqIFRoaXMgd2lsbCBkZWZhdWx0IHRvIFZhdWx0Lk5hbWVzcGFjZSBmaWVsZCBpZiBzZXQsIG9yIGVtcHR5IG90aGVyd2lzZVxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGgjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRva2VuU2VjcmV0UmVmIGF1dGhlbnRpY2F0ZXMgd2l0aCBWYXVsdCBieSBwcmVzZW50aW5nIGEgdG9rZW4uXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aCN0b2tlblNlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgdG9rZW5TZWNyZXRSZWY/OiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVG9rZW5TZWNyZXRSZWY7XG5cbiAgLyoqXG4gICAqIFVzZXJQYXNzIGF1dGhlbnRpY2F0ZXMgd2l0aCBWYXVsdCBieSBwYXNzaW5nIHVzZXJuYW1lL3Bhc3N3b3JkIHBhaXJcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoI3VzZXJQYXNzXG4gICAqL1xuICByZWFkb25seSB1c2VyUGFzcz86IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzcztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoKG9iajogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2FwcFJvbGUnOiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGUob2JqLmFwcFJvbGUpLFxuICAgICdjZXJ0JzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0KG9iai5jZXJ0KSxcbiAgICAnaWFtJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW0ob2JqLmlhbSksXG4gICAgJ2p3dCc6IHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0KG9iai5qd3QpLFxuICAgICdrdWJlcm5ldGVzJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzKG9iai5rdWJlcm5ldGVzKSxcbiAgICAnbGRhcCc6IHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcChvYmoubGRhcCksXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gICAgJ3Rva2VuU2VjcmV0UmVmJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhUb2tlblNlY3JldFJlZihvYmoudG9rZW5TZWNyZXRSZWYpLFxuICAgICd1c2VyUGFzcyc6IHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3Mob2JqLnVzZXJQYXNzKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgcHJvdmlkZXIgZm9yIHRoZSBDQSBidW5kbGUgdG8gdXNlIHRvIHZhbGlkYXRlIFZhdWx0IHNlcnZlciBjZXJ0aWZpY2F0ZS5cbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckNhUHJvdmlkZXJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyIHtcbiAgLyoqXG4gICAqIFRoZSBrZXkgd2hlcmUgdGhlIENBIGNlcnRpZmljYXRlIGNhbiBiZSBmb3VuZCBpbiB0aGUgU2VjcmV0IG9yIENvbmZpZ01hcC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgb2JqZWN0IGxvY2F0ZWQgYXQgdGhlIHByb3ZpZGVyIHR5cGUuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQ2FQcm92aWRlciNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2UgdGhlIFByb3ZpZGVyIHR5cGUgaXMgaW4uXG4gICAqIENhbiBvbmx5IGJlIGRlZmluZWQgd2hlbiB1c2VkIGluIGEgQ2x1c3RlclNlY3JldFN0b3JlLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckNhUHJvdmlkZXIjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSB0eXBlIG9mIHByb3ZpZGVyIHRvIHVzZSBzdWNoIGFzIFwiU2VjcmV0XCIsIG9yIFwiQ29uZmlnTWFwXCIuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQ2FQcm92aWRlciN0eXBlXG4gICAqL1xuICByZWFkb25seSB0eXBlOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyVHlwZTtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJDYVByb3ZpZGVyKG9iajogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQ2FQcm92aWRlciB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgICAndHlwZSc6IG9iai50eXBlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBjb25maWd1cmF0aW9uIHVzZWQgZm9yIGNsaWVudCBzaWRlIHJlbGF0ZWQgVExTIGNvbW11bmljYXRpb24sIHdoZW4gdGhlIFZhdWx0IHNlcnZlclxuICogcmVxdWlyZXMgbXV0dWFsIGF1dGhlbnRpY2F0aW9uLiBPbmx5IHVzZWQgaWYgdGhlIFNlcnZlciBVUkwgaXMgdXNpbmcgSFRUUFMgcHJvdG9jb2wuXG4gKiBUaGlzIHBhcmFtZXRlciBpcyBpZ25vcmVkIGZvciBwbGFpbiBIVFRQIHByb3RvY29sIGNvbm5lY3Rpb24uXG4gKiBJdCdzIHdvcnRoIG5vdGluZyB0aGlzIGNvbmZpZ3VyYXRpb24gaXMgZGlmZmVyZW50IGZyb20gdGhlIFwiVExTIGNlcnRpZmljYXRlcyBhdXRoIG1ldGhvZFwiLFxuICogd2hpY2ggaXMgYXZhaWxhYmxlIHVuZGVyIHRoZSBgYXV0aC5jZXJ0YCBzZWN0aW9uLlxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzIHtcbiAgLyoqXG4gICAqIENlcnRTZWNyZXRSZWYgaXMgYSBjZXJ0aWZpY2F0ZSBhZGRlZCB0byB0aGUgdHJhbnNwb3J0IGxheWVyXG4gICAqIHdoZW4gY29tbXVuaWNhdGluZyB3aXRoIHRoZSBWYXVsdCBzZXJ2ZXIuXG4gICAqIElmIG5vIGtleSBmb3IgdGhlIFNlY3JldCBpcyBzcGVjaWZpZWQsIGV4dGVybmFsLXNlY3JldCB3aWxsIGRlZmF1bHQgdG8gJ3Rscy5jcnQnLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRscyNjZXJ0U2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBjZXJ0U2VjcmV0UmVmPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzQ2VydFNlY3JldFJlZjtcblxuICAvKipcbiAgICogS2V5U2VjcmV0UmVmIHRvIGEga2V5IGluIGEgU2VjcmV0IHJlc291cmNlIGNvbnRhaW5pbmcgY2xpZW50IHByaXZhdGUga2V5XG4gICAqIGFkZGVkIHRvIHRoZSB0cmFuc3BvcnQgbGF5ZXIgd2hlbiBjb21tdW5pY2F0aW5nIHdpdGggdGhlIFZhdWx0IHNlcnZlci5cbiAgICogSWYgbm8ga2V5IGZvciB0aGUgU2VjcmV0IGlzIHNwZWNpZmllZCwgZXh0ZXJuYWwtc2VjcmV0IHdpbGwgZGVmYXVsdCB0byAndGxzLmtleScuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzI2tleVNlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkga2V5U2VjcmV0UmVmPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzS2V5U2VjcmV0UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRscycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzKG9iajogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnY2VydFNlY3JldFJlZic6IHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNDZXJ0U2VjcmV0UmVmKG9iai5jZXJ0U2VjcmV0UmVmKSxcbiAgICAna2V5U2VjcmV0UmVmJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0tleVNlY3JldFJlZihvYmoua2V5U2VjcmV0UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBWZXJzaW9uIGlzIHRoZSBWYXVsdCBLViBzZWNyZXQgZW5naW5lIHZlcnNpb24uIFRoaXMgY2FuIGJlIGVpdGhlciBcInYxXCIgb3JcbiAqIFwidjJcIi4gVmVyc2lvbiBkZWZhdWx0cyB0byBcInYyXCIuXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJWZXJzaW9uXG4gKi9cbmV4cG9ydCBlbnVtIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclZlcnNpb24ge1xuICAvKiogdjEgKi9cbiAgVjEgPSBcInYxXCIsXG4gIC8qKiB2MiAqL1xuICBWMiA9IFwidjJcIixcbn1cblxuLyoqXG4gKiBBcHBSb2xlIGF1dGhlbnRpY2F0ZXMgd2l0aCBWYXVsdCB1c2luZyB0aGUgQXBwIFJvbGUgYXV0aCBtZWNoYW5pc20sXG4gKiB3aXRoIHRoZSByb2xlIGFuZCBzZWNyZXQgc3RvcmVkIGluIGEgS3ViZXJuZXRlcyBTZWNyZXQgcmVzb3VyY2UuXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVxuICovXG5leHBvcnQgaW50ZXJmYWNlIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlIHtcbiAgLyoqXG4gICAqIFBhdGggd2hlcmUgdGhlIEFwcCBSb2xlIGF1dGhlbnRpY2F0aW9uIGJhY2tlbmQgaXMgbW91bnRlZFxuICAgKiBpbiBWYXVsdCwgZS5nOiBcImFwcHJvbGVcIlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlI3BhdGhcbiAgICovXG4gIHJlYWRvbmx5IHBhdGg6IHN0cmluZztcblxuICAvKipcbiAgICogUm9sZUlEIGNvbmZpZ3VyZWQgaW4gdGhlIEFwcCBSb2xlIGF1dGhlbnRpY2F0aW9uIGJhY2tlbmQgd2hlbiBzZXR0aW5nXG4gICAqIHVwIHRoZSBhdXRoZW50aWNhdGlvbiBiYWNrZW5kIGluIFZhdWx0LlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlI3JvbGVJZFxuICAgKi9cbiAgcmVhZG9ubHkgcm9sZUlkPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBSZWZlcmVuY2UgdG8gYSBrZXkgaW4gYSBTZWNyZXQgdGhhdCBjb250YWlucyB0aGUgQXBwIFJvbGUgSUQgdXNlZFxuICAgKiB0byBhdXRoZW50aWNhdGUgd2l0aCBWYXVsdC5cbiAgICogVGhlIGBrZXlgIGZpZWxkIG11c3QgYmUgc3BlY2lmaWVkIGFuZCBkZW5vdGVzIHdoaWNoIGVudHJ5IHdpdGhpbiB0aGUgU2VjcmV0XG4gICAqIHJlc291cmNlIGlzIHVzZWQgYXMgdGhlIGFwcCByb2xlIGlkLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlI3JvbGVSZWZcbiAgICovXG4gIHJlYWRvbmx5IHJvbGVSZWY/OiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVJvbGVSZWY7XG5cbiAgLyoqXG4gICAqIFJlZmVyZW5jZSB0byBhIGtleSBpbiBhIFNlY3JldCB0aGF0IGNvbnRhaW5zIHRoZSBBcHAgUm9sZSBzZWNyZXQgdXNlZFxuICAgKiB0byBhdXRoZW50aWNhdGUgd2l0aCBWYXVsdC5cbiAgICogVGhlIGBrZXlgIGZpZWxkIG11c3QgYmUgc3BlY2lmaWVkIGFuZCBkZW5vdGVzIHdoaWNoIGVudHJ5IHdpdGhpbiB0aGUgU2VjcmV0XG4gICAqIHJlc291cmNlIGlzIHVzZWQgYXMgdGhlIGFwcCByb2xlIHNlY3JldC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZSNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZjogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVTZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGUnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlKG9iajogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGUgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdwYXRoJzogb2JqLnBhdGgsXG4gICAgJ3JvbGVJZCc6IG9iai5yb2xlSWQsXG4gICAgJ3JvbGVSZWYnOiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVSb2xlUmVmKG9iai5yb2xlUmVmKSxcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlU2VjcmV0UmVmKG9iai5zZWNyZXRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIENlcnQgYXV0aGVudGljYXRlcyB3aXRoIFRMUyBDZXJ0aWZpY2F0ZXMgYnkgcGFzc2luZyBjbGllbnQgY2VydGlmaWNhdGUsIHByaXZhdGUga2V5IGFuZCBjYSBjZXJ0aWZpY2F0ZVxuICogQ2VydCBhdXRoZW50aWNhdGlvbiBtZXRob2RcbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnQge1xuICAvKipcbiAgICogQ2xpZW50Q2VydCBpcyBhIGNlcnRpZmljYXRlIHRvIGF1dGhlbnRpY2F0ZSB1c2luZyB0aGUgQ2VydCBWYXVsdFxuICAgKiBhdXRoZW50aWNhdGlvbiBtZXRob2RcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydCNjbGllbnRDZXJ0XG4gICAqL1xuICByZWFkb25seSBjbGllbnRDZXJ0PzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0O1xuXG4gIC8qKlxuICAgKiBTZWNyZXRSZWYgdG8gYSBrZXkgaW4gYSBTZWNyZXQgcmVzb3VyY2UgY29udGFpbmluZyBjbGllbnQgcHJpdmF0ZSBrZXkgdG9cbiAgICogYXV0aGVudGljYXRlIHdpdGggVmF1bHQgdXNpbmcgdGhlIENlcnQgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnQjc2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRSZWY/OiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydFNlY3JldFJlZjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnQob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2NsaWVudENlcnQnOiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0KG9iai5jbGllbnRDZXJ0KSxcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0U2VjcmV0UmVmKG9iai5zZWNyZXRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIElhbSBhdXRoZW50aWNhdGVzIHdpdGggdmF1bHQgYnkgcGFzc2luZyBhIHNwZWNpYWwgQVdTIHJlcXVlc3Qgc2lnbmVkIHdpdGggQVdTIElBTSBjcmVkZW50aWFsc1xuICogQVdTIElBTSBhdXRoZW50aWNhdGlvbiBtZXRob2RcbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtIHtcbiAgLyoqXG4gICAqIEFXUyBFeHRlcm5hbCBJRCBzZXQgb24gYXNzdW1lZCBJQU0gcm9sZXNcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtI2V4dGVybmFsSURcbiAgICovXG4gIHJlYWRvbmx5IGV4dGVybmFsSWQ/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNwZWNpZnkgYSBzZXJ2aWNlIGFjY291bnQgd2l0aCBJUlNBIGVuYWJsZWRcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtI2p3dFxuICAgKi9cbiAgcmVhZG9ubHkgand0PzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dDtcblxuICAvKipcbiAgICogUGF0aCB3aGVyZSB0aGUgQVdTIGF1dGggbWV0aG9kIGlzIGVuYWJsZWQgaW4gVmF1bHQsIGUuZzogXCJhd3NcIlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW0jcGF0aFxuICAgKi9cbiAgcmVhZG9ubHkgcGF0aD86IHN0cmluZztcblxuICAvKipcbiAgICogQVdTIHJlZ2lvblxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW0jcmVnaW9uXG4gICAqL1xuICByZWFkb25seSByZWdpb24/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoaXMgaXMgdGhlIEFXUyByb2xlIHRvIGJlIGFzc3VtZWQgYmVmb3JlIHRhbGtpbmcgdG8gdmF1bHRcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtI3JvbGVcbiAgICovXG4gIHJlYWRvbmx5IHJvbGU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNwZWNpZnkgY3JlZGVudGlhbHMgaW4gYSBTZWNyZXQgb2JqZWN0XG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbSNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZj86IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWY7XG5cbiAgLyoqXG4gICAqIFgtVmF1bHQtQVdTLUlBTS1TZXJ2ZXItSUQgaXMgYW4gYWRkaXRpb25hbCBoZWFkZXIgdXNlZCBieSBWYXVsdCBJQU0gYXV0aCBtZXRob2QgdG8gbWl0aWdhdGUgYWdhaW5zdCBkaWZmZXJlbnQgdHlwZXMgb2YgcmVwbGF5IGF0dGFja3MuIE1vcmUgZGV0YWlscyBoZXJlOiBodHRwczovL2RldmVsb3Blci5oYXNoaWNvcnAuY29tL3ZhdWx0L2RvY3MvYXV0aC9hd3NcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtI3ZhdWx0QXdzSWFtU2VydmVySURcbiAgICovXG4gIHJlYWRvbmx5IHZhdWx0QXdzSWFtU2VydmVySWQ/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFZhdWx0IFJvbGUuIEluIHZhdWx0LCBhIHJvbGUgZGVzY3JpYmVzIGFuIGlkZW50aXR5IHdpdGggYSBzZXQgb2YgcGVybWlzc2lvbnMsIGdyb3Vwcywgb3IgcG9saWNpZXMgeW91IHdhbnQgdG8gYXR0YWNoIGEgdXNlciBvZiB0aGUgc2VjcmV0cyBlbmdpbmVcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtI3ZhdWx0Um9sZVxuICAgKi9cbiAgcmVhZG9ubHkgdmF1bHRSb2xlOiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbShvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW0gfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdleHRlcm5hbElEJzogb2JqLmV4dGVybmFsSWQsXG4gICAgJ2p3dCc6IHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0KG9iai5qd3QpLFxuICAgICdwYXRoJzogb2JqLnBhdGgsXG4gICAgJ3JlZ2lvbic6IG9iai5yZWdpb24sXG4gICAgJ3JvbGUnOiBvYmoucm9sZSxcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gICAgJ3ZhdWx0QXdzSWFtU2VydmVySUQnOiBvYmoudmF1bHRBd3NJYW1TZXJ2ZXJJZCxcbiAgICAndmF1bHRSb2xlJzogb2JqLnZhdWx0Um9sZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBKd3QgYXV0aGVudGljYXRlcyB3aXRoIFZhdWx0IGJ5IHBhc3Npbmcgcm9sZSBhbmQgSldUIHRva2VuIHVzaW5nIHRoZVxuICogSldUL09JREMgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dCB7XG4gIC8qKlxuICAgKiBPcHRpb25hbCBTZXJ2aWNlQWNjb3VudFRva2VuIHNwZWNpZmllcyB0aGUgS3ViZXJuZXRlcyBzZXJ2aWNlIGFjY291bnQgZm9yIHdoaWNoIHRvIHJlcXVlc3RcbiAgICogYSB0b2tlbiBmb3Igd2l0aCB0aGUgYFRva2VuUmVxdWVzdGAgQVBJLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3Qja3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5cbiAgICovXG4gIHJlYWRvbmx5IGt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuO1xuXG4gIC8qKlxuICAgKiBQYXRoIHdoZXJlIHRoZSBKV1QgYXV0aGVudGljYXRpb24gYmFja2VuZCBpcyBtb3VudGVkXG4gICAqIGluIFZhdWx0LCBlLmc6IFwiand0XCJcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0I3BhdGhcbiAgICovXG4gIHJlYWRvbmx5IHBhdGg6IHN0cmluZztcblxuICAvKipcbiAgICogUm9sZSBpcyBhIEpXVCByb2xlIHRvIGF1dGhlbnRpY2F0ZSB1c2luZyB0aGUgSldUL09JREMgVmF1bHRcbiAgICogYXV0aGVudGljYXRpb24gbWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dCNyb2xlXG4gICAqL1xuICByZWFkb25seSByb2xlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBPcHRpb25hbCBTZWNyZXRSZWYgdGhhdCByZWZlcnMgdG8gYSBrZXkgaW4gYSBTZWNyZXQgcmVzb3VyY2UgY29udGFpbmluZyBKV1QgdG9rZW4gdG9cbiAgICogYXV0aGVudGljYXRlIHdpdGggVmF1bHQgdXNpbmcgdGhlIEpXVC9PSURDIGF1dGhlbnRpY2F0aW9uIG1ldGhvZC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0I3NlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0UmVmPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dFNlY3JldFJlZjtcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0KG9iajogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2t1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlbihvYmoua3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW4pLFxuICAgICdwYXRoJzogb2JqLnBhdGgsXG4gICAgJ3JvbGUnOiBvYmoucm9sZSxcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RTZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogS3ViZXJuZXRlcyBhdXRoZW50aWNhdGVzIHdpdGggVmF1bHQgYnkgcGFzc2luZyB0aGUgU2VydmljZUFjY291bnRcbiAqIHRva2VuIHN0b3JlZCBpbiB0aGUgbmFtZWQgU2VjcmV0IHJlc291cmNlIHRvIHRoZSBWYXVsdCBzZXJ2ZXIuXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzIHtcbiAgLyoqXG4gICAqIFBhdGggd2hlcmUgdGhlIEt1YmVybmV0ZXMgYXV0aGVudGljYXRpb24gYmFja2VuZCBpcyBtb3VudGVkIGluIFZhdWx0LCBlLmc6XG4gICAqIFwia3ViZXJuZXRlc1wiXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXMjbW91bnRQYXRoXG4gICAqL1xuICByZWFkb25seSBtb3VudFBhdGg6IHN0cmluZztcblxuICAvKipcbiAgICogQSByZXF1aXJlZCBmaWVsZCBjb250YWluaW5nIHRoZSBWYXVsdCBSb2xlIHRvIGFzc3VtZS4gQSBSb2xlIGJpbmRzIGFcbiAgICogS3ViZXJuZXRlcyBTZXJ2aWNlQWNjb3VudCB3aXRoIGEgc2V0IG9mIFZhdWx0IHBvbGljaWVzLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzI3JvbGVcbiAgICovXG4gIHJlYWRvbmx5IHJvbGU6IHN0cmluZztcblxuICAvKipcbiAgICogT3B0aW9uYWwgc2VjcmV0IGZpZWxkIGNvbnRhaW5pbmcgYSBLdWJlcm5ldGVzIFNlcnZpY2VBY2NvdW50IEpXVCB1c2VkXG4gICAqIGZvciBhdXRoZW50aWNhdGluZyB3aXRoIFZhdWx0LiBJZiBhIG5hbWUgaXMgc3BlY2lmaWVkIHdpdGhvdXQgYSBrZXksXG4gICAqIGB0b2tlbmAgaXMgdGhlIGRlZmF1bHQuIElmIG9uZSBpcyBub3Qgc3BlY2lmaWVkLCB0aGUgb25lIGJvdW5kIHRvXG4gICAqIHRoZSBjb250cm9sbGVyIHdpbGwgYmUgdXNlZC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlcyNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZj86IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VjcmV0UmVmO1xuXG4gIC8qKlxuICAgKiBPcHRpb25hbCBzZXJ2aWNlIGFjY291bnQgZmllbGQgY29udGFpbmluZyB0aGUgbmFtZSBvZiBhIGt1YmVybmV0ZXMgU2VydmljZUFjY291bnQuXG4gICAqIElmIHRoZSBzZXJ2aWNlIGFjY291bnQgaXMgc3BlY2lmaWVkLCB0aGUgc2VydmljZSBhY2NvdW50IHNlY3JldCB0b2tlbiBKV1Qgd2lsbCBiZSB1c2VkXG4gICAqIGZvciBhdXRoZW50aWNhdGluZyB3aXRoIFZhdWx0LiBJZiB0aGUgc2VydmljZSBhY2NvdW50IHNlbGVjdG9yIGlzIG5vdCBzdXBwbGllZCxcbiAgICogdGhlIHNlY3JldFJlZiB3aWxsIGJlIHVzZWQgaW5zdGVhZC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlcyNzZXJ2aWNlQWNjb3VudFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VydmljZUFjY291bnRSZWY/OiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlcyhvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnbW91bnRQYXRoJzogb2JqLm1vdW50UGF0aCxcbiAgICAncm9sZSc6IG9iai5yb2xlLFxuICAgICdzZWNyZXRSZWYnOiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gICAgJ3NlcnZpY2VBY2NvdW50UmVmJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VydmljZUFjY291bnRSZWYob2JqLnNlcnZpY2VBY2NvdW50UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBMZGFwIGF1dGhlbnRpY2F0ZXMgd2l0aCBWYXVsdCBieSBwYXNzaW5nIHVzZXJuYW1lL3Bhc3N3b3JkIHBhaXIgdXNpbmdcbiAqIHRoZSBMREFQIGF1dGhlbnRpY2F0aW9uIG1ldGhvZFxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcCB7XG4gIC8qKlxuICAgKiBQYXRoIHdoZXJlIHRoZSBMREFQIGF1dGhlbnRpY2F0aW9uIGJhY2tlbmQgaXMgbW91bnRlZFxuICAgKiBpbiBWYXVsdCwgZS5nOiBcImxkYXBcIlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwI3BhdGhcbiAgICovXG4gIHJlYWRvbmx5IHBhdGg6IHN0cmluZztcblxuICAvKipcbiAgICogU2VjcmV0UmVmIHRvIGEga2V5IGluIGEgU2VjcmV0IHJlc291cmNlIGNvbnRhaW5pbmcgcGFzc3dvcmQgZm9yIHRoZSBMREFQXG4gICAqIHVzZXIgdXNlZCB0byBhdXRoZW50aWNhdGUgd2l0aCBWYXVsdCB1c2luZyB0aGUgTERBUCBhdXRoZW50aWNhdGlvblxuICAgKiBtZXRob2RcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcCNzZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFJlZj86IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwU2VjcmV0UmVmO1xuXG4gIC8qKlxuICAgKiBVc2VybmFtZSBpcyBhbiBMREFQIHVzZXJuYW1lIHVzZWQgdG8gYXV0aGVudGljYXRlIHVzaW5nIHRoZSBMREFQIFZhdWx0XG4gICAqIGF1dGhlbnRpY2F0aW9uIG1ldGhvZFxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwI3VzZXJuYW1lXG4gICAqL1xuICByZWFkb25seSB1c2VybmFtZTogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcChvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAncGF0aCc6IG9iai5wYXRoLFxuICAgICdzZWNyZXRSZWYnOiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBTZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gICAgJ3VzZXJuYW1lJzogb2JqLnVzZXJuYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRva2VuU2VjcmV0UmVmIGF1dGhlbnRpY2F0ZXMgd2l0aCBWYXVsdCBieSBwcmVzZW50aW5nIGEgdG9rZW4uXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVG9rZW5TZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVG9rZW5TZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFRva2VuU2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhUb2tlblNlY3JldFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFRva2VuU2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhUb2tlblNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFRva2VuU2VjcmV0UmVmKG9iajogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFRva2VuU2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFVzZXJQYXNzIGF1dGhlbnRpY2F0ZXMgd2l0aCBWYXVsdCBieSBwYXNzaW5nIHVzZXJuYW1lL3Bhc3N3b3JkIHBhaXJcbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzcyB7XG4gIC8qKlxuICAgKiBQYXRoIHdoZXJlIHRoZSBVc2VyUGFzc3dvcmQgYXV0aGVudGljYXRpb24gYmFja2VuZCBpcyBtb3VudGVkXG4gICAqIGluIFZhdWx0LCBlLmc6IFwidXNlcnBhc3NcIlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzcyNwYXRoXG4gICAqL1xuICByZWFkb25seSBwYXRoOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldFJlZiB0byBhIGtleSBpbiBhIFNlY3JldCByZXNvdXJjZSBjb250YWluaW5nIHBhc3N3b3JkIGZvciB0aGVcbiAgICogdXNlciB1c2VkIHRvIGF1dGhlbnRpY2F0ZSB3aXRoIFZhdWx0IHVzaW5nIHRoZSBVc2VyUGFzcyBhdXRoZW50aWNhdGlvblxuICAgKiBtZXRob2RcbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3Mjc2VjcmV0UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRSZWY/OiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3NTZWNyZXRSZWY7XG5cbiAgLyoqXG4gICAqIFVzZXJuYW1lIGlzIGEgdXNlcm5hbWUgdXNlZCB0byBhdXRoZW50aWNhdGUgdXNpbmcgdGhlIFVzZXJQYXNzIFZhdWx0XG4gICAqIGF1dGhlbnRpY2F0aW9uIG1ldGhvZFxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzcyN1c2VybmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgdXNlcm5hbWU6IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3MnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzcyhvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3BhdGgnOiBvYmoucGF0aCxcbiAgICAnc2VjcmV0UmVmJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1NlY3JldFJlZihvYmouc2VjcmV0UmVmKSxcbiAgICAndXNlcm5hbWUnOiBvYmoudXNlcm5hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIHR5cGUgb2YgcHJvdmlkZXIgdG8gdXNlIHN1Y2ggYXMgXCJTZWNyZXRcIiwgb3IgXCJDb25maWdNYXBcIi5cbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckNhUHJvdmlkZXJUeXBlXG4gKi9cbmV4cG9ydCBlbnVtIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckNhUHJvdmlkZXJUeXBlIHtcbiAgLyoqIFNlY3JldCAqL1xuICBTRUNSRVQgPSBcIlNlY3JldFwiLFxuICAvKiogQ29uZmlnTWFwICovXG4gIENPTkZJR19NQVAgPSBcIkNvbmZpZ01hcFwiLFxufVxuXG4vKipcbiAqIENlcnRTZWNyZXRSZWYgaXMgYSBjZXJ0aWZpY2F0ZSBhZGRlZCB0byB0aGUgdHJhbnNwb3J0IGxheWVyXG4gKiB3aGVuIGNvbW11bmljYXRpbmcgd2l0aCB0aGUgVmF1bHQgc2VydmVyLlxuICogSWYgbm8ga2V5IGZvciB0aGUgU2VjcmV0IGlzIHNwZWNpZmllZCwgZXh0ZXJuYWwtc2VjcmV0IHdpbGwgZGVmYXVsdCB0byAndGxzLmNydCcuXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNDZXJ0U2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzQ2VydFNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNDZXJ0U2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0NlcnRTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0NlcnRTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzQ2VydFNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzQ2VydFNlY3JldFJlZihvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0NlcnRTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogS2V5U2VjcmV0UmVmIHRvIGEga2V5IGluIGEgU2VjcmV0IHJlc291cmNlIGNvbnRhaW5pbmcgY2xpZW50IHByaXZhdGUga2V5XG4gKiBhZGRlZCB0byB0aGUgdHJhbnNwb3J0IGxheWVyIHdoZW4gY29tbXVuaWNhdGluZyB3aXRoIHRoZSBWYXVsdCBzZXJ2ZXIuXG4gKiBJZiBubyBrZXkgZm9yIHRoZSBTZWNyZXQgaXMgc3BlY2lmaWVkLCBleHRlcm5hbC1zZWNyZXQgd2lsbCBkZWZhdWx0IHRvICd0bHMua2V5Jy5cbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0tleVNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlclRsc0tleVNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNLZXlTZWNyZXRSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzS2V5U2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNLZXlTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyVGxzS2V5U2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNLZXlTZWNyZXRSZWYob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJUbHNLZXlTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogUmVmZXJlbmNlIHRvIGEga2V5IGluIGEgU2VjcmV0IHRoYXQgY29udGFpbnMgdGhlIEFwcCBSb2xlIElEIHVzZWRcbiAqIHRvIGF1dGhlbnRpY2F0ZSB3aXRoIFZhdWx0LlxuICogVGhlIGBrZXlgIGZpZWxkIG11c3QgYmUgc3BlY2lmaWVkIGFuZCBkZW5vdGVzIHdoaWNoIGVudHJ5IHdpdGhpbiB0aGUgU2VjcmV0XG4gKiByZXNvdXJjZSBpcyB1c2VkIGFzIHRoZSBhcHAgcm9sZSBpZC5cbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlUm9sZVJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlUm9sZVJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVJvbGVSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVSb2xlUmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVJvbGVSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVSb2xlUmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVJvbGVSZWYob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVJvbGVSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogUmVmZXJlbmNlIHRvIGEga2V5IGluIGEgU2VjcmV0IHRoYXQgY29udGFpbnMgdGhlIEFwcCBSb2xlIHNlY3JldCB1c2VkXG4gKiB0byBhdXRoZW50aWNhdGUgd2l0aCBWYXVsdC5cbiAqIFRoZSBga2V5YCBmaWVsZCBtdXN0IGJlIHNwZWNpZmllZCBhbmQgZGVub3RlcyB3aGljaCBlbnRyeSB3aXRoaW4gdGhlIFNlY3JldFxuICogcmVzb3VyY2UgaXMgdXNlZCBhcyB0aGUgYXBwIHJvbGUgc2VjcmV0LlxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVTZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQXBwUm9sZVNlY3JldFJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhBcHBSb2xlU2VjcmV0UmVmKG9iajogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEFwcFJvbGVTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogQ2xpZW50Q2VydCBpcyBhIGNlcnRpZmljYXRlIHRvIGF1dGhlbnRpY2F0ZSB1c2luZyB0aGUgQ2VydCBWYXVsdFxuICogYXV0aGVudGljYXRpb24gbWV0aG9kXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydENsaWVudENlcnRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydENsaWVudENlcnQge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0I2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0Q2xpZW50Q2VydCNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZXNwYWNlIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqIElnbm9yZWQgaWYgcmVmZXJlbnQgaXMgbm90IGNsdXN0ZXItc2NvcGVkLCBvdGhlcndpc2UgZGVmYXVsdHMgdG8gdGhlIG5hbWVzcGFjZSBvZiB0aGUgcmVmZXJlbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0I25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0Q2xpZW50Q2VydCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0KG9iajogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRDbGllbnRDZXJ0IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlY3JldFJlZiB0byBhIGtleSBpbiBhIFNlY3JldCByZXNvdXJjZSBjb250YWluaW5nIGNsaWVudCBwcml2YXRlIGtleSB0b1xuICogYXV0aGVudGljYXRlIHdpdGggVmF1bHQgdXNpbmcgdGhlIENlcnQgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydFNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0U2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0U2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhDZXJ0U2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydFNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydFNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aENlcnRTZWNyZXRSZWYob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoQ2VydFNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBTcGVjaWZ5IGEgc2VydmljZSBhY2NvdW50IHdpdGggSVJTQSBlbmFibGVkXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dCB7XG4gIC8qKlxuICAgKiBBIHJlZmVyZW5jZSB0byBhIFNlcnZpY2VBY2NvdW50IHJlc291cmNlLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1Kd3Qjc2VydmljZUFjY291bnRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlcnZpY2VBY2NvdW50UmVmPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dFNlcnZpY2VBY2NvdW50UmVmO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1Kd3QnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1Kd3Qob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VydmljZUFjY291bnRSZWYnOiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dFNlcnZpY2VBY2NvdW50UmVmKG9iai5zZXJ2aWNlQWNjb3VudFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogU3BlY2lmeSBjcmVkZW50aWFscyBpbiBhIFNlY3JldCBvYmplY3RcbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIFRoZSBBY2Nlc3NLZXlJRCBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWYjYWNjZXNzS2V5SURTZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IGFjY2Vzc0tleUlkU2VjcmV0UmVmPzogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmO1xuXG4gIC8qKlxuICAgKiBUaGUgU2VjcmV0QWNjZXNzS2V5IGlzIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZiNzZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldEFjY2Vzc0tleVNlY3JldFJlZj86IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWY7XG5cbiAgLyoqXG4gICAqIFRoZSBTZXNzaW9uVG9rZW4gdXNlZCBmb3IgYXV0aGVudGljYXRpb25cbiAgICogVGhpcyBtdXN0IGJlIGRlZmluZWQgaWYgQWNjZXNzS2V5SUQgYW5kIFNlY3JldEFjY2Vzc0tleSBhcmUgdGVtcG9yYXJ5IGNyZWRlbnRpYWxzXG4gICAqIHNlZTogaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL0lBTS9sYXRlc3QvVXNlckd1aWRlL2lkX2NyZWRlbnRpYWxzX3RlbXBfdXNlLXJlc291cmNlcy5odG1sXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZiNzZXNzaW9uVG9rZW5TZWNyZXRSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlc3Npb25Ub2tlblNlY3JldFJlZj86IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZihvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhY2Nlc3NLZXlJRFNlY3JldFJlZic6IHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWYob2JqLmFjY2Vzc0tleUlkU2VjcmV0UmVmKSxcbiAgICAnc2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYob2JqLnNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiksXG4gICAgJ3Nlc3Npb25Ub2tlblNlY3JldFJlZic6IHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmKG9iai5zZXNzaW9uVG9rZW5TZWNyZXRSZWYpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE9wdGlvbmFsIFNlcnZpY2VBY2NvdW50VG9rZW4gc3BlY2lmaWVzIHRoZSBLdWJlcm5ldGVzIHNlcnZpY2UgYWNjb3VudCBmb3Igd2hpY2ggdG8gcmVxdWVzdFxuICogYSB0b2tlbiBmb3Igd2l0aCB0aGUgYFRva2VuUmVxdWVzdGAgQVBJLlxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuIHtcbiAgLyoqXG4gICAqIE9wdGlvbmFsIGF1ZGllbmNlcyBmaWVsZCB0aGF0IHdpbGwgYmUgdXNlZCB0byByZXF1ZXN0IGEgdGVtcG9yYXJ5IEt1YmVybmV0ZXMgc2VydmljZVxuICAgKiBhY2NvdW50IHRva2VuIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHJlZmVyZW5jZWQgYnkgYHNlcnZpY2VBY2NvdW50UmVmYC5cbiAgICogRGVmYXVsdHMgdG8gYSBzaW5nbGUgYXVkaWVuY2UgYHZhdWx0YCBpdCBub3Qgc3BlY2lmaWVkLlxuICAgKiBEZXByZWNhdGVkOiB1c2Ugc2VydmljZUFjY291bnRSZWYuQXVkaWVuY2VzIGluc3RlYWRcbiAgICpcbiAgICogQGRlZmF1bHQgYSBzaW5nbGUgYXVkaWVuY2UgYHZhdWx0YCBpdCBub3Qgc3BlY2lmaWVkLlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlbiNhdWRpZW5jZXNcbiAgICovXG4gIHJlYWRvbmx5IGF1ZGllbmNlcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBPcHRpb25hbCBleHBpcmF0aW9uIHRpbWUgaW4gc2Vjb25kcyB0aGF0IHdpbGwgYmUgdXNlZCB0byByZXF1ZXN0IGEgdGVtcG9yYXJ5XG4gICAqIEt1YmVybmV0ZXMgc2VydmljZSBhY2NvdW50IHRva2VuIGZvciB0aGUgc2VydmljZSBhY2NvdW50IHJlZmVyZW5jZWQgYnlcbiAgICogYHNlcnZpY2VBY2NvdW50UmVmYC5cbiAgICogRGVwcmVjYXRlZDogdGhpcyB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIGZ1dHVyZS5cbiAgICogRGVmYXVsdHMgdG8gMTAgbWludXRlcy5cbiAgICpcbiAgICogQGRlZmF1bHQgMTAgbWludXRlcy5cbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW4jZXhwaXJhdGlvblNlY29uZHNcbiAgICovXG4gIHJlYWRvbmx5IGV4cGlyYXRpb25TZWNvbmRzPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBTZXJ2aWNlIGFjY291bnQgZmllbGQgY29udGFpbmluZyB0aGUgbmFtZSBvZiBhIGt1YmVybmV0ZXMgU2VydmljZUFjY291bnQuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuI3NlcnZpY2VBY2NvdW50UmVmXG4gICAqL1xuICByZWFkb25seSBzZXJ2aWNlQWNjb3VudFJlZjogVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuU2VydmljZUFjY291bnRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW4ob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW4gfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhdWRpZW5jZXMnOiBvYmouYXVkaWVuY2VzPy5tYXAoeSA9PiB5KSxcbiAgICAnZXhwaXJhdGlvblNlY29uZHMnOiBvYmouZXhwaXJhdGlvblNlY29uZHMsXG4gICAgJ3NlcnZpY2VBY2NvdW50UmVmJzogdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlblNlcnZpY2VBY2NvdW50UmVmKG9iai5zZXJ2aWNlQWNjb3VudFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogT3B0aW9uYWwgU2VjcmV0UmVmIHRoYXQgcmVmZXJzIHRvIGEga2V5IGluIGEgU2VjcmV0IHJlc291cmNlIGNvbnRhaW5pbmcgSldUIHRva2VuIHRvXG4gKiBhdXRoZW50aWNhdGUgd2l0aCBWYXVsdCB1c2luZyB0aGUgSldUL09JREMgYXV0aGVudGljYXRpb24gbWV0aG9kLlxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dFNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RTZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dFNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0U2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0U2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RTZWNyZXRSZWYob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0U2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE9wdGlvbmFsIHNlY3JldCBmaWVsZCBjb250YWluaW5nIGEgS3ViZXJuZXRlcyBTZXJ2aWNlQWNjb3VudCBKV1QgdXNlZFxuICogZm9yIGF1dGhlbnRpY2F0aW5nIHdpdGggVmF1bHQuIElmIGEgbmFtZSBpcyBzcGVjaWZpZWQgd2l0aG91dCBhIGtleSxcbiAqIGB0b2tlbmAgaXMgdGhlIGRlZmF1bHQuIElmIG9uZSBpcyBub3Qgc3BlY2lmaWVkLCB0aGUgb25lIGJvdW5kIHRvXG4gKiB0aGUgY29udHJvbGxlciB3aWxsIGJlIHVzZWQuXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZWNyZXRSZWYob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBPcHRpb25hbCBzZXJ2aWNlIGFjY291bnQgZmllbGQgY29udGFpbmluZyB0aGUgbmFtZSBvZiBhIGt1YmVybmV0ZXMgU2VydmljZUFjY291bnQuXG4gKiBJZiB0aGUgc2VydmljZSBhY2NvdW50IGlzIHNwZWNpZmllZCwgdGhlIHNlcnZpY2UgYWNjb3VudCBzZWNyZXQgdG9rZW4gSldUIHdpbGwgYmUgdXNlZFxuICogZm9yIGF1dGhlbnRpY2F0aW5nIHdpdGggVmF1bHQuIElmIHRoZSBzZXJ2aWNlIGFjY291bnQgc2VsZWN0b3IgaXMgbm90IHN1cHBsaWVkLFxuICogdGhlIHNlY3JldFJlZiB3aWxsIGJlIHVzZWQgaW5zdGVhZC5cbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VydmljZUFjY291bnRSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoS3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50UmVmIHtcbiAgLyoqXG4gICAqIEF1ZGllbmNlIHNwZWNpZmllcyB0aGUgYGF1ZGAgY2xhaW0gZm9yIHRoZSBzZXJ2aWNlIGFjY291bnQgdG9rZW5cbiAgICogSWYgdGhlIHNlcnZpY2UgYWNjb3VudCB1c2VzIGEgd2VsbC1rbm93biBhbm5vdGF0aW9uIGZvciBlLmcuIElSU0Egb3IgR0NQIFdvcmtsb2FkIElkZW50aXR5XG4gICAqIHRoZW4gdGhpcyBhdWRpZW5jZXMgd2lsbCBiZSBhcHBlbmRlZCB0byB0aGUgbGlzdFxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VydmljZUFjY291bnRSZWYjYXVkaWVuY2VzXG4gICAqL1xuICByZWFkb25seSBhdWRpZW5jZXM/OiBzdHJpbmdbXTtcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlcnZpY2VBY2NvdW50IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VydmljZUFjY291bnRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBOYW1lc3BhY2Ugb2YgdGhlIHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VydmljZUFjY291bnRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFJlZihvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhLdWJlcm5ldGVzU2VydmljZUFjY291bnRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhdWRpZW5jZXMnOiBvYmouYXVkaWVuY2VzPy5tYXAoeSA9PiB5KSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlY3JldFJlZiB0byBhIGtleSBpbiBhIFNlY3JldCByZXNvdXJjZSBjb250YWluaW5nIHBhc3N3b3JkIGZvciB0aGUgTERBUFxuICogdXNlciB1c2VkIHRvIGF1dGhlbnRpY2F0ZSB3aXRoIFZhdWx0IHVzaW5nIHRoZSBMREFQIGF1dGhlbnRpY2F0aW9uXG4gKiBtZXRob2RcbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBTZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBTZWNyZXRSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aExkYXBTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwU2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwU2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoTGRhcFNlY3JldFJlZihvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhMZGFwU2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlY3JldFJlZiB0byBhIGtleSBpbiBhIFNlY3JldCByZXNvdXJjZSBjb250YWluaW5nIHBhc3N3b3JkIGZvciB0aGVcbiAqIHVzZXIgdXNlZCB0byBhdXRoZW50aWNhdGUgd2l0aCBWYXVsdCB1c2luZyB0aGUgVXNlclBhc3MgYXV0aGVudGljYXRpb25cbiAqIG1ldGhvZFxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFVzZXJQYXNzU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aFVzZXJQYXNzU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1NlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3NTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1NlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoVXNlclBhc3NTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1NlY3JldFJlZihvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhVc2VyUGFzc1NlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBIHJlZmVyZW5jZSB0byBhIFNlcnZpY2VBY2NvdW50IHJlc291cmNlLlxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dFNlcnZpY2VBY2NvdW50UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dFNlcnZpY2VBY2NvdW50UmVmIHtcbiAgLyoqXG4gICAqIEF1ZGllbmNlIHNwZWNpZmllcyB0aGUgYGF1ZGAgY2xhaW0gZm9yIHRoZSBzZXJ2aWNlIGFjY291bnQgdG9rZW5cbiAgICogSWYgdGhlIHNlcnZpY2UgYWNjb3VudCB1c2VzIGEgd2VsbC1rbm93biBhbm5vdGF0aW9uIGZvciBlLmcuIElSU0Egb3IgR0NQIFdvcmtsb2FkIElkZW50aXR5XG4gICAqIHRoZW4gdGhpcyBhdWRpZW5jZXMgd2lsbCBiZSBhcHBlbmRlZCB0byB0aGUgbGlzdFxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1Kd3RTZXJ2aWNlQWNjb3VudFJlZiNhdWRpZW5jZXNcbiAgICovXG4gIHJlYWRvbmx5IGF1ZGllbmNlcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VydmljZUFjY291bnQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dFNlcnZpY2VBY2NvdW50UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZXNwYWNlIG9mIHRoZSByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0U2VydmljZUFjY291bnRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbUp3dFNlcnZpY2VBY2NvdW50UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9WYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0U2VydmljZUFjY291bnRSZWYob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtSnd0U2VydmljZUFjY291bnRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhdWRpZW5jZXMnOiBvYmouYXVkaWVuY2VzPy5tYXAoeSA9PiB5KSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBBY2Nlc3NLZXlJRCBpcyB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZkFjY2Vzc0tleUlkU2VjcmV0UmVmIHtcbiAgLyoqXG4gICAqIEEga2V5IGluIHRoZSByZWZlcmVuY2VkIFNlY3JldC5cbiAgICogU29tZSBpbnN0YW5jZXMgb2YgdGhpcyBmaWVsZCBtYXkgYmUgZGVmYXVsdGVkLCBpbiBvdGhlcnMgaXQgbWF5IGJlIHJlcXVpcmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmQWNjZXNzS2V5SWRTZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZihvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZBY2Nlc3NLZXlJZFNlY3JldFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBUaGUgU2VjcmV0QWNjZXNzS2V5IGlzIHVzZWQgZm9yIGF1dGhlbnRpY2F0aW9uXG4gKlxuICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBBIGtleSBpbiB0aGUgcmVmZXJlbmNlZCBTZWNyZXQuXG4gICAqIFNvbWUgaW5zdGFuY2VzIG9mIHRoaXMgZmllbGQgbWF5IGJlIGRlZmF1bHRlZCwgaW4gb3RoZXJzIGl0IG1heSBiZSByZXF1aXJlZC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2VjcmV0QWNjZXNzS2V5U2VjcmV0UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWVzcGFjZSBvZiB0aGUgU2VjcmV0IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKiBJZ25vcmVkIGlmIHJlZmVyZW50IGlzIG5vdCBjbHVzdGVyLXNjb3BlZCwgb3RoZXJ3aXNlIGRlZmF1bHRzIHRvIHRoZSBuYW1lc3BhY2Ugb2YgdGhlIHJlZmVyZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYjbmFtZXNwYWNlXG4gICAqL1xuICByZWFkb25seSBuYW1lc3BhY2U/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZlNlY3JldEFjY2Vzc0tleVNlY3JldFJlZihvYmo6IFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZWNyZXRBY2Nlc3NLZXlTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIFNlc3Npb25Ub2tlbiB1c2VkIGZvciBhdXRoZW50aWNhdGlvblxuICogVGhpcyBtdXN0IGJlIGRlZmluZWQgaWYgQWNjZXNzS2V5SUQgYW5kIFNlY3JldEFjY2Vzc0tleSBhcmUgdGVtcG9yYXJ5IGNyZWRlbnRpYWxzXG4gKiBzZWU6IGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9JQU0vbGF0ZXN0L1VzZXJHdWlkZS9pZF9jcmVkZW50aWFsc190ZW1wX3VzZS1yZXNvdXJjZXMuaHRtbFxuICpcbiAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYge1xuICAvKipcbiAgICogQSBrZXkgaW4gdGhlIHJlZmVyZW5jZWQgU2VjcmV0LlxuICAgKiBTb21lIGluc3RhbmNlcyBvZiB0aGlzIGZpZWxkIG1heSBiZSBkZWZhdWx0ZWQsIGluIG90aGVycyBpdCBtYXkgYmUgcmVxdWlyZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aElhbVNlY3JldFJlZlNlc3Npb25Ub2tlblNlY3JldFJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2Ugb2YgdGhlIFNlY3JldCByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1ZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhJYW1TZWNyZXRSZWZTZXNzaW9uVG9rZW5TZWNyZXRSZWYob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSWFtU2VjcmV0UmVmU2Vzc2lvblRva2VuU2VjcmV0UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlcnZpY2UgYWNjb3VudCBmaWVsZCBjb250YWluaW5nIHRoZSBuYW1lIG9mIGEga3ViZXJuZXRlcyBTZXJ2aWNlQWNjb3VudC5cbiAqXG4gKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlblNlcnZpY2VBY2NvdW50UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuU2VydmljZUFjY291bnRSZWYge1xuICAvKipcbiAgICogQXVkaWVuY2Ugc3BlY2lmaWVzIHRoZSBgYXVkYCBjbGFpbSBmb3IgdGhlIHNlcnZpY2UgYWNjb3VudCB0b2tlblxuICAgKiBJZiB0aGUgc2VydmljZSBhY2NvdW50IHVzZXMgYSB3ZWxsLWtub3duIGFubm90YXRpb24gZm9yIGUuZy4gSVJTQSBvciBHQ1AgV29ya2xvYWQgSWRlbnRpdHlcbiAgICogdGhlbiB0aGlzIGF1ZGllbmNlcyB3aWxsIGJlIGFwcGVuZGVkIHRvIHRoZSBsaXN0XG4gICAqXG4gICAqIEBzY2hlbWEgVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuU2VydmljZUFjY291bnRSZWYjYXVkaWVuY2VzXG4gICAqL1xuICByZWFkb25seSBhdWRpZW5jZXM/OiBzdHJpbmdbXTtcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIFNlcnZpY2VBY2NvdW50IHJlc291cmNlIGJlaW5nIHJlZmVycmVkIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFZhdWx0RHluYW1pY1NlY3JldFNwZWNQcm92aWRlckF1dGhKd3RLdWJlcm5ldGVzU2VydmljZUFjY291bnRUb2tlblNlcnZpY2VBY2NvdW50UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZXNwYWNlIG9mIHRoZSByZXNvdXJjZSBiZWluZyByZWZlcnJlZCB0by5cbiAgICogSWdub3JlZCBpZiByZWZlcmVudCBpcyBub3QgY2x1c3Rlci1zY29wZWQsIG90aGVyd2lzZSBkZWZhdWx0cyB0byB0aGUgbmFtZXNwYWNlIG9mIHRoZSByZWZlcmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5TZXJ2aWNlQWNjb3VudFJlZiNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5TZXJ2aWNlQWNjb3VudFJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fVmF1bHREeW5hbWljU2VjcmV0U3BlY1Byb3ZpZGVyQXV0aEp3dEt1YmVybmV0ZXNTZXJ2aWNlQWNjb3VudFRva2VuU2VydmljZUFjY291bnRSZWYob2JqOiBWYXVsdER5bmFtaWNTZWNyZXRTcGVjUHJvdmlkZXJBdXRoSnd0S3ViZXJuZXRlc1NlcnZpY2VBY2NvdW50VG9rZW5TZXJ2aWNlQWNjb3VudFJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1ZGllbmNlcyc6IG9iai5hdWRpZW5jZXM/Lm1hcCh5ID0+IHkpLFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ25hbWVzcGFjZSc6IG9iai5uYW1lc3BhY2UsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cblxuLyoqXG4gKiBXZWJob29rIGNvbm5lY3RzIHRvIGEgdGhpcmQgcGFydHkgQVBJIHNlcnZlciB0byBoYW5kbGUgdGhlIHNlY3JldHMgZ2VuZXJhdGlvblxuY29uZmlndXJhdGlvbiBwYXJhbWV0ZXJzIGluIHNwZWMuXG5Zb3UgY2FuIHNwZWNpZnkgdGhlIHNlcnZlciwgdGhlIHRva2VuLCBhbmQgYWRkaXRpb25hbCBib2R5IHBhcmFtZXRlcnMuXG5TZWUgZG9jdW1lbnRhdGlvbiBmb3IgdGhlIGZ1bGwgQVBJIHNwZWNpZmljYXRpb24gZm9yIHJlcXVlc3RzIGFuZCByZXNwb25zZXMuXG4gKlxuICogQHNjaGVtYSBXZWJob29rXG4gKi9cbmV4cG9ydCBjbGFzcyBXZWJob29rIGV4dGVuZHMgQXBpT2JqZWN0IHtcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGFwaVZlcnNpb24gYW5kIGtpbmQgZm9yIFwiV2ViaG9va1wiXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEdWSzogR3JvdXBWZXJzaW9uS2luZCA9IHtcbiAgICBhcGlWZXJzaW9uOiAnZ2VuZXJhdG9ycy5leHRlcm5hbC1zZWNyZXRzLmlvL3YxYWxwaGExJyxcbiAgICBraW5kOiAnV2ViaG9vaycsXG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyBhIEt1YmVybmV0ZXMgbWFuaWZlc3QgZm9yIFwiV2ViaG9va1wiLlxuICAgKlxuICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGlubGluZSByZXNvdXJjZSBtYW5pZmVzdHMgaW5zaWRlIG90aGVyIG9iamVjdHMgKGUuZy4gYXMgdGVtcGxhdGVzKS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1hbmlmZXN0KHByb3BzOiBXZWJob29rUHJvcHMgPSB7fSk6IGFueSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLldlYmhvb2suR1ZLLFxuICAgICAgLi4udG9Kc29uX1dlYmhvb2tQcm9wcyhwcm9wcyksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgXCJXZWJob29rXCIgQVBJIG9iamVjdFxuICAgKiBAcGFyYW0gc2NvcGUgdGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIG9iamVjdFxuICAgKiBAcGFyYW0gaWQgYSBzY29wZS1sb2NhbCBuYW1lIGZvciB0aGUgb2JqZWN0XG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBXZWJob29rUHJvcHMgPSB7fSkge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgLi4uV2ViaG9vay5HVkssXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBvYmplY3QgdG8gS3ViZXJuZXRlcyBKU09OLlxuICAgKi9cbiAgcHVibGljIHRvSnNvbigpOiBhbnkge1xuICAgIGNvbnN0IHJlc29sdmVkID0gc3VwZXIudG9Kc29uKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uV2ViaG9vay5HVkssXG4gICAgICAuLi50b0pzb25fV2ViaG9va1Byb3BzKHJlc29sdmVkKSxcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogV2ViaG9vayBjb25uZWN0cyB0byBhIHRoaXJkIHBhcnR5IEFQSSBzZXJ2ZXIgdG8gaGFuZGxlIHRoZSBzZWNyZXRzIGdlbmVyYXRpb25cbiAqIGNvbmZpZ3VyYXRpb24gcGFyYW1ldGVycyBpbiBzcGVjLlxuICogWW91IGNhbiBzcGVjaWZ5IHRoZSBzZXJ2ZXIsIHRoZSB0b2tlbiwgYW5kIGFkZGl0aW9uYWwgYm9keSBwYXJhbWV0ZXJzLlxuICogU2VlIGRvY3VtZW50YXRpb24gZm9yIHRoZSBmdWxsIEFQSSBzcGVjaWZpY2F0aW9uIGZvciByZXF1ZXN0cyBhbmQgcmVzcG9uc2VzLlxuICpcbiAqIEBzY2hlbWEgV2ViaG9va1xuICovXG5leHBvcnQgaW50ZXJmYWNlIFdlYmhvb2tQcm9wcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIFdlYmhvb2sjbWV0YWRhdGFcbiAgICovXG4gIHJlYWRvbmx5IG1ldGFkYXRhPzogQXBpT2JqZWN0TWV0YWRhdGE7XG5cbiAgLyoqXG4gICAqIFdlYmhvb2tTcGVjIGNvbnRyb2xzIHRoZSBiZWhhdmlvciBvZiB0aGUgZXh0ZXJuYWwgZ2VuZXJhdG9yLiBBbnkgYm9keSBwYXJhbWV0ZXJzIHNob3VsZCBiZSBwYXNzZWQgdG8gdGhlIHNlcnZlciB0aHJvdWdoIHRoZSBwYXJhbWV0ZXJzIGZpZWxkLlxuICAgKlxuICAgKiBAc2NoZW1hIFdlYmhvb2sjc3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgc3BlYz86IFdlYmhvb2tTcGVjO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1dlYmhvb2tQcm9wcycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fV2ViaG9va1Byb3BzKG9iajogV2ViaG9va1Byb3BzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnbWV0YWRhdGEnOiBvYmoubWV0YWRhdGEsXG4gICAgJ3NwZWMnOiB0b0pzb25fV2ViaG9va1NwZWMob2JqLnNwZWMpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFdlYmhvb2tTcGVjIGNvbnRyb2xzIHRoZSBiZWhhdmlvciBvZiB0aGUgZXh0ZXJuYWwgZ2VuZXJhdG9yLiBBbnkgYm9keSBwYXJhbWV0ZXJzIHNob3VsZCBiZSBwYXNzZWQgdG8gdGhlIHNlcnZlciB0aHJvdWdoIHRoZSBwYXJhbWV0ZXJzIGZpZWxkLlxuICpcbiAqIEBzY2hlbWEgV2ViaG9va1NwZWNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBXZWJob29rU3BlYyB7XG4gIC8qKlxuICAgKiBCb2R5XG4gICAqXG4gICAqIEBzY2hlbWEgV2ViaG9va1NwZWMjYm9keVxuICAgKi9cbiAgcmVhZG9ubHkgYm9keT86IHN0cmluZztcblxuICAvKipcbiAgICogUEVNIGVuY29kZWQgQ0EgYnVuZGxlIHVzZWQgdG8gdmFsaWRhdGUgd2ViaG9vayBzZXJ2ZXIgY2VydGlmaWNhdGUuIE9ubHkgdXNlZFxuICAgKiBpZiB0aGUgU2VydmVyIFVSTCBpcyB1c2luZyBIVFRQUyBwcm90b2NvbC4gVGhpcyBwYXJhbWV0ZXIgaXMgaWdub3JlZCBmb3JcbiAgICogcGxhaW4gSFRUUCBwcm90b2NvbCBjb25uZWN0aW9uLiBJZiBub3Qgc2V0IHRoZSBzeXN0ZW0gcm9vdCBjZXJ0aWZpY2F0ZXNcbiAgICogYXJlIHVzZWQgdG8gdmFsaWRhdGUgdGhlIFRMUyBjb25uZWN0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIFdlYmhvb2tTcGVjI2NhQnVuZGxlXG4gICAqL1xuICByZWFkb25seSBjYUJ1bmRsZT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHByb3ZpZGVyIGZvciB0aGUgQ0EgYnVuZGxlIHRvIHVzZSB0byB2YWxpZGF0ZSB3ZWJob29rIHNlcnZlciBjZXJ0aWZpY2F0ZS5cbiAgICpcbiAgICogQHNjaGVtYSBXZWJob29rU3BlYyNjYVByb3ZpZGVyXG4gICAqL1xuICByZWFkb25seSBjYVByb3ZpZGVyPzogV2ViaG9va1NwZWNDYVByb3ZpZGVyO1xuXG4gIC8qKlxuICAgKiBIZWFkZXJzXG4gICAqXG4gICAqIEBzY2hlbWEgV2ViaG9va1NwZWMjaGVhZGVyc1xuICAgKi9cbiAgcmVhZG9ubHkgaGVhZGVycz86IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH07XG5cbiAgLyoqXG4gICAqIFdlYmhvb2sgTWV0aG9kXG4gICAqXG4gICAqIEBzY2hlbWEgV2ViaG9va1NwZWMjbWV0aG9kXG4gICAqL1xuICByZWFkb25seSBtZXRob2Q/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFJlc3VsdCBmb3JtYXR0aW5nXG4gICAqXG4gICAqIEBzY2hlbWEgV2ViaG9va1NwZWMjcmVzdWx0XG4gICAqL1xuICByZWFkb25seSByZXN1bHQ6IFdlYmhvb2tTcGVjUmVzdWx0O1xuXG4gIC8qKlxuICAgKiBTZWNyZXRzIHRvIGZpbGwgaW4gdGVtcGxhdGVzXG4gICAqIFRoZXNlIHNlY3JldHMgd2lsbCBiZSBwYXNzZWQgdG8gdGhlIHRlbXBsYXRpbmcgZnVuY3Rpb24gYXMga2V5IHZhbHVlIHBhaXJzIHVuZGVyIHRoZSBnaXZlbiBuYW1lXG4gICAqXG4gICAqIEBzY2hlbWEgV2ViaG9va1NwZWMjc2VjcmV0c1xuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0cz86IFdlYmhvb2tTcGVjU2VjcmV0c1tdO1xuXG4gIC8qKlxuICAgKiBUaW1lb3V0XG4gICAqXG4gICAqIEBzY2hlbWEgV2ViaG9va1NwZWMjdGltZW91dFxuICAgKi9cbiAgcmVhZG9ubHkgdGltZW91dD86IHN0cmluZztcblxuICAvKipcbiAgICogV2ViaG9vayB1cmwgdG8gY2FsbFxuICAgKlxuICAgKiBAc2NoZW1hIFdlYmhvb2tTcGVjI3VybFxuICAgKi9cbiAgcmVhZG9ubHkgdXJsOiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnV2ViaG9va1NwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1dlYmhvb2tTcGVjKG9iajogV2ViaG9va1NwZWMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdib2R5Jzogb2JqLmJvZHksXG4gICAgJ2NhQnVuZGxlJzogb2JqLmNhQnVuZGxlLFxuICAgICdjYVByb3ZpZGVyJzogdG9Kc29uX1dlYmhvb2tTcGVjQ2FQcm92aWRlcihvYmouY2FQcm92aWRlciksXG4gICAgJ2hlYWRlcnMnOiAoKG9iai5oZWFkZXJzKSA9PT0gdW5kZWZpbmVkKSA/IHVuZGVmaW5lZCA6IChPYmplY3QuZW50cmllcyhvYmouaGVhZGVycykucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KSksXG4gICAgJ21ldGhvZCc6IG9iai5tZXRob2QsXG4gICAgJ3Jlc3VsdCc6IHRvSnNvbl9XZWJob29rU3BlY1Jlc3VsdChvYmoucmVzdWx0KSxcbiAgICAnc2VjcmV0cyc6IG9iai5zZWNyZXRzPy5tYXAoeSA9PiB0b0pzb25fV2ViaG9va1NwZWNTZWNyZXRzKHkpKSxcbiAgICAndGltZW91dCc6IG9iai50aW1lb3V0LFxuICAgICd1cmwnOiBvYmoudXJsLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBwcm92aWRlciBmb3IgdGhlIENBIGJ1bmRsZSB0byB1c2UgdG8gdmFsaWRhdGUgd2ViaG9vayBzZXJ2ZXIgY2VydGlmaWNhdGUuXG4gKlxuICogQHNjaGVtYSBXZWJob29rU3BlY0NhUHJvdmlkZXJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBXZWJob29rU3BlY0NhUHJvdmlkZXIge1xuICAvKipcbiAgICogVGhlIGtleSB3aGVyZSB0aGUgQ0EgY2VydGlmaWNhdGUgY2FuIGJlIGZvdW5kIGluIHRoZSBTZWNyZXQgb3IgQ29uZmlnTWFwLlxuICAgKlxuICAgKiBAc2NoZW1hIFdlYmhvb2tTcGVjQ2FQcm92aWRlciNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIG9iamVjdCBsb2NhdGVkIGF0IHRoZSBwcm92aWRlciB0eXBlLlxuICAgKlxuICAgKiBAc2NoZW1hIFdlYmhvb2tTcGVjQ2FQcm92aWRlciNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lc3BhY2UgdGhlIFByb3ZpZGVyIHR5cGUgaXMgaW4uXG4gICAqXG4gICAqIEBzY2hlbWEgV2ViaG9va1NwZWNDYVByb3ZpZGVyI25hbWVzcGFjZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZXNwYWNlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdHlwZSBvZiBwcm92aWRlciB0byB1c2Ugc3VjaCBhcyBcIlNlY3JldFwiLCBvciBcIkNvbmZpZ01hcFwiLlxuICAgKlxuICAgKiBAc2NoZW1hIFdlYmhvb2tTcGVjQ2FQcm92aWRlciN0eXBlXG4gICAqL1xuICByZWFkb25seSB0eXBlOiBXZWJob29rU3BlY0NhUHJvdmlkZXJUeXBlO1xuXG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1dlYmhvb2tTcGVjQ2FQcm92aWRlcicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fV2ViaG9va1NwZWNDYVByb3ZpZGVyKG9iajogV2ViaG9va1NwZWNDYVByb3ZpZGVyIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICduYW1lc3BhY2UnOiBvYmoubmFtZXNwYWNlLFxuICAgICd0eXBlJzogb2JqLnR5cGUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogUmVzdWx0IGZvcm1hdHRpbmdcbiAqXG4gKiBAc2NoZW1hIFdlYmhvb2tTcGVjUmVzdWx0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgV2ViaG9va1NwZWNSZXN1bHQge1xuICAvKipcbiAgICogSnNvbiBwYXRoIG9mIHJldHVybiB2YWx1ZVxuICAgKlxuICAgKiBAc2NoZW1hIFdlYmhvb2tTcGVjUmVzdWx0I2pzb25QYXRoXG4gICAqL1xuICByZWFkb25seSBqc29uUGF0aD86IHN0cmluZztcblxufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdXZWJob29rU3BlY1Jlc3VsdCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fV2ViaG9va1NwZWNSZXN1bHQob2JqOiBXZWJob29rU3BlY1Jlc3VsdCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2pzb25QYXRoJzogb2JqLmpzb25QYXRoLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgV2ViaG9va1NwZWNTZWNyZXRzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgV2ViaG9va1NwZWNTZWNyZXRzIHtcbiAgLyoqXG4gICAqIE5hbWUgb2YgdGhpcyBzZWNyZXQgaW4gdGVtcGxhdGVzXG4gICAqXG4gICAqIEBzY2hlbWEgV2ViaG9va1NwZWNTZWNyZXRzI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogU2VjcmV0IHJlZiB0byBmaWxsIGluIGNyZWRlbnRpYWxzXG4gICAqXG4gICAqIEBzY2hlbWEgV2ViaG9va1NwZWNTZWNyZXRzI3NlY3JldFJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0UmVmOiBXZWJob29rU3BlY1NlY3JldHNTZWNyZXRSZWY7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnV2ViaG9va1NwZWNTZWNyZXRzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9XZWJob29rU3BlY1NlY3JldHMob2JqOiBXZWJob29rU3BlY1NlY3JldHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ3NlY3JldFJlZic6IHRvSnNvbl9XZWJob29rU3BlY1NlY3JldHNTZWNyZXRSZWYob2JqLnNlY3JldFJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbi8qKlxuICogVGhlIHR5cGUgb2YgcHJvdmlkZXIgdG8gdXNlIHN1Y2ggYXMgXCJTZWNyZXRcIiwgb3IgXCJDb25maWdNYXBcIi5cbiAqXG4gKiBAc2NoZW1hIFdlYmhvb2tTcGVjQ2FQcm92aWRlclR5cGVcbiAqL1xuZXhwb3J0IGVudW0gV2ViaG9va1NwZWNDYVByb3ZpZGVyVHlwZSB7XG4gIC8qKiBTZWNyZXQgKi9cbiAgU0VDUkVUID0gXCJTZWNyZXRcIixcbiAgLyoqIENvbmZpZ01hcCAqL1xuICBDT05GSUdfTUFQID0gXCJDb25maWdNYXBcIixcbn1cblxuLyoqXG4gKiBTZWNyZXQgcmVmIHRvIGZpbGwgaW4gY3JlZGVudGlhbHNcbiAqXG4gKiBAc2NoZW1hIFdlYmhvb2tTcGVjU2VjcmV0c1NlY3JldFJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFdlYmhvb2tTcGVjU2VjcmV0c1NlY3JldFJlZiB7XG4gIC8qKlxuICAgKiBUaGUga2V5IHdoZXJlIHRoZSB0b2tlbiBpcyBmb3VuZC5cbiAgICpcbiAgICogQHNjaGVtYSBXZWJob29rU3BlY1NlY3JldHNTZWNyZXRSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBTZWNyZXQgcmVzb3VyY2UgYmVpbmcgcmVmZXJyZWQgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgV2ViaG9va1NwZWNTZWNyZXRzU2VjcmV0UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnV2ViaG9va1NwZWNTZWNyZXRzU2VjcmV0UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBxdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9XZWJob29rU3BlY1NlY3JldHNTZWNyZXRSZWYob2JqOiBXZWJob29rU3BlY1NlY3JldHNTZWNyZXRSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIHF1b3RlLXByb3BzICovXG5cbiJdfQ==